package com.greenlightplanet.kazi.liteFseProspective.view.activity.adapter


import android.content.Context
import android.content.Intent
import android.graphics.Color
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.greenlightplanet.kazi.databinding.ProspectiveListItemBinding
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import com.greenlightplanet.kazi.liteFseProspective.view.activity.MapsCheckActivity
import org.jetbrains.annotations.NotNull


class VerificationAdapter(val context: Context, var list: List<LiteFseProspectResponseModel>) :
    RecyclerView.Adapter<VerificationAdapter.ViewHolder>() {

    var verificationAdapterCallback: VerificationAdapterCallback? = null


    override fun onCreateViewHolder(@NotNull p0: ViewGroup, viewType: Int): ViewHolder {
        val itemBinding =
            ProspectiveListItemBinding.inflate(LayoutInflater.from(p0.context), p0, false)
        return ViewHolder(itemBinding)
    }


    private fun stsHandler(data: LiteFseProspectResponseModel): String {
        var revisedStatus = "NA"
        data.statusUpdateObjects!!.forEach { sts ->
            if (data.status!!.equals(sts.status, true)) {
                revisedStatus = sts.showCaseName!!
            }
        }
        return revisedStatus
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val data = list.get(position)
        holder.bind(
            data,
            holder.itemView
        )
    }

    inner class ViewHolder(val itemBinding: ProspectiveListItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(data: LiteFseProspectResponseModel, itemView: View) {
            itemBinding.tvCustomerName.text = data.name
            itemBinding.tvProductName.text = data.productName
            itemBinding.tvCurrentStatus.text = stsHandler(data)

            if (data.latitude == null && data.longitude == null) {
                itemBinding.btnMap.visibility = View.INVISIBLE
            } else {
                if (data.latitude == 0.0 && data.longitude == 0.0) {
                    itemBinding.btnMap.visibility = View.INVISIBLE
                } else {
                    itemBinding.btnMap.visibility = View.VISIBLE
                }

            }

            itemBinding.btnMap.setOnClickListener {
                val intent = Intent(context, MapsCheckActivity::class.java)
                intent.putExtra("LAT", data.latitude)
                intent.putExtra("LONG", data.longitude)
                intent.putExtra("NAME", data.name)
                context.startActivity(intent)
            }

            if (!data.approved) {
                itemBinding.tvCurrentStatus.setTextColor(Color.RED)
            } else {
                itemBinding.tvCurrentStatus.setTextColor(Color.BLACK)
            }

            itemView.setOnClickListener {
                verificationAdapterCallback?.onTapped(position, data)
            }

            if (data.errorOccurred) {
                itemBinding.ivError.visibility = View.VISIBLE
            } else {
                itemBinding.ivError.visibility = View.GONE
            }


        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    interface VerificationAdapterCallback {

        fun onTapped(position: Int, value: LiteFseProspectResponseModel)

    }

}
