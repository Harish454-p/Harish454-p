package com.greenlightplanet.kazi.incentivenew.adapter

import android.graphics.Color
import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.Keep
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.RecyclerItemProductGroupBinding
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.Content
import com.greenlightplanet.kazi.utils.Util
import timber.log.Timber
import java.lang.ref.WeakReference

@Keep
class CollectionBreakdownAdapter() : RecyclerView.Adapter<CollectionBreakdownAdapter.ViewHolder>() {

    lateinit var binding: RecyclerItemProductGroupBinding
    var dataList = mutableListOf<Content>()
    lateinit var listener: WeakReference<AdapterClickListener>
    val TAG = "AmountCollectedAdapter"
    var isPagination = false

    fun setRvData(list: List<Content>, isPaging: Boolean = false) {
        isPagination = isPaging
        Timber.d("Adapter: AdapterList -> $list")
        dataList.addAll(list)
        Timber.d("$TAG: New updated AdapterList -> $dataList")
        notifyDataSetChanged()

    }

    fun clearRvData() {
        dataList.clear()
        Timber.d("$TAG: AdapterList Cleared ")
        notifyDataSetChanged()

    }

    fun attachListener(clickListener: WeakReference<AdapterClickListener>) {
        listener = clickListener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        binding = RecyclerItemProductGroupBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (dataList.isNotEmpty()) {
            holder.bind(dataList[position])
        }

    }

    override fun getItemCount(): Int = dataList.size

    inner class ViewHolder(val binding: RecyclerItemProductGroupBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(holdingData: Content) {
            if (isPagination) {
                binding.tvProductName.text = (holdingData.accountNumber ?: "NA").toString()
                val mm = holdingData.totalAmountCollected ?: 0
                binding.tvTotalCollection.text = Util.formatAmount(mm.toDouble())
                if (holdingData.commissionPercentage != null) {
                    binding.tvCommissionPercentage.text = "${holdingData.commissionPercentage}%"
                } else {
                    binding.tvCommissionPercentage.text = "NA"
                }
                val aa = holdingData.commission?:0
                binding.tvCommission.text = Util.formatAmount(aa.toDouble())
//                binding.tvCommission.text = (holdingData.commission ?: "NA").toString()
//                Timber.d("$TAG: Bind Item -> $holdingData")
            } else {
                binding.tvProductName.text = (holdingData.productGroup ?: "NA").toString()
                val mm = holdingData.totalCollection ?: 0
                binding.tvTotalCollection.text = Util.formatAmount(mm.toDouble())
//                    textCleanUp((holdingData.totalCollection ?: "NA").toString())
                if (holdingData.commissionPercentage != null) {
                    binding.tvCommissionPercentage.text = "${holdingData.commissionPercentage}%"
                } else {
                    binding.tvCommissionPercentage.text = "NA"
                }
                val aa = holdingData.commission?:0
                binding.tvCommission.text = Util.formatAmount(aa.toDouble())
//                (holdingData.commission ?: "NA").toString()
                addUnderline(binding.tvCommission)
//                Timber.d("$TAG: Bind Item -> $holdingData")
            }
            binding.tvCommission.setOnClickListener {
                if (!isPagination) {
                    Timber.d("$TAG: tvCommission clickkkk $holdingData")
                    listener.get()?.onItemClicked(holdingData)
                }
            }

        }
    }


    fun addUnderline(textView: TextView) {
        textView.paintFlags = Paint.UNDERLINE_TEXT_FLAG
        textView.setTextColor(Color.BLUE)
    }

    fun textCleanUp(type: String): String {
        val newStr = type.trim().replace("_", " ")
        Timber.d("CLeanedUp Text: New: $newStr || Old : $type")
        return newStr
    }

}

@Keep
interface AdapterClickListener {
    fun onItemClicked(data: Content)
}
