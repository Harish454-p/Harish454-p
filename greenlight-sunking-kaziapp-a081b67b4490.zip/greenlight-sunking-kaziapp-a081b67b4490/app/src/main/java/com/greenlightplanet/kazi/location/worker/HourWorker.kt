package com.greenlightplanet.kazi.location.worker

import android.content.Context
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.greenlightplanet.kazi.location.extras.PermissionUtils
import com.greenlightplanet.kazi.location.extras.FunctionalUtils
import com.greenlightplanet.kazi.location.model.LocationRequestModel
import com.greenlightplanet.kazi.location.model.LocationResponseModel
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers


class HourWorker(val context: Context, workerParams: WorkerParameters) : Worker(context, workerParams) {

    companion object {
        public const val TAG = "HourWorker"

    }

    private val bag = CompositeDisposable()

    private var localDb: AppDatabase? = null

    var preference: GreenLightPreference? = null

    override fun doWork(): Result {

        localDb = AppDatabase.getAppDatabase(context)

        preference = GreenLightPreference.getInstance(context)
        performWork(context)

        return Result.success()
    }


    private fun performWork(context: Context) {

        if (PermissionUtils.checkLocationPermission(context) && PermissionUtils.checkImeiPermission(context)) { //&& ((preference?.getLastCalledWorkManager()!!.plus(3600000 * 2)) <= (System.currentTimeMillis()))) {

            Log.d(TAG, "Step = 1 --> CheckPermission-Success: Thread = ${Thread.currentThread().id}")

            //bag.add(
            //Requesting current location from RxLocation Lib
            FunctionalUtils.getLocation12(context, preference?.getLoginResponseModel()?.angazaId
                    ?: "", bag)
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .flatMapCompletable { generatedModel: LocationRequestModel ->
                        //Generated LocationRequestModel with CurrentLocation
                        Log.d(
                                TAG,
                                "Step = 2 --> gotCurrentLocation-Success: Thread = ${Thread.currentThread().id}"
                        )

                        insertCurrentLocationToDb(generatedModel)

                    }.doOnError {
                        Log.d(
                                TAG, "Step = 2 --> gotCurrentLocation-Error: ${it.localizedMessage}\n" +
                                "Thread : ${Thread.currentThread().id}"
                        )
                    }.doOnSubscribe {
                        bag.add(it)
                    }
                    .doFinally {
                        Log.d(TAG, "doFinally: dispose");
                        bag.clear()
                    }
                    .subscribe()
            //)
        } else {
            Log.d(TAG, "Step = 1 --> CheckPermission-Error: Thread = ${Thread.currentThread().id}")
            bag.clear()
        }

    }


    private fun insertCurrentLocationToDb(currentLocationRequestModel: LocationRequestModel): Completable? {

        return Completable.fromAction { localDb!!.locationRequestDao().insert(currentLocationRequestModel) }
                .doOnComplete {

                    //Insertion of new LocationRequestModel Completed
                    Log.d(
                            TAG,
                            "Step = 3 --> insertCurrentLocationToDb-Success: Thread = ${Thread.currentThread().id}"
                    )

                    //Check If Internet is Connected
                    //Yes - Then first getAllLocationRequests From Db and Then send the request to Server
                    //No - Clear the bag
                    if (FunctionalUtils.isNetworkConnected(context)) {

                        //Get All Location Request From Database
                        getAllLocationRequestFromDb().subscribe({},
                                {
                                    Log.d(
                                            TAG, "Step = 4 --> getAllLocationRequestFromDb-Error: ${it.localizedMessage}\n" +
                                            "Thread : ${Thread.currentThread().id}"
                                    )
                                })

                    } else {
                        //Clearing the bag
                        bag.clear()
                    }


                }.doOnError {
                    Log.d(
                            TAG, "Step = 3 --> insertCurrentLocationToDb-Error: ${it.localizedMessage}\n" +
                            "Thread : ${Thread.currentThread().id}"
                    )
                }

    }


    private fun getAllLocationRequestFromDb(): Single<LocationResponseModel> {

        return localDb!!.locationRequestDao().getAll()
                .flatMap { locationRequestModels: List<LocationRequestModel> ->

                    Log.d(
                            TAG, "Step = 4 --> getAllLocationRequestFromDb-Success: Thread = ${Thread.currentThread().id}"
                    )

                    val millisInHour = 3600000L

                    val sortedList = locationRequestModels.sortedBy { it.deviceTimeMilli }

                    val finalList = mutableListOf<LocationRequestModel>()

                    sortedList.forEachIndexed  { index, locationRequestModel ->

                        if (index > 0) {

                            val diffInMillis = sortedList.get(index).deviceTimeMilli - sortedList.get(index - 1).deviceTimeMilli

                            if (diffInMillis >= millisInHour) {
                                finalList.add(locationRequestModel)

                                //for test
                                Log.d(TAG, """:Greater then hour
                                        index:$index,
                                        current.deviceTimeMilli:${sortedList.get(index).deviceTimeMilli}
                                        last.deviceTimeMilli:${sortedList.get(index - 1).deviceTimeMilli}
                                        diffInMillis:$diffInMillis
                                        """);
                            } else {

                                //for test
                                Log.d(TAG, """:Not greater then hour
                                        index:$index,
                                        current.deviceTimeMilli:${sortedList.get(index).deviceTimeMilli}
                                        last.deviceTimeMilli:${sortedList.get(index - 1).deviceTimeMilli}
                                        diffInMillis:$diffInMillis
                                        """); }

                        } else {
                            Log.d(TAG, "locationRequestModel.deviceTimeMilli:${locationRequestModel.deviceTimeMilli} ");
                            Log.d(TAG, "preference?.getLastCalledWorkManager():${preference?.getLastCalledWorker()} ");
                            //val abc = locationRequestModel.deviceTimeMilli - preference?.getLastCalledWorkManager()!!
                            /*if (abc >= millisInHour) {
                                finalList.add(locationRequestModel)
                            }*/
                        }

                    }

                    //Send All Location Request From Db to Server
                    //sendAllLocationToServer(locationRequestModels)
                    sendAllLocationToServer(finalList)

                }.doOnError {
                    Log.d(
                            TAG, "Step = 4 --> getAllLocationRequestFromDb-Error: ${it.localizedMessage}\n" +
                            "Thread : ${Thread.currentThread().id}"
                    )
                }
    }


    private fun sendAllLocationToServer(modelList: List<LocationRequestModel>): Single<LocationResponseModel> {

        return ServiceInstance.getInstance(context).service?.sendLocation(modelList)!!
                .doOnSuccess {

                    Log.d(
                            TAG,
                            "Step = 5 --> sendAllLocationToServer-Success: Thread = ${Thread.currentThread().id}"
                    )
//                    preference?.setLastCalledWorkManager(modelList.last().deviceTimeMilli)

                    //Delete all Location Request
                    bag.add(
                            deleteAllLocationRequest()
                    )

                }.doOnError {

                    Log.d(
                            TAG,
                            "Step = 5 --> sendAllLocationToServer-Error: ${it.localizedMessage}\n" + "Thread : ${Thread.currentThread().id}"
                    )
                }

    }


    private fun deleteAllLocationRequest(): Disposable {

        return Completable.fromAction { localDb!!.locationRequestDao().deleteAll() }
                .subscribe({
                    //onCompleted

                    Log.d(
                            TAG,
                            "Step = 6 --> deleteAllLocationRequest-Success: Thread = ${Thread.currentThread().id}"
                    )

                    bag.clear()

                }, {
                    //onError

                    Log.d(
                            TAG,
                            "Step = 6 --> deleteAllLocationRequest-Error: ${it.localizedMessage}\n" + "Thread : ${Thread.currentThread().id}"
                    )
                    bag.clear()

                })

    }

    override fun onStopped() {
        Log.d(TAG, "Stopped: ")
        bag.clear()
        super.onStopped()

    }


}
