package com.greenlightplanet.kazi.fseProspective.view.activity

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import android.util.Log
import android.view.MenuItem
import android.widget.Toast
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.activity.DashBoardActivity
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityProspectiveBinding
import com.greenlightplanet.kazi.fseProspective.extras.AmazonS3Helper
import com.greenlightplanet.kazi.fseProspective.model.AwsImageModel
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseModel
import com.greenlightplanet.kazi.fseProspective.view.activity.adapter.ProspectivePagerAdapter
import com.greenlightplanet.kazi.fseProspective.viewmodel.ProspectiveViewModel
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.SetDateDialog
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener

class ProspectiveActivity : BaseActivity(), AmazonS3Helper.AmazonS3HelperCallback {

    public val TAG = "ProspectiveActivity"

    var amazonS3Helper: AmazonS3Helper? = AmazonS3Helper(this)
    var viewPagerAdapter: ProspectivePagerAdapter? = null
    lateinit var viewModel: ProspectiveViewModel
    var loginResponseData: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    var viewpagerAdapterList = mutableListOf<FseProspectResponseModel>()
    var isFromNotification = false
    private var allowedDistance: Int = 0
	var mHomeWatcher: HomeWatcher? = null
    private lateinit var binding: ActivityProspectiveBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_prospective)
        binding = ActivityProspectiveBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProviders.of(this).get(ProspectiveViewModel::class.java)
        preference = GreenLightPreference.getInstance(this)
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        if (intent.hasExtra("fromNotification")) {
            isFromNotification = intent.getBooleanExtra("fromNotification", false)
        }

        Util.setToolbar(this, toolbar)

        binding.tablay.setupWithViewPager(binding.viewPager2)

        initialize()
        clickHandler()

		mHomeWatcher = HomeWatcher(this)
		mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
			override fun onHomePressed() {
				finish()
			}
		})
		mHomeWatcher!!.startWatch()
    }

    private fun clickHandler() {

        binding.ivSync.setOnClickListener {
            performSyncStep1()
        }
    }

    fun initialize() {

        amazonS3Helper?.initializer()
        amazonS3Helper?.amazonS3HelperCallback = this
        loginResponseData = preference?.getLoginResponseModel()

    }

    override fun onResume() {
        super.onResume()

        if (Util.getDate().equals(preference?.getServerDate())) {
            //isTimeAutomatic(context) == true &&
            supportFragmentManager.findFragmentByTag("SETDATE")?.let {
                (it as SetDateDialog).dismiss()
            }

        } else {
            val fm = supportFragmentManager
            val custom = SetDateDialog();
            if (fm != null) {
                fm.findFragmentByTag("SETDATE")?.let {
                    (it as SetDateDialog).dismiss()
                }
                custom.show(fm, "SETDATE")
                custom.isCancelable = false
            }
        }
        showProgressDialog(this)
        viewModel!!.getRXVersion().observe(this, Observer {
            if (it.success) {

                if (it.responseData!!.appVersionCode!! > BuildConfig.VERSION_CODE) {
                    if (it.responseData!!.isForceUpdate!!) {
                        cancelProgressDialog()
                        Util.customFseRationaleDialog(this, "",
                            hideNegative = true,
                            titleSpanned = null,
                            hideTitle = true,
                            setCanceledOnTouchOutside = false,
                            setCancelable = false,
                            message = "Please update your App to use this Module.",
                            positveSelected = {
                                it.dismiss()
                                val intent = Intent(this, DashBoardActivity::class.java)
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                startActivity(intent)
                                finish()
                            },
                            negativeSeleted = {
                                it.dismiss()
                            }
                        )
                    } else {
                        cancelProgressDialog()
                        callApiLogic(viewModel)
                    }
                } else {
                    cancelProgressDialog()
                    callApiLogic(viewModel)
                }

            } else {
                cancelProgressDialog()
                callApiLogic(viewModel)
            }
        })


    }

    fun callApiLogic(viewModel: ProspectiveViewModel){
        viewModel.getFseProspective(this, loginResponseData?.angazaId!!, showProgress = {
            showProgressDialog(this)
        })?.observe(this, Observer { data ->
            cancelProgressDialog()
            data?.let {
                if (data.success) {
                    allowedDistance = it.responseData?.allowedDistance ?: 0
                    setSyncedColor(it.responseData!!.prospects!!)
                    setAdapter(it.responseData!!.prospects!!)
                } else {
                    //Util.showToast(data.error!!.messageToUser, this)
                    setAdapter(listOf<FseProspectResponseModel>())
                }
                binding.tvLastSavedP.text = "${getString(R.string.last_saved_key)} ${preference?.getFseProspectLastSynced()}"
            }
        })
    }

    fun setAdapter(list: List<FseProspectResponseModel>) {
        viewpagerAdapterList.clear()
        viewpagerAdapterList.addAll(list)
        if (viewPagerAdapter == null) {

            viewPagerAdapter = ProspectivePagerAdapter(this, supportFragmentManager, viewpagerAdapterList, allowedDistance)
            binding.viewPager2.adapter = viewPagerAdapter

        } else {

            binding.viewPager2.adapter?.notifyDataSetChanged()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item?.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }


    override fun onBackPressed() {
        if (isFromNotification) {

            val intent = Intent(this, DashBoardActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        } else {

            super.onBackPressed()
        }
    }

    fun performSyncStep1() {
        //showProgresss
        if (Util.isOnline(this)) {

            Log.d(TAG, "abc1: ");
            showProgressDialog(this)
            viewModel.getAwsImageModelsFromDatabase().observe(this, Observer { awsModels ->

                Log.d(TAG, "abc2: ");
                val validToUpload = awsModels?.filter {
                    !it.uploadedToAws &&
                            !it.uploadedToGLPServer &&
                            !it.fileUri.isNullOrEmpty()
                }

                if (validToUpload.isNullOrEmpty()) {
                    Log.d(TAG, "abc3: ");
                    cancelProgressDialog()
                    //start step 2
                    viewModel.getAllInOne(showProgress = {
                        //if (!isProgressShowing()) {
                        showProgressDialog(this)
                        //}
                    }).observe(this@ProspectiveActivity, Observer {
                        Log.d(TAG, "abc4: ");

                        Log.d(TAG, "syncData:$it ");
                        if (it != null) {

                            Log.d(TAG, "abc5: ");

                            viewModel.alpha(it).observe(this@ProspectiveActivity, Observer {

                                Log.d(TAG, "abc6: ");
                                cancelProgressDialog()

                                if (it!!.success) {
                                    Log.d(TAG, "abc7: ");
                                    Util.showToast(getString(R.string.sync_successful), this)
                                } else {
                                    Log.d(TAG, "abc8: ");
                                    Util.showToast(it.error!!.messageToUser, this)
                                }
                                onResume()
                            })

                        } else {
                            Log.d(TAG, "abc9: ");
                            cancelProgressDialog()
                            onResume()
                        }

//                        onResume()
                    })

                } else {
                    Log.d(TAG, "abc10: ");
//                    amazonS3Helper?.startUploadProcess(validToUpload, true)

					if(preference?.getAwsAccess().isNullOrEmpty() ||  preference?.getAwsSecret().isNullOrEmpty()){
						viewModel.awsRX(this, BaseRequestModel().apply {
							this.angazaId = loginResponseData?.angazaId
							this.country = loginResponseData?.country
						}).observe(this, Observer {

							if (it == null || it.Success == false || it.ResponseData?.accessKey.isNullOrEmpty() || it.ResponseData?.secretKey.isNullOrEmpty()) {
								Util.customFseCompletionDialog(
										context = this,
										hideTitle = true,
										title = null,
										message = getString(R.string.unable_to_upload_image),
										okSelected = {
											it.dismiss()
										}
								)
							} else {
								preference?.setAwsAccess(it.ResponseData?.accessKey!!)
								preference?.setAwsSecret(it.ResponseData?.secretKey!!)
								amazonS3Helper?.startUploadProcess(validToUpload, true)
							}
						})
					}else{
						amazonS3Helper?.startUploadProcess(validToUpload, true)
					}
                }

            })
        } else {
            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_LONG).show()
        }

    }

    private fun setSyncedColor(fseProspectResponseModels: List<FseProspectResponseModel>) {

        if (fseProspectResponseModels.filterNot { it.errorOccurred }?.filter { it.isChanged }?.size!! > 0) {

            val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
            DrawableCompat.setTint(backgroundDrawable!!, Color.RED)
            binding.ivSyncColor.setImageDrawable(backgroundDrawable)

        } else {

            val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
            DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
            binding.ivSyncColor.setImageDrawable(backgroundDrawable)
        }
    }

    override fun onAllUploadCompleted(fileModelsList: List<AwsImageModel>) {

        val isOnline = Util.isOnline(this)

        Log.d(TAG, "Happend:1a ");

        fileModelsList.forEach { it.tried = false }


        Log.d(TAG, "onAllUploadCompleted:fileModelsList = $fileModelsList ");

        if (isOnline) {

            Log.d(TAG, "Happend:1b ");


            viewModel.insertAwsImageModelToDatabase(fileModelsList, true).observe(this, Observer { savedAwsImageModels ->

                Log.d(TAG, "Happend:1 ");

                savedAwsImageModels?.let {
                    val awsImageModels = savedAwsImageModels.filter {
                        !it.awsLink.isNullOrEmpty()
                    }

                    viewModel.getInstallationRequestModelFromDatabaseById(awsImageModels).observe(this, Observer {

                        Log.d(TAG, "Happend: ");

                        viewModel.getAllInOne(showProgress = {
                            if (!isProgressShowing()) {
                                showProgressDialog(this)
                            }

                        }).observe(this@ProspectiveActivity, Observer {

                            if (it != null) {
                                viewModel.alpha(it).observe(this@ProspectiveActivity, Observer {

                                    cancelProgressDialog()

                                    if (it!!.success) {
                                        Util.showToast(getString(R.string.sync_successful), this)

                                    } else {
                                        Util.showToast(it.error!!.messageToUser, this)
                                    }

                                    onResume()
                                })

                            } else {
                                cancelProgressDialog()
                            }

                        })

                    })

                }

            })

        }

    }

    override fun onDestroy() {
        super.onDestroy()
        //AmazonS3Helper.destroy()
        amazonS3Helper?.amazonS3HelperCallback = null
        amazonS3Helper = null
		mHomeWatcher?.stopWatch();

	}

}
