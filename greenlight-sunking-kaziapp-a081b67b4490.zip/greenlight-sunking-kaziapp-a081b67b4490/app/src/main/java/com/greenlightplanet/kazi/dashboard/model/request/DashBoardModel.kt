package com.greenlightplanet.kazi.dashboard.model.request

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import com.google.gson.annotations.SerializedName

@Parcelize
@Entity(tableName = "%s")
data class DashBoardModel(
    @ColumnInfo(name = "angazaId")
    @SerializedName("angazaId")
    val angazaId: String,
    @ColumnInfo(name = "imei")
    @SerializedName("imei")
    val imei: String,
    @ColumnInfo(name = "territory")
    @SerializedName("territory")
    var territory:String,
    @ColumnInfo(name = "versionCode")
    @SerializedName("versionCode")
    val versionCode: Int
) : Parcelable
