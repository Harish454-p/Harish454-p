package com.greenlightplanet.kazi.incentive.starclubrepo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.heroboard.extras.LeaderBoardUtil
import com.greenlightplanet.kazi.incentive.model.StarClubResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import io.reactivex.Completable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

class StarClubRepo(val context: Context) {

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null

    companion object :
            SingletonHolderUtil<StarClubRepo, Context>(::StarClubRepo) {
        val TAG = "StarClubRepo"
    }

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
        } catch (e: Exception) {
            Log.d(TAG, ":Error ")
        }
    }


    fun getStarClub(context: Context, angazaId: String): MutableLiveData<NewCommonResponseModel<StarClubResponseModel>> {

        val data = MutableLiveData<NewCommonResponseModel<StarClubResponseModel>>()
        if (LeaderBoardUtil.isNetworkConnected(context = context)) {
            bag.add(
                    ServiceInstance.getInstance(context).service?.getStarClub(angazaId)!!.retry(3)
                    !!.subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                              Log.e(TAG, "API-Success: ${it.responseData}")
                                Log.e("responseData",""+it.responseData.toString())

                                InsertAllStarClub(data, it.responseData!!)
                            }, { t ->
                                Log.e(TAG, "API-Error3: ${t.localizedMessage}")
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )
            return data
        } else {
            bag.add(
                    localDb?.starClubDao()?.getAllStartClubData()!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                data.postValue(NewCommonResponseModel(
                                        responseData = it, success = true
                                ))
                            }, {
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )

            return data
        }
    }


    private fun InsertAllStarClub(liveData: MutableLiveData<NewCommonResponseModel<StarClubResponseModel>>,
                                            responseData: StarClubResponseModel): Disposable {
        return Completable.fromAction {
            localDb?.starClubDao()?.deleteAll()
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Deletion:Completed ")
                    localDb?.let {
                        bag.add(
                                Completable.fromAction {
                                    it.starClubDao().insertAll(responseData)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = responseData,
                                                    success = true
                                            ))
                                            Log.d(TAG, "Insertion:Completed ")

                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = null, success = false
                                            ))
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }



    fun onDestroy() {
        bag.clear()
    }

}
