package com.greenlightplanet.kazi.fseProspective.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


@Parcelize
@Entity(tableName = "RegistrationCheckinRequest")
data class RegistrationCheckinRequestModel(
        @PrimaryKey
        @ColumnInfo(name = "prospectId")
        @SerializedName("prospectId")
        var prospectId: String, // PP12345
        @ColumnInfo(name = "angazaId")
        @SerializedName("angazaId")
        var angazaId: String?, // US00001
        @ColumnInfo(name = "checkinTime")
        @SerializedName("checkinTime")
        var checkinTime: String?, // 2019-12-23 12:35:43
        @ColumnInfo(name = "latitude")
        @SerializedName("latitude")
        var latitude: String?, // 29.0001
        @ColumnInfo(name = "longitude")
        @SerializedName("longitude")
        var longitude: String?, // 12.0001
        @ColumnInfo(name = "area")
        @SerializedName("area")
        var area: String?, // area

        @ColumnInfo(name = "accuracy")
        @SerializedName("accuracy")
        var accuracy: String?, // "123.12"

        @ColumnInfo(name = "country")
        @SerializedName("country")
        var country: String // Uganda

) : Parcelable
