package com.greenlightplanet.kazi.incentivenew.repo

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.heroboard.extras.LeaderBoardUtil
import com.greenlightplanet.kazi.incentivenew.model.deduction.DeductionResponseData
import com.greenlightplanet.kazi.incentivenew.model.earning.EarningResponseData
import com.greenlightplanet.kazi.incentivenew.model.incentive.AgentIncentiveResponseData
import com.greenlightplanet.kazi.incentivenew.model.reffrel.AgentReffedResponseData
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryResponseData
import com.greenlightplanet.kazi.incentivenew.model.tvinstallation.Incentive_TvInstallation
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import io.reactivex.Completable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

class IncentiveRepo(val context: Context) {

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null

    companion object :
            SingletonHolderUtil<IncentiveRepo, Context>(::IncentiveRepo) {
        val TAG = "IncentiveRepo"
    }

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
        } catch (e: Exception) {
            Log.d(TAG, ":Error ")
        }
    }
    // summary

    fun getSummaryData(context: Context, angazaId: String?): MutableLiveData<NewCommonResponseModel<SummaryResponseData>> {
        val data = MutableLiveData<NewCommonResponseModel<SummaryResponseData>>()
        if (LeaderBoardUtil.isNetworkConnected(context = context)) {
            bag.add(
                    ServiceInstance.getInstance(context).service?.getSummaryDataAgentIncentive(angazaId)
                    !!.subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.e(TAG, "API-Success: ${it.responseData}")
                                Log.e("responseData", "" + it.responseData.toString())
                                data.postValue(it)

                                if (!it.responseData?.area.isNullOrBlank()){
                                    it.responseData?.let { it1 -> InsertAllSummaryData(data, it1) }
                                }
                            }, { t ->
                                Log.e(TAG, "API-Error3: ${t.localizedMessage}")
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )
            return data
        } else {

            bag.add(

                    localDb?.incentiveSummaryDao()?.getAllSummaryData()!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                data.postValue(NewCommonResponseModel(
                                        responseData = it, success = true
                                ))
                            }, {
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )

            return data
        }
    }


    private fun InsertAllSummaryData(liveData: MutableLiveData<NewCommonResponseModel<SummaryResponseData>>,
                                     responseData: SummaryResponseData): Disposable {
        return Completable.fromAction {
            localDb?.incentiveSummaryDao()?.deleteAll()
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Deletion:Completed ")
                    localDb?.let {
                        bag.add(
                                Completable.fromAction {
                                    it.incentiveSummaryDao().insertAll(responseData)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = responseData,
                                                    success = true
                                            ))
                                            Log.d(TAG, "Insertion:Completed-Summary")

                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = null, success = false
                                            ))
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }
// end summry


    // ================================== Earning ===============================================

    fun getEarningData(context: Context, angazaId: String?): MutableLiveData<NewCommonResponseModel<EarningResponseData>> {
        val data = MutableLiveData<NewCommonResponseModel<EarningResponseData>>()
        if (LeaderBoardUtil.isNetworkConnected(context = context)) {
            bag.add(
                    ServiceInstance.getInstance(context).service?.getIncentiveEarning(angazaId)
                    !!.subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.e(TAG, "API-Success: ${it.responseData}")
                                Log.e("responseData", "" + it.responseData.toString())
                                data.postValue(it)

                                InsertAllEarningData(data, it.responseData!!)
                            }, { t ->
                                Log.e(TAG, "API-Error3: ${t.localizedMessage}")
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )
            return data
        } else {
            bag.add(
                    localDb?.earningDao()?.getAllEarningData()!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                data.postValue(NewCommonResponseModel(
                                        responseData = it, success = true
                                ))
                            }, {
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )

            return data
        }
    }


    private fun InsertAllEarningData(liveData: MutableLiveData<NewCommonResponseModel<EarningResponseData>>,
                                     responseData: EarningResponseData): Disposable {
        return Completable.fromAction {
            localDb?.earningDao()?.deleteAll()
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Deletion:Completed ")
                    localDb?.let {
                        bag.add(
                                Completable.fromAction {
                                    it.earningDao().insertAll(responseData)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = responseData,
                                                    success = true
                                            ))
                                            Log.d(TAG, "Insertion:Completed ")

                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = null, success = false
                                            ))
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }
    // ============================================= end earning ==========================================


    // ================================== Deduction Repo ===============================================

    fun getDeductionData(context: Context, angazaId: String?): MutableLiveData<NewCommonResponseModel<DeductionResponseData>> {
        val data = MutableLiveData<NewCommonResponseModel<DeductionResponseData>>()
        if (LeaderBoardUtil.isNetworkConnected(context = context)) {
            bag.add(
                    ServiceInstance.getInstance(context).service?.getIncentiveDeduction(angazaId)
                    !!.subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.e(TAG, "API-Success: ${it.responseData}")
                                Log.e("responseData", "" + it.responseData.toString())
                                data.postValue(it)

                                InsertAllDeductionData(data, it.responseData!!)
                            }, { t ->
                                Log.e(TAG, "API-Error3: ${t.localizedMessage}")
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )
            return data
        } else {
            bag.add(
                    localDb?.deductionDao()?.getAllDeduction()!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                data.postValue(NewCommonResponseModel(
                                        responseData = it, success = true
                                ))
                            }, {
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )

            return data
        }
    }


    private fun InsertAllDeductionData(liveData: MutableLiveData<NewCommonResponseModel<DeductionResponseData>>,
                                       responseData: DeductionResponseData): Disposable {
        return Completable.fromAction {
            localDb?.deductionDao()?.deleteAll()
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Deletion:Completed ")
                    localDb?.let {
                        bag.add(
                                Completable.fromAction {
                                    it.deductionDao().insertAll(responseData)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = responseData,
                                                    success = true
                                            ))
                                            Log.d(TAG, "Insertion:Completed ")

                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = null, success = false
                                            ))
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }
    // ============================================= end earning ==========================================


    // ================================== AgentIncentiveResponseData Repo ===============================================

    fun getAgentIncentiveResponseData(context: Context, angazaId: String?): MutableLiveData<NewCommonResponseModel<AgentIncentiveResponseData>> {
        val data = MutableLiveData<NewCommonResponseModel<AgentIncentiveResponseData>>()
        if (LeaderBoardUtil.isNetworkConnected(context = context)) {
            bag.add(
                    ServiceInstance.getInstance(context).service?.getAgentIncentive(angazaId)
                    !!.subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.e(TAG, "API-Success: ${it.responseData}")
                                Log.e("responseData", "" + it.responseData.toString())
                              //  data.postValue(it)

                                InsertAllAgentIncentiveResponseData(data, it.responseData!!)
                            }, { t ->
                                Log.e(TAG, "API-Error3: ${t.localizedMessage}")
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )
            return data
        } else {
            bag.add(
                    localDb?.incentivesDao()?.getAllIncentiveData()!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                data.postValue(NewCommonResponseModel(
                                        responseData = it, success = true
                                ))
                            }, {
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )

            return data
        }
    }


    private fun InsertAllAgentIncentiveResponseData(liveData: MutableLiveData<NewCommonResponseModel<AgentIncentiveResponseData>>,
                                                        responseData: AgentIncentiveResponseData): Disposable {
        return Completable.fromAction {
            localDb?.incentivesDao()?.deleteAll()
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Deletion:Completed ")
                    localDb?.let {
                        bag.add(
                                Completable.fromAction {
                                    it.incentivesDao().insertAll(responseData)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = responseData,
                                                    success = true
                                            ))
                                            Log.d(TAG, "Insertion:Completed ")

                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = null, success = false
                                            ))
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }
    // ============================================= end AgentIncentiveResponseData ==========================================


    // ================================== AgentIncentiveResponseData Repo ===============================================

    fun getAgentReffedResponseData(context: Context, angazaId: String?): MutableLiveData<NewCommonResponseModel<AgentReffedResponseData>> {
        val data = MutableLiveData<NewCommonResponseModel<AgentReffedResponseData>>()
        if (LeaderBoardUtil.isNetworkConnected(context = context)) {
            bag.add(
                    ServiceInstance.getInstance(context).service?.getAgentRefrel(angazaId)
                    !!.subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.e(TAG, "API-Success: ${it.responseData}")
                                Log.e("responseData", "" + it.responseData.toString())
                                data.postValue(it)

                                InsertAllAAgentReffedResponseData(data, it.responseData!!)
                            }, { t ->
                                Log.e(TAG, "API-Error3: ${t.localizedMessage}")
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )
            return data
        } else {
            bag.add(
                    localDb?.reffrelDao()?.getAllRefrrelData()!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                data.postValue(NewCommonResponseModel(
                                        responseData = it, success = true
                                ))
                            }, {
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )

            return data
        }
    }


    private fun InsertAllAAgentReffedResponseData(liveData: MutableLiveData<NewCommonResponseModel<AgentReffedResponseData>>,
                                                  responseData: AgentReffedResponseData): Disposable {
        return Completable.fromAction {
            localDb?.reffrelDao()?.deleteAll()
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Deletion:Completed ")
                    localDb?.let {
                        bag.add(
                                Completable.fromAction {
                                    it.reffrelDao().insertAll(responseData)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = responseData,
                                                    success = true
                                            ))
                                            Log.d(TAG, "Insertion:Completed ")

                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = null, success = false
                                            ))
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }
    // ============================================= end AgentIncentiveResponseData ==========================================


    // ================================== AgentIncentiveResponseData Repo ===============================================

    fun getTvInstallation(context: Context, angazaId: String?): MutableLiveData<NewCommonResponseModel<Incentive_TvInstallation>> {
        val data = MutableLiveData<NewCommonResponseModel<Incentive_TvInstallation>>()
        if (LeaderBoardUtil.isNetworkConnected(context = context)) {
            bag.add(
                    ServiceInstance.getInstance(context).service?.getTvInstallation(angazaId)
                    !!.subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.e(TAG, "API-Success: ${it.responseData}")
                                Log.e("responseData", "" + it.responseData.toString())
                                //  data.postValue(it)

                                InsertAllTvInstallationResponseData(data, it.responseData!!)
                            }, { t ->
                                Log.e(TAG, "API-Error3: ${t.localizedMessage}")
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )
            return data
        } else {
            bag.add(
                    localDb?.incentivesTvInstallationDao()?.getAllTvInstallation()!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                data.postValue(NewCommonResponseModel(
                                        responseData = it, success = true
                                ))
                            }, {
                                data.postValue(NewCommonResponseModel(
                                        responseData = null, success = false
                                ))
                            })
            )

            return data
        }
    }


    private fun InsertAllTvInstallationResponseData(liveData: MutableLiveData<NewCommonResponseModel<Incentive_TvInstallation>>,
                                                    responseData: Incentive_TvInstallation): Disposable {
        return Completable.fromAction {
            localDb?.incentivesTvInstallationDao()?.deleteAll()
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Deletion:Completed ")
                    localDb?.let {
                        bag.add(
                                Completable.fromAction {
                                    it.incentivesTvInstallationDao().insertAll(responseData)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = responseData,
                                                    success = true
                                            ))
                                            Log.d(TAG, "Insertion:Completed ")

                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                            liveData.postValue(NewCommonResponseModel(
                                                    responseData = null, success = false
                                            ))
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }
    // ============================================= end AgentIncentiveResponseData ==========================================



    fun onDestroy() {
        bag.clear()
    }

}
