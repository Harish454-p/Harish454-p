package com.greenlightplanet.kazi.incentivenew.fragment


import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentChecklistsIncentiveBinding
import com.greenlightplanet.kazi.incentivenew.adapter.CheckListAdapter
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryResponseData
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util


class CheckListIncentiveFragment : Fragment(), CheckListAdapter.MyDateData {
    private val TAG = "CheckListIncentiveFragm"
   // var recyclerView: RecyclerView? = null
private var _binding:FragmentChecklistsIncentiveBinding ? =null
    private val  binding get() = _binding!!
    var preference: GreenLightPreference? = null

    var summaryResponseData: SummaryResponseData? = null


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        _binding = FragmentChecklistsIncentiveBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)


        val bundlesales = arguments
        summaryResponseData = bundlesales?.getParcelable<SummaryResponseData>("checklist")
        preference = GreenLightPreference.getInstance(requireActivity())

        try {
            if (summaryResponseData?.checkListFields?.size!! > 0) {
                binding.tvNoData.visibility = View.GONE
            } else {
                binding.tvNoData.visibility = View.VISIBLE
            }
        } catch (e: Exception) {
            Log.e(TAG, "onActivityCreated: $e")
                binding.tvNoData.visibility = View.VISIBLE

        }

        val adapter = summaryResponseData?.checkListFields?.let { CheckListAdapter(it, this) }
        binding.recyclerView?.setHasFixedSize(true)
       binding.recyclerView?.layoutManager = LinearLayoutManager(requireContext())

        binding.recyclerView?.adapter = adapter
    }

    override fun selectedData(date: String, position: Int) {


        Util.CustomRedirectBaseDialog(
                context = requireActivity(),
                hideTitle = true,
                title = requireContext().getString(R.string.ok_label),
                message = date,
                okSelected = {
                    it.dismiss()
                }
        )
    }


}
