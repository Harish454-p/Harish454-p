package com.greenlightplanet.kazi.loyalty.adapter.passbook

import android.view.ViewGroup
import androidx.paging.PagedListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.loyalty.model.passbook.Entries
import com.greenlightplanet.kazi.loyalty.pagging.State


class PassbookAdapter(private val retry: () -> Unit)
    : PagedListAdapter<Entries, RecyclerView.ViewHolder>(NewsDiffCallback) {

    private val DATA_VIEW_TYPE = 1
    private val FOOTER_VIEW_TYPE = 2

    private var state = State.LOADING

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == DATA_VIEW_TYPE) PassbookViewHolder.create(parent) else PassbookFooterViewHolder.create(retry, parent)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (getItemViewType(position) == DATA_VIEW_TYPE)
            getItem(position)?.let { (holder as PassbookViewHolder).bind(it) }
        else (holder as PassbookFooterViewHolder).bind(state)
    }

    override fun getItemViewType(position: Int): Int {
        return if (position < super.getItemCount()) DATA_VIEW_TYPE else FOOTER_VIEW_TYPE
    }

    companion object {
        val NewsDiffCallback = object : DiffUtil.ItemCallback<Entries>() {
            override fun areItemsTheSame(oldItem: Entries, newItem: Entries): Boolean {
                return oldItem.event_name == newItem.event_name
            }

            override fun areContentsTheSame(oldItem: Entries, newItem: Entries): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun getItemCount(): Int {
        return super.getItemCount() + if (hasFooter()) 1 else 0
    }

    private fun hasFooter(): Boolean {
        return super.getItemCount() != 0 && (state == State.LOADING || state == State.ERROR || state ==State.OFFLINE)
    }

    fun setState(state: State) {
        this.state = state
        notifyItemChanged(super.getItemCount())
    }
}