package com.greenlightplanet.kazi.fse.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import android.os.Parcelable
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import kotlinx.android.parcel.Parcelize


@Parcelize
data class FseDetailsResponse(
        @ColumnInfo(name = "Request")
        @SerializedName("Request")
        var request: Request?,
        @ColumnInfo(name = "ResponseData")
        @SerializedName("ResponseData")
        var responseData: ResponseData?,
        @ColumnInfo(name = "ResponseStatus")
        @SerializedName("ResponseStatus")
        var responseStatus: Int?, // 200
        @ColumnInfo(name = "Success")
        @SerializedName("Success")
        var success: Boolean? // true
) : Parcelable {
    @Parcelize
    data class Request(
            @ColumnInfo(name = "ExecutionTime")
            @SerializedName("ExecutionTime")
            var executionTime: Double? // 1.139
    ) : Parcelable

    @Parcelize
    @Entity(tableName = "FseResponseData")
    data class ResponseData(

            @ColumnInfo(name = "id")
            @PrimaryKey(autoGenerate = true)
            @SerializedName("id")
            var id: Int?,

            @ColumnInfo(name = "isCommitmentConfirmed")
            @SerializedName("isCommitmentConfirmed")
            var isCommitmentConfirmed: Boolean = false,


            @ColumnInfo(name = "fseList")
            @SerializedName("fseList")
            var fseList: List<Fse?>?

    ) : Parcelable

    class FseConverter {


        @TypeConverter
        fun fromFseList(fseList: List<Fse>?): String? {
            if (fseList == null) {
                return null
            }
            val gson = Gson()
            val type = object : TypeToken<List<Fse>>() {

            }.type
            return gson.toJson(fseList, type)
        }

        @TypeConverter
        fun toFseList(fseListString: String?): List<Fse>? {
            if (fseListString == null) {
                return null
            }
            val gson = Gson()
            val type = object : TypeToken<List<Fse>>() {

            }.type
            return gson.fromJson(fseListString, type)
        }

    }
}
