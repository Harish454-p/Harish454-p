package com.greenlightplanet.kazi.attendance.model

class Locat {


    var title: String? = null
    var genre: String? = null
    var year: String? = null


    constructor(title: String, genre: String, year: String) {
        this.title = title
        this.genre = genre
        this.year = year
    }


}

fun Locat.setTitle(name: String) {
    this.title = name
}

fun Locat.getYear(): String? {
    return year
}

fun Locat.setYear(year: String) {
    this.year = year
}

fun Locat.getGenre(): String? {
    return genre
}

fun Locat.setGenre(genre: String) {
    this.genre = genre
}

fun Locat.getTitle(): String? {
    return title
}
