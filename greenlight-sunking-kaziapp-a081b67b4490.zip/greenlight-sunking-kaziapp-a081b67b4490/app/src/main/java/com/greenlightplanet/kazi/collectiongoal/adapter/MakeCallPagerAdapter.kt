package com.greenlightplanet.kazi.collectiongoal.adapter

import androidx.annotation.Keep
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.collectiongoal.view.fragment.CompletedFragment
import com.greenlightplanet.kazi.collectiongoal.view.fragment.PendingFragment

@Keep
class MakeCallPagerAdapter(
    fm: FragmentManager,
    var completedList: List<MakeCallNewModel.ColGoalAccount>,
    var pendingList: List<MakeCallNewModel.ColGoalAccount>,
    var makeCallNewModel: MakeCallNewModel
) : FragmentPagerAdapter(fm) {

    companion object {
        const val TAG = "AccountLastWeekPagerAdapter"
    }

    var completedFragment: CompletedFragment? = null
    var pendingFragment: PendingFragment? = null


    override fun getCount(): Int {
        return 2
    }

    override fun getItem(position: Int): Fragment {
        val fragment: Fragment? = null

        when (position) {
            0 -> {
                if (pendingFragment == null) {
                    //Log.d("NotAchievedListPagerAdp", "success: ${pendingList}")
                    pendingFragment = PendingFragment.newInstance(
                        pendingList,
                        makeCallNewModel,
                        "PENDING_CALL_FRAG"
                    )
                }
                return pendingFragment as Fragment
            }
            1 -> {

                if (completedFragment == null) {
                    //Log.d("AchievedListPagerAdp", "success: ${completedList}")
                    completedFragment = CompletedFragment.newInstance(
                        completedList,
                        makeCallNewModel,
                        "COMPLETED_CALL_FRAG"
                    )
                }

                return completedFragment as Fragment

            }
            else -> return fragment!!
        }
    }
}