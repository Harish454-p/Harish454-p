package com.greenlightplanet.kazi.agentReferral

import android.text.SpannableString
import android.text.format.DateFormat
import android.text.style.UnderlineSpan
import android.widget.TextView

object ReferralConstants {

    const val default_zero : String = "0"
    const val sort_none : Int = -1
    const val sort_by_name : Int = 0

    const val sort_by_regis_date : Int = 1
    const val sort_by_mtd : Int = 2
    const val sort_by_agent_number : Int = 0

    const val sort_referred_date : Int = 1
    const val sort_current_status : Int = 2
    const val sort_parent_phone : Int = 0

    const val sort_stage : Int = 1
    const val sort_referral_date : Int = 2
    const val all_stages : String = "All Stages"

    private const val calendar_range_format_display : String = "dd MMM"
    const val calendar_format_display : String = "dd-MM-yyyy"
    const val status_failed : String = "Failed"

    const val status_in_progress : String = "In Progress"
    const val status_success : String = "Success"
    const val status_error : String = "Error"
    const val status_manual_error : String = "manual_error"
    const val status_prospect_resub : String = "Prospect_Resubmission"
    const val referred_agent_status : String = "referred agent status parcel key"

    const val referral_status_detail : String = "referral status detail parcel key"
    const val referral_territory : String = "agent referral territory key"
    const val stage_assessment : String = "Assessment"
    const val stage_telerivet_assessment : String = "Telerivet Assessment"

    fun fetchRangeDisplayDate(firstDate : Long, secondDate : Long): String {
        val first = DateFormat.format(calendar_range_format_display, firstDate).toString()
        val second = DateFormat.format(calendar_range_format_display, secondDate).toString()

        return when (firstDate) {
            secondDate -> first
            else -> "$first - $second"
        }
    }

    fun countryCode(country : String) : String {
        return when(country) {
            "india" -> "+91"
            "myanmar" -> "+95"
            "nigeria" -> "+234"
            "tanzania" -> "+255"
            "uganda" -> "+256"
            "kenya" -> "+254"
            "zambia" -> "+260"
            "mozambique" -> "+258"
            "cameroon" -> "+237"
            "malawi" -> "+265"
            "togo" -> "+228"
            else -> "+000"
        }
    }

    fun addUnderline(textView: TextView) {
        val content = SpannableString(textView.text)
        content.setSpan(UnderlineSpan(), 0, content.length, 0)
        textView.text = content
    }
}