package com.greenlightplanet.kazi.attendance.extra

import android.app.Activity
import android.content.Context
import android.util.Log
import android.widget.Toast
import com.greenlightplanet.kazi.utils.MultiSelectDialog.MultiSelectDialog
import com.greenlightplanet.kazi.utils.MultiSelectDialog.MultiSelectModel
import com.greenlightplanet.kazi.utils.Util
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.DexterError
import com.karumi.dexter.listener.PermissionRequestErrorListener
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class AttendanceUtils {

    companion object{
        val TAG = "AttendanceUtils"
        fun makeDailog(
                list: List<MultiSelectModel>?,
                onSelected: (name: String) -> Unit,
                onCancel: () -> Unit = {}
        ): MultiSelectDialog? {

            list?.forEach { it.setSelected(false) }

            return MultiSelectDialog()
                    .title("Select the Customer") //setting title for dialog
                    .titleSize(25f)
                    .positiveText("Done")
                    .negativeText("Cancel")
                    .setMinSelectionLimit(1)
                    .setMaxSelectionLimit(1)
                    //.preSelectIDsList(alreadySelectedCountries) //List of ids that you need to be selected
                    .multiSelectList(ArrayList(list!!)) // the multi select model list with ids and name
                    .onSubmit(object : MultiSelectDialog.SubmitCallbackListener {
                        override fun onSelected(
                                selectedIds: java.util.ArrayList<Int>,
                                selectedNames: java.util.ArrayList<String>,
                                dataString: String
                        ) {
                            onSelected(selectedNames.last())

                            Log.d(TAG, "selectedIds: ${selectedIds.last()}");
                            Log.d(TAG, "selectedNames: ${selectedNames.last()}");

                        }

                        override fun onCancel() {
                            onCancel()
                        }
                    })
        }


        /**
         * Requesting multiple permission
         * On permanent denial opens settings dialog
         */
        fun requestAllPermission(activity: Context, permissions: Collection<String>) {
            Dexter.withActivity(activity as Activity?)
                    .withPermissions(
                            permissions)
                    .withListener(object : MultiplePermissionsListener {
                        override fun onPermissionRationaleShouldBeShown(permissions: MutableList<com.karumi.dexter.listener.PermissionRequest>?, token: PermissionToken?) {
                            token?.continuePermissionRequest()
                        }

                        override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                            // check if all permissions are granted
                            if (report.areAllPermissionsGranted()) {
                                // Toast.makeText(activity, "All permissions are granted!", Toast.LENGTH_SHORT).show()
                            }
                            // check for permanent denial of any permission
                            if (report.isAnyPermissionPermanentlyDenied) {
                                // show alert dialog navigating to Settings
                                Util.showSettingsDialog(activity)
                            }
                        }

                    }).withErrorListener(object : PermissionRequestErrorListener {
                        override fun onError(error: DexterError) {
                            Toast.makeText(activity, "Error occurred! ", Toast.LENGTH_SHORT).show()
                        }
                    })
                    .onSameThread()
                    .check()


        }


        fun getDaysAgo(daysAgo: Int): String? {
            val calendar = Calendar.getInstance()
            calendar.add(Calendar.DAY_OF_YEAR, -daysAgo)
            val format = SimpleDateFormat("dd-MM-yyy")

            val formatedDate = format.format(calendar.time)

            return formatedDate.toString()
        }

        fun getLineNumber(): String {
            return Thread.currentThread().getStackTrace()[2].getLineNumber().toString()
        }


        fun getFormattedDatezz(time: String): Date {

            val sdf = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
            val date: Date? = sdf.parse(time)
            return date!!
        }



    }

}