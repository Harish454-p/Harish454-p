package com.greenlightplanet.kazi.loyalty.dao.achievements

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.incentive.model.StarClubResponseModel
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryResponseData
import com.greenlightplanet.kazi.loyalty.model.achievements.Achieved
import com.greenlightplanet.kazi.loyalty.model.passbook.Entries
import com.greenlightplanet.kazi.loyalty.model.profile.ProfileResponse
import com.greenlightplanet.kazi.task.model.dialogIntent.FeedbackModel
import com.greenlightplanet.kazi.task.model.dialogIntent.NotAnsweredModel
import com.greenlightplanet.kazi.task.model.response.CallDetail
import com.greenlightplanet.kazi.task.model.response.TaskMddel
import com.greenlightplanet.kazi.task.model.response.firstCall

import io.reactivex.Single

@Dao
interface AchieveDao {

    @Query("SELECT * FROM Achieved")
    fun getAllAchievedResponse(): Single<List<Achieved>>



    @Query("SELECT * FROM Achieved WHERE longDate  BETWEEN :startDate AND :endDate AND page=:page AND typeName=:typeId")
    fun getAllAchievedResponseById(page:Int?,startDate:Long?,endDate:Long?,typeId: Int?): Single<List<Achieved>>


   @Query("SELECT * FROM Achieved WHERE longDate  BETWEEN :startDate AND :endDate") //AND type_id=:typeId
    fun getAllAchievedTypeId(startDate:Long?,endDate:Long?): Single<List<Achieved>>


    @Query("SELECT * FROM Achieved WHERE type_id=:typeId ")
    fun getAchievedByEventTypeId(typeId:Int?): Single<List<Achieved>>

    @Query("SELECT * FROM Achieved")
    fun getAchievedByEventTypeId(): Single<List<Achieved>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(achieved: List<Achieved>?)

    @Query("DELETE FROM Achieved")
    fun deleteAll(): Int

    @Query("DELETE FROM Achieved WHERE longDate  BETWEEN :startDate AND :endDate AND page=:page AND typeName=:typeId")
    fun deleteById(page:Int?,startDate:Long?,endDate:Long?,typeId: Int?): Int


    @Query("DELETE FROM Achieved WHERE  typeName=:typeId")
    fun deleteByTypeName(typeId: Int?): Int


    @Query("SELECT count(*) FROM Achieved")
    fun getAchievedCount(): Single<Int>



}
