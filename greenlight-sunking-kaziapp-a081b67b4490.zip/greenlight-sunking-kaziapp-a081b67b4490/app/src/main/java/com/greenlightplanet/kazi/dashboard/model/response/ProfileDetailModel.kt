package com.greenlightplanet.kazi.dashboard.model.response

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.annotation.NonNull
import org.jetbrains.annotations.NotNull
import java.io.Serializable

@Entity(tableName = "ProfileDetailModel")
class ProfileDetailModel:Serializable
{
    @ColumnInfo(name = "first_name")
    var firstName:String?=null

    @ColumnInfo(name = "last_name")
    var lastName:String?=null

    @ColumnInfo(name = "photo_url")
    var photoUrl:String?=null

    @PrimaryKey
    @ColumnInfo(name = "phone_number")
    var phoneNumber:String =""


    @ColumnInfo(name = "id")
    var id:String?=null

    @ColumnInfo(name = "area")
    var area:String?=null

    @ColumnInfo(name = "cluster")
    var cluster:String?=null




}
