package com.greenlightplanet.kazi.location.newworker

import android.os.Parcelable
import android.telephony.CellInfo
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "CellInfoModel")
data class CellInfoModel(
	@PrimaryKey(autoGenerate = true)
	@ColumnInfo(name = "id")
	@SerializedName("id")
	var id: Int,
	@ColumnInfo(name = "cellInfo")
	@SerializedName("cellInfo")
	var awsLink: CellInfo?
): Parcelable
