package com.greenlightplanet.kazi.heroboard.model

import androidx.room.ColumnInfo
import androidx.room.TypeConverter
import kotlinx.android.parcel.Parcelize
import com.google.gson.annotations.SerializedName
import android.os.Parcelable
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

@Parcelize

data class HeroboardModel(
    @ColumnInfo(name = "leaderboard")
    @SerializedName("leaderboard")
    var leaderboard: List<LeaderboardModel>
) : Parcelable


class LeaderConverter {

    @TypeConverter
    fun fromLeaderList(leaderListResponse: List<LeaderboardModel>?): String? {
        if (leaderListResponse == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<LeaderboardModel>>() {

        }.type
        return gson.toJson(leaderListResponse, type)
    }

    @TypeConverter
    fun toLeaderList(leaderListString: String?): List<LeaderboardModel>? {
        if (leaderListString == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<LeaderboardModel>>() {

        }.type
        return gson.fromJson(leaderListString, type)
    }

}
