package com.greenlightplanet.kazi.location.dao

import androidx.room.*
import com.greenlightplanet.kazi.location.model.LocationRequestModel
import io.reactivex.Single


@Dao
interface LocationRequestDao {


	@Insert(onConflict = OnConflictStrategy.REPLACE)
	fun insertAll(locationRequestModels: List<LocationRequestModel?>): List<Long>

	@Insert(onConflict = OnConflictStrategy.REPLACE)
	fun insert(locationRequestModel: LocationRequestModel): Long

	@Delete
	fun delete(locationRequestModel: LocationRequestModel): Int

	@Delete
	fun deleteAllAnother(locationRequestModel: List<LocationRequestModel>): Int

	@Query("DELETE FROM LocationRequestModel")
	//fun deleteAllLocationRequest(): Observer<Int>
	fun deleteAll(): Int


	@Query("SELECT * FROM LocationRequestModel")
	fun getAll(): Single<List<LocationRequestModel>>


	@Query("SELECT * FROM LocationRequestModel WHERE angazaId = :angazaId LIMIT 1")
	fun get(angazaId: String): Single<LocationRequestModel>


	@Query("SELECT COUNT(*) from LocationRequestModel")
	fun count(): Single<Int>

}
