package com.greenlightplanet.kazi.liteFseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.location.Location
import com.greenlightplanet.kazi.liteFseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.liteFseProspective.model.*
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteInstallationRepo
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteProspectiveRepo
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteRegistrationRepo
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteVerificationRepo
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.networking.CommonResponseModel

import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel
import com.greenlightplanet.kazi.utils.Util

class ProspectDetailViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "ProspectDetailViewModel"
    }


    val verificationRepo = LiteVerificationRepo.getInstance(application)
    val registrationRepo = LiteRegistrationRepo.getInstance(application)
    val installationRepo = LiteInstallationRepo.getInstance(application)
    val prospectiveRepo = LiteProspectiveRepo.getInstance(application)


    //start verificationRepo
    fun processOtp(
        context: Context,
        isOnline: Boolean,
        isValid: Boolean,
        prospectID: String,
        angazaId: String,
        unsuccessfulAttempt: Int = 0,
        country: String,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

        showProgress()

        if (isValid) {
            return verificationRepo.onValidOtp(isOnline, prospectID, angazaId, country)
        } else {
            return verificationRepo.onInvalidOtp(
                isOnline,
                prospectID,
                angazaId,
                unsuccessfulAttempt,
                country
            )
        }
    }

    fun getCombineRequestModelVerification(prospectID: String): MutableLiveData<CombineRequestModel?> {
        return verificationRepo.getCombineRequestModel(prospectID)
    }

    fun sendOtpApprovalToServerForceUpload(
        isValid: Boolean,
        otpApprovalRequest: LiteOtpApprovalRequestModel,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return verificationRepo.sendOtpApprovalToServerForceUpload(isValid, otpApprovalRequest)
    }

    fun getFseProspectiveFromServerVerification(
        angazaId: String,
        prospectId: String,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>? {
        showProgress()
        return verificationRepo.getFseProspectiveFromServer(angazaId, prospectId)
    }
    //end verificationRepo

    //getCombineRequestModel //getFseProspectiveFromServer

    //start registrationRepo
    fun processCheckIn(
        context: Context,
        isOnline: Boolean,
        prospectID: String,
        angazaId: String,
        area: String,
        prospectAllowedDistance: Int,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {
        showProgress()
        return registrationRepo.performCheckin(
            context,
            isOnline,
            prospectID,
            angazaId,
            area,
            prospectAllowedDistance
        )
    }

    fun processCheckIn2(
        context: Context,
        isOnline: Boolean,
        prospectID: String,
        angazaId: String,
        area: String,
        location: Location,
        prospectAllowedDistance: Int,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {
        showProgress()
        return registrationRepo.performCheckin2(
            context,
            isOnline,
            prospectID,
            angazaId,
            area,
            location,
            prospectAllowedDistance
        )
    }

    fun getCombineRequestModelRegistration(prospectID: String): MutableLiveData<CombineRequestModel?> {
        return registrationRepo.getCombineRequestModel(prospectID)
    }

    fun sendRegistrationCheckinRequestToServerForceUpload(
        registrationCheckinRequestModel: LiteRegistrationCheckinRequestModel,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return registrationRepo.sendRegistrationCheckinRequestToServerForceUpload(
            registrationCheckinRequestModel
        )
    }

    fun getFseProspectiveFromServerRegistration(
        angazaId: String,
        prospectId: String,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>? {
        showProgress()
        return registrationRepo.getFseProspectiveFromServer(angazaId, prospectId)
    }
    //end registrationRepo

    //start installationRepo
    fun compressImageForAws(
        context: Context,
        files: List<ImageUploadUtil.ImageModel>,
        showProgress: () -> Unit = {}
    ): MutableLiveData<List<LiteAwsImageModel>?> {
        showProgress()
        return installationRepo.compressImageForAws(context, files)
    }

    fun performInstallation(
        context: Context,
        fseProspectResponseModel: LiteFseProspectResponseModel?,
        isOnline: Boolean,
        prospectId: String,
        angazaId: String,
        accountNumber: String,
        installationAttempted: Int,
        fileModel: List<LiteAwsImageModel>,
        location: Location,
        imageName: String,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return installationRepo.performInstallation(
            context,
            fseProspectResponseModel,
            isOnline,
            prospectId,
            angazaId,
            accountNumber,
            installationAttempted,
            fileModel/*, location*/
        )
    }

    fun performInstallation2(
        context: Context,
        fseProspectResponseModel: LiteFseProspectResponseModel?,
        isOnline: Boolean,
        prospectId: String,
        fileModel: List<LiteAwsImageModel>,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return installationRepo.performInstallation2(
            context,
            fseProspectResponseModel,
            isOnline,
            prospectId,
            fileModel
        )
    }


    fun insertAwsImageModelToDatabase(
        inputFiles: List<LiteAwsImageModel>,
        isUploadedToAws: Boolean
    ): MutableLiveData<List<LiteAwsImageModel>?> {
        return installationRepo.insertAwsImageModelToDatabase(inputFiles, isUploadedToAws)
    }


    fun getCombineRequestModelInstallation(prospectId: String): MutableLiveData<CombineRequestModel> {
        return installationRepo.getCombineRequestModel(prospectId)
    }


    /*not used*/
    fun getAwsImageModelByProspectId(prospectId: String): MutableLiveData<List<LiteAwsImageModel>> {
        return installationRepo.getAllAwsImageModelByProspectId(prospectId)
    }

    fun getAllAwsImageModelByProspectId(prospectId: String): MutableLiveData<List<LiteAwsImageModel>> {
        return installationRepo.getAllAwsImageModelByProspectId(prospectId)
    }

    fun sendInstallationRequestToServerForce(
        installationRequestModel: LiteInstallationRequestModel,
        fileModel: List<LiteAwsImageModel>,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return installationRepo.sendInstallationRequestToServerForce(
            installationRequestModel,
            fileModel
        )
    }

    fun updateFseProspect(fseProspectResponseModel: LiteFseProspectResponseModel): MutableLiveData<LiteFseProspectResponseModel> {
        return installationRepo.updateFseProspect(fseProspectResponseModel)
    }

    fun getFseProspectiveFromServerInstallation(
        angazaId: String,
        prospectId: String,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>? {
        showProgress()
        return installationRepo.getFseProspectiveFromServer(angazaId, prospectId)
    }

    fun awsRX(
        context: Context,
        requestModel: BaseRequestModel
    ): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
        return installationRepo.awsRX(context, requestModel)
    }

    //end installationRepo


    //region new prospect Call details

    fun getProspectCallDetails(
        context: Context,
        prospectId: String
    ): MutableLiveData<NewCommonResponseModel<ProspectCallDetailsModel>> {

        return if (Util.isOnline(context = context)) {
            prospectiveRepo.getProspectCallDetails(prospectId)
        } else {
            prospectiveRepo.getProspectCallDetailsFromDatabase(prospectId)
        }
    }


    //endregion

    fun getSingleProspect(prospectId: String): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>> {
        return prospectiveRepo.getSingleProspect(prospectId)
    }

    override fun onCleared() {
        super.onCleared()
        verificationRepo.destroy()
        registrationRepo.destroy()
        installationRepo.destroy()

    }

}
