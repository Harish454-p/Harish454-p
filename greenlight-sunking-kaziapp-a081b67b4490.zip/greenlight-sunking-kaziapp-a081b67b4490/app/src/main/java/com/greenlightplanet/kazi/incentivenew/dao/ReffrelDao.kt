package com.greenlightplanet.kazi.incentivenew.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.incentive.model.StarClubResponseModel
import com.greenlightplanet.kazi.incentivenew.model.deduction.DeductionResponseData
import com.greenlightplanet.kazi.incentivenew.model.incentive.AgentIncentiveResponseData
import com.greenlightplanet.kazi.incentivenew.model.reffrel.AgentReffedResponseData
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryResponseData
import com.greenlightplanet.kazi.task.model.dialogIntent.FeedbackModel
import com.greenlightplanet.kazi.task.model.dialogIntent.NotAnsweredModel
import com.greenlightplanet.kazi.task.model.response.CallDetail
import com.greenlightplanet.kazi.task.model.response.TaskMddel
import com.greenlightplanet.kazi.task.model.response.firstCall

import io.reactivex.Single

@Dao
interface ReffrelDao {

    @Query("SELECT * FROM AgentReffedResponseData")
    fun getAllRefrrelData(): Single<AgentReffedResponseData>


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(deductionResponseData: AgentReffedResponseData): Long

    @Query("DELETE FROM AgentReffedResponseData")
    fun deleteAll(): Int




}
