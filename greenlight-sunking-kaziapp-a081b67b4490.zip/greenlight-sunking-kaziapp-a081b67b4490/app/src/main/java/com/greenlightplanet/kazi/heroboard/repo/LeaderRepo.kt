package com.greenlightplanet.kazi.heroboard.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.heroboard.extras.LeaderBoardUtil
import com.greenlightplanet.kazi.heroboard.model.HeroboardModel
import com.greenlightplanet.kazi.heroboard.model.LeaderboardModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.AppDatabase
import io.reactivex.Completable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

class LeaderRepo(val context: Context) {

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null

    companion object : SingletonHolderUtil<LeaderRepo, Context>(::LeaderRepo) {
        val TAG = "MZD=={XLeaderRepoX}=="
    }

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
        } catch (e: Exception) {
            Log.d(TAG, ":Error ")
        }
    }


    fun getLeaderBoardData(anganzaID: String): MutableLiveData<NewCommonResponseModel<HeroboardModel>> {

        val data = MutableLiveData<NewCommonResponseModel<HeroboardModel>>()
        if (LeaderBoardUtil.isNetworkConnected(context = context)) {
			Log.d("TIME_CALC", "heroboard-start:${System.currentTimeMillis()} ")
            bag.add(
                    ServiceInstance.getInstance(context!!).service?.getLeaderBoard(angazaId = anganzaID)
                    !!.subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.d(TAG, "API-Success: ${it.responseData}")
                                InsertAllLeader(data, it.responseData!!)
                                updateSharedPref(true)
                            }, { t ->
                                Log.d(TAG, "API-Error3: ${t.localizedMessage}")
                                data.postValue(NewCommonResponseModel<HeroboardModel>(
                                        error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable get data from server"
                                        ),
                                        success = false
                                ))
                            })
            )
            return data
        } else {
            bag.add(

                    localDb?.leaderDao()?.getAll()!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                data.postValue(NewCommonResponseModel<HeroboardModel>(
                                        responseData = HeroboardModel(it),
                                        success = true
                                ))
                                updateSharedPref(false)
                            }, {
                                data.postValue(NewCommonResponseModel<HeroboardModel>(
                                        error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable get data from server"
                                        ),
                                        success = false
                                ))
                            })
            )

            return data
        }
    }

    private fun InsertAllLeader(liveData: MutableLiveData<NewCommonResponseModel<HeroboardModel>>, responseData: HeroboardModel): Disposable {
        return Completable.fromAction {
            localDb?.leaderDao()?.deleteAll()
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Deletion:Completed ")
                    localDb?.let {
                        bag.add(
                                Completable.fromAction {
                                    it.leaderDao().insertAll(responseData.leaderboard)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            Log.d(TAG, "Insertion:Completed ")
//                                            liveData.postValue(responseData)
											Log.d("TIME_CALC", "heroboard-end:${System.currentTimeMillis()} ")
                                            liveData.postValue(NewCommonResponseModel<HeroboardModel>(
                                                    responseData = responseData,
                                                    success = true
                                            ))
                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                            liveData.postValue(NewCommonResponseModel<HeroboardModel>(
                                                    error = NewCommonResponseModel.Error(
                                                            messageToUser = "Unable get data from server"
                                                    ),
                                                    success = false
                                            ))
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }

    fun getLeaderFromDatabase(): MutableLiveData<List<LeaderboardModel>> {

        val data = MutableLiveData<List<LeaderboardModel>>()

        bag.add(

                localDb?.leaderDao()?.getAll()!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({
                            data.postValue(it)
                        }, {
                            data.postValue(null)
                        })
        )

        return data
    }


    private fun updateSharedPref(fromInternet: Boolean) {
        var data: LastSaved? = OfferUtils.loadSummaryFromPref(context!!)
        if (data == null) {
            data = LastSaved()
            data.heroBoard = "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveSummaryToPref(context, data)
        } else {

            if (fromInternet) {
                data.heroBoard = "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveSummaryToPref(context, data)
            }
        }

    }

    fun destroy() {
        Log.d(TAG, "LeaderRepo : Distroyed");
        bag.clear()

    }


}
