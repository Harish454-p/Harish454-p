package com.greenlightplanet.kazi.incentive.model

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.annotation.NonNull
import java.io.Serializable

@Entity(tableName = "incentives")
class IncentiveResponseModel : Serializable {

    @PrimaryKey
    @ColumnInfo(name = "angazaId")
    var angazaId: String = ""

    @ColumnInfo(name = "area")
    var area: String? = "NA"

    @ColumnInfo(name = "currentRole")
    var currentRole: String? = "NA"

    @ColumnInfo(name = "cluster")
    var cluster: String? = "NA"

    @Embedded
    var collection: collection? = null

    @Embedded
    var sales: sales? = null

    @Embedded
    var phoneRecovery: phoneRecovery? = null

    @Embedded
    var others: others? = null

}

class collection : Serializable {
    @ColumnInfo(name = "collection_duration")
    var duration: String? = "NA"


    @ColumnInfo(name = "collection_score")
    var collectionScore: String? = "NA"

    @ColumnInfo(name = "collectionRate")
    var collectionRate: String? = "NA"


    @ColumnInfo(name = "collection_post_tax")
    var postTax: String? = "0.0"

    @ColumnInfo(name = "collection_total_collection")
    var totalCollection: String? = "0.0"

    @ColumnInfo(name = "collection_commission")
    var commission: String? = "0.0"

    @ColumnInfo(name = "collection_pre_tax")
    var preTax: String? = "0.0"
}

class sales : Serializable {

    @ColumnInfo(name = "sales_duration")
    var duration: String? = "NA"

    @ColumnInfo(name = "sales_post_tax")
    var postTax: String? = "0.0"

    @ColumnInfo(name = "sales_this_week")
    var thisWeek: String? = "0.0"

    @ColumnInfo(name = "sales_pre_tax")
    var preTax: String? = "0.0"
}

class phoneRecovery : Serializable {
    @ColumnInfo(name = "phone_recovery_amount")
    var phoneRecoveredAmount: String? = null

    @ColumnInfo(name = "phone_value")
    var phoneValue: String? = null

    @ColumnInfo(name = "phone_balance")
    var phoneBalance: String? = null
}

class others : Serializable {
    @ColumnInfo(name = "callReimbursement")
    var callReimbursement: String? = null

    @ColumnInfo(name = "totalCallDuration")
    var totalCallDuration: String? = null

}
