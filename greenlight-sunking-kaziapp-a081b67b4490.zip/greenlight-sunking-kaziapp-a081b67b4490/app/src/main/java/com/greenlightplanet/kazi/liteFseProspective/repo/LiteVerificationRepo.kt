package com.greenlightplanet.kazi.liteFseProspective.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.liteFseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.liteFseProspective.model.*
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.util.*

class LiteVerificationRepo(val context: Context) {

    companion object :
        SingletonHolderUtil<LiteVerificationRepo, Context>(::LiteVerificationRepo) {
        public const val TAG = "LiteVerificationRepo"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    var gson: Gson? = null
    var country: String? = null

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context!!)
            country = preference?.getLoginResponseModel()?.country
            gson = Gson()

        } catch (e: Exception) {
            Log.d(TAG, ":Error ");
        }
    }


    fun getCombineRequestModel(prospectId: String): MutableLiveData<CombineRequestModel?> {

        val data = MutableLiveData<CombineRequestModel?>()
        val combineModel = CombineRequestModel()

        bag.add(
            localDb?.liteFseProspectResponseDao()?.getByProspectId(prospectId)!!
                .flatMap {
                    combineModel.fseProspectResponseModel = it
                    localDb?.liteOtpApprovalRequestDao()?.getByProspectId(prospectId)
                }.flatMap {
                    combineModel.otpApprovalRequestModel = it
                    localDb?.liteFseErrorDao()?.getByProspectId(prospectId)!!
                }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .doFinally { data.postValue(combineModel) }
                .subscribe({
                    combineModel.fseError = it
                }, {
                    it.printStackTrace()
                    Log.d(TAG, "ERROR:${it.localizedMessage} ");
                })
        )
        return data
    }


    //Valid and InValid
    //step-0
    private fun getOtpApprovalRequestFromDBIfExist(prospectId: String): Single<LiteOtpApprovalRequestModel> {

        return localDb!!.liteOtpApprovalRequestDao().getByProspectId(prospectId)!!
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
    }

    fun getOtpApprovalRequestFromDB(prospectId: String): MutableLiveData<LiteOtpApprovalRequestModel> {
        val data: MutableLiveData<LiteOtpApprovalRequestModel> = MutableLiveData()

        bag.add(
            getOtpApprovalRequestFromDBIfExist(prospectId)
                .subscribe({
                    data.postValue(it)
                }, {
                    it.printStackTrace()
                    data.postValue(null)
                })
        )
        return data
    }

    /////////////////


    //InValid
    //step-1

    fun onInvalidOtp(
        isOnline: Boolean,
        prospectId: String,
        angazaId: String,
        unsuccessfulAttempt: Int,
        country: String
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {
        val data: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> = MutableLiveData()
        localDb?.let { appDatabase ->
            bag.add(
                getOtpApprovalRequestFromDBIfExist(prospectId).subscribe({

                    //  if (it != null) {
                    //it.unsuccessfulAttempts = it.unsuccessfulAttempts.inc()
                    it.unsuccessfulAttempts = unsuccessfulAttempt.inc()
                    processOtp(data, isOnline, false, it)
                    Log.d(TAG, "DB-EO-List: ${""}")
                    //     }


                }, { t ->

                    val newOtpApprovalRequestModel = LiteOtpApprovalRequestModel(
                        prospectId = prospectId,
                        unsuccessfulAttempts = unsuccessfulAttempt.inc(),
                        otpVerificationTime = "",
                        angazaId = angazaId,
                        country = country
                            ?: ""
                    )
                    processOtp(data, isOnline, false, newOtpApprovalRequestModel)
                    Log.d(TAG, "API-Error: ${t.localizedMessage}")
                })

            )
        }
        return data

    }


    //Valid
    //step-1
    fun onValidOtp(
        isOnline: Boolean,
        prospectId: String,
        angazaId: String,
        country: String
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {
        val data: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> = MutableLiveData()
        localDb?.let { appDatabase ->
            bag.add(
                getOtpApprovalRequestFromDBIfExist(prospectId).subscribe({

                    it.otpVerificationTime = Util.fseDateToUtcFormatted(Date())!!
                    processOtp(data, isOnline, true, it)
                    Log.d(TAG, "DB-EO-List: ${""}")

                }, { t ->

                    val newOtpApprovalRequest = LiteOtpApprovalRequestModel(
                        prospectId = prospectId,
                        unsuccessfulAttempts = 0,
                        otpVerificationTime = Util.fseDateToUtcFormatted(Date())!!,
                        angazaId = angazaId,
                        country = country
                            ?: ""
                    )
                    processOtp(data, isOnline, true, newOtpApprovalRequest)
                    Log.d(TAG, "API-Error: ${t.localizedMessage}")
                })

            )
        }
        return data

    }


    //Valid and InValid
    //step-2
    private fun processOtp(
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        isOnline: Boolean,
        isValid: Boolean,
        otpApprovalRequestModel: LiteOtpApprovalRequestModel
    ) {
        if (isOnline) {
            return processOtpToServer(liveData, isValid, otpApprovalRequestModel)
        } else {
            return processOtpToDatabase(liveData, isValid, otpApprovalRequestModel)
        }
    }

    //Valid and InValid
    //step-3
    private fun processOtpToDatabase(
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        isValid: Boolean,
        otpApprovalRequest: LiteOtpApprovalRequestModel
    ) {


        bag.add(

            insertOtpApprovalToDatabase(otpApprovalRequest)
                .flatMapCompletable {
                    performIsChanged(
                        otpApprovalRequest.prospectId,
                        true,
                        !isValid,
                        otpApprovalRequest.otpVerificationTime
                    )
                }
                .subscribe({

                    liveData.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            success = true
                        )
                    )
                }, {
                    //error
                    liveData.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )

                })
        )


    }

    //Valid and InValid
    //step-3
    private fun processOtpToServer(
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        isValid: Boolean,
        otpApprovalRequest: LiteOtpApprovalRequestModel
    ) {


        bag.add(

            insertOtpApprovalToDatabase(otpApprovalRequest)
                .subscribe({
                    sendOtpApprovalToServer(liveData, isValid, otpApprovalRequest)
                }, {
                    //error
                    liveData.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )

                })
        )


    }

    fun sendOtpApprovalToServerForceUpload(
        isValid: Boolean,
        otpApprovalRequest: LiteOtpApprovalRequestModel
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {

        val data: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> = MutableLiveData()

        var response: NewCommonResponseModel<NewEmptyParcelable>? = null

        bag.add(
            ServiceInstance.getInstance(context).service?.postLiteOtpApproval(
                //url = "http://demo4291977.mockable.io/otp-approval",
                otpApprovalRequestModel = otpApprovalRequest
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable {
                    response = it
                    if (it.success) {

                        performIsChanged(
                            otpApprovalRequest.prospectId,
                            false,
                            !isValid,
                            otpApprovalRequest.otpVerificationTime
                        )
                    } else {
                        //data.postValue(it)
                        performIsChanged(
                            prospectId = otpApprovalRequest.prospectId,
                            isChanged = false,
                            increment = !isValid,
                            errorOccurred = true,
                            errorModel = it.error
                        )
                    }

                }
                .subscribe({

                    data.postValue(response)

                }, {


                    /*val error = it as HttpException
                    val errorBody = error.response().errorBody()?.string()
                    val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)*/

                    val isApi = it is retrofit2.HttpException

                    var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                    if (isApi) {
                        val error = it as HttpException
                        val errorBody = error.response().errorBody()?.string()
                        errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(
                            errorBody,
                            NewCommonResponseModel::class.java
                        )

                    } else {


                        errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = it.localizedMessage
                            ),
                            success = false

                        )

                    }


                    bag.add(
                        performIsChanged(
                            prospectId = otpApprovalRequest.prospectId,
                            isChanged = false,
                            increment = !isValid,
                            errorOccurred = true,
                            errorModel = errorModel?.error
                        ).subscribe({
//                    Log.d(TAG, " on Success ===");
                        }, {
                            Log.d(TAG, " Error:${it.printStackTrace()}");
                        })
                    )

                    data.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )
                    Log.d(TAG, "Error:${it.localizedMessage} ");

                })

        )

        return data
    }

    //Valid and InValid
    //step-4
    private fun sendOtpApprovalToServer(
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        isValid: Boolean,
        otpApprovalRequest: LiteOtpApprovalRequestModel
    ) {

        bag.add(
            ServiceInstance.getInstance(context).service?.postLiteOtpApproval(
                //url = "http://demo4291977.mockable.io/otp-approval",
                otpApprovalRequestModel = otpApprovalRequest
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable {
                    if (it.success) {
                        liveData.postValue(it)
                        performIsChanged(
                            otpApprovalRequest.prospectId,
                            false,
                            !isValid,
                            otpApprovalRequest.otpVerificationTime
                        )
                    } else {
                        liveData.postValue(it)
                        performIsChanged(
                            prospectId = otpApprovalRequest.prospectId,
                            isChanged = false,
                            increment = !isValid,
                            errorOccurred = true,
                            errorModel = it.error
                        )
                    }

                }
                .subscribe({}, {


                    /*val error = it as HttpException
                    val errorBody = error.response().errorBody()?.string()
                    val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)
*/

                    val isApi = it is retrofit2.HttpException

                    var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                    if (isApi) {
                        val error = it as HttpException
                        val errorBody = error.response().errorBody()?.string()
                        errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(
                            errorBody,
                            NewCommonResponseModel::class.java
                        )

                    } else {


                        errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = it.localizedMessage
                            ),
                            success = false

                        )

                    }


                    bag.add(
                        performIsChanged(
                            prospectId = otpApprovalRequest.prospectId,
                            isChanged = false,
                            increment = !isValid,
                            errorOccurred = true,
                            errorModel = errorModel?.error
                        ).subscribe({
//                    Log.d(TAG, " on Success ===");
                        }, {
                            Log.d(TAG, " Error:${it.printStackTrace()}");
                        })
                    )


                    liveData.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )



                    Log.d(TAG, "Error:${it.localizedMessage} ");

                })


            /*.subscribe({ success ->
                success?.let { responseData ->

                    Log.d(TAG, "Response: ${success}")

                    liveData.postValue(responseData)
                    //todo There is some logic here
                }

            }, { t ->

                Log.d(TAG, "API-Error3: ${t.localizedMessage}")

                liveData.postValue(null)
            })*/
        )
    }

    //Valid and InValid
    //step-4
    private fun insertOtpApprovalToDatabase(otpApprovalRequestModel: LiteOtpApprovalRequestModel): Single<LiteOtpApprovalRequestModel> {

        return Single.create { emitter ->

            try {
                val result = localDb!!.liteOtpApprovalRequestDao().insert(otpApprovalRequestModel)
                result.let {
                    emitter.onSuccess(otpApprovalRequestModel)
                }

            } catch (e: Exception) {
                emitter.onError(e)
            }
        }
    }


    private fun performIsChanged(
        prospectId: String,
        isChanged: Boolean,
        increment: Boolean,
        date: String = "",
        errorOccurred: Boolean = false,
        errorModel: NewCommonResponseModel.Error? = null
    ): Completable {
        //bag.add(
        return localDb!!.liteFseProspectResponseDao().getByProspectId(prospectId)!!
            .flatMapCompletable {
                val value = it
                value.isChanged = isChanged
                value.errorOccurred = errorOccurred


                if (increment) {
                    value.unsuccessfulOtpAttempts = value.unsuccessfulOtpAttempts + 1
                } else {
                    value.statusUpdateTime?.otpApproved = date
                    value.status = FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                }

                val fseError = LiteFseError(
                    prospectId = prospectId,
                    errorType = FseProspectiveConstant.ProspectiveType.VERIFICATION,
                    code = errorModel?.code,
                    errorClass = errorModel?.errorClass,
                    errorTrace = errorModel?.errorTrace,
                    messageToUser = errorModel?.messageToUser
                )

                /* Completable.fromAction {
                     localDb!!.liteFseProspectResponseDao().insert(value)
                 }.mergeWith {
                     if (errorOccurred) {
                         Completable.fromAction {
                             localDb!!.liteFseErrorDao().insert(fseError)
                         }
                     }
                 }*/

                val list = mutableListOf<Completable>()

                list.add(
                    Completable.fromAction {
                        localDb!!.liteFseProspectResponseDao().insert(value)
                    }
                )
                if (errorOccurred) {
                    list.add(
                        Completable.fromAction {
                            localDb!!.liteFseErrorDao().insert(fseError)
                        }
                    )
                }

                /* if (!isChanged){
                     list.add(
                             Completable.fromAction {
                                 localDb!!.liteFseErrorDao().deleteProspectById(prospectId)
                             }
                     )
                 }*/

                Completable.merge(list)


            }
    }

    fun destroy() {

        Log.d(TAG, "Repo : Distroyed");
        bag.clear()

    }


    /*fun onFailedToApprove(prospectID: String): MutableLiveData<OtpApprovalRequest> {

        val data = MutableLiveData<OtpApprovalRequest>()

        localDb?.let { appDatabase ->
            bag.add(

                    appDatabase.liteOtpApprovalRequestDao().getByProspectID(prospectID)!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            *//*.flatMap {
                                var otpApprovalRequest = it
                                if (otpApprovalRequest != null) {
                                    otpApprovalRequest.unsuccessfulAttempts = otpApprovalRequest.unsuccessfulAttempts + 1
                                } else {
                                    otpApprovalRequest = OtpApprovalRequest(prospectID = prospectID, unsuccessfulAttempts = 1)
                                }
                                Single.create<OtpApprovalRequest> { emitter ->
                                    try {
                                        val result = appDatabase.liteOtpApprovalRequestDao().insert(otpApprovalRequest)

                                        result?.let {
                                            emitter.onSuccess(otpApprovalRequest)
                                        }


                                    } catch (e: Exception) {
                                        emitter.onError(e)
                                    }
                                }
                            }*//*
                            .subscribe({
                                onFailedToApproveLogic(data, it, prospectID)
                                Log.d(TAG, "DB-EO-List: ${""}")
                            }, { t ->
                                onFailedToApproveLogic(data, null, prospectID)
                                Log.d(TAG, "API-Error: ${t.localizedMessage}")
                            })

            )
        }
        return data
    }*/


    /*private fun onFailedToApproveLogic(liveData: MutableLiveData<OtpApprovalRequest>, otpApprovalRequest: OtpApprovalRequest?, prospectID: String): Disposable {
        return Completable.fromAction {
            var request = otpApprovalRequest
            if (request != null) {
                request.unsuccessfulAttempts = request.unsuccessfulAttempts + 1
            } else {
                request = OtpApprovalRequest(prospectID = prospectID, unsuccessfulAttempts = 1)
            }
            localDb?.liteOtpApprovalRequestDao()?.insert(request)
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({

                    liveData.postValue(otpApprovalRequest)

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }*/


    ///new

    private fun syncServerOtpApprovalRequestModel(otpApprovalRequest: LiteOtpApprovalRequestModel): Single<NewCommonResponseModel<NewEmptyParcelable>> {


        return ServiceInstance.getInstance(context).service?.postLiteOtpApproval(
            otpApprovalRequestModel = otpApprovalRequest
        )!!
            .subscribeOn(Schedulers.newThread())
            .onErrorResumeNext { it ->

                /*val error = it as HttpException
                val errorBody = error.response().errorBody()?.string()
                val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)
*/

                val isApi = it is retrofit2.HttpException

                var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                if (isApi) {
                    val error = it as HttpException
                    val errorBody = error.response().errorBody()?.string()
                    errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(
                        errorBody,
                        NewCommonResponseModel::class.java
                    )

                } else {


                    errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                        error = NewCommonResponseModel.Error(
                            messageToUser = it.localizedMessage
                        ),
                        success = false

                    )

                }


                performIsChanged(
                    prospectId = otpApprovalRequest.prospectId,
                    isChanged = false,
                    increment = otpApprovalRequest.otpVerificationTime.isNullOrBlank(),
                    errorOccurred = true,
                    errorModel = errorModel?.error
                )
                    .toSingleDefault(true)
                    .onErrorReturnItem(false)
                    .flatMap {
                        Single.just(NewCommonResponseModel<NewEmptyParcelable>())
                    }


            }


    }

    private fun syncInsertOtpApprovalRequestModel(single: Single<LiteOtpApprovalRequestModel>): Single<LiteOtpApprovalRequestModel> {

        return single.flatMap {
            insertOtpApprovalToDatabase(it)
        }
    }


    private fun syncLoopOtpApprovalRequestModel(otpApprovalRequestModels: List<LiteOtpApprovalRequestModel>): Single<List<LiteOtpApprovalRequestModel>> {


        val requests = mutableListOf<Single<NewCommonResponseModel<NewEmptyParcelable>>>()

        otpApprovalRequestModels.forEach {
            requests.add(syncServerOtpApprovalRequestModel(it))
        }

        return Single.zip(requests) {
            otpApprovalRequestModels
        }
    }


    private fun syncAllInsertOtpApprovalRequestModel(allSingles: Single<List<LiteOtpApprovalRequestModel>>): Single<List<LiteOtpApprovalRequestModel>> {
        return allSingles.flatMap {
            insertAllOtpApprovalToDatabase(it)
        }

    }

    private fun insertAllOtpApprovalToDatabase(otpApprovalRequestModels: List<LiteOtpApprovalRequestModel>): Single<List<LiteOtpApprovalRequestModel>> {

        return Single.create { emitter ->

            try {
                val result =
                    localDb!!.liteOtpApprovalRequestDao().insertAll(otpApprovalRequestModels)
                result.let {
                    emitter.onSuccess(otpApprovalRequestModels)
                }

            } catch (e: Exception) {
                emitter.onError(e)
            }
        }
    }

    fun processAll(otpApprovalRequestModels: List<LiteOtpApprovalRequestModel>): Single<List<LiteOtpApprovalRequestModel>> {
        return syncLoopOtpApprovalRequestModel(otpApprovalRequestModels).flatMap {
            insertAllOtpApprovalToDatabase(it)
        }
    }

    fun getFseProspectiveFromServer(
        angazaId: String,
        prospectId: String
    ): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>? {

        val data = MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>()

        var value: NewCommonResponseModel<LiteFseProspectItemResponseModel>? = null

        bag.add(

            localDb!!.liteFseProspectResponseDao().getByProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable { prospectFromDatabase ->
                    // here delete all data from database
                    Completable.fromAction {
                        localDb!!.liteFseProspectResponseDao().delete(prospectFromDatabase)
                    }.doOnError {
                        Log.d(TAG, "Error-2: ${it.localizedMessage}");
                        data.postValue(
                            NewCommonResponseModel<LiteFseProspectResponseModel>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from server"
                                ),
                                success = false
                            )
                        )
                        it.printStackTrace()
                    }.doOnComplete {
                        //ServiceInstance.getInstance(context).service?.getFseProspectives()!!
                        ServiceInstance.getInstance(context).service?.getLiteFseProspective(
                            angazaId,
                            prospectId,
                            territory = ""
                        )!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                value = it!!

                                val fromDatabase = prospectFromDatabase

                                var fromServer = value!!.responseData!!.prospect!!

                                var oldChangedData: LiteFseProspectResponseModel? = null

                                //notNewAddedServerValue.forEach { itemServer ->

                                val sameDataInDatabase = fromDatabase

                                fun statusUpdateTimeHandler(
                                    oldStatus: LiteFseProspectResponseModel.StatusUpdateTime,
                                    newStatus: LiteFseProspectResponseModel.StatusUpdateTime,
                                    oldFseProspectResponseModel: LiteFseProspectResponseModel
                                ): LiteFseProspectResponseModel.StatusUpdateTime {
                                    var revisedStatus = oldStatus

                                    if (!newStatus.prospect.isNullOrEmpty()) {
                                        revisedStatus.prospect = newStatus.prospect
                                    }


                                    if (!newStatus.otpApproved.isNullOrEmpty()) {
                                        revisedStatus.otpApproved = newStatus.otpApproved
                                    }


                                    if (!newStatus.preApprovedProspect.isNullOrEmpty()) {
                                        revisedStatus.preApprovedProspect =
                                            newStatus.preApprovedProspect
                                    }

                                    if (!newStatus.checkedIn.isNullOrEmpty()) {
                                        revisedStatus.checkedIn = newStatus.checkedIn
                                    }

                                    if (!newStatus.threeWayCallVerification.isNullOrEmpty()) {
                                        revisedStatus.threeWayCallVerification =
                                            newStatus.threeWayCallVerification
                                    }

                                    if (!newStatus.installationPending.isNullOrEmpty()) {
                                        revisedStatus.installationPending =
                                            newStatus.installationPending
                                    }


                                    if (oldFseProspectResponseModel.reattemptedStage != 1 || oldFseProspectResponseModel.reattemptedStage != 2) {
                                        if (!newStatus.installed.isNullOrEmpty()) {
                                            revisedStatus.installed = newStatus.installed
                                        }

                                        if (!newStatus.installationVerified.isNullOrEmpty()) {
                                            revisedStatus.installationVerified =
                                                newStatus.installationVerified
                                        }
                                    }

                                    return revisedStatus
                                }

                                fun statusHandler(oldStatus: String, newStatus: String): String {
                                    var revisedStatus = ""

                                    when (oldStatus) {
                                        FseProspectiveConstant.ProspectStatus.PROSPECT -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.OTP_APPROVED) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PROSPECT
                                            }

                                        }

                                        FseProspectiveConstant.ProspectStatus.OTP_APPROVED -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.CHECKED_IN) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.CHECKED_IN -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            } else if (newStatus == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLED) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLED
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.INSTALLED -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                            } else if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLED
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                            }
                                        }

                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            }
                                        }

                                        else -> {
                                            revisedStatus =
                                                FseProspectiveConstant.ProspectStatus.PROSPECT
                                        }

                                    }

                                    return revisedStatus
                                }

                                sameDataInDatabase?.let {

                                    sameDataInDatabase.approved = fromServer.approved
                                    sameDataInDatabase.message = fromServer.message
                                    sameDataInDatabase.customerAddress = fromServer.customerAddress

                                    sameDataInDatabase.name = fromServer.name
                                    sameDataInDatabase.otp = fromServer.otp
                                    sameDataInDatabase.productName = fromServer.productName
                                    sameDataInDatabase.status = statusHandler(
                                        sameDataInDatabase.status!!,
                                        fromServer.status!!
                                    )
                                    sameDataInDatabase.statusUpdateTime = statusUpdateTimeHandler(
                                        sameDataInDatabase.statusUpdateTime!!,
                                        fromServer.statusUpdateTime!!,
                                        sameDataInDatabase
                                    )
                                    sameDataInDatabase.ticketType = fromServer.ticketType
                                    sameDataInDatabase.accountNumber = fromServer.accountNumber
                                    sameDataInDatabase.installationPicture =
                                        fromServer.installationPicture
                                    sameDataInDatabase.customerPhoneNumber =
                                        fromServer.customerPhoneNumber
                                    sameDataInDatabase.area = fromServer.area

                                    oldChangedData = sameDataInDatabase

                                }
                                //need to add some new attributes here
                                //}


                                val resultData = oldChangedData


                                if (resultData != null) {

                                    //data.postValue(value)
                                    fromServer = resultData
                                    fseProspectiveFromServerLogic(
                                        data,
                                        NewCommonResponseModel(
                                            responseData = fromServer,
                                            success = true
                                        )
                                    )
                                    //add to database

                                } else {
                                    data.postValue(
                                        NewCommonResponseModel<LiteFseProspectResponseModel>(
                                            error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable get data from server"
                                            ),
                                            success = false
                                        )
                                    )
                                }
                            }, {
                                Log.d(TAG, "Error-1: ${it.localizedMessage}");

                                data.postValue(
                                    NewCommonResponseModel<LiteFseProspectResponseModel>(
                                        error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable get data from server"
                                        ),
                                        success = false
                                    )
                                )

                                it.printStackTrace()
                            })
                    }
                }.doOnError {
                    Log.d(TAG, "Error-1: ${it.localizedMessage}");
                    data.postValue(
                        NewCommonResponseModel<LiteFseProspectResponseModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from server"
                            ),
                            success = false
                        )
                    )
                    it.printStackTrace()
                }.subscribe({
//                    Log.d(TAG, " on Success ===");
                }, {
                    Log.d(TAG, " Error:${it.printStackTrace()}");
                })

        )

        return data
    }

    private fun fseProspectiveFromServerLogic(
        liveData: MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>,
        responseData: NewCommonResponseModel<LiteFseProspectResponseModel>
    ) {

        bag.add(
            Completable.fromAction {
                localDb?.liteFseProspectResponseDao()?.insert(responseData.responseData!!)
            }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Insertion:Completed ")
                    preference?.setFseProspectLastSynced(Util.getCurrentLocalFormattedDateForSync())
                    liveData.postValue(responseData)
                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })
        )

    }

    fun getAllVerificationFSE(): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {

        val data = MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>()


        localDb?.let { appDatabase ->
            bag.add(

                appDatabase.liteFseProspectResponseDao().getAll()
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        Log.d(TAG, "DB-EO-List: ${it}")

                        var list =
                            it.filter { it.status == FseProspectiveConstant.ProspectStatus.PROSPECT || it.status == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL }

                        data.postValue(
                            NewCommonResponseModel<LiteFseProspectResponseData>(
                                responseData = LiteFseProspectResponseData(prospects = list),
                                success = true
                            )
                        )
                    }, { t ->
                        Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        data.postValue(
                            NewCommonResponseModel<LiteFseProspectResponseData>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable to find data in database"
                                ),
                                success = false
                            )
                        )
                    })

            )
        }

        return data
    }


}
