package com.greenlightplanet.kazi.agentReferral.model.submitAgent


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Sms(
    @SerializedName("message")
    var message: String?,
    @SerializedName("mobileNumbers")
    var mobileNumbers: String?
) : Parcelable