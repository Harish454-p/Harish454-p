package com.greenlightplanet.kazi.incentivenew.common_utils

object Constants {
    const val ANGAZA_ID_INTENT = "angaza_id_incentive"
    const val INCENTIVE_WEEK_INTENT = "incentive_week"
    const val TOTAL_COMMISSION_INTENT = "incentive_total_commission"
    const val COMMISSION_INTENT = "incentive_commission"
    const val PRODUCT_NAME_INTENT = "product_name"
    const val PAGE_SIZE = 2

}