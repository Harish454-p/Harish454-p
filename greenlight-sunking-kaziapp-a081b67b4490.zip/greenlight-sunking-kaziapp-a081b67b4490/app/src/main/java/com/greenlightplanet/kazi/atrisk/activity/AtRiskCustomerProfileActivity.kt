package com.greenlightplanet.kazi.atrisk.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.view.View
import com.greenlightplanet.kazi.atrisk.model.AtRiskAccountModel
import com.greenlightplanet.kazi.databinding.ActivityAtriskCustomerDetailsBinding
import com.greenlightplanet.kazi.liteFseProspective.view.activity.MapsCheckActivity
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener

class AtRiskCustomerProfileActivity : BaseActivity() {

    companion object {
        public const val TAG = "AtRiskCustomerProfileActivity"

    }

    private lateinit var binding: ActivityAtriskCustomerDetailsBinding

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)
        outState.clear()
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        savedInstanceState.clear()
    }

    var preference: GreenLightPreference? = null
    var mHomeWatcher: HomeWatcher? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_atrisk_customer_details)
        binding = ActivityAtriskCustomerDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initialize()

        var data = intent.getBundleExtra("data")


        var customerData =
            data?.getParcelable<AtRiskAccountModel.CollectionAccount>("collectionAccount")


        if (customerData != null) {

            setCustomerDetails(customerData)
        }

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                finish()
            }
        })
        mHomeWatcher!!.startWatch()

    }


    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();

    }

    @SuppressLint("SetTextI18n")
    private fun setCustomerDetails(customerData: AtRiskAccountModel.CollectionAccount) {

        val symbol = preference?.getCountryResponseModel()?.countryCurrency ?: "NA"

        binding.tvCustomerAccount.text = customerData.accountNumber.toString()
        binding.tv1stPhoneNumber.text = customerData.ownerPhoneNumber.toString()
        binding.tv2PhoneNumber.text = customerData.secondaryPhoneNumber.toString()
        binding.tvCustomerName.text = customerData.customerName.toString()
        binding.tvDaysDisabled.text = customerData.daysDisabled.toString()

        if (customerData.lastPaidDate.isNullOrBlank()) {
            binding.tvLastPayment.text = "NA"
        } else {
            binding.tvLastPayment.text =
                Util.parseYYYY_MM_DDtoDD_MM_YYYY(customerData.lastPaidDate.toString())
        }

        binding.tvCustomerAddress.text = customerData.address ?: "NA"
        binding.tvProductName.text = customerData.product_name.toString()
        customerData.registrationDate?.let {
            binding.tvRegDate.text = Util.parseYYYY_MM_DDtoDD_MM_YYYY(customerData.registrationDate)
        }
        binding.tvStatus.text = customerData.status.toString()

        binding.tvBalanceAmt.text =
            Util.checkBlank(customerData.balanceAmount.toString(), context = this).toDouble()
                .let { Util.formatAmount(it) } + " " + symbol       // tvTotalAmtPaid?.setText(customerData.totalPaid.toString())
        binding.tvTotalAmtPaid.text =
            Util.checkBlank(customerData.totalPaid?.toString(), context = this).toDouble()
                .let { Util.formatAmount(it) } + " " + symbol

        binding.tvExpectedPaid.text =
            Util.checkBlank(customerData.expectedPaid.toString(), context = this).toDouble()
                .let { Util.formatAmount(it) } + " " + symbol


        if (customerData.latitude == 0.0 || customerData.longitude == 0.0) {
            binding.imgLoc.visibility = View.INVISIBLE
        } else {
            binding.imgLoc.visibility = View.VISIBLE
        }
        binding.imgLoc.setOnClickListener {
            val intent = Intent(this, MapsCheckActivity::class.java)
            intent.putExtra("LAT", customerData.latitude)
            intent.putExtra("LONG", customerData.longitude)
            intent.putExtra("NAME", customerData.customerName)
            startActivity(intent)
        }


        binding.btnFirstCall.setOnClickListener {

        }
    }


    fun initialize() {

        Util.setToolbar(this, this.binding.toolbar)
        preference = GreenLightPreference.getInstance(this)

    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
