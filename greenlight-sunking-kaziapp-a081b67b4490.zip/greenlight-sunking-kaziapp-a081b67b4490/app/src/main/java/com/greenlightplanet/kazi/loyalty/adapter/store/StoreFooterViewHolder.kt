package com.greenlightplanet.kazi.loyalty.adapter.store

import android.view.LayoutInflater
import android.view.View
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.ItemListFooterBinding
import com.greenlightplanet.kazi.loyalty.pagging.State

/**
 * Created by Rahul on 08/04/21.
 */
class StoreFooterViewHolder(val itemBinding:  ItemListFooterBinding) : RecyclerView.ViewHolder(itemBinding.root) {

    fun bind(status: State?) {
        itemBinding.txtNodata.text="No more items available"
        itemBinding.txtError.text="No more items available"
        itemBinding.progressBar.visibility = if (status == State.LOADING) VISIBLE else View.INVISIBLE
        itemBinding.txtError.visibility = if (status == State.ERROR) VISIBLE else View.INVISIBLE
        itemBinding.txtNodata.visibility = if (status == State.OFFLINE) VISIBLE else View.INVISIBLE

    }

    companion object {
        fun create(retry: () -> Unit, parent: ViewGroup): StoreFooterViewHolder {
            val itemBinding = ItemListFooterBinding.inflate( LayoutInflater.from(parent.context)
                    , parent, false)
            itemBinding.txtError.setOnClickListener { retry() }
            return StoreFooterViewHolder(itemBinding)
        }
    }
}