package com.greenlightplanet.kazi.fse.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.fse.model.Fse
import com.greenlightplanet.kazi.fse.model.FseDetailsResponse
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.tvinstallation.model.FseCustomerResponse
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.Completable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

class FseCommitmentRepo(val context: Context) {

    companion object :
            SingletonHolderUtil<FseCommitmentRepo, Context>(::FseCommitmentRepo) {
        public const val TAG = "FseCommitmentRepo"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null

    var preference: GreenLightPreference? = null

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context!!)

        } catch (e: Exception) {
            Log.d(TAG, ":Error ");
        }
    }

    //working fine
    /*fun getFseCommitmentFromServer(): MutableLiveData<List<Fse>?> {

        val data = MutableLiveData<List<Fse>?>()

        bag.add(

                ServiceInstance.getInstance(this).service?.getFseDetails(url = "http://demo8859911.mockable.io/fse-details/US029933")!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success.responseData?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")

                                bag.add(

                                        //localDb.fseDao().deleteAll().toCompletable()
                                        Completable.fromAction { localDb.fseDao().deleteAll() }
                                                .subscribeOn(Schedulers.io())
                                                .observeOn(Schedulers.io())
                                                .subscribe({

                                                    Log.d(TAG, "Deletion:Completed ")

                                                    bag.add(
                                                            //localDb.fseDao().insertAll(responseData.fseList!!).toSingle()
                                                            Completable.fromAction { localDb.fseDao().insertAll(responseData.fseList!!) }
                                                                    .subscribeOn(Schedulers.io())
                                                                    .observeOn(Schedulers.io())
                                                                    .subscribe({
                                                                        Log.d(TAG, "Insertion:Completed ")
                                                                        data.postValue(responseData.fseList as List<Fse>?)
                                                                    }, { t ->
                                                                        Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                                                    })
                                                    )

                                                }, { t ->
                                                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                                })
                                )

                            }

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        })
        )

        return data
    }*/

    //todo current version workig fine
    /*fun getFseCommitmentFromServer(angazaId: String): MutableLiveData<List<Fse>?> {

        val data = MutableLiveData<List<Fse>?>()

        bag.add(

                ServiceInstance.getInstance(this).service?.getFseDetails(angazaId)!!
                        //ServiceInstance.getInstance(this).service?.getFseDetails(url = "http://demo8859911.mockable.io/fse-details/US029933")!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success.responseData?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")

                                bag.add(

                                        fseServerResponseLogic(data, responseData)
                                )
                            }

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        })
        )

        return data
    }*/

    //todo current version workig fine
    /*fun getFseCommitmentFromDatabase(): MutableLiveData<List<Fse>?> {

        val data = MutableLiveData<List<Fse>?>()

        localDb?.let {
            bag.add(

                    it.fseDao().getAll()
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({ success ->

                                Log.d(TAG, "DB-EO-List: ${success}")

                                data.postValue(success)

                            }, { t ->
                                Log.d(TAG, "API-Error: ${t.localizedMessage}")
                            })
            )
        }



        return data
    }*/

    //todo old but working
    /*fun postFseCommitmentDetails(angazaId: String, fseList: List<Fse>): MutableLiveData<List<Fse>?> {

        val data = MutableLiveData<List<Fse>?>()

        bag.add(

                ServiceInstance.getInstance(this).service?.postFseCommitmentDetails(
                        angazaId = angazaId,
                        fseResponseData = FseDetailsResponse.ResponseData(fseList = fseList))!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success.responseData?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")

                                preference?.setIsCommitmentConfirmed(responseData.isCommitmentConfirmed)

                                bag.add(
                                        fseServerResponseLogic(data, responseData)
                                )

                            }

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        })

        )

        return data

    }*/

    //todo new post
    fun postNewFseCommitmentDetails(angazaId: String, fseList: List<Fse>): MutableLiveData<FseDetailsResponse.ResponseData> {

        val data = MutableLiveData<FseDetailsResponse.ResponseData>()

        bag.add(

                ServiceInstance.getInstance(context).service?.postFseCommitmentDetails(
                        angazaId = angazaId,
                        fseResponseData = FseDetailsResponse.ResponseData(id = 0, fseList = fseList),
                        country = (preference?.getLoginResponseModel()!!.country!!)!! ?: "")!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success.responseData?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")

                                preference?.setIsCommitmentConfirmed(responseData.isCommitmentConfirmed)

                                bag.add(
                                        newFseServerResponseLogic(data, responseData)
                                )

                            }

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        })

        )

        return data

    }

    //todo new fse from server
    fun getNewFseCommitmentFromServer(angazaId: String): MutableLiveData<FseDetailsResponse.ResponseData> {

        //var data: MutableLiveData<FseDetailsResponse.ResponseData>? = null
        var data: MutableLiveData<FseDetailsResponse.ResponseData> = MutableLiveData<FseDetailsResponse.ResponseData>()


        bag.add(

                ServiceInstance.getInstance(context).service?.getFseDetails(angazaId, country = (preference?.getLoginResponseModel()!!.country!!)!!
                        ?: "")!!
                        //ServiceInstance.getInstance(this).service?.getFseDetails(url = "http://demo8859911.mockable.io/fse-details/US029933")!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success.responseData?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")
                                //data = MutableLiveData<FseDetailsResponse.ResponseData>()

                                bag.add(

                                        newFseServerResponseLogic(data!!, responseData)
                                )
                            }

                        }, { t ->

                            Log.d(TAG, "API-Error3: ${t.localizedMessage}")

                            data.postValue(null)
                            //data = getNewFseCommitmentFromDatabase()
                        })
        )

        return data
    }

    //todo new fse from database
    fun getNewFseCommitmentFromDatabase(): MutableLiveData<FseDetailsResponse.ResponseData> {

        val data = MutableLiveData<FseDetailsResponse.ResponseData>()

        localDb?.let { appDatabase ->
            bag.add(

                    appDatabase.fseResponseDataDao().get().flatMap { responseData ->
                        appDatabase.fseDao().getAll()
                                .subscribeOn(Schedulers.io())
                                .observeOn(Schedulers.io())
                                .doOnSuccess {
                                    Log.d(TAG, "DB-EO-List: ${it}")
                                    responseData.fseList = it
                                    data.postValue(responseData)

                                }.doOnError { t ->
                                    Log.d(TAG, "API-Error: ${t.localizedMessage}")
                                    data.postValue(null)
                                }
                        //.subscribe()
                        /*.subscribe({ success ->

                            Log.d(TAG, "DB-EO-List: ${success}")

                            data.postValue(success)

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        }) */
                    }.subscribe({}, { t ->
                        data.postValue(null)
                        Log.d(TAG, "API-Error2: ${t.localizedMessage}")
                    })

            )
        }


        return data
    }

    //todo old working logic
    /*private fun fseServerResponseLogic(liveData: MutableLiveData<List<Fse>?>, responseData: FseDetailsResponse.ResponseData): Disposable {
        return Completable.fromAction { localDb?.fseDao()?.deleteAll() }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({

                    Log.d(TAG, "Deletion:Completed ")

                    localDb?.let {
                        bag.add(
                                //localDb.fseDao().insertAll(responseData.fseList!!).toSingle()
                                Completable.fromAction { it.fseDao().insertAll(responseData.fseList!!) }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            Log.d(TAG, "Insertion:Completed ")
                                            liveData.postValue(responseData.fseList as List<Fse>?)
                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                        })
                        )
                    }


                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }*/

    //todo new logic
    private fun newFseServerResponseLogic(liveData: MutableLiveData<FseDetailsResponse.ResponseData>, responseData: FseDetailsResponse.ResponseData): Disposable {
        return Completable.fromAction {
            localDb?.fseDao()?.deleteAll()
            localDb?.fseResponseDataDao()?.deleteAll()
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({

                    Log.d(TAG, "Deletion:Completed ")

                    localDb?.let {
                        bag.add(
                                //localDb.fseDao().insertAll(responseData.fseList!!).toSingle()
                                Completable.fromAction {
                                    it.fseDao().insertAll(responseData.fseList!!)
                                    it.fseResponseDataDao().insert(responseData)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            Log.d(TAG, "Insertion:Completed ")
                                            liveData.postValue(responseData)
                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }

    fun getFseCount(): MutableLiveData<Int> {

        val data = MutableLiveData<Int>()


        localDb?.let {

            bag.add(

                    it.fseCustomerResponseDataDao().get()
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({

                                it?.let {
                                    Log.d(TAG, "count3:$it ");
                                    it.fseList?.size

                                    Log.d(TAG, "DB-getFseCount: ${it?.fseList?.size}")

                                    data.postValue(it?.fseList?.size ?: 0)
                                } ?: run {
                                    data.postValue(0)

                                }


                            }, { t ->
                                data.postValue(0)
                                Log.d(TAG, "getFseCount-Error: ${t.localizedMessage}")
                            })
            )

        }



        return data
    }

    //new for attendence
    fun getNewFseCustomerFromServer(angazaId: String): MutableLiveData<FseCustomerResponse.ResponseData> {

        val data = MutableLiveData<FseCustomerResponse.ResponseData>()

        bag.add(

                ServiceInstance.getInstance(context).service?.getFseCustomer(angazaId, country = (preference?.getLoginResponseModel()!!.country!!)!!
                        ?: "")!!
                        //ServiceInstance.getInstance(this).service?.getFseDetails(url = "http://demo8859911.mockable.io/fse-details/US029933")!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success.responseData?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")

                                bag.add(

                                        newFseCustomerServerResponseLogic(data, responseData)
                                )
                            }

                        }, { t ->
                            Log.d(TAG, "API-Error1: ${t.localizedMessage}")
                        })
        )

        return data
    }

    //todo new logic
    private fun newFseCustomerServerResponseLogic(liveData: MutableLiveData<FseCustomerResponse.ResponseData>, responseData: FseCustomerResponse.ResponseData): Disposable {
        return Completable.fromAction {
            //localDb?.fseDao()?.deleteAll()
            localDb?.fseCustomerResponseDataDao()?.deleteAll()
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({

                    Log.d(TAG, "Deletion:Completed ")

                    localDb?.let {
                        bag.add(
                                //localDb.fseDao().insertAll(responseData.fseList!!).toSingle()
                                Completable.fromAction {
                                    //it.fseDao().insertAll(responseData.fseList!!)
                                    it.fseCustomerResponseDataDao().insert(responseData)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            Log.d(TAG, "Insertion:Completed ")
                                            liveData.postValue(responseData)
                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                        })
                        )
                    }


                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }

    fun getNewFseCustomerFromDatabase(): MutableLiveData<FseCustomerResponse.ResponseData> {

        val data = MutableLiveData<FseCustomerResponse.ResponseData>()

        localDb?.let { appDatabase ->
            bag.add(

                    appDatabase.fseCustomerResponseDataDao().get()
                            /*.flatMap { responseData ->
                                appDatabase.fseDao().getAll()
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .doOnSuccess {
                                            Log.d(TAG, "DB-EO-List: ${it}")
                                            responseData.fseList = it
                                            data.postValue(responseData)

                                        }.doOnError { t ->
                                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                                            data.postValue(null)
                                        }*/
                            //.subscribe()
                            /*.subscribe({ success ->

                                Log.d(TAG, "DB-EO-List: ${success}")

                                data.postValue(success)

                            }, { t ->
                                Log.d(TAG, "API-Error: ${t.localizedMessage}")
                            }) */
                            //}
                            .subscribe({
                                Log.d(TAG, "DB-List: ${it}")
                                data.postValue(it)
                            }, { t ->
                                data.postValue(null)
                                Log.d(TAG, "API-Error: ${t.localizedMessage}")
                            })
            )
        }


        return data
    }

    fun destroy() {

        Log.d(TAG, "Repo : Distroyed");
        bag.clear()

    }


}
