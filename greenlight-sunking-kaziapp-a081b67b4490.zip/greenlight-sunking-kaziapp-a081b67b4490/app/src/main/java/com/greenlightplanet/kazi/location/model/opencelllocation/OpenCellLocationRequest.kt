package com.greenlightplanet.kazi.location.model.opencelllocation


import com.google.gson.annotations.SerializedName

data class OpenCellLocationRequest(
    @SerializedName("address")
    var address: Int?, // 1
    @SerializedName("cells")
    var cells: List<Cell>?,
    @SerializedName("mcc")
    var mcc: Int?, // 310
    @SerializedName("mnc")
    var mnc: Int?, // 404
    @SerializedName("radio")
    var radio: String?, // gsm
    @SerializedName("token")
    var token: String? // 5f0335b7fbf91b
)
