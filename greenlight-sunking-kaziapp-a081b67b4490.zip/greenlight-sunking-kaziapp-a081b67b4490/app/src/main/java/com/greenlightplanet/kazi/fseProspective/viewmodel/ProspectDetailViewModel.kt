package com.greenlightplanet.kazi.fseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.location.Location
import android.util.Log
import com.greenlightplanet.kazi.fseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.fseProspective.model.*
import com.greenlightplanet.kazi.fseProspective.repo.InstallationRepo
import com.greenlightplanet.kazi.fseProspective.repo.RegistrationRepo
import com.greenlightplanet.kazi.fseProspective.repo.VerificationRepo
import com.greenlightplanet.kazi.liteFseProspective.model.LiteAwsImageModel
import com.greenlightplanet.kazi.liteFseProspective.model.LiteInstallationRequestModel
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.networking.CommonResponseModel

import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel

class ProspectDetailViewModel(application: Application) : AndroidViewModel(application) {

	companion object {
		public const val TAG = "ProspectDetailViewModel"
	}


	val verificationRepo = VerificationRepo.getInstance(application)
	val registrationRepo = RegistrationRepo.getInstance(application)
	val installationRepo = InstallationRepo.getInstance(application)


	//start verificationRepo
	fun processOtp(context: Context, isOnline: Boolean, isValid: Boolean, prospectID: String, angazaId: String, unsuccessfulAttempt: Int = 0, country: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

		showProgress()

		if (isValid) {
			return verificationRepo.onValidOtp(isOnline, prospectID, angazaId, country)
		} else {
			return verificationRepo.onInvalidOtp(isOnline, prospectID, angazaId, unsuccessfulAttempt, country)
		}
	}

	fun getCombineRequestModelVerification(prospectID: String): MutableLiveData<CombineRequestModel?> {
		return verificationRepo.getCombineRequestModel(prospectID)
	}

	fun sendOtpApprovalToServerForceUpload(isValid: Boolean, otpApprovalRequest: OtpApprovalRequestModel, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
		showProgress()
		return verificationRepo.sendOtpApprovalToServerForceUpload(isValid, otpApprovalRequest)
	}

	fun getFseProspectiveFromServerVerification(angazaId: String, prospectId: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>? {
		showProgress()
		return verificationRepo.getFseProspectiveFromServer(angazaId, prospectId)
	}
	//end verificationRepo

	//getCombineRequestModel //getFseProspectiveFromServer

	//start registrationRepo
	fun processCheckIn(context: Context, isOnline: Boolean, prospectID: String, angazaId: String, area: String,  prospectAllowedDistance: Int,showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {
		showProgress()
		return registrationRepo.performCheckin(context, isOnline, prospectID, angazaId, area,prospectAllowedDistance)
	}

	fun processCheckIn2(context: Context, isOnline: Boolean, prospectID: String, angazaId: String, area: String, location: Location, prospectAllowedDistance: Int, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {
		showProgress()
		return registrationRepo.performCheckin2(context, isOnline, prospectID, angazaId, area, location,prospectAllowedDistance)
	}

	fun getCombineRequestModelRegistration(prospectID: String): MutableLiveData<CombineRequestModel?> {
		return registrationRepo.getCombineRequestModel(prospectID)
	}

	fun sendRegistrationCheckinRequestToServerForceUpload(registrationCheckinRequestModel: RegistrationCheckinRequestModel, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
		showProgress()
		return registrationRepo.sendRegistrationCheckinRequestToServerForceUpload(registrationCheckinRequestModel)
	}

	fun getFseProspectiveFromServerRegistration(angazaId: String, prospectId: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>? {
		showProgress()
		return registrationRepo.getFseProspectiveFromServer(angazaId, prospectId)
	}
	//end registrationRepo

	//start installationRepo
	fun compressImageForAws(context: Context, files: List<ImageUploadUtil.ImageModel>, showProgress: () -> Unit = {}): MutableLiveData<List<AwsImageModel>?> {
		showProgress()
		return installationRepo.compressImageForAws(context, files)
	}

	fun performInstallation(context: Context, fseProspectResponseModel: FseProspectResponseModel?, isOnline: Boolean, prospectId: String, angazaId: String, accountNumber: String, installationAttempted: Int, fileModel: List<AwsImageModel>, location: Location, imageName: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
		showProgress()
		return installationRepo.performInstallation(context, fseProspectResponseModel, isOnline, prospectId, angazaId, accountNumber, installationAttempted, fileModel/*, location*/)
	}

	fun performInstallation2(context: Context, fseProspectResponseModel: FseProspectResponseModel?, isOnline: Boolean, prospectId: String, fileModel: List<AwsImageModel>, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
		showProgress()
		return installationRepo.performInstallation2(context, fseProspectResponseModel, isOnline, prospectId, fileModel)
	}

	fun insertAwsImageModelToDatabase(inputFiles: List<AwsImageModel>, isUploadedToAws: Boolean): MutableLiveData<List<AwsImageModel>?> {
		return installationRepo.insertAwsImageModelToDatabase(inputFiles, isUploadedToAws)
	}

	fun getAllAwsImageModelByProspectId(prospectId: String): MutableLiveData<List<AwsImageModel>> {
		return installationRepo.getAllAwsImageModelByProspectId(prospectId)
	}

	fun getCombineRequestModelInstallation(prospectId: String): MutableLiveData<CombineRequestModel> {
		return installationRepo.getCombineRequestModel(prospectId)
	}


	fun getAwsImageModelByProspectId(prospectId: String): MutableLiveData<AwsImageModel> {
		return installationRepo.getAwsImageModelByProspectId(prospectId)
	}

	fun sendInstallationRequestToServerForce(installationRequestModel: InstallationRequestModel, fileModel: List<AwsImageModel>, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
		showProgress()
		return installationRepo.sendInstallationRequestToServerForce(installationRequestModel, fileModel)
	}

	fun updateFseProspect(fseProspectResponseModel: FseProspectResponseModel): MutableLiveData<FseProspectResponseModel> {
		return installationRepo.updateFseProspect(fseProspectResponseModel)
	}

	fun getFseProspectiveFromServerInstallation(angazaId:String,prospectId:String,showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>? {
		showProgress()
		return installationRepo.getFseProspectiveFromServer(angazaId,prospectId)
	}

	fun awsRX(context: Context, requestModel: BaseRequestModel): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
		return installationRepo.awsRX(context, requestModel)
	}

	//end installationRepo


	override fun onCleared() {
		super.onCleared()
		Log.e("$TAG","onCleared === ")
//		verificationRepo.destroy()
//		registrationRepo.destroy()
//		installationRepo.destroy()
	}

}
