package com.greenlightplanet.kazi.leads.repo

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.leads.extras.AdapterUtils
import com.greenlightplanet.kazi.leads.extras.ErrorUtils
import com.greenlightplanet.kazi.leads.extras.LEAD_INTENT
import com.greenlightplanet.kazi.leads.extras.LEAD_STATUS
import com.greenlightplanet.kazi.leads.model.*
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.Flowable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

class CustomerLeadsRepo(val context: Context) {

    companion object : SingletonHolderUtil<CustomerLeadsRepo, Context>(::CustomerLeadsRepo) {
        public const val TAG = "CustomerLeadsR"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    private val angazaId: String? by lazy {
        preference?.getLoginResponseModel()?.angazaId
    }

    var gson: Gson? = null

    init {
        try {

            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context)
            gson = Gson()

        } catch (e: Exception) {
            Log.d(TAG, "Init:Error ");
        }
    }


    fun getCustomerLeadsFromServer(): MutableLiveData<NewCommonResponseModel<LeadsResponseModel>> {

        val data = MutableLiveData<NewCommonResponseModel<LeadsResponseModel>>()


        bag.add(

            ServiceInstance.getInstance(context).service?.newgetCrossSalesLead(angazaId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({ success ->
                    success.responseData?.let { response ->

                        Log.d(TAG, "getCustomerLeadsFromServer - success: ${success}")

                        if (response.leadVersion != preference?.getLeadFilterVersion()) {
                            bag.add(
                                performNewFilterLogic(success, data)
                            )

                        } else {
                            bag.add(insertLeadResponseModelToDb(success, data))
                        }
                        updateSharedPref(true)
                    }

                }, { t ->

                    data.postValue(
                        NewCommonResponseModel<LeadsResponseModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to get data from server"
                            ),
                            success = false
                        )
                    )
                })
        )

        return data
    }


    fun getCustomerLeadsFromDb(): MutableLiveData<NewCommonResponseModel<LeadsResponseModel>> {

        val data = MutableLiveData<NewCommonResponseModel<LeadsResponseModel>>()

        var result: NewCommonResponseModel<LeadsResponseModel>? = null

        bag.add(
            localDb?.leadsResponseModelDao()?.get()!!
                .flatMap {
                    result = NewCommonResponseModel(success = true, responseData = it)
                    localDb?.leadsCrossSalesLeadDao()?.getAll()
                }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({ success ->

                    Log.d(TAG, "getCustomerLeadsFromDb - success: ${success}")

                    result?.responseData?.crossSalesLeads = success

                    data.postValue(result)
                    updateSharedPref(false)

                }, { t ->

                    ErrorUtils.errorDatabase(
                        t,
                        TAG,
                        "getCustomerLeadsFromDb",
                        "Unable to get data from server",
                        data
                    )
                })
        )

        return data
    }


    fun insertLeadResponseModelToDb(
        data: NewCommonResponseModel<LeadsResponseModel>,
        liveData: MutableLiveData<NewCommonResponseModel<LeadsResponseModel>>
    ): Disposable {
        return Flowable.fromCallable {
            localDb?.leadsCrossSalesLeadDao()?.deleteAll()
        }.flatMap {
            Flowable.fromCallable {
                localDb?.leadsResponseModelDao()?.insert(data.responseData!!)
            }
        }.flatMap {
            Flowable.fromCallable {
                if (!data.responseData!!.crossSalesLeads.isNullOrEmpty()) {
                    localDb?.leadsCrossSalesLeadDao()
                        ?.insertAll(data.responseData!!.crossSalesLeads!!)
                }
            }
        }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe({
                if (!data.responseData!!.crossSalesLeads.isNullOrEmpty()) {
                    Log.d(TAG, "insertLeadResponseModelToDb - success: ${data}")
                    preference!!.setLeadsFollowupLimit(
                        data.responseData!!.leadFollowupLimit ?: "14"
                    )
                    liveData.postValue(data)
                } else {
                    liveData.postValue(
                        NewCommonResponseModel<LeadsResponseModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = context.resources.getString(R.string.no_data_available)
                            ),
                            success = false
                        )
                    )
                }
            }, { t ->
                if (data.responseData!!.equals(null)) {
                    ErrorUtils.errorDatabase(
                        t,
                        TAG,
                        "insertLeadResponseModelToDb",
                        "No data available",
                        liveData
                    )
                } else {
                    ErrorUtils.errorDatabase(
                        t,
                        TAG,
                        "insertLeadResponseModelToDb",
                        "Unable to save data to database",
                        liveData
                    )
                }
            })
    }

    fun performNewFilterLogic(
        data: NewCommonResponseModel<LeadsResponseModel>,
        liveData: MutableLiveData<NewCommonResponseModel<LeadsResponseModel>>
    ): Disposable {

        return ServiceInstance.getInstance(context).serviceTask?.newgetLeadsFilters(preference?.getLoginResponseModel()?.country)!!
            .flatMap {
                Single.fromCallable {
                    localDb?.leadsIntentDao()?.insertAll(it.responseData?.intents!!)
                }
            }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe({

                Log.d(TAG, "performNewFilterLogic - success: ${data}")
                bag.add(

                    insertLeadResponseModelToDb(data, liveData)
                )

            }, { t ->
                ErrorUtils.errorDatabase(
                    t,
                    TAG,
                    "performNewFilterLogic",
                    "Unable to save data to database",
                    liveData
                )
            })

    }

    fun getLeadsIntentFromDb(): MutableLiveData<List<LeadsIntent>> {

        val data = MutableLiveData<List<LeadsIntent>>()

        bag.add(
            localDb?.leadsIntentDao()?.getAll()!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({ success ->
                    Log.d(TAG, "getLeadsIntentFromDb - success: ${success}")
                    data.postValue(success)

                }, { t ->
                    ErrorUtils.errorDatabase(
                        t,
                        TAG,
                        "getLeadsIntentFromDb",
                        "Unable to get data from server",
                        data
                    )
                })
        )
        return data
    }


    fun insertCallDetailRequestToDb(callDetailRequestModel: CallDetailRequestModel): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        bag.add(
            insertLeadsCalledDetails(callDetailRequestModel)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "insertCallDetailRequestToDb - success: ${it}")
                    data.postValue(
                        NewCommonResponseModel(
                            success = true,
                            responseData = NewEmptyParcelable()
                        )
                    )

                }, { t ->
                    ErrorUtils.errorDatabase(
                        t,
                        TAG,
                        "insertCallDetailRequestToDb",
                        "Unable to save data to database",
                        data
                    )
                })
        )

        return data
    }


    fun solveCallDetailRequest(callDetailRequestModel: CallDetailRequestModel): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        bag.add(

            insertLeadsCalledDetails(callDetailRequestModel)
                .flatMap { solveLeadsCalledDetails(angazaId!!) }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "solveCallDetailRequest - success: ${it}")
                    data.postValue(it)
                }, { t ->
                    ErrorUtils.errorDatabase(
                        t,
                        TAG,
                        "solveCallDetailRequest",
                        "Unable to save data to database",
                        data
                    )
                })
        )

        return data
    }


    fun solveabc(): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        bag.add(
            solveLeadsCalledDetails(angazaId!!)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "solveabc - success: ${it}")
                    data.postValue(it)
                }, { t ->
                    ErrorUtils.errorDatabase(
                        t,
                        TAG,
                        "solveabc",
                        "Unable to save data to database",
                        data
                    )
                })
        )

        return data
    }


    private fun solveLeadsCalledDetails(angazaId: String): Single<NewCommonResponseModel<NewEmptyParcelable>?> {

        return localDb?.callDetailRequestModelDao()?.getAll()!!
            .flatMap {
                if (it.isNullOrEmpty()) {
                    Single.just(
                        NewCommonResponseModel(
                            success = false,
                            error = NewCommonResponseModel.Error(messageToUser = "No leads to solve")
                        )
                    )
                } else {
                    sendCallDetailRequestToServer(angazaId, CalledLeadsRequestModel(it))
                }
            }
    }

    private fun sendCallDetailRequestToServer(
        angazaId: String,
        calledLeadsRequestModel: CalledLeadsRequestModel
    ): Single<NewCommonResponseModel<NewEmptyParcelable>?> {

        var response: NewCommonResponseModel<NewEmptyParcelable>? = null

        return ServiceInstance.getInstance(context).service?.solveLeadsCallDetails(
            angazaId,
            calledLeadsRequestModel
        )!!
            .flatMap {
                response = it
                Single.fromCallable {
                    localDb?.callDetailRequestModelDao()?.deleteAll()
                }
            }
            .flatMap { Single.just(response) }
    }

    private fun insertLeadsCalledDetails(callDetailRequestModel: CallDetailRequestModel): Single<Any?> {

        return Single.fromCallable {
            localDb?.callDetailRequestModelDao()?.insert(callDetailRequestModel)
        }.flatMap {
            Log.d(
                TAG,
                "changedLeadsCrossSalesLead - accountNumber:${callDetailRequestModel.accountNumber.toString()} "
            );
            localDb?.leadsCrossSalesLeadDao()
                ?.getByAccountNumber(callDetailRequestModel.accountNumber.toString())
        }.flatMap {
            //val singleList = mutableListOf<Single<Any>>()
            Log.d(TAG, "calledTime:${callDetailRequestModel.calledTime} ");
            val changedLeadsCrossSalesLead = it

            if (changedLeadsCrossSalesLead.callDetails != null) {
                changedLeadsCrossSalesLead.callDetails?.add(
                    LeadsCallDetail(
                        attempt = callDetailRequestModel.attempt!!,
                        callDuration = callDetailRequestModel.callDuration,
                        calledDate = AdapterUtils.newVisitDateTOPromiseDateConverter2(
                            callDetailRequestModel.calledTime
                        ),//check this datetime formate
                        contactedNumber = callDetailRequestModel.contactedNumber,
                        intent = callDetailRequestModel.intentId,
                        newVisitDate = AdapterUtils.newVisitDateTOPromiseDateConverter(
                            callDetailRequestModel.newVisitDate
                        ),
                        otherReason = callDetailRequestModel.otherReason
                    )
                )
            } else {
                changedLeadsCrossSalesLead.callDetails = mutableListOf()
                changedLeadsCrossSalesLead.callDetails?.add(
                    LeadsCallDetail(
                        attempt = callDetailRequestModel.attempt!!,
                        callDuration = callDetailRequestModel.callDuration,
                        calledDate = AdapterUtils.newVisitDateTOPromiseDateConverter2(
                            callDetailRequestModel.calledTime
                        ),//check this datetime formate
                        contactedNumber = callDetailRequestModel.contactedNumber,
                        intent = callDetailRequestModel.intentId,
                        newVisitDate = AdapterUtils.newVisitDateTOPromiseDateConverter(
                            callDetailRequestModel.newVisitDate
                        ),
                        otherReason = callDetailRequestModel.otherReason
                    )
                )
            }

            Log.d(TAG, "changedLeadsCrossSalesLead:$changedLeadsCrossSalesLead ");

            if (callDetailRequestModel.intentId == LEAD_INTENT.CANCLE) {
                Single.fromCallable {
                    localDb?.leadsCrossSalesLeadDao()?.delete(changedLeadsCrossSalesLead)
                }
            } else {
                if (callDetailRequestModel.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
                    changedLeadsCrossSalesLead.status = LEAD_STATUS.CALLED
                }

                Single.fromCallable {
                    localDb?.leadsCrossSalesLeadDao()?.insert(changedLeadsCrossSalesLead)
                }
            }

        }
    }

    private fun updateSharedPref(fromInternet: Boolean) {
        var data: LastSaved? = OfferUtils.loadSummaryFromPref(context!!)
        if (data == null) {
            data = LastSaved()
            data.leadsCalls = "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveSummaryToPref(context, data)
        } else {

            if (fromInternet) {
                data.leadsCalls = "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveSummaryToPref(context, data)
            }
        }

    }

    fun destroy() {

        Log.d(TAG, "Repo : destroy");
        bag.clear()
    }
}