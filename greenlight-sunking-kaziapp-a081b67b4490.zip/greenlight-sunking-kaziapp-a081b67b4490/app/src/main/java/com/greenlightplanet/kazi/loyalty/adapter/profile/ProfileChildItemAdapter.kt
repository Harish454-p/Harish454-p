package com.greenlightplanet.kazi.loyalty.adapter.profile

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYou
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYouListener
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentProfileChildItemBinding
import com.greenlightplanet.kazi.loyalty.model.profile.EligibleEvents
import com.squareup.picasso.Picasso


/**
 * Created by Rahul on 06/04/21.
 */


class ProfileChildItemAdapter internal constructor(
    val childItemList: List<EligibleEvents>?,
    val context: Context
) : RecyclerView.Adapter<ProfileChildItemAdapter.ChildViewHolder?>() {
    private val ChildItemList: List<EligibleEvents>?

    @NonNull
    override fun onCreateViewHolder(
        @NonNull viewGroup: ViewGroup,
        i: Int
    ): ChildViewHolder {

        val itemBinding = FragmentProfileChildItemBinding.inflate(LayoutInflater.from(viewGroup.context)
               ,
                        viewGroup, false)
        return ChildViewHolder(itemBinding)
    }

    override fun onBindViewHolder(
        @NonNull childViewHolder: ChildViewHolder,
        position: Int
    ) {

        val childItem = ChildItemList?.get(position)


     childViewHolder.bind(childItem)

    }

    override fun getItemCount(): Int {


        return ChildItemList?.size ?: 0
    }

    inner class ChildViewHolder(val itemBinding:  FragmentProfileChildItemBinding) : RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(childItem: EligibleEvents?) {
            itemBinding.childItemTitle.text = childItem?.name



            if (childItem?.icon_url?.contains(".svg") == true) {
                GlideToVectorYou
                    .init()
                    .with(context)
                    .withListener(object : GlideToVectorYouListener {
                        override fun onLoadFailed() {

                        }

                        override fun onResourceReady() {
                        }
                    })
                    .load(Uri.parse(childItem?.icon_url), itemBinding.imgChildItem)
            } else {

                Picasso.get().load(childItem?.icon_url)
                    .into(itemBinding.imgChildItem)
            }
        }

    }

    // Constuctor
    init {
        ChildItemList = childItemList
    }
}