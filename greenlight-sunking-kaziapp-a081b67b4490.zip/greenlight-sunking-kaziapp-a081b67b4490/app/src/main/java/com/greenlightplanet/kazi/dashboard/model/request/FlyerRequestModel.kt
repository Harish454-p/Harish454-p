package com.greenlightplanet.kazi.dashboard.model.request



import android.os.Parcelable
import androidx.room.*
import kotlinx.android.parcel.Parcelize
import com.google.gson.annotations.SerializedName

@Parcelize
data class FlyerRequestModel(
    @ColumnInfo(name = "angazaId")
    @SerializedName("angazaId")
    var angazaId: String,
    @ColumnInfo(name = "flyerId")
    @SerializedName("flyerId")
    var flyerId: Int
):Parcelable