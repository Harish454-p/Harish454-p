package com.greenlightplanet.kazi.loyalty.converter.leaderboard

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.loyalty.model.leaderboard.Current_user_rank
import com.greenlightplanet.kazi.loyalty.model.profile.Profile

class CurrentRankConverter {

    @TypeConverter
    fun fromCurrent_user_rank(list: Current_user_rank): String? {
        if (list == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<Current_user_rank>() {

        }.type
        return gson.toJson(list, type)
    }

    @TypeConverter
    fun toCurrent_user_rank(string: String?): Current_user_rank? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<Current_user_rank>() {

        }.type
        return gson.fromJson(string, type)
    }

}


