package com.greenlightplanet.kazi.liteFseProspective.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.dashboard.model.FakeLocationRequest
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseData
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteProspectiveRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable

class AllViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "AllViewModel"

    }

    val repo = LiteProspectiveRepo.getInstance(application)


    fun getAllFse(): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {
        return repo.getAllFSE()
    }

    fun sendFakeLocationLog(context: Context, angazaId: String, fakeLocationRequest: FakeLocationRequest): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        return repo.sendFakeLocationRequestToServer(context, angazaId,fakeLocationRequest)
    }

    fun getFseProspectiveFromDatabase(): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {
        return repo.getFseProspectiveFromDatabase()
    }

    override fun onCleared() {
        super.onCleared()
//        repo.destroy()
    }

}
