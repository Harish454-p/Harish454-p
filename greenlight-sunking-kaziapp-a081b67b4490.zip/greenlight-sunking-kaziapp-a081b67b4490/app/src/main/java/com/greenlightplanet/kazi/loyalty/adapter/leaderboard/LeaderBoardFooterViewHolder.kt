package com.greenlightplanet.kazi.loyalty.adapter.leaderboard

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.ItemListFooterBinding
import com.greenlightplanet.kazi.loyalty.pagging.State

/**
 * Created by Rahul on 08/04/21.
 */
class LeaderBoardFooterViewHolder(val itemBinding:  ItemListFooterBinding) : RecyclerView.ViewHolder(itemBinding.root) {

    fun bind(status: State?) {

        Log.e("Status", "${status}")
        itemBinding.progressBar.visibility = if (status == State.LOADING) VISIBLE else View.INVISIBLE
        itemBinding.txtError.visibility = if (status == State.ERROR) VISIBLE else View.INVISIBLE
        itemBinding.txtNodata.visibility = if (status == State.OFFLINE) VISIBLE else View.INVISIBLE

    }

    companion object {
        fun create(retry: () -> Unit, parent: ViewGroup): LeaderBoardFooterViewHolder {
            val itemBinding = ItemListFooterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            itemBinding.txtError.setOnClickListener {

                if (com.greenlightplanet.kazi.utils.Util.isOnline(parent.context)) {
                    retry()
                }
            }
            return LeaderBoardFooterViewHolder(itemBinding)
        }
    }
}