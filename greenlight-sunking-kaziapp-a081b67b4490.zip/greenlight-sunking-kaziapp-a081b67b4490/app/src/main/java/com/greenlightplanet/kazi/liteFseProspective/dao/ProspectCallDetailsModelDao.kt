package com.greenlightplanet.kazi.liteFseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.liteFseProspective.model.ProspectCallDetail
import io.reactivex.Single

@Dao
interface ProspectCallDetailsModelDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(callDetail: List<ProspectCallDetail>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(callDetail: ProspectCallDetail): Long

    @Delete
    fun delete(callDetail: ProspectCallDetail): Int

    @Query("DELETE FROM ProspectCallDetail")
    fun deleteAll(): Int

    @Query("SELECT * FROM ProspectCallDetail")
    fun getAll(): Single<List<ProspectCallDetail>>

    @Query("SELECT * FROM ProspectCallDetail")
    fun getAllTask(): Single<ProspectCallDetail>

    @Query("SELECT * FROM ProspectCallDetail WHERE prospectId = :prospectId")
    fun getAllByProspectId(prospectId: String): Single<List<ProspectCallDetail>>


    @Query("SELECT * FROM ProspectCallDetail LIMIT 1")
    fun get(): Single<ProspectCallDetail>

    @Query("SELECT COUNT(*) from ProspectCallDetail")
    fun count(): Single<Int>

}
