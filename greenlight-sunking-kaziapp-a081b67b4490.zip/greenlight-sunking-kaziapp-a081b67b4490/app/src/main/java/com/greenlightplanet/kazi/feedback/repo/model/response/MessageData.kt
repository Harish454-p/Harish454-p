package com.greenlightplanet.kazi.feedback.repo.model.response

import androidx.annotation.Keep

@Keep
data class MessageData(
    val ticketId: String,
    val sender: String,
    val senderType: String,
    val message: String,
    val attachments: List<String>,
    val timestamp: String,
)



/*
{
    "ticketId":"",
    "sender":"Identifier",
    "senderType":"Customer/CC Agent",
    "message":"Text description",
    "attachments":[]
    "timestamp":"01-01-2022 12:00:01",
}*/
