package com.greenlightplanet.kazi.loyalty.adapter.leaderboard

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.LeaderRecyclerItemViewBinding
import com.greenlightplanet.kazi.loyalty.model.leaderboard.User_rank
import com.greenlightplanet.kazi.utils.Util


/**
 * Created by Rahul on 08/04/21.
 */
class LeaderBoardViewHolder(val itemBinding: LeaderRecyclerItemViewBinding) : RecyclerView.ViewHolder(itemBinding.root) {


    fun bind(data: User_rank, position: Int,type:String) {

        if (data.event_id != null) {
            try {
               // if (data.user_type.equals(CURRENT_USER,true)) {
                   // itemView.main_bg.setBackgroundColor(itemView.context.resources.getColor(R.color.borderGrey))

                   // itemView.visibility=View.GONE
                   // itemView.layoutParams.height = 0
                   // itemView.layoutParams.width = 0
              //  }// else {
                  //  itemView.visibility=View.VISIBLE

                    //  val height: Int = itemView.measuredHeight
                   // val width: Int = itemView.measuredWidth
                  // itemView.layoutParams.height = itemView.measuredHeight
                   // itemView.layoutParams.width = itemView.measuredWidth
                //    itemView.main_bg.setBackgroundColor(itemView.context.resources.getColor(R.color.pure_white))
              //  }

                if (type.equals("Area",true)){
                    itemBinding.areaId.visibility=View.GONE
                }else{
                    itemBinding.areaId.visibility=View.VISIBLE

                }

            } catch (e: Exception) {
                Log.e("Error-Leader", "bind: ${e}")
            }
        /*    if (data.rank == 1) {
                itemView.rankIconId.visibility = View.VISIBLE
            } else {

               itemView.rankIconId.visibility = View.INVISIBLE

            }*/

            Log.e("jkbvjdfjv","out == ${data.rank}")

            if (data.rank == 1) {
                itemBinding.rankIconId.background=itemView.context.resources.getDrawable(R.drawable.ic_star_icon)
                itemBinding.rankIconId.visibility = View.VISIBLE

                Log.e("jkbvjdfjv","out == ${data.rank}")

            }
           else if (data.color_coding == 2 && data.rank != 1){
                Log.e("jkbvjdfjv","two == ${data.rank} ${data.color_coding }")

                itemBinding.rankIconId.background=itemView.context.resources.getDrawable(R.drawable.arrow_downward)
                itemBinding.rankIconId.visibility = View.VISIBLE

            }else if (data.color_coding == 1 && data.rank != 1){
                Log.e("jkbvjdfjv","three == ${data.rank} ${data.color_coding }")

                itemBinding.rankIconId.background=itemView.context.resources.getDrawable(R.drawable.arrow_upward)
                itemBinding.rankIconId.visibility = View.VISIBLE

            }else{
                itemBinding.rankIconId.visibility=View.INVISIBLE

            }

          //  itemView.tvRankId.visibility = View.VISIBLE
            itemBinding.salesId.text = data.point?.let { Util.formatAmount(it.toDouble()) }
            itemBinding.tvRankId.text = data.rank?.let { Util.formatAmount(it.toDouble()) }
            itemBinding.name.text = "${data.first_name} ${data.last_name}"
            itemBinding.areaId.text = "${data.area?:""}"


        }

    }

    companion object {
        fun create(parent: ViewGroup): LeaderBoardViewHolder {
            val itemBinding =LeaderRecyclerItemViewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return LeaderBoardViewHolder(itemBinding)
        }
    }


}