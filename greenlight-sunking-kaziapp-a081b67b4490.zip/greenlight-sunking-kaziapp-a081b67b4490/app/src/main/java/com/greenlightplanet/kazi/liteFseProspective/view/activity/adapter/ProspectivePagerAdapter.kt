package com.greenlightplanet.kazi.liteFseProspective.view.activity.adapter

import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager.widget.PagerAdapter
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.liteFseProspective.extras.FseProspectiveConstant.ProspectStatus
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import com.greenlightplanet.kazi.liteFseProspective.view.activity.LiteProspectiveActivity
import com.greenlightplanet.kazi.liteFseProspective.view.fragment.AllFragment
import com.greenlightplanet.kazi.liteFseProspective.view.fragment.InstallationFragment
import com.greenlightplanet.kazi.liteFseProspective.view.fragment.RegistrationFragment
import com.greenlightplanet.kazi.liteFseProspective.view.fragment.VerificationFragment

class ProspectivePagerAdapter(fm: FragmentManager, var list: List<LiteFseProspectResponseModel>, val allowedDistance: Int, val activity: LiteProspectiveActivity) : FragmentStatePagerAdapter(fm) {


    var installationFragment: InstallationFragment? = null
    var registrationFragment: RegistrationFragment? = null
    var verificationFragment: VerificationFragment? = null
    var allFragment: AllFragment? = null

    override fun getCount(): Int {
        return 3
    }

    override fun getItem(position: Int): Fragment {
        val fragment: Fragment? = null

        when (position) {
            0 -> {
                allFragment = AllFragment.newInstance(/*list, */allowedDistance)
                Log.e("mazhar","allFragment=== ${list.size}")
                return allFragment as Fragment
            }
            1 -> {
                verificationFragment = VerificationFragment.newInstance(
//                        list.filter { it.status == ProspectStatus.PROSPECT || it.status == ProspectStatus.THREE_WAY_CALL },
                    allowedDistance)

                return verificationFragment as Fragment
            }
            2 -> {
                installationFragment = InstallationFragment.newInstance(
//                        list.filter {
//                            it.status == ProspectStatus.INSTALLATION_PENDING || it.status == ProspectStatus.INSTALLED
//                                    || it.status == ProspectStatus.INSTALLATION_VERIFIED || it.status == ProspectStatus.INSTALLATION_REATTEMPT
//                        },
                    allowedDistance)
                return installationFragment as Fragment
            }

//            3 -> {
//                installationFragment = InstallationFragment.newInstance(
//                        list.filter { it.ticketType == FseProspectiveConstant.ProspectiveType.INSTALLATION }
//                        , allowedDistance)
//                return installationFragment as Fragment
//            }
            else ->
                return fragment!!
        }
    }


    /*override fun getItemPosition(object: Any): Int {
        return PagerAdapter.POSITION_NONE
    }*/

    override fun getItemPosition(`object`: Any): Int {
        return PagerAdapter.POSITION_NONE
    }

    override fun getPageTitle(position: Int): CharSequence {
        var title: String? = null
        when (position) {
            0 -> {
                title = activity.getString(R.string.all)
                return title
            }
            1 -> {
                title = activity.getString(R.string.prospect)
                return title
            }
            2 -> {
                title = activity.getString(R.string.installation)
                return title
            }
//            3 -> {
//                title = "Installation"
//                return title
//            }
            else ->
                return title!!
        }
    }


}
