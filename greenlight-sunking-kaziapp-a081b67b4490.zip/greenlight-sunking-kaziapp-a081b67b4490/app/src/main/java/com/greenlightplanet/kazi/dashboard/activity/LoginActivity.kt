package com.greenlightplanet.kazi.dashboard.activity

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Process
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.KaziApplication
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.CountryResponseModel
import com.greenlightplanet.kazi.dashboard.model.call_sms.CallLogRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.ContactRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.SmsRequest
import com.greenlightplanet.kazi.dashboard.model.request.LoginRequestModel
import com.greenlightplanet.kazi.dashboard.model.response.CountryModel
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.dashboard.repo.DashBoardRepo
import com.greenlightplanet.kazi.dashboard.viewmodel.LoginViewModel
import com.greenlightplanet.kazi.databinding.LoginActivityBinding
import com.greenlightplanet.kazi.member.activity.RegisteredMobileActivity
import com.greenlightplanet.kazi.networking.APICallback
import com.greenlightplanet.kazi.networking.APIInterface
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.newtasks.view.fragment.NewTaskFragment
import com.greenlightplanet.kazi.utils.*
import com.greenlightplanet.kazi.utils.Util.Companion.isOnline
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap


class LoginActivity : AppCompatActivity(),
    APIInterface<CommonResponseModel<LoginResponseModel>> { //, LoaderManager.LoaderCallbacks<Cursor?> {

    private lateinit var countryResponseModel: CountryResponseModel
    private lateinit var binding: LoginActivityBinding
    var edMobileNumber: String? = null
    var edPassword: String? = null
    var countryCode: String? = null

    var checkLength: Int? = null

    var mCode: String? = null
    var filteredCountyList: List<String> = ArrayList()
    var countyList: List<CountryResponseModel> = ArrayList()
    var mHomeWatcher: HomeWatcher? = null

    var preference: GreenLightPreference? = null
    var txtCountry: String? = null

    var isRequesting = false
    var adapterCountry: ArrayAdapter<String>? = null

    val MY_PERMISSIONS_REQUEST_READ_SMS = 913
    val MY_PERMISSIONS_REQUEST_READ_CONTACTS = 312
    val ALL_SMS_LOADER = 261
    private var mCurFilter: String? = null
    val SMS_SELECTION_SEARCH = "address LIKE ? OR body LIKE ?"
    val ALL_SMS_URI = Uri.parse("content://sms/inbox")
    val SORT_DESC = "date DESC"
    var data: ArrayList<SMS>? = null

    var smsRequests = mutableListOf<SmsRequest>()
    var callLogRequest = mutableListOf<CallLogRequest>()
    var contactRequest = mutableListOf<ContactRequest>()

    val completionMap = HashMap<String, Boolean>()
    val completion = MutableLiveData<HashMap<String, Boolean>>()

    val repo = DashBoardRepo.getInstance(this)
    var viewModel: LoginViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContentView(R.layout.login_activity)
        binding = LoginActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvAppVersion.text = "App version :" + BuildConfig.VERSION_NAME
        viewModel = ViewModelProviders.of(this).get(LoginViewModel::class.java)
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            //Todo : delete WRITE_CALL_LOG n QUERY_ALL_PACKAGES and remove if condition after discussion and approval... with mazhar.
            Util.requestAllPermission(
                this, arrayListOf(
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.READ_CALL_LOG,
                    //
                    Manifest.permission.WRITE_CALL_LOG,
                    Manifest.permission.QUERY_ALL_PACKAGES,
                    //
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.RECEIVE_SMS,
                    Manifest.permission.READ_SMS,
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
            )
        } else {
            Util.requestAllPermission(
                this, arrayListOf(
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.RECEIVE_SMS,
                    Manifest.permission.READ_SMS,
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
            )
        }

        preference = GreenLightPreference.getInstance(this)

        Util.disableWhiteSpace(binding.password)
        viewModel!!.getCountryList(this).observe(this, Observer {
            countyList = it
            filteredCountyList = it.map { it.country.toString() }
            adapterCountry = ArrayAdapter(
                this,
//                android.R.layout.simple_spinner_item,
                android.R.layout.simple_list_item_1,
                filteredCountyList
            )

            /// Log.d("TAG7777777", "onCreate: "+)
            adapterCountry?.setDropDownViewResource(R.layout.spinner_filter_text)
            binding.spinnerCountry!!.adapter = adapterCountry
            binding.spinnerCountry.onItemSelectedListener =
                object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        adapterView: AdapterView<*>, view: View,
                        position: Int, id: Long
                    ) {
                        onItemSelecteds(position, it.get(position))
                    }

                    override fun onNothingSelected(adapterView: AdapterView<*>) {}

                }
        })

        binding.loginButton.setOnClickListener {
            //contactAndSmsLogic()
            onLoginConfirm()
        }

        binding.signupButton.setOnClickListener {
            signup()
        }

        binding.txtForgetPassword.setOnClickListener {
            forgotPasswordIntent()
        }

        // 715637322
        //test password
//        binding.password.setText("5529999444")
////        //visits
//        binding.edMobile.setText("848351399")
//        binding.edMobile.setText("745903853")

        //Kazi CG
//        binding.edMobile.setText("728372551")

//        binding.edMobile.setText("743738875")
        //dev visits
//        binding.edMobile.setText("797257062")
//        binding.edMobile.setText("720872937")
//        797257062
        //onfield
//        binding.edMobile.setText("9015179729")
//      binding.edMobile.setText("724488692")
//        test user 0001
//       ed_mobile.setText("754024792")
        //loyalty prod
        //ed_mobile.setText("741427300")
        //binding.edMobile.setText("717690402")
//     binding.edMobile.setText("717690403")
        //for Kenya For Collection Rate
//        ed_mobile.setText("704297717")


        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                finish()
            }
        })
        mHomeWatcher!!.startWatch()


    }

    override fun onResponse(response: CommonResponseModel<LoginResponseModel>) {

        Log.d("TIME_CALC", "login-end:${System.currentTimeMillis()} ")

        Log.e("bvjfjvdjfjgdfhg", "${response.ResponseData}")

        if (response.Success!!) {
            Util.addEvent("283", "Login", "login_successful_event")

            preference = GreenLightPreference.getInstance(this)
            val loginResponseModel = response.ResponseData
            loginResponseModel?.country = txtCountry
            loginResponseModel?.phoneNumber = countryCode + binding.edMobile?.text.toString()
            preference?.setshowProspectTab(response.ResponseData!!.showProspectTab)
            preference!!.setshowWebViewTab(response.ResponseData!!.showWebViewTab)
            preference!!.setPassword(binding.password.text.toString() ?: "")
            preference?.setLoginResponseModel(loginResponseModel!!)
            preference?.setCountryResponseModel(countryResponseModel)
            loginResponseModel?.securityKey?.let {
                preference?.setAuthToken(loginResponseModel?.securityKey!!)
            }
//            preference!!.setLanguage("language", countryResponseModel.languageShort ?: "en")

            fcmErrorHandling()

            startService()
            Log.e("Mazhar === ", "AUTH  +++ ${preference!!.getAuthToken()}")
            val intent = Intent(this, DashBoardActivity::class.java)
            intent.putExtra("LoginResponseModel", loginResponseModel)
            startActivity(intent)
            finish()

        } else {
            Log.e("bvjfjvdjfjgdfhg", "errror2   ${response.Error?.MessageToUser}")

            Util.addEvent("284", "Login", "login_failure_event")
            Util.customFseRationaleDialog(this, "",
                hideNegative = true,
                titleSpanned = null,
                hideTitle = true,
                message = response.Error?.MessageToUser!!,
                positveSelected = { it.dismiss() },
                negativeSeleted = { it.dismiss() }
            )
        }
    }

    override fun onError() {
        Log.e("bvjfjvdjfjgdfhg", "errror   ${"FAILL"}")

        Util.addEvent("284", "Login", "login_failure_event")
    }

    fun startService() {
        if (!isRequesting && (preference?.getLoginResponseModel() != null)
            && KaziApplication.checkPermission(
                this
            )
        ) {
            KaziApplication.mService!!.requestLocationUpdates()
            isRequesting = true
        }
    }

    fun onItemSelecteds(position: Int, countryModel: CountryResponseModel) {
        mCode = countryModel.countryCode

        txtCountry = countryModel.country

        countryCode = countryModel.countryCode

        checkLength = countryModel.countryLength

    }

    private fun onLoginConfirm() {
        countryResponseModel = countyList.get(binding.spinnerCountry.selectedItemPosition)
        txtCountry = countryResponseModel.country
        countryCode = countryResponseModel.countryCode

        edMobileNumber = binding.edMobile?.text.toString()
        edPassword = binding.password?.text.toString()
        val mobileLength = countryResponseModel.countryLength/*!! + countryCode!!.length*/

        if (TextUtils.isEmpty(binding.edMobile?.text.toString())) {
            Util.showToast("" + resources.getString(R.string.error_enter_mobile_no), this)
        }
        else if (countryResponseModel.phoneNumberLengthRegex?.toRegex()
                ?.let { binding.edMobile.text?.matches(it) } != true) {

            Util.showToast("" + resources.getString(R.string.error_enter_valid_mobile), this)
        }
//        else if (binding.edMobile?.text?.length != mobileLength) {
//            Util.showToast("" + resources.getString(R.string.error_enter_valid_mobile), this)
//        }
        else if (TextUtils.isEmpty(binding.password?.text)) {
            Util.showToast("" + resources.getString(R.string.error_enter_password), this)
        } else {
//            726054025
            if (binding.edMobile?.text.toString() == "123456789" && binding.password.text.toString() == "rajiv_$123") {

                Util.customUrlDialog(
                    context = this,
                    poitiveSelected = { dialog, selectionUrl, selecturlLoyalty ->
                        preference?.setSuperUser(true)
                        preference?.setSuperUserUrl(selectionUrl)
                        preference?.setSuperUserUrlLoyalty(selecturlLoyalty)
                        binding.edMobile?.setText("")
                        binding.password?.setText("")
                        dialog.dismiss()
                    },
                    negetiveSelected = {
                        binding.edMobile?.setText("")
                        binding.password?.setText("")
                        it.dismiss()
                    })
            } else {
                val loginRequest = LoginRequestModel()

                loginRequest.activityType = Constants.ACTIVATION_LOGIN
                loginRequest.password = edPassword
                edMobileNumber = countryCode + edMobileNumber
                loginRequest.phoneNumber = edMobileNumber
                loginRequest.imei = Util.getImeiNumber(applicationContext)
                preference!!.setPassword(binding.password.text.toString() ?: "")
                if (isOnline(this)) {
                    /*       viewModel?.login(this,loginRequest)!!.observe(this, Observer {response->


                               Log.e("bvjfjvdjfjgdfhg","${response?.responseData}")

                               if (response?.success!!) {
                                   Util.addEvent("283", "Login", "login_successful_event")

                                   preference = GreenLightPreference.getInstance(this)
                                   val loginResponseModel = response?.responseData
                                   loginResponseModel?.country = txtCountry
                                   loginResponseModel?.phoneNumber = countryCode + binding.edMobile?.text.toString()
                                   preference?.setshowProspectTab(response?.responseData!!.showProspectTab)
                                   preference!!.setshowWebViewTab(response?.responseData!!.showWebViewTab)

                                   preference?.setLoginResponseModel(loginResponseModel!!)
                                   loginResponseModel?.securityKey?.let {
                                       preference?.setAuthToken(loginResponseModel?.securityKey!!)
                                   }

                                   fcmErrorHandling()

                                   startService()

                                   val intent = Intent(this, DashBoardActivity::class.java)
                                   intent.putExtra("LoginResponseModel", loginResponseModel)
                                   startActivity(intent)
                                   finish()

                               } else {
                                   Log.e("bvjfjvdjfjgdfhg","errror2   ${response?.error?.messageToUser}")

                                   Util.addEvent("284", "Login", "login_failure_event")
                                   Util.customFseRationaleDialog(this, "",
                                       hideNegative = true,
                                       titleSpanned = null,
                                       hideTitle = true,
                                       message = response.error?.messageToUser!!,
                                       positveSelected = { it.dismiss() },
                                       negativeSeleted = { it.dismiss() }
                                   )
                               }

                           })
       */

                    Log.d(
                        "LoginRequest1", " ${loginRequest.activityType} " +
                                " ${loginRequest.phoneNumber}" +
                                " ${loginRequest.password}" +
                                " ${loginRequest.imei}"
                    )
                    Log.d("TIME_CALC", "login-start:${System.currentTimeMillis()} ")
                    ServiceInstance.getInstance(this).service?.loginPost(loginRequest)
                        ?.enqueue(object : APICallback<CommonResponseModel<LoginResponseModel>>(
                            this as APIInterface<CommonResponseModel<LoginResponseModel>>,
                            this
                        ) {})
                } else {
                    Util.showToast(resources.getString(R.string.no_internet_try_again), this)
                }
            }

        }

    }

    fun signup() {
        Util.addEvent("272", "Sign Up", "signup_clicked")
        val registeredMobileIntent = Intent(this, RegisteredMobileActivity::class.java)
        Constants.IsForgotPassword = false
        startActivity(registeredMobileIntent)
    }

    fun forgotPasswordIntent() {
        val registeredMobileIntent = Intent(this, RegisteredMobileActivity::class.java)
        Constants.IsForgotPassword = true
        startActivity(registeredMobileIntent)
    }

    private fun fcmErrorHandling() {
        val instance = FirebaseCrashlytics.getInstance()
        if (preference?.getLoginResponseModel() != null) {
            instance.setCustomKey("userData", preference?.getLoginResponseModel().toString())

            instance.setUserId("${preference?.getLoginResponseModel()?.angazaId}")

        } else {
            instance.setCustomKey("isLoggedIn", true)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        getLogs()
        mHomeWatcher?.stopWatch();
    }

    private fun getLogs(): File {
        //set a file
        val datum = Date()
        val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val fullName: String = df.format(datum).toString() + "LoginAppLog.log"
        val file =
            File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fullName)

        Log.e("TAG", "Maz =file== ${file.absolutePath}")
        //clears a file
        if (file.exists()) {
            file.delete()
        }

        //write log to file
        val pid = Process.myPid()
        try {
            val command = String.format("logcat -d -v -e threadtime *:*")
            val process = Runtime.getRuntime().exec(command)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val result = StringBuilder()
            var currentLine: String? = null
            while (reader.readLine().also { currentLine = it } != null) {
//                Log.e(TAG,"Maz =currentLine== ${currentLine}")
                if (currentLine != null && currentLine!!.contains(pid.toString())) {
                    result.append(currentLine)
                    result.append("\n")

//                    Log.e(TAG,"Maz =result||||== ${result.toString()}")
                }
            }
            Log.e("TAG", "Maz =result==")
            val out = FileWriter(file)
            out.write(result.toString())
            out.close()

            //Runtime.getRuntime().exec("logcat -d -v time -f "+file.getAbsolutePath());
        } catch (e: IOException) {
            Log.e("TAG", "Maz === ${e.localizedMessage}")
//            Toast.makeText(requireContext(), "===="+ e.toString(), Toast.LENGTH_SHORT).show()
        }

        //clear the log
        try {
            Runtime.getRuntime().exec("logcat -c")
        } catch (e: IOException) {
            Log.e("TAG", "Maz === ${e.localizedMessage}")
//            Toast.makeText(applicationContext, "|||||||====||||"+e.toString(), Toast.LENGTH_SHORT).show()
        }
        return file
    }

}

