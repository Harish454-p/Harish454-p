package com.greenlightplanet.kazi.leads.dao

import androidx.room.*
import com.greenlightplanet.kazi.leads.model.CallDetailRequestModel
import io.reactivex.Single


@Dao
interface CallDetailRequestModelDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(CallDetailRequestModel: List<CallDetailRequestModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(CallDetailRequestModel: CallDetailRequestModel): Long

    @Delete
    fun delete(CallDetailRequestModel: CallDetailRequestModel): Int

    @Query("DELETE FROM CallDetailRequestModel")
    fun deleteAll(): Int

    @Query("SELECT * FROM CallDetailRequestModel")
    fun getAll(): Single<List<CallDetailRequestModel>>

    @Query("SELECT * FROM CallDetailRequestModel LIMIT 1")
    fun get(): Single<CallDetailRequestModel>

    @Query("SELECT COUNT(*) from CallDetailRequestModel")
    fun count(): Int


}

