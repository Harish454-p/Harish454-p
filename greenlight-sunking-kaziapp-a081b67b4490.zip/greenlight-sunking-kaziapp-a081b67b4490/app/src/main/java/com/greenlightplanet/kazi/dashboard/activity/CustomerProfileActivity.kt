package com.greenlightplanet.kazi.dashboard.activity

import android.os.Bundle
import android.os.PersistableBundle
import com.greenlightplanet.kazi.databinding.ActivityCustomerDetailsBinding
import com.greenlightplanet.kazi.task.model.response.TaskMddel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener


class CustomerProfileActivity : BaseActivity() {
    private lateinit var binding: ActivityCustomerDetailsBinding


	override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
		super.onSaveInstanceState(outState, outPersistentState)
		outState?.clear()
	}

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        savedInstanceState?.clear()
    }

    var preference: GreenLightPreference? = null
	var mHomeWatcher: HomeWatcher? = null


	override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_customer_details)

         binding = ActivityCustomerDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initialize()

        var data = intent.getBundleExtra("data")

        var arrayList = ArrayList<String>()
        var customerData = TaskMddel()
        customerData = data?.getSerializable("customerDetails") as TaskMddel
        //var customerData = intent.getSerializableExtra("customerDetails") as TaskMddel


        if (customerData != null) {

            setCustomerDetails(customerData)
        }

		mHomeWatcher = HomeWatcher(this)
		mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
			override fun onHomePressed() {
				finish()
			}
		})
		mHomeWatcher!!.startWatch()

    }


	override fun onDestroy() {
		super.onDestroy()
		mHomeWatcher?.stopWatch();

	}
	
	private fun setCustomerDetails(customerData: TaskMddel) {

        val symbol = preference?.getCountryResponseModel()?.countryCurrency ?: "NA"

        binding.tvCustomerAccount?.text = customerData.accountNumber.toString()
        binding. tv2PhoneNumber?.text = customerData.secondaryPhoneNumber.toString()
        binding. tv1stPhoneNumber?.text = customerData.ownerPhoneNumber.toString()
        binding. tvCustomerName?.text = customerData.ownerName.toString()
        binding. tvDaysDisabled?.text = customerData.daysDisabled.toString()

        if (customerData.latestPayment.isNullOrBlank()) {
            binding. tvLastPayment?.text = "NA"
        } else {
            binding. tvLastPayment?.text = Util.parseYYYY_MM_DDtoDD_MM_YYYY(customerData.latestPayment.toString())
        }

        binding.tvCustomerAddress.text = customerData.address?:"NA"
        binding.tvProductName?.text = customerData.groupName.toString()
		customerData.registrationDate?.let {
            binding.tvRegDate?.text = Util.parseYYYY_MM_DDtoDD_MM_YYYY(customerData.registrationDate)
		}
        binding. tvTaskType?.text = customerData.ticketType.toString()

        binding.tvBalanceAmt?.text = Util.checkBlank(customerData.balanceAmount.toString(), context = this).toDouble().let { Util.formatAmount(it) } + " " + symbol       // tvTotalAmtPaid?.setText(customerData.totalPaid.toString())
        binding. tvTotalAmtPaid?.text = Util.checkBlank(customerData.totalPaid?.toString(), context = this).toDouble().let { Util.formatAmount(it) } + " " + symbol

        binding.tvExpectedPaid?.text = Util.checkBlank(customerData.expectedPaid.toString(), context = this).toDouble().let { Util.formatAmount(it) } + " " + symbol


        binding.btnFirstCall?.setOnClickListener {

        }
    }


    fun initialize() {

        Util.setToolbar(this, this. binding.toolbar!!)
        preference = GreenLightPreference.getInstance(this)

    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
