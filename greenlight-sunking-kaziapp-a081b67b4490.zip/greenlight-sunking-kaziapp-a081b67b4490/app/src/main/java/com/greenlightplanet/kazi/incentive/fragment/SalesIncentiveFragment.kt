package com.greenlightplanet.kazi.incentive.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup


import com.greenlightplanet.kazi.databinding.FragmentSalesIncentiveBinding
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.incentive.model.sales
import com.greenlightplanet.kazi.utils.Util


class SalesIncentiveFragment : Fragment() {

private var _binding:FragmentSalesIncentiveBinding  ? = null
    private val binding get() = _binding!!

//    @BindView(R.id.tvWeeksSales)
//    @JvmField
//    var tvWeeksSale: TextView? = null
//
//    @BindView(R.id.tvSalesDuration)
//    @JvmField
//    var tvSalesDuration: TextView? = null
//
//    @BindView(R.id.tvPreTaxIncentive)
//    @JvmField
//    var tvPreTaxIncentive: TextView? = null
//
//    @BindView(R.id.tvPostTax)
//    @JvmField
//    var tvPostTax: TextView? = null


    var sales: sales? = null

    var preference: GreenLightPreference? = null


    private fun setSalesDetails() {
        var symbol = preference?.getCountryResponseModel()?.countryCurrency ?: "NA"

        binding.tvWeeksSales?.text = Util.checkBlank(sales?.thisWeek?.toDouble()?.let { Util.formatAmount(it) } + "", context = context)
        binding.tvSalesDuration?.text = Util.checkBlankNA(sales?.duration.toString(), context)
        binding.tvPreTaxIncentive?.text = Util.checkBlank(sales?.preTax?.toDouble()?.let { Util.formatAmount(it) } + " " + symbol, context)
        binding.tvPostTax?.text = Util.checkBlank(sales?.postTax?.toDouble()?.let { Util.formatAmount(it) } + " " + symbol, context = context)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
       _binding = FragmentSalesIncentiveBinding.inflate(inflater, container, false)



        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val bundlesales = arguments
        sales = bundlesales?.getSerializable("sales") as sales?
        preference = GreenLightPreference.getInstance(requireActivity())
        setSalesDetails()


    }

}// Required empty public constructor
