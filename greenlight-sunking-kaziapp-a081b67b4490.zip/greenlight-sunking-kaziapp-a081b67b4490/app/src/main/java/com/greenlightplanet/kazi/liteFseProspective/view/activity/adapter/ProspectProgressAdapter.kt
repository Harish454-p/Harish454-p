package com.greenlightplanet.kazi.liteFseProspective.view.activity.adapter


import android.content.Context
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ProspectProgressListItemBinding
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import com.greenlightplanet.kazi.utils.Util
import org.jetbrains.annotations.NotNull


class ProspectProgressAdapter(
    val context: Context,
    var list: List<LiteFseProspectResponseModel.StatusUpdateObjects>,
    var fseProspectResponseModel: LiteFseProspectResponseModel
) : RecyclerView.Adapter<ProspectProgressAdapter.ViewHolder>() {

    var prospectProgressAdapterCallbackCallback: ProspectProgressAdapterCallback? = null


    override fun onCreateViewHolder(@NotNull p0: ViewGroup, viewType: Int): ViewHolder {

        val itemBinding =
            ProspectProgressListItemBinding.inflate(LayoutInflater.from(p0.context), p0, false)
        return ViewHolder(itemBinding)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = list!!.get(position)

        holder.bind(data, holder.itemView)
    }


    inner class ViewHolder(val itemBinding: ProspectProgressListItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(data: LiteFseProspectResponseModel.StatusUpdateObjects, itemView: View) {
            itemBinding.tvStatusName.text = data.showCaseName

            if (!data.statusTime.isNullOrBlank()) {

                itemBinding.tvDate.text = Util.fseUiDateFormatter(data.statusTime!!)
                if (!data.customApproved!!) {
                    itemBinding.imgIndicator.setImageDrawable(
                        ContextCompat.getDrawable(
                            context,
                            R.drawable.ic_cancel
                        )
                    )
                    itemBinding.imgIndicator.setOnClickListener {
                        prospectProgressAdapterCallbackCallback?.onErrorClick(
                            position,
                            fseProspectResponseModel
                        )
                    }
                } else {
                    itemBinding.imgIndicator.setImageDrawable(
                        ContextCompat.getDrawable(
                            context,
                            R.drawable.double_check
                        )
                    )
                    itemBinding.imgIndicator.setOnClickListener {
                        Log.e("imgIndicator", "=====setOnClickListener=======")
                    }
                }

            } else {
                itemBinding.tvDate.text = ""
                itemBinding.imgIndicator.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.exclamation_mark
                    )
                )
            }

            if (position == list.size - 1) {
                itemView.setBackgroundResource(R.drawable.square_padding_border_with_bottom)
            } else {
                itemView.setBackgroundResource(R.drawable.square_padding_border_without_bottom)
            }

        }
    }

    override fun getItemCount(): Int {
        return list.size ?: 0
    }

    interface ProspectProgressAdapterCallback {

        fun onErrorClick(position: Int, value: LiteFseProspectResponseModel)

    }

}
