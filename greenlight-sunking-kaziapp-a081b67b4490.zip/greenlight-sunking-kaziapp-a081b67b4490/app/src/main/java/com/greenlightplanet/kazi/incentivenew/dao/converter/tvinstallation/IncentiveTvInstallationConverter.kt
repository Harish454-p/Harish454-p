package com.greenlightplanet.kazi.incentivenew.dao.converter.tvinstallation

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.incentivenew.model.reffrel.ReferredAgents
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryFields
import com.greenlightplanet.kazi.incentivenew.model.tvinstallation.AccountsList
import com.greenlightplanet.kazi.pricegroup.model.Pricing_group

class IncentiveTvInstallationConverter {

    @TypeConverter
    fun fromAccountsListList(list: List<AccountsList>?): String? {
        if (list == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<AccountsList>>() {

        }.type
        return gson.toJson(list, type)
    }

    @TypeConverter
    fun toAccountsListList(string: String?): List<AccountsList>? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<AccountsList>>() {

        }.type
        return gson.fromJson(string, type)
    }

}


