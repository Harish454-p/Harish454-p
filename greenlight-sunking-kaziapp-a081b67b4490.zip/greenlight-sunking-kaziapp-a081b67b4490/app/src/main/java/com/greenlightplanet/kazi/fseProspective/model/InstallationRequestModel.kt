package com.greenlightplanet.kazi.fseProspective.model

import android.os.Parcelable
import androidx.room.*
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "InstallationRequest")
data class InstallationRequestModel(
        @PrimaryKey
        @ColumnInfo(name = "prospectId")
        @SerializedName("prospectId")
        var prospectId: String, // PP12345
        @ColumnInfo(name = "angazaId")
        @SerializedName("angazaId")
        var angazaId: String?, // US000001
        @ColumnInfo(name = "installationCompletedTime")
        @SerializedName("installationCompletedTime")
        var installationCompletedTime: String?, // 2019-12-23 14:22:56
//        @ColumnInfo(name = "installationPicture")
//        @SerializedName("installationPicture")
//        var installationPictures: String?, // http://127.0.0.1
//        @ColumnInfo(name = "latitude")
//        @SerializedName("latitude")
//        var latitude: String?, // 12.431
//        @ColumnInfo(name = "longitude")
//        @SerializedName("longitude")
//        var longitude: String?, // 32.768
//        @ColumnInfo(name = "accuracy")
//        @SerializedName("accuracy")
//        var accuracy: String?, // "123.12"
        @TypeConverters(ImagesListConverter::class)
        @ColumnInfo(name = "images")
        @SerializedName("images")
        var images: List<ImagesList>?,

//        var pictureUri: String?, // /sdCard/DCIM/Kazi_312325.jpeg

        @ColumnInfo(name = "installationAttempted")
        @SerializedName("attempt")
        var installationAttempted: Int?, // 12.431

        //add acccount number
        @ColumnInfo(name = "accountNumber")
        @SerializedName("accountNumber")
        var accountNumber: String?,

        @ColumnInfo(name = "country")
        @SerializedName("country")
        var country: String // Uganda
) : Parcelable {

        @Parcelize
        data class ImagesList(
                @ColumnInfo(name = "installationPicture")
                @SerializedName("installationPicture")
                var installationPictures: String?, // http://127.0.0.1
                @ColumnInfo(name = "latitude")
                @SerializedName("latitude")
                var latitude: String?, // 12.431
                @ColumnInfo(name = "longitude")
                @SerializedName("longitude")
                var longitude: String?, // 32.768
                @ColumnInfo(name = "accuracy")
                @SerializedName("accuracy")
                var accuracy: String?, // "123.12"
                @ColumnInfo(name = "attempt")
                @SerializedName("attempt")
                var attempt: Int?, // "123.12"
                @ColumnInfo(name = "imageName")
                @SerializedName("imageName")
                var imageName: String? // "123.12"
        ) : Parcelable
}


class ImagesListConverter {

        @TypeConverter
        fun fromImagesList(installationPictures: List<InstallationRequestModel.ImagesList>?): String? {
                if (installationPictures == null) {
                        return null
                }
                val gson = Gson()
                val type = object : TypeToken<List<InstallationRequestModel.ImagesList>>() {

                }.type
                return gson.toJson(installationPictures, type)
        }

        @TypeConverter
        fun toImagesListList(listString: String?): List<InstallationRequestModel.ImagesList>? {
                if (listString == null) {
                        return null
                }
                val gson = Gson()
                val type = object : TypeToken<List<InstallationRequestModel.ImagesList>>() {

                }.type
                return gson.fromJson(listString, type)
        }

}
