package com.greenlightplanet.kazi.agentReferral.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.agentReferral.model.referredagentlist.ReferredAgent
import io.reactivex.Single

@Dao
interface ReferredAgentsDao {
    @Query("SELECT * FROM ReferredAgent")
    fun getAgentReferral() : Single<List<ReferredAgent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAgentReferral(referredAgent: ReferredAgent)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAllAgentReferral(referredAgents : List<ReferredAgent>)

    @Query("DELETE FROM ReferredAgent")
    fun deleteAllAgentReferral() : Int
}