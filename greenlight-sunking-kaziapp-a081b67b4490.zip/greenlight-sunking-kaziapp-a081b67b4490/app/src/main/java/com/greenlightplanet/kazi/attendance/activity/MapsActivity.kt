package com.greenlightplanet.kazi.attendance.activity

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.view.ViewAnimationUtils
import android.view.animation.AccelerateDecelerateInterpolator
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.utils.DateComparator
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.attendance.model.AttendanceRequestModel
import com.greenlightplanet.kazi.attendance.model.AttendanceResponseModel
import com.greenlightplanet.kazi.attendance.model.checkins
import com.greenlightplanet.kazi.databinding.ActivityAttendanceBinding
import com.greenlightplanet.kazi.databinding.ActivityMaps2Binding
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import java.util.*

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    var preference: GreenLightPreference? = null
    var valueReceived: Array<String>? = null
    var capture_latlng: LatLng? = null
    private val options = MarkerOptions()
    private val latlngs = ArrayList<LatLng>()
    private val savedPreferences: SharedPreferences? = null
    var activity: Activity? = null
    var context: Context? = null
    val checkList: ArrayList<checkins>? = null
    // var list: List<String>? = null
    var time: String? = null
    var list: ArrayList<String>? = null
    var lat: Double = 0.toDouble()
    var country: String? = null
    var i: Int = 0
    var lng: Double = 0.toDouble()
    var eo_time: String? = null
    var checkIns: ArrayList<AttendanceResponseModel.Checkin>? = null

	var mHomeWatcher: HomeWatcher? = null
    private lateinit var binding: ActivityMaps2Binding


	override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_maps2)
        binding = ActivityMaps2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        activity = this
        context = activity
        preference = GreenLightPreference.getInstance(this)

        val greenlightpreference = GreenLightPreference.getInstance(this)

        country = greenlightpreference?.getLoginResponseModel()?.country


        val bundle = intent.extras

        val attendanceRequestModel = bundle!!.get("mapData") as ArrayList<AttendanceResponseModel.Checkin>
        checkIns = attendanceRequestModel as ArrayList<AttendanceResponseModel.Checkin>

		mHomeWatcher = HomeWatcher(this)
		mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
			override fun onHomePressed() {
				Log.i("MapsActivity", "onHomePressed")
				finish()
			}
		})
		mHomeWatcher!!.startWatch()
    }

    @SuppressLint("RestrictedApi")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        Collections.sort(checkIns, DateComparator())
        Collections.reverse(checkIns)


        lat = checkIns!![0].latitude!!.toDouble()
        lng = checkIns!![0].longitude!!.toDouble()

        eo_time = Util.convertUTCtoLocatTimeHHMMAMPM(checkIns!![0].time!!)

        capture_latlng = LatLng(lat, lng)



        mMap.moveCamera(CameraUpdateFactory.newLatLng(capture_latlng))
        mMap.uiSettings.isZoomGesturesEnabled = true
        mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
        val zoomLevel = 16.0f
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(capture_latlng, zoomLevel))



        try {
            i = 0
            while (i < checkIns!!.size) {

                lat = checkIns!![i].latitude!!.toDouble()
                lng = checkIns!![i].longitude!!.toDouble()
                eo_time = Util.convertUTCtoLocatTimeHHMMAMPM(checkIns!![i].time!!)
                latlngs.add(LatLng(lat, lng))
                for (point in latlngs) {
                    options.position(point)
                    options.title(resources.getString(R.string.map_time))

                    options.snippet(eo_time)
                    mMap.addMarker(options)
                }
                i++


            }


            
            
            //SATATLITE VIEW


            // Initialise the map variable

            // When map is initially loaded, determine which map type option to 'select'
            when {
                mMap.mapType == GoogleMap.MAP_TYPE_SATELLITE -> {
                    binding.mapTypeSatelliteBackground.visibility = View.VISIBLE
                    binding.mapTypeSatelliteText.setTextColor(Color.BLUE)
                }
                mMap.mapType == GoogleMap.MAP_TYPE_TERRAIN -> {
                   binding.mapTypeTerrainBackground.visibility = View.VISIBLE
                   binding.mapTypeTerrainText.setTextColor(Color.BLUE)
                }
                else -> {
                   binding.mapTypeDefaultBackground.visibility = View.VISIBLE
                   binding.mapTypeDefaultText.setTextColor(Color.BLUE)
                }
            }

            // Set click listener on FAB to open the map type selection view
           binding.mapTypeFAB.setOnClickListener {

                // Start animator to reveal the selection view, starting from the FAB itself
                val anim = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    ViewAnimationUtils.createCircularReveal(
                            binding.mapTypeSelection,
                            binding.mapTypeSelection.width - (binding.mapTypeFAB.width / 2),
                            binding.mapTypeFAB.height / 2,
                            binding.mapTypeFAB.width / 2f,
                           binding.mapTypeSelection.width.toFloat())
                } else {
                    TODO("VERSION.SDK_INT < LOLLIPOP")
                }
                anim.duration = 200
                anim.interpolator = AccelerateDecelerateInterpolator()

                anim.addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationStart(animation: Animator) {
                        super.onAnimationEnd(animation)
                       binding.mapTypeSelection.visibility = View.VISIBLE
                    }
                })

                anim.start()
                binding.mapTypeFAB.visibility = View.INVISIBLE

            }

            // Set click listener on the map to close the map type selection view
            mMap.setOnMapClickListener {

                // Conduct the animation if the FAB is invisible (window open)
                if (binding.mapTypeFAB.visibility == View.INVISIBLE) {

                    // Start animator close and finish at the FAB position
                    val anim = ViewAnimationUtils.createCircularReveal(
                           binding.mapTypeSelection,
                        binding.mapTypeSelection.width - (binding.mapTypeFAB.width / 2),
                            binding.mapTypeFAB.height / 2,
                        binding.mapTypeSelection.width.toFloat(),
                            binding.mapTypeFAB.width / 2f)
                    anim.duration = 200
                    anim.interpolator = AccelerateDecelerateInterpolator()

                    anim.addListener(object : AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: Animator) {
                            super.onAnimationEnd(animation)
                            binding.mapTypeSelection.visibility = View.INVISIBLE
                        }
                    })

                    // Set a delay to reveal the FAB. Looks better than revealing at end of animation
                    Handler().postDelayed({
                        kotlin.run {
                            binding.mapTypeFAB.visibility = View.VISIBLE
                        }
                    }, 100)
                    anim.start()
                }
            }

            // Handle selection of the Default map type
            binding.mapTypeDefault.setOnClickListener {
                binding.mapTypeDefaultBackground.visibility = View.VISIBLE
                binding.mapTypeSatelliteBackground.visibility = View.INVISIBLE
                binding.mapTypeTerrainBackground.visibility = View.INVISIBLE
                binding.mapTypeDefaultText.setTextColor(Color.BLUE)
                binding.mapTypeSatelliteText.setTextColor(Color.parseColor("#808080"))
                binding.mapTypeTerrainText.setTextColor(Color.parseColor("#808080"))
                mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
            }

            // Handle selection of the Satellite map type
            binding.mapTypeSatellite.setOnClickListener {
                binding.mapTypeDefaultBackground.visibility = View.INVISIBLE
                binding.mapTypeSatelliteBackground.visibility = View.VISIBLE
                binding.mapTypeTerrainBackground.visibility = View.INVISIBLE
               binding.mapTypeDefaultText.setTextColor(Color.parseColor("#808080"))
               binding.mapTypeSatelliteText.setTextColor(Color.BLUE)
               binding.mapTypeTerrainText.setTextColor(Color.parseColor("#808080"))
                mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
            }

            // Handle selection of the terrain map type
           binding.mapTypeTerrain.setOnClickListener {
                binding.mapTypeDefaultBackground.visibility = View.INVISIBLE
                binding.mapTypeSatelliteBackground.visibility = View.INVISIBLE
                binding.mapTypeTerrainBackground.visibility = View.VISIBLE
                binding.mapTypeDefaultText.setTextColor(Color.parseColor("#808080"))
                binding.mapTypeSatelliteText.setTextColor(Color.parseColor("#808080"))
                binding.mapTypeTerrainText.setTextColor(Color.BLUE)
                mMap.mapType = GoogleMap.MAP_TYPE_TERRAIN
            }
            
            
            
        }
        catch (e: Exception) {
            e.printStackTrace()
        }

    }

	override fun onDestroy() {
		super.onDestroy()
		mHomeWatcher?.stopWatch();

	}


}
