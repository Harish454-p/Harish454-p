package com.greenlightplanet.kazi.feedback.repo.model.response

import androidx.annotation.Keep

@Keep
data class ConversationFeedbackResponse(
    val request: RequestTime,
    val responseData: List<ChatData>,
    val responseStatus: Int,
    val serverIp: String,
    val serverPort: String,
    val success: Boolean
)
@Keep
data class RequestTime(
    val executionTime: Double
)
@Keep
data class ChatData(
    var message: String = "",
    var sender: String = "",
    var senderType: String = "",
    var ticketId: String = "",
    var timestamp: String = ""
)