package com.greenlightplanet.kazi.leads.view.adapter

import android.content.Context
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.greenlightplanet.kazi.databinding.AdapterCustomerLeadsBinding
import com.greenlightplanet.kazi.leads.extras.AdapterUtils
import com.greenlightplanet.kazi.leads.extras.LEAD_STATUS
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead

class CustomerLeadsAdapter constructor(private val context: Context, private val values: List<LeadsCrossSalesLead>, private val isCustomSearch: Boolean = false) :
	RecyclerView.Adapter<CustomerLeadsAdapter.ViewHolder>() {

	companion object {
		public const val TAG = "CustomerLeadsAdapter"
	}

	var customerLeadsAdapterCallback: CustomerLeadsAdapterCallback? = null

	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
		val itemBinding =AdapterCustomerLeadsBinding.inflate(LayoutInflater.from(parent.context)
			, parent, false)
		return ViewHolder(itemBinding)
	}

	override fun onBindViewHolder(holder: ViewHolder, position: Int) {
		val lead = values.get(position)

			holder.bind(lead,holder)

	}

	private fun clickHandler(
		holder: AdapterCustomerLeadsBinding,
		lead: LeadsCrossSalesLead,
		position: Int,
		viewHolder: ViewHolder
	) {

		viewHolder.itemView.setOnClickListener {
			customerLeadsAdapterCallback?.gotoCustomerLeadsProfile(position, lead)
		}

		holder.ivbCall.setOnClickListener {
			if (AdapterUtils.checkCallLogPermission(context)) {
				customerLeadsAdapterCallback?.makeCall(position, lead)
			} else {
				customerLeadsAdapterCallback?.requestCallLogPermission(position, lead)
			}
		}

		holder.ivbArrow.setOnClickListener {
			customerLeadsAdapterCallback?.gotoCustomerLeadsFeedback(position, lead)
		}
		holder.tvDays.setOnClickListener { holder.ivbArrow.performClick() }

//        if (lead.status == LEAD_STATUS.PENDING || lead.status == LEAD_STATUS.REASSIGNED) {
//            holder.tvDays.setOnClickListener {
//                customerLeadsAdapterCallback?.gotoCustomerLeadsProfile(position, lead)
//            }
//
//        } else if (lead.status == LEAD_STATUS.CALLED) {
//            holder.tvDays.setOnClickListener {
//                customerLeadsAdapterCallback?.gotoCustomerLeadsFeedback(position, lead)
//            }
//        }
	}

	override fun getItemCount(): Int = values.size

	inner class ViewHolder(val itemBinding: AdapterCustomerLeadsBinding) :
		RecyclerView.ViewHolder(itemBinding.root){
			fun bind(lead: LeadsCrossSalesLead, viewHolder: ViewHolder) {
				if (isCustomSearch) {
					itemBinding.llType.visibility = View.VISIBLE
					if (lead.status == LEAD_STATUS.PENDING || lead.status == LEAD_STATUS.REASSIGNED) {
						itemBinding.tvType.text = "Pending"
					} else if (lead.status == LEAD_STATUS.CALLED) {
						itemBinding.tvType.text = "Called"
					}
				} else {
					itemBinding.llType.visibility = View.GONE
				}

				itemBinding.tvCustomerName.text = lead.customerName
				itemBinding.tvProductName.text = lead.interestedIn

				if (lead.status == LEAD_STATUS.PENDING || lead.status == LEAD_STATUS.REASSIGNED) {

					itemBinding.ivbCall.visibility = View.VISIBLE
					//todo new logic to add ask aditya and sadar
					itemBinding.tvDays.text = AdapterUtils.getPendingDaysLeft(AdapterUtils.pendingDaysLeftLogic(lead))

				} else if (lead.status == LEAD_STATUS.CALLED) {
					itemBinding.ivbCall.visibility = View.GONE
					itemBinding.tvDays.text = AdapterUtils.getCalledDaysToGo(AdapterUtils.calledDaysToGoLogic(lead))
				}

				clickHandler(itemBinding, lead, position,viewHolder)
			}
		}


	interface CustomerLeadsAdapterCallback {

		fun gotoCustomerLeadsProfile(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead)
		fun gotoCustomerLeadsFeedback(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead)
		fun makeCall(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead)
		fun requestCallLogPermission(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead)

	}
}
