package com.greenlightplanet.kazi.feedback.repo.model.response

import android.os.Parcelable
import androidx.annotation.Keep
import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackConstants
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.utils.Util
import kotlinx.parcelize.Parcelize

@Keep
@Parcelize
data class SupportTicketResponse(
    val count: Int,
    val pageNumber: Int,
    val request: TicketRequest,
    val responseData: List<TicketResponseData>,
    val responseStatus: Int,
    val serverIp: String,
    val serverPort: String,
    val success: Boolean,
    val totalPages: Int
): Parcelable

@Keep
@Parcelize
data class TicketResponseData(
    val category: String?,
    val closedAt: String?,
    val createdAt: String?,
    val status: String,
    val subCategory: String?,
    val ticketId: String
): Parcelable {
    fun getClosedAtTimeStampUtc(): Long {
        var timestamp: Long = 0
        closedAt?.let {
            timestamp = Helper.getDateToTimeStamp(it, FeedbackConstants.utcDateFormat)
        }
        return timestamp
    }
    fun getCreatedAtTimeStampUtc(): Long {
        var timestamp: Long = 0
        createdAt?.let {
            timestamp = Helper.getDateToTimeStamp(it, FeedbackConstants.utcDateFormat)
        }
        return timestamp
    }
    fun getClosedAtTimeStampLocal(): Long {
        var timestamp: Long = 0
        closedAt?.let {
            timestamp = Helper.getDateToTimeStamp(it ?: "", FeedbackConstants.utcDateFormat)
        }
        return timestamp
    }
    fun getCreatedAtTimeStampLocal(): Long {
        var timestamp: Long = 0
        createdAt?.let {
            timestamp = Helper.getDateToTimeStamp(it ?: "", FeedbackConstants.utcDateFormat)
        }
        return timestamp
    }
    fun getClosedAtUtcToLocal(): String {
        return closedAt?.let {
            Helper.convertUTCtoLocatTimeDDMMYYYYYHHmmss(it)
        }?: ""
    }
    fun getCreatedAtUtcToLocal(): String {
        return createdAt?.let {
            Helper.convertUTCtoLocatTimeDDMMYYYYYHHmmss(it)
        } ?: ""
    }
}

@Keep
@Parcelize
data class TicketRequest(
    val executionTime: Double
): Parcelable