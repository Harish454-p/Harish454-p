package com.greenlightplanet.kazi.fseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.fseProspective.model.AwsImageModel
import io.reactivex.Single

@Dao
interface AwsImageModelDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(AwsImageModel: List<AwsImageModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(AwsImageModel: AwsImageModel): Long

    @Delete
    fun delete(AwsImageModel: AwsImageModel): Int

    @Query("DELETE FROM AwsImageModel")
    fun deleteAll(): Int

    @Query("SELECT * FROM AwsImageModel")
    fun getAll(): Single<List<AwsImageModel>>

    @Query("SELECT * FROM AwsImageModel LIMIT 1")
    fun get(): Single<AwsImageModel>

    @Query("SELECT COUNT(*) from AwsImageModel")
    fun count(): Int

    @Query("SELECT * FROM AwsImageModel WHERE prospectId=:prospectId LIMIT 1")
    fun getByProspectId(prospectId: String): Single<AwsImageModel>?

    @Query("SELECT * FROM AwsImageModel WHERE prospectId IN (:prospectId)")
    fun getAllByProspectID(prospectId: List<String>): Single<List<AwsImageModel>?>

    @Query("SELECT * FROM AwsImageModel WHERE prospectId=:prospectId")
    fun getByALLProspectId(prospectId: String): Single<List<AwsImageModel>>



}
