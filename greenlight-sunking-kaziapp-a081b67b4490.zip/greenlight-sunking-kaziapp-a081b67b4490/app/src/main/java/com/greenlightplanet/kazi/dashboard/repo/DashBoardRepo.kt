package com.greenlightplanet.kazi.dashboard.repo

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.dashboard.model.PutBeforeLogoutModel
import com.greenlightplanet.kazi.dashboard.model.call_sms.CallLogRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.ContactRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.SmsRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.SyncResourcesRequest
import com.greenlightplanet.kazi.dashboard.model.request.DashBoardModel
import com.greenlightplanet.kazi.dashboard.model.request.FlyerRequestModel
import com.greenlightplanet.kazi.dashboard.model.response.AppVersionResponse
import com.greenlightplanet.kazi.dashboard.model.response.DashboardResponseModel
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.member.model.FireBaseRequestBody
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.Completable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class DashBoardRepo(val context: Context) {

    companion object : SingletonHolderUtil<DashBoardRepo, Context>(::DashBoardRepo) {
        public const val TAG = "DashBoardRepo"
    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null

    //private val angazaId = "US029268"
    private val angazaId: String? by lazy {
        preference?.getLoginResponseModel()?.angazaId
    }
    private val territory: String? by lazy {
        preference?.getLoginResponseModel()?.territory
    }

    var gson: Gson? = null

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context)
            gson = Gson()
        } catch (e: Exception) {
            Log.d(TAG, "Init:Error ");
        }
    }

    fun dashboardRX(
        context: Context,
        dashBoardModel: DashBoardModel
    ): MutableLiveData<NewCommonResponseModel<DashboardResponseModel>> {
        val data = MutableLiveData<NewCommonResponseModel<DashboardResponseModel>>()

        bag.add(
            ServiceInstance.getInstance(context).service!!.dashboardRX(/*angazaId!!, */
                dashBoardModel
            )
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "||==DashboardResponseModel=====${it}")
                    it.responseData?.isLite?.let { it1 -> preference?.setIsLite(it1) }
                    it.responseData?.useNewLocationLogic?.let { it1 ->
                        preference?.setFakeLocationSolution(
                            it1
                        )
                    }

                    data.postValue(it)
                    it.responseData?.current_time?.let { it1 ->
                        Util.convertUTCtoLocatTimeYYYYYMMDD_English(it1)
                    }?.let { it2 -> preference?.setServerDate(it2) }
                }, {
                    Log.e(TAG, "||==DashboardResponseModel=====EROORRRR = $it")
                    data.postValue(
                        NewCommonResponseModel<DashboardResponseModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )

                })
        )

        return data

    }


    fun putBeforeLogout(putBeforeLogoutModel: PutBeforeLogoutModel): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        bag.add(
            ServiceInstance.getInstance(context).service!!.putBeforeLogout(putBeforeLogoutModel)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "||==DashboardResponseModel=====${it}")
                    data.postValue(it)
                }, {
                    Log.e(TAG, "||==DashboardResponseModel=====EROORRRR = $it")
                    data.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )

                })
        )

        return data

    }

    fun awsRX(
        context: Context,
        requestModel: BaseRequestModel
    ): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
        val data = MutableLiveData<CommonResponseModel<AWSResponseModel>>()

        bag.add(
            ServiceInstance.getInstance(context).service!!.awsRx(requestModel)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "||==awsRX=====${it}")
                    data.postValue(it)

                }, {
                    Log.e(TAG, "||==awsRX=====EROORRRR = $it")

                    data.postValue(
                        CommonResponseModel<AWSResponseModel>().apply {
                            this.Error =
                                com.greenlightplanet.kazi.member.Error(MessageToUser = "Unable to send data to server")
                            this.Success = false
                        }
                    )
                })
        )

        return data

    }

    fun syncResourcesPart1(
        callLogs: MutableList<CallLogRequest>,
        sms: MutableList<SmsRequest>,
        contacts: MutableList<ContactRequest>
    ) {

        var resultCallLogs = mutableListOf<CallLogRequest>()
        var resultSms = mutableListOf<SmsRequest>()
        var resultContacts = mutableListOf<ContactRequest>()
        bag.add(
            localDb!!.callLogRequestDao().getAll()
                .flatMap { callLogsFromDb ->

                    for (callLog in callLogs) {
                        if (callLogsFromDb.find { callLog.date == it.date && callLog.contactNumber == it.contactNumber } == null) {
                            resultCallLogs.add(callLog)
                        }
                    }

                    localDb!!.smsRequestDao().getAll()
                }.flatMap { smsFromDb ->
                    for (s in sms) {
                        if (smsFromDb.find { s.id == it.id } == null) {
                            resultSms.add(s)
                        }
                    }
                    localDb!!.contactRequestDao().getAll()
                }.flatMapCompletable { contactsFromDb ->
                    //find updated
                    val sumContact = contacts + contactsFromDb

                    val created = sumContact.groupBy { it.localId }
                        .filter { it.value.size == 1 }
                        .flatMap { it.value }
                        .filter { it.serverId.isNullOrEmpty() }

                    val deleted = sumContact.groupBy { it.localId }
                        .filter { it.value.size == 1 }
                        .flatMap { it.value }
                        .filter { !it.serverId.isNullOrEmpty() }
                    Log.e("C_S", "Maz===: ${created.size}==${deleted.size}")
                    for (contact in contacts) {
                        val updateContact =
                            contactsFromDb.find { contact.localId == it.localId && ((contact.numbers != it.numbers) || (contact.name != it.name)) }
                        val isUpdated = updateContact != null

                        if (isUpdated) {
                            updateContact.apply {
                                this?.name = contact.name
                                this?.numbers = contact.numbers
                                this?.status = "UPDATED"
                            }
                            resultContacts.add(updateContact!!)
                        }
                    }

                    deleted.map {
                        it.status = "DELETED"
                    }

                    created.map {
                        it.status = "CREATED"
                    }

//                    resultContacts.addAll(deleted)
//                    resultContacts.addAll(created)
                    resultContacts = (resultContacts + deleted + created).toMutableList()

                    val insertSMS = Completable.fromAction {
                        localDb!!.smsRequestDao().insertAllIgnore(resultSms)
                    }

                    val insertCallLog = Completable.fromAction {
                        localDb!!.callLogRequestDao().insertAllIgnore(resultCallLogs)
                    }

                    val insertContacts = Completable.fromAction {
                        localDb!!.contactRequestDao().insertAllIgnore(resultContacts)
                    }

                    Completable.mergeArray(insertSMS, insertCallLog, insertContacts)

                }.subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({

                    Log.d(TAG, "syncResources: resultCallLogs : $resultCallLogs")
                    Log.d(TAG, "syncResources: resultSms : $resultSms ")
                    Log.d(TAG, "syncResources: resultContacts : $resultContacts")

                    syncResourcesPart2()
                }, {

                    Log.d(TAG, "syncResources:error=> resultCallLogs : $resultCallLogs")
                    Log.d(TAG, "syncResources:error=> resultSms : $resultSms ")
                    Log.d(TAG, "syncResources:error=> resultContacts : $resultContacts")
                    Log.d(TAG, "syncResources: error-real ${it.message}")

                    it.printStackTrace()

                })
        )

    }


    fun syncResourcesPart2() {
        var requestSms: List<SmsRequest>? = null
        var requestCallLog: List<CallLogRequest>? = null
        var requestContact: List<ContactRequest>? = null
        bag.add(

            localDb!!.smsRequestDao().getAllForUpload().flatMap { smsToUpload ->
                requestSms = smsToUpload
                localDb!!.callLogRequestDao().getAllForUpload()
            }.flatMap { callLogToUpload ->
                requestCallLog = callLogToUpload
                localDb!!.contactRequestDao().getAllForUpload()
            }.map { contactToUpload ->
                requestContact = contactToUpload

                ServiceInstance.getInstance(context).service!!.postSyncResources(
                    SyncResourcesRequest(
                        angazaId = preference?.getLoginResponseModel()?.angazaId,
                        sms = requestSms,
                        callLog = requestCallLog,
                        contacts = contactToUpload

                    )
                )
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        Log.e("responseServereData", "" + it.contacts)
                        if (it.contacts!!.isNotEmpty()) {
                            it.contacts?.forEach {
                                localDb?.contactRequestDao()
                                    ?.updateContact(it.localId, it?.serverId)
                            }
                        }
                    }, { t ->
                        Log.e("erroororo", "${t.message} \n\n\n${t.localizedMessage}")

                    })

                SyncResourcesRequest(
                    angazaId = preference?.getLoginResponseModel()?.angazaId,
                    sms = requestSms,
                    callLog = requestCallLog,
                    contacts = requestContact

                )
            }.subscribeOn(Schedulers.io()).observeOn(Schedulers.io()).subscribe({
                Log.d(TAG, "syncResourcesPart2:SyncResourcesRequest : $it ")
            }, {
                it.printStackTrace()
            })

        )
    }

    fun putFireBaseToken(
        url: String,
        fireBaseRequestBody: FireBaseRequestBody
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        bag.add(
            ServiceInstance.getInstance(context).service!!.putFireBaseToken(
                url,
                fireBaseRequestBody
            )
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({

                    Log.e("hdfbjkdbjffdjkgjkd", "ress ${it.responseData}")

                    Log.e(TAG, "||==DashboardResponseModel==FireBase=====${it}")
                    data.postValue(it)
                }, {

                    Log.e("hdfbjkdbjffdjkgjkd", "erro ${it.localizedMessage}")
                    Log.e(TAG, "||==DashboardResponseModel==FireBase=====EROORRRR = $it")
                    data.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )

                })
        )

        return data

    }

    fun flyerPost(
        flyerId: Int
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        val flyerRequestModel = FlyerRequestModel(angazaId!!, flyerId)

        bag.add(
            ServiceInstance.getInstance(context).service!!.flyer(flyerRequestModel)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
//                    Log.e(TAG, "||==flyerPost=====${it}")
                    data.postValue(it)
                }, {
                    Log.e(TAG, "||==flyerPost=====EROORRRR = $it")
                    data.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ), success = false
                        )
                    )

                })
        )

        return data

    }

    /*new added by Mazhar on 10 Nov 21*/
    fun getRXVersion(): MutableLiveData<NewCommonResponseModel<AppVersionResponse>> {
        val data = MutableLiveData<NewCommonResponseModel<AppVersionResponse>>()

        bag.add(
            ServiceInstance.getInstance(context).service!!
                .getRXVersion(versionCode = BuildConfig.VERSION_CODE, territory = territory ?: "")
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "||===${it}")
                    data.postValue(it)

                }, {
                    Log.e(TAG, "||===EROORRRR = $it")
                    data.postValue(
                        NewCommonResponseModel<AppVersionResponse>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )

                })
        )

        return data

    }

}
