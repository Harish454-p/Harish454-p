package com.greenlightplanet.kazi.incentivenew.dao.converter.earning

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.incentivenew.model.earning.EarningsFields
import com.greenlightplanet.kazi.incentivenew.model.summary.CheckListFields
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryFields
import com.greenlightplanet.kazi.pricegroup.model.Pricing_group

class EarningFieldConverter {

    @TypeConverter
    fun fromEarningFieldsList(list: List<EarningsFields>?): String? {
        if (list == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<EarningsFields>>() {

        }.type
        return gson.toJson(list, type)
    }

    @TypeConverter
    fun toEarningFieldsList(string: String?): List<EarningsFields>? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<EarningsFields>>() {

        }.type
        return gson.fromJson(string, type)
    }

}


