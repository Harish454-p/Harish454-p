package com.greenlightplanet.kazi.heroboard.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.heroboard.model.HeroboardModel
import com.greenlightplanet.kazi.heroboard.model.LeaderboardModel
import io.reactivex.Single

@Dao
interface LeaderDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(leaderboardModel: List<LeaderboardModel>): List<Long>

    @Query("DELETE FROM leaderBoard")
    fun deleteAll(): Int

    @Query("SELECT * FROM leaderBoard")
    fun getAll(): Single<List<LeaderboardModel>>

//    @Query("SELECT * FROM leaderBoard LIMIT 1")
//    fun get(): Single<List<LeaderboardModel>>




}
