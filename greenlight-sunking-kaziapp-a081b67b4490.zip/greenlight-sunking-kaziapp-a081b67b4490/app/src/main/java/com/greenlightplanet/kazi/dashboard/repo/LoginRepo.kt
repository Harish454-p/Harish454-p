package com.greenlightplanet.kazi.dashboard.repo

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.greenlightplanet.kazi.dashboard.model.CountryResponseModel
import com.greenlightplanet.kazi.dashboard.model.request.LoginRequestModel
import com.greenlightplanet.kazi.dashboard.model.response.DashboardResponseModel
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.fseProspective.extras.ErrorUtils
import com.greenlightplanet.kazi.fseProspective.model.AwsImageModel
import com.greenlightplanet.kazi.fseProspective.model.InstallationRequestModel
import com.greenlightplanet.kazi.fseProspective.repo.InstallationRepo
import com.greenlightplanet.kazi.heroboard.extras.LeaderBoardUtil
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.member.model.BaseResponseModel
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.task.model.dialogIntent.FeedbackModel
import com.greenlightplanet.kazi.task.model.request.TicketRequestModel
import com.greenlightplanet.kazi.task.repo.CallsRepo
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.Completable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import org.json.JSONObject

class LoginRepo(val context: Context)  {

    companion object : SingletonHolderUtil<LoginRepo, Context>(::LoginRepo) {
        public const val TAG = "SplashScreenRepo"
    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    //private val angazaId = "US029268"
    private val angazaId: String? by lazy {
        preference?.getLoginResponseModel()?.angazaId
    }
    var gson: Gson? = null

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context)
            gson = Gson()
        } catch (e: Exception) {
            Log.d(TAG, "Init:Error ");
        }
    }
/*

   public fun login(
        context: Context,
        loginRequestModel: LoginRequestModel
    ): MutableLiveData<NewCommonResponseModel<LoginResponseModel>?> {
        val data = MutableLiveData<NewCommonResponseModel<LoginResponseModel>?>()

        bag.add(


            ServiceInstance.getInstance(context).service!!.loginPost(loginRequestModel)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(it)
                }, {
                    Log.e(TAG, "||==LoginResponseModel=====EROORRRR = ${it.localizedMessage}")

                    ErrorUtils.errorHandler(
                        gson,
                        it,
                        InstallationRepo.TAG,
                        it.localizedMessage,
                        it.message?:"",
                        data
                    )



                     */
/*   ErrorUtils.errorApi(
                            gson,
                            it,
                            InstallationRepo.TAG,
                            it.localizedMessage,
                            it.localizedMessage,
                            data
                        )*//*

                })
        )

        return data

    }
*/

     fun getCountryList(context: Context): MutableLiveData<List<CountryResponseModel>> {

        val data = MutableLiveData<List<CountryResponseModel>>()

            bag.add(
                localDb?.countryDaos()?.selectToAll()!!
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        data.postValue(it)
                    }, {
                        //data.postValue(it)
                    })
            )

            return data

    }

}