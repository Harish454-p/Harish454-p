package com.greenlightplanet.kazi.dashboard.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.greenlightplanet.kazi.dashboard.model.PutBeforeLogoutModel
import com.greenlightplanet.kazi.dashboard.model.request.DashBoardModel
import com.greenlightplanet.kazi.dashboard.model.response.AppVersionResponse
import com.greenlightplanet.kazi.dashboard.model.response.DashboardResponseModel
import com.greenlightplanet.kazi.dashboard.repo.DashBoardRepo
import com.greenlightplanet.kazi.dashboard.repo.SplashScreenRepo
import com.greenlightplanet.kazi.liteFseProspective.model.*
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteProspectiveRepo
import com.greenlightplanet.kazi.leads.repo.CustomerLeadsRepo
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.member.model.BaseResponseModel
import com.greenlightplanet.kazi.member.model.FireBaseRequestBody
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.new_attendance.repo.AttendanceCheckInRepo
import com.greenlightplanet.kazi.notification.model.notification.Messages
import com.greenlightplanet.kazi.notification.repo.NotificationsRepo
import com.greenlightplanet.kazi.task.model.request.TicketRequestModel
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel

class DashBoardViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val TAG = "DashBoardVM"
    }

    val repo = DashBoardRepo.getInstance(application)

    fun dashboardRX(
        context: Context,
        dashBoardModel: DashBoardModel
    ): MutableLiveData<NewCommonResponseModel<DashboardResponseModel>> {
        return repo.dashboardRX(context, dashBoardModel)
    }

    fun putBeforeLogout(putBeforeLogoutModel: PutBeforeLogoutModel): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        return repo.putBeforeLogout(putBeforeLogoutModel)
    }


    val notificationsRepo = NotificationsRepo.getInstance(application)

    val splashRepo = SplashScreenRepo.getInstance(application)

    val attendanceRepo = AttendanceCheckInRepo.getInstance(application)

    val customerLeadsRepo = CustomerLeadsRepo.getInstance(application)

    val prospectiveRepo = LiteProspectiveRepo.getInstance(application)


    fun postTask(
        angazaId: String,
        requestModel: TicketRequestModel?
    ): MutableLiveData<CommonResponseModel<BaseResponseModel>> {
        return splashRepo.postTask(angazaId, requestModel)
    }

    /*fun updateOfflineList(isOnlineAdded: Boolean, makeTrue: Boolean): Disposable {
        return attendanceRepo.updateOfflineList(isOnlineAdded, makeTrue)
    }

    fun attendanceRXPost(context: Context, angazaId: String, attendanceRequestModel: AttendanceResponseModel?): MutableLiveData<CommonResponseModel<BaseResponseModel>> {
        return attendanceRepo.attendanceRXPost(context, angazaId, attendanceRequestModel)
    }*/

    fun performSendLogic(): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        return attendanceRepo.performSendLogic()
    }

    fun solveabc(): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        return customerLeadsRepo.solveabc()
    }

    fun getAwsImageModelsFromDatabase(): MutableLiveData<List<LiteAwsImageModel>> {
        return prospectiveRepo.getAwsImageModelsFromDatabase()
    }

    fun getAllInOne(): MutableLiveData<SyncCombineModel> {
        return prospectiveRepo.getAllInOne()
    }

    fun alpha(syncCombineModel: SyncCombineModel): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {

        val otpList = mutableListOf<LiteOtpApprovalRequestModel>()
        val registrationCheckinList = mutableListOf<LiteRegistrationCheckinRequestModel>()
        val installationRequestList = mutableListOf<LiteInstallationRequestModel>()

        otpList.clear()
        syncCombineModel.otpApprovalRequestModels?.let {
            otpList.addAll(it)
        }

        registrationCheckinList.clear()
        syncCombineModel.registrationCheckinRequestModels?.let {
            registrationCheckinList.addAll(it)
        }

        installationRequestList.clear()
        syncCombineModel.installationRequestModels?.let {
            installationRequestList.addAll(it)
            Log.e(TAG, "installationRequestList:$installationRequestList");
        }
        return prospectiveRepo.processSyncAll(
            otpList,
            registrationCheckinList,
            installationRequestList
        )
    }

    fun insertAwsImageModelToDatabase(
        inputFiles: List<LiteAwsImageModel>,
        isUploadedToAws: Boolean
    ): MutableLiveData<List<LiteAwsImageModel>?> {
        return prospectiveRepo.insertAwsImageModelToDatabase(inputFiles, isUploadedToAws)
    }

    fun getInstallationRequestModelFromDatabaseById(awsImageModels: List<LiteAwsImageModel>): MutableLiveData<List<LiteInstallationRequestModel>> {
        return prospectiveRepo.getInstallationRequestModelFromDatabaseById(awsImageModels)
    }

    fun getNewNotificationsList(check: Boolean): MutableLiveData<List<Messages>> {
        return notificationsRepo.getNewNotificationsList(check)
    }


    fun awsRX(
        context: Context,
        requestModel: BaseRequestModel
    ): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
        return repo.awsRX(context, requestModel)
    }

    fun putFireBaseToken(
        url: String,
        fireBaseRequestBody: FireBaseRequestBody
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        return repo.putFireBaseToken(url, fireBaseRequestBody)
    }

    //
    fun getRXVersion(): MutableLiveData<NewCommonResponseModel<AppVersionResponse>> {
        return repo.getRXVersion()
    }
    //


    fun flyerPost(
        flyerId: Int
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        return repo.flyerPost(flyerId)
    }
}
