package com.greenlightplanet.kazi.fseProspective.model


data class CombineRequestModel(
        var otpApprovalRequestModel: OtpApprovalRequestModel? = null,
        var registrationCheckinRequestModel: RegistrationCheckinRequestModel? = null,
        var installationRequestModels: InstallationRequestModel? = null,
        var fseProspectResponseModel: FseProspectResponseModel? = null,
        var fseError: FseError? = null
)