package com.greenlightplanet.kazi.loyalty.adapter.leaderboard

import android.content.Context
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckedTextView
import android.widget.TextView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.loyalty.model.leaderboard.events.AllEvents


/**
 * Created by Rahul on 15/04/21.
 */
class LeaderSpinnerAdapter(val context: Context, var dataSource: List<AllEvents>) : BaseAdapter() {

    private val inflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

        val view: View
        val vh: ItemHolder
        if (convertView == null) {
            view = inflater.inflate(R.layout.leader_custome_sppiner, parent, false)
            vh = ItemHolder(view)
            view?.tag = vh
        } else {
            view = convertView
            vh = view.tag as ItemHolder
        }


     
        vh.eventId.text = dataSource[position].id.toString()

        vh.eventName.text = dataSource[position].name


        return view
    }

    override fun getItem(position: Int): Any? {
        return dataSource[position];
    }

    override fun getCount(): Int {
        return dataSource.size;
    }

    override fun getItemId(position: Int): Long {
        return position.toLong();
    }

    private class ItemHolder(row: View?) {
        val eventId: TextView = row?.findViewById(R.id.eventId) as TextView
        val eventName: TextView = row?.findViewById(R.id.eventName) as TextView
    }

}