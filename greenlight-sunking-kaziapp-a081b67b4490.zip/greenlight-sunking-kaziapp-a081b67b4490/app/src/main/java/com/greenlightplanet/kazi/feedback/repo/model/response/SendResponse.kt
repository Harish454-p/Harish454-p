package com.greenlightplanet.kazi.feedback.repo.model.response

import androidx.annotation.Keep

@Keep
data class SendResponse(
    val message: String,
    val request: MessageRequest,
    val status: String,
    val statusCode: Int,
    val ticketId: String
)
@Keep
data class MessageRequest(
    val accountNumber: Any,
    val angazaId: String,
    val attachments: Any,
    val category: Any,
    val message: String,
    val requesterType: String,
    val status: String,
    val subcategory: Any,
    val ticketId: String,
    val updatedBy: String
)