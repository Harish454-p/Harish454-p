package com.greenlightplanet.kazi.feedback.repo.paging

import androidx.lifecycle.MutableLiveData
import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackConstants
import com.greenlightplanet.kazi.feedback.repo.model.response.SupportTicketResponse

import com.greenlightplanet.kazi.feedback.repo.model.response.TicketResponseData
import com.greenlightplanet.kazi.networking.ErrorResponse
import com.greenlightplanet.kazi.networking.NetworkService
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.NetworkResult
import com.greenlightplanet.kazi.utils.Util
import retrofit2.Response
import timber.log.Timber

import javax.inject.Inject
/** This class Handles Pagination for Closed and Pending Ticket screens*/
class SupportDataPagingSource @Inject
constructor(private val apiInterface: NetworkService, val preference: GreenLightPreference) :
    PagingSource<Int, TicketResponseData>() {
    var status = ""

    companion object {
        val ticketResponseLiveData = MutableLiveData<NetworkResult<SupportTicketResponse>>()
        val lastSyncedLiveData = MutableLiveData<Boolean>()
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, TicketResponseData> {
        val currentPageKey = params.key ?: 0
        val limit = 20
        return try {

            val angazaId = preference.getLoginResponseModel()?.angazaId
            val url = "${FeedbackConstants.BASE_URL}${FeedbackConstants.TICKET_LIST_ENDPOINT}$angazaId"
            val response = apiInterface.getTicketsPagingData(
                url = url,
                status = status,
                pageSize = limit.toString(),
                pageNumber = currentPageKey.toString()
            )
            /** Notifying the Views about the new dataList received*/
            if (response.isSuccessful) {
                if (response.body() != null && !response.body()?.responseData.isNullOrEmpty()) {
                    lastSyncedLiveData.postValue(true)
                    preference.setFeedbackTicketLastSynced(Util.getCurrentLocalFormattedDateForSync())
                    ticketResponseLiveData.postValue(NetworkResult.Success(response.body()!!))
                } else {
                    if (currentPageKey == 0) {
                        ticketResponseLiveData.postValue(NetworkResult.Error(message = "${status.lowercase().trim()}"))
                    }
                }
            } else {
                val errorResponse = getErrorBody(response)
                errorResponse?.let {
                    ticketResponseLiveData.postValue(NetworkResult.Error("${it.error?.MessageToUser}"))
                }
            }
            Timber.d("PagingAdapter: Response: ${response.body()}")
            val mList = response.body()?.responseData
            LoadResult.Page(
                data = mList!!,
                prevKey = if (currentPageKey == 0) null else currentPageKey - 1,
                nextKey = if (mList.isNullOrEmpty()) null else currentPageKey + 1
            )
        } catch (e: Exception) {
            ticketResponseLiveData.postValue(NetworkResult.Exception("${e.message}"))
            Timber.d("PagingAdapter: Exception: $e")
            LoadResult.Error(e)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, TicketResponseData>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            state.closestPageToPosition(anchorPosition)?.prevKey?.plus(1)
                ?: state.closestPageToPosition(anchorPosition)?.nextKey?.minus(1)
        }

    }

    fun getErrorBody(response: Response<SupportTicketResponse>): ErrorResponse? {
        val gson = Gson()
        val type = object : TypeToken<ErrorResponse>() {}.type
        var errorResponse: ErrorResponse? = gson.fromJson(response.errorBody()!!.charStream(), type)
        return errorResponse
    }
}