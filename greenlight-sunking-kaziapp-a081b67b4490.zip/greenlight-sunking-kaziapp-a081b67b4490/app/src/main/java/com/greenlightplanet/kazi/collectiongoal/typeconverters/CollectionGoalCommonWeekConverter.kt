package com.greenlightplanet.kazi.collectiongoal.typeconverters

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.collectiongoal.model.pastweekincentive.LastWeekIncentiveModel
import com.greenlightplanet.kazi.summary.model.SummaryModel

class CollectionGoalCommonWeekConverter {

    @TypeConverter
    fun fromCollectionGoalCommonWeek(collectionGoalCommonWeek: SummaryModel.CollectionGoalCommonWeek?): String? {
        if (collectionGoalCommonWeek == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<SummaryModel.CollectionGoalCommonWeek>() {

        }.type
        return gson.toJson(collectionGoalCommonWeek, type)
    }

    @TypeConverter
    fun toCollectionGoalCommonWeek(string: String?): SummaryModel.CollectionGoalCommonWeek? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<SummaryModel.CollectionGoalCommonWeek?>() {

        }.type
        return gson.fromJson(string, type)
    }
}

class CommonWeekIncentiveConverter {

    @TypeConverter
    fun fromCollection(commonchievedIncentiveModelList: List<LastWeekIncentiveModel.AchievedAccount>?): String? {
        if (commonchievedIncentiveModelList == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<LastWeekIncentiveModel.AchievedAccount>>() {

        }.type
        return gson.toJson(commonchievedIncentiveModelList, type)
    }

    @TypeConverter
    fun toCollectionList(clList: String?): List<LastWeekIncentiveModel.AchievedAccount>? {
        if (clList == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<LastWeekIncentiveModel.AchievedAccount>>() {

        }.type
        return gson.fromJson(clList, type)
    }
}

class CollectionGoalLastWeekConverter {

    @TypeConverter
    fun fromCollectionGoalLastWeek(collectionGoalCommonWeek: LastWeekIncentiveModel.CollectionGoalCommonWeek?): String? {
        if (collectionGoalCommonWeek == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<LastWeekIncentiveModel.CollectionGoalCommonWeek>() {

        }.type
        return gson.toJson(collectionGoalCommonWeek, type)
    }

    @TypeConverter
    fun toCollectionGoalLastWeek(string: String?): LastWeekIncentiveModel.CollectionGoalCommonWeek? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<LastWeekIncentiveModel.CollectionGoalCommonWeek?>() {

        }.type
        return gson.fromJson(string, type)
    }
}