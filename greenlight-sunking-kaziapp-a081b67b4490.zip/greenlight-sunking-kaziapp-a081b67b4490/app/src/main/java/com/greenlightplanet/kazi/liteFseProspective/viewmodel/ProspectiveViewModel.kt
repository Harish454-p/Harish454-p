package com.greenlightplanet.kazi.liteFseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.greenlightplanet.kazi.dashboard.model.response.AppVersionResponse
import com.greenlightplanet.kazi.dashboard.repo.DashBoardRepo
import com.greenlightplanet.kazi.liteFseProspective.model.*
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteProspectiveRepo
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel
import com.greenlightplanet.kazi.utils.Util

class ProspectiveViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "LiteProspectiveVM"

    }

    val repo = LiteProspectiveRepo.getInstance(application)
    val dashRepo = DashBoardRepo.getInstance(application)

    fun getFseProspective(
        context: Context,
        angazaId: String,
        forceOffline: Boolean = false,
        showProgress: () -> Unit = {}
    )
            : MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {

        showProgress()

        if (forceOffline) {
            return repo.getFseProspectiveFromDatabase()
        } else if (Util.isOnline(context)) {
            return repo.getFseProspectiveFromServer(angazaId)
        } else {
            return repo.getFseProspectiveFromDatabase()
        }

    }

    fun getAllInOne(showProgress: () -> Unit = {}): MutableLiveData<SyncCombineModel> {
        return repo.getAllInOne()
    }

    fun alpha(syncCombineModel: SyncCombineModel): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {


        val otpList = mutableListOf<LiteOtpApprovalRequestModel>()
        val registrationCheckinList = mutableListOf<LiteRegistrationCheckinRequestModel>()
        val installationRequestList = mutableListOf<LiteInstallationRequestModel>()

        otpList.clear()
        syncCombineModel.otpApprovalRequestModels?.let {
            otpList.addAll(it)
        }

        registrationCheckinList.clear()
//        syncCombineModel.registrationCheckinRequestModels?.let {
//            registrationCheckinList.addAll(it)
//        }

        installationRequestList.clear()
        syncCombineModel.installationRequestModels?.let {
            installationRequestList.addAll(it)
            Log.d(TAG, "installationRequestList:$installationRequestList");
        }


        return repo.processSyncAll(otpList, registrationCheckinList, installationRequestList)
    }

    fun getInstallationRequestModelFromDatabaseById(awsImageModels: List<LiteAwsImageModel>): MutableLiveData<List<LiteInstallationRequestModel>> {
        return repo.getInstallationRequestModelFromDatabaseById(awsImageModels)
    }

    fun insertAwsImageModelToDatabase(
        inputFiles: List<LiteAwsImageModel>,
        isUploadedToAws: Boolean
    ): MutableLiveData<List<LiteAwsImageModel>?> {
        return repo.insertAwsImageModelToDatabase(inputFiles, isUploadedToAws)
    }

    fun getAwsImageModelsFromDatabase(): MutableLiveData<List<LiteAwsImageModel>> {
        return repo.getAwsImageModelsFromDatabase()
    }

    fun awsRX(
        context: Context,
        requestModel: BaseRequestModel
    ): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
        return repo.awsRX(context, requestModel)
    }

    fun getRXVersion(): MutableLiveData<NewCommonResponseModel<AppVersionResponse>> {
        return dashRepo.getRXVersion()
    }

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }


}
