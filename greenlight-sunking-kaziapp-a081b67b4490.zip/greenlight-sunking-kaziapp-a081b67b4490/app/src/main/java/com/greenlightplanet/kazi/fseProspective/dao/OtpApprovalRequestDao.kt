package com.greenlightplanet.kazi.fseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.fseProspective.model.OtpApprovalRequestModel
import io.reactivex.Single

@Dao
interface OtpApprovalRequestDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(OtpApprovalRequest: List<OtpApprovalRequestModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(OtpApprovalRequestModel: OtpApprovalRequestModel): Long

    @Delete
    fun delete(OtpApprovalRequestModel: OtpApprovalRequestModel): Int

    @Query("DELETE FROM OtpApprovalRequest")
    fun deleteAll(): Int

    @Query("SELECT * FROM OtpApprovalRequest")
    fun getAll(): Single<List<OtpApprovalRequestModel>>

    @Query("SELECT * FROM OtpApprovalRequest LIMIT 1")
    fun get(): Single<OtpApprovalRequestModel>

    @Query("SELECT COUNT(*) from OtpApprovalRequest")
    fun count(): Single<Int>

    @Query("SELECT * FROM OtpApprovalRequest WHERE prospectId=:prospectId LIMIT 1")
    fun getByProspectId(prospectId: String): Single<OtpApprovalRequestModel>?

    @Query("SELECT * FROM OtpApprovalRequest WHERE prospectId IN (:prospectId)")
    fun getAllByProspectID(prospectId: List<String>): Single<List<OtpApprovalRequestModel>?>

}
