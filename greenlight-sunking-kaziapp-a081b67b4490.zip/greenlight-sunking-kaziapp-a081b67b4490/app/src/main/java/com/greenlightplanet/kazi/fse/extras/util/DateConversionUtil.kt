package com.greenlightplanet.kazi.fse.extras.util

import java.text.SimpleDateFormat
import java.util.*

class DateConversionUtil {

    companion object {
        public const val TAG = "DateConversionUtil"
        val calendar = Calendar.getInstance()
        //val sdf = SimpleDateFormat("yyyy-MM-dd")
        val sdf = SimpleDateFormat("yyyy-MM-dd")


        //remove this
        fun getCurrentDate(): String {
            return sdf.format(calendar.time)
        }


        //remove this
        fun getMilliseconds(date: String): Long {
            val date = sdf.parse(date)
            return date.time
        }


        fun getTimeAsPerPosition(position: Int): String {

            val clonedCalendar = calendar.clone() as Calendar


            return when (position) {

                0 -> {
                    getCurrentDate()
                }

                1 -> {

                    clonedCalendar.add(Calendar.DATE, -1)
                    sdf.format(clonedCalendar.time)

                }

                2 -> {

                    clonedCalendar.add(Calendar.DATE, -7)
                    sdf.format(clonedCalendar.time)


                }

                3 -> {
                    clonedCalendar.add(Calendar.DATE, -14)
                    sdf.format(clonedCalendar.time)

                }

                else -> {
                    getCurrentDate()

                }

            }
        }


        fun validToSubmitCommitment(): Boolean {
            val currentDate = Date()
            val submissionDate = Date()
            //val calendar = Calendar.getInstance()
            val validationCalendar = calendar.clone() as Calendar
            validationCalendar.time = submissionDate
            validationCalendar.set(Calendar.HOUR_OF_DAY, 11)// for 6 hour
            validationCalendar.set(Calendar.MINUTE, 0)// for 0 min
            validationCalendar.set(Calendar.SECOND, 0)// for 0 sec
            return currentDate.before(validationCalendar.time)
        }

    }


}