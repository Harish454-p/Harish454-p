package com.greenlightplanet.kazi.fseProspective.extras

class FseProspectiveConstant {

    object ProspectiveType {
        val VERIFICATION = "VERIFICATION"
        val REGISTRATION = "REGISTRATION"
        val INSTALLATION = "INSTALLATION"
    }


    object ProspectStatus {

        val PROSPECT = "PROSPECT"//step -1
        val OTP_APPROVED = "OTP_APPROVED"//step -2
        val PRE_APPROVED_PROSPECT = "PRE_APPROVED_PROSPECT"//step -3
        val CHECKED_IN = "CHECKED_IN"//step -4
        val THREE_WAY_CALL = "THREE_WAY_CALL"//step -4 = not sure about name
        val INSTALLATION_PENDING = "INSTALLATION_PENDING"//step -5
        val INSTALLED = "INSTALLED"//step -6
        val INSTALLATION_VERIFIED = "INSTALLATION_VERIFIED"//step -6
        val INSTALLATION_REATTEMPT = "INSTALLATION_REATTEMPT"//step -7

    }
}
