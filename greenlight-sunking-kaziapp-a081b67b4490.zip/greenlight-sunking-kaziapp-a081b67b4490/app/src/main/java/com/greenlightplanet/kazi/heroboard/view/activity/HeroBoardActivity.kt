package com.greenlightplanet.kazi.heroboard.view.activity

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityHeroBoardBinding
import com.greenlightplanet.kazi.heroboard.model.LeaderboardModel
import com.greenlightplanet.kazi.heroboard.view.adapter.HeroBoardPagerAdapter
import com.greenlightplanet.kazi.heroboard.viewmodel.LeaderViewModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import java.util.*


class HeroBoardActivity : BaseActivity() {

     private lateinit var binding:ActivityHeroBoardBinding
    var viewpagerAdapterList = mutableListOf<LeaderboardModel>()
    var filterList: MutableList<LeaderboardModel> = mutableListOf()

    var mainList: MutableList<LeaderboardModel> = mutableListOf()
    var viewPagerAdapter: HeroBoardPagerAdapter? = null
    var viewModel: LeaderViewModel? = null

    var Current_Month: String? = null
    var Previous_Month: String? = null
    var loginResponseData: LoginResponseModel? = null
    var preference: GreenLightPreference? = null

	var mHomeWatcher: HomeWatcher? = null


	override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_hero_board)
        binding = ActivityHeroBoardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        Util.setToolbar(this, toolbar)
        binding.tabLayout.setupWithViewPager(binding.viewpagerId)
        preference = GreenLightPreference.getInstance(this)
        loginResponseData = preference?.getLoginResponseModel()
        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
//        txt_Previous.setPaintFlags(txt_Previous.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)

        val mCalendar = Calendar.getInstance()
        Current_Month = mCalendar.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.US)
        mCalendar.add(Calendar.MONTH, -1).toString()
        Previous_Month = mCalendar.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.US) //getDefault()
        Log.e("||rr =MOnths=", "Current_Month = $Current_Month === Previous_Month = $Previous_Month")
        InitVM()
        ClickList()

		mHomeWatcher = HomeWatcher(this)
		mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
			override fun onHomePressed() {
				finish()
			}
		})
		mHomeWatcher!!.startWatch()
    }

    fun InitVM() {
        viewModel = ViewModelProviders.of(this).get(LeaderViewModel::class.java)
        showProgressDialog(this)
        viewModel?.getLeaderModel( /*"US029794"*/loginResponseData!!.angazaId!!)?.observe(this, Observer { hero ->

            if (hero!!.success) {
                val data = hero.responseData!!.leaderboard

                binding.tvNodata.visibility = View.GONE
                binding.tabLayout.visibility = View.VISIBLE
                binding.viewpagerId.visibility = View.VISIBLE
                binding.txtPrevious.visibility = View.VISIBLE
                binding.viewUnderL.visibility = View.VISIBLE
                val last: LastSaved? = OfferUtils.loadSummaryFromPref(this)
                binding.tvLastSaved.text = last?.heroBoard
                data.let {
                    if (!data.isNullOrEmpty()) {
                        mainList = it.toMutableList()
                        if (binding.txtPrevious.text == getString(R.string.last_month_ranking)) {

                            filterList = it.filter { it.month == Current_Month }.toMutableList()
                            setAdapter(filterList)
                            Log.e("||rr =if=", filterList.toString())

                        } else {

                            filterList = it.filter { it.month == Previous_Month }.toMutableList()
                            setAdapter(filterList)
                            Log.e("||rr =else=", filterList.toString())
                        }
                    } else {
                        Util.showToast(this.resources.getString(R.string.no_data_available), this)
                        finish()
                    }
                }


            } else {
                binding. tvNodata.visibility = View.VISIBLE
                binding. tabLayout.visibility = View.GONE
                binding. viewpagerId.visibility = View.GONE
                binding.txtPrevious.visibility = View.GONE
                binding.viewUnderL.visibility = View.GONE
//                Util.showToast("No data available", this)
//                finish()
            }
            cancelProgressDialog()
        })
    }

    fun ClickList() {

        binding.txtPrevious.setOnClickListener {

            if (binding.txtPrevious.text == getString(R.string.last_month_ranking)) {
                filterList = mainList.filter { it.month == Previous_Month }.toMutableList()
                setAdapter(filterList)
                binding.txtPrevious.text = getString(R.string.current_month_ranking)
                binding.txtPrevious.setTextColor(resources.getColor(R.color.colorBlack))
                binding.viewUnderL.setBackgroundColor(resources.getColor(R.color.colorBlack))
            } else {
                filterList = mainList.filter { it.month == Current_Month }.toMutableList()
                setAdapter(filterList)
                binding.txtPrevious.text = getString(R.string.last_month_ranking)
                binding.txtPrevious.setTextColor(resources.getColor(R.color.colorBlue))
                binding.viewUnderL.setBackgroundColor(resources.getColor(R.color.colorBlue))
            }
        }
    }

    fun setAdapter(list: List<LeaderboardModel>) {
        viewpagerAdapterList.clear()
        viewpagerAdapterList.addAll(list)
        if (viewPagerAdapter == null) {
            viewPagerAdapter = HeroBoardPagerAdapter(this,supportFragmentManager, viewpagerAdapterList)
            binding.viewpagerId.adapter = viewPagerAdapter

        } else {
            binding.viewpagerId.adapter?.notifyDataSetChanged()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item?.itemId) {
            android.R.id.home -> {

                onBackPressed()

                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }


	override fun onDestroy() {
		super.onDestroy()
		mHomeWatcher?.stopWatch();

	}
}
