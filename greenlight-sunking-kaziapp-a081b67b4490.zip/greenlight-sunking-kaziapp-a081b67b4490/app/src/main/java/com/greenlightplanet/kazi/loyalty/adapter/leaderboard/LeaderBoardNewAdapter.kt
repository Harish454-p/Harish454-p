package com.greenlightplanet.kazi.loyalty.adapter.leaderboard

/*

import android.content.Context
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYou
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYouListener
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.loyalty.model.achievements.Achieved
import com.greenlightplanet.kazi.loyalty.model.leaderboard.User_rank



*/
/**
 * Created by Rahul on 06/04/21.
 *//*



class LeaderBoardNewAdapter internal constructor(var context: Context, var listItem: MutableList<User_rank>) : RecyclerView.Adapter<LeaderBaseViewHolder>() {
    private val VIEW_TYPE_LOADING = 0
    private val VIEW_TYPE_NORMAL = 1
    private var isLoaderVisible = false



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LeaderBaseViewHolder {
        return when (viewType) {
            VIEW_TYPE_NORMAL -> ViewHolder(
                    LayoutInflater.from(parent.context).inflate(R.layout.leader_recycler_item_view, parent, false), listItem, context)
            VIEW_TYPE_LOADING -> ProgressHolder(
                    LayoutInflater.from(parent.context).inflate(R.layout.item_loading, parent, false))
            else -> null!!
        }
    }

    override fun onBindViewHolder(holder: LeaderBaseViewHolder, position: Int) {
        holder.onBind(position)
    }

    override fun getItemViewType(position: Int): Int {
        return if (isLoaderVisible) {
            if (position == listItem.size - 1) VIEW_TYPE_LOADING else VIEW_TYPE_NORMAL
        } else {
            VIEW_TYPE_NORMAL
        }
    }

    override fun getItemCount(): Int {
        return listItem.size
    }

    fun addItems(achieved: MutableList<User_rank>) {

Log.e("hfbhbrfr",achieved?.size.toString())
     //   listItem.removeAll(achieved)
        listItem.addAll(achieved)
        notifyDataSetChanged()
    }

    fun addLoading() {
        isLoaderVisible = true
        listItem.add(User_rank(0, 0, 0, "", "", 0, "","","","",0))
        notifyItemInserted(listItem.size - 1)
    }

    fun removeLoading() {
        isLoaderVisible = false
        val position = listItem.size - 1
        val item: User_rank? = getItem(position)

        if (item?.user_id == 0) {
            listItem.removeAt(position)
            notifyItemRemoved(position)
        }
    }


    fun clear() {
        listItem.clear()
        notifyDataSetChanged()
    }

    fun getItem(position: Int): User_rank? {
        return listItem[position]
    }

    class ViewHolder internal constructor(itemView: View?, private val listItem: MutableList<User_rank>?, val context: Context) : LeaderBaseViewHolder(itemView) {

        override fun clear() {}
        override fun onBind(position: Int) {
            super.onBind(position)
            val item: User_rank? = listItem?.get(position)


            Log.e("jnjnjnjnjk","${item}")
           // if (item?.event_id != null) {

                itemView.tvRankId.visibility = View.VISIBLE
                itemView.salesId.text = item?.point.toString()
                itemView.tvRankId.text = item?.rank.toString()
                itemView.name.text = "${item?.first_name} ${item?.last_name}"


          //  }
        }

    }

    class ProgressHolder internal constructor(itemView: View?) : LeaderBaseViewHolder(itemView) {
        override fun clear() {}


    }

    interface OnAchievedClickItem {

        fun onAchievedTab(storeItem: Achieved)


    }
}*/
