package com.greenlightplanet.kazi.incentivenew.model.reffrel

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Created by Rahul on 09/12/20.
 */

@Parcelize
@Entity
data class ReferredAgents (

        @ColumnInfo
        @SerializedName("refferedAgentName") val refferedAgentName : String?,

        @PrimaryKey
        @ColumnInfo
        @SerializedName("unitSold") val unitSold : String
):Parcelable