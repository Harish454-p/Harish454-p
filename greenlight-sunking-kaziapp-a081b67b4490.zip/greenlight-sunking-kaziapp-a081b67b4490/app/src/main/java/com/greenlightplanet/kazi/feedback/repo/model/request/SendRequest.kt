package com.greenlightplanet.kazi.feedback.repo.model.request

import androidx.annotation.Keep

@Keep
data class SendRequest(
    val angazaId: String,
    val attachment: List<String> = emptyList(),
    val message: String,
    val requesterType: String = "EO",
    val status: String = "",
    val ticketId: String,
    val updatedBy: String
)