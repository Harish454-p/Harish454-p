package com.greenlightplanet.kazi.feedback.view.activities

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivitySupportFeedbackBinding
import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackConstants
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.feedback.repo.paging.SupportDataPagingSource
import com.greenlightplanet.kazi.feedback.view.adapter.FeedbackPagerAdapter
import com.greenlightplanet.kazi.feedback.viewmodel.SupportFeedbackViewModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.NetworkResult
import com.greenlightplanet.kazi.utils.Util
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import timber.log.Timber

@AndroidEntryPoint
class SupportFeedbackActivity : BaseActivity() {
    private lateinit var binding: ActivitySupportFeedbackBinding
    private var pagerAdapter: FeedbackPagerAdapter? = null
    private val viewModel by viewModels<SupportFeedbackViewModel>()
    val tabArray = arrayOf(
        "Closed",
        "Pending"
    )

    companion object {
        var isRestart = false
    }



    override fun onResume() {
        super.onResume()
        if (FeedbackConstants.isTicketPostSuccess) {
            FeedbackConstants.isTicketPostSuccess = false
            isRestart = true
            restartActivity()
        }
    }
    /** Restarts activity and resets everything */
    private fun restartActivity() {
        val intent = Intent(this@SupportFeedbackActivity, SupportFeedbackActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySupportFeedbackBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initToolbar()
        val date = "07-02-2023 13:34:01"
//        Timber.d("TEST DATE: Current Time in UTC : ${Helper.convertUTCTimeWithFormatToRequired(date, FeedbackConstants.utcDateFormat)}")
        Timber.d("TEST DATE: Current Time in UTC to Local : ${Helper.convertUTCtoLocatTimeDDMMYYYYYHHmmss(date)}")
        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        val viewPager = binding.viewpager
        val tabLayout = binding.tabLayout

        pagerAdapter = FeedbackPagerAdapter(supportFragmentManager, lifecycle)
        viewPager.adapter = pagerAdapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = tabArray[position]
        }.attach()
        initTabLayout()
        if (isRestart) {
            isRestart = false
            selectPendingFrag()
        }
        observer()
        listener()
    }

    private fun initToolbar() {
        setSupportActionBar(binding.toolbar)
        Util.setToolbar(this@SupportFeedbackActivity, binding.toolbar)
    }

    private fun listener() {
        binding.btnNewTicket.setOnClickListener {
            val intent = Intent(this@SupportFeedbackActivity, NewTicketFeedbackActivity::class.java)
            startActivity(intent)
        }
    }


    private fun observer() {
        with(viewModel) {
            ticketResponseLiveData.observe(this@SupportFeedbackActivity) { response ->
                when (response) {
                    is NetworkResult.Success -> {
                        response.data?.let { ticketResponse ->
                            Timber.d("Activity: Ticket API Success -> $ticketResponse ")

                        }
                        cancelProgressDialog()
                    }
                    is NetworkResult.DbSuccess -> {
                        response.isSuccess?.let {
                            if (it) {
                                if (response.data?.size != 0) {
//                                    updateSharedPref(true)
                                    Timber.d("TicketApiData: Room Cache Success : ${response.data}")
//                                    getAllPendingTickets()
//                                    getAllClosedTickets()
                                }


                            } else Timber.d("TicketApiData: Room Cache Failed")
                        }
                        cancelProgressDialog()
                    }
                    is NetworkResult.Error -> {
                        response.message?.let {
                            Util.showToast(this@SupportFeedbackActivity, it)
                            Timber.d("TicketApi ERROR: $it")
                        }
                        cancelProgressDialog()
                    }
                    is NetworkResult.Loading -> {
                        showProgressDialog(this@SupportFeedbackActivity)
                    }
                    else->{}
                }
            }
            SupportDataPagingSource.lastSyncedLiveData.observe(this@SupportFeedbackActivity) {
                if (it) {
                    binding.tvLastSaved.text = "${getString(R.string.last_saved_key)} ${GreenLightPreference(this@SupportFeedbackActivity).getFeedbackTicketLastSynced()}"
                }
            }
        }
    }

    /** Navigates to Pending Ticket Screen if user comes back after submitting the ticket successfully */
    fun selectPendingFrag() {
        lifecycleScope.launch(Dispatchers.Main) {
            showProgressDialog(this@SupportFeedbackActivity)
            delay(2000)
            dialog?.dismiss()
            binding.tabLayout.getTabAt(1)?.select()
        }
    }


    private fun initTabLayout() {
        binding.tabLayout.tabGravity = TabLayout.GRAVITY_FILL

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                binding.viewpager.currentItem = tab.position
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}

            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        val pageChangeCallback = object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {

            }
        }

        binding.viewpager.registerOnPageChangeCallback(pageChangeCallback)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            android.R.id.home -> {

                onBackPressed()

                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

}