package com.greenlightplanet.kazi.incentivenew.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.AdapterEarningChildBinding
import com.greenlightplanet.kazi.incentivenew.model.deduction.SubFields
import com.greenlightplanet.kazi.utils.Util.Companion.formatAmount


/**
 * Created by Rahul on 25/06/20.
 */
class EarningChildAdapter(private val children: List<SubFields>) :
    RecyclerView.Adapter<EarningChildAdapter.ViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {

        val itemBinding = AdapterEarningChildBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(itemBinding)
    }

    override fun getItemCount(): Int {
        return children.size
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int
    ) {

        val child: SubFields = children[position]
        holder.bind(child)
        // setFadeAnimation(holder.itemView)
    }


    inner class ViewHolder(val itemBinding: AdapterEarningChildBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {

        fun bind(child: SubFields) {

            itemBinding.tvItemOne.text = child.name

            if (/*child.fieldValueDataType.equals("DOUBLE", true) ||*/
                child.fieldValueDataType.equals("INTEGER", true)
            ) {
                itemBinding.tvItemTwo.text = child.value?.toDouble()?.let { formatAmount(it) }
            } else {
                itemBinding.tvItemTwo.text = child.value?:"NA"
            }
        }

    }

    private fun setFadeAnimation(view: View) {
        val anim = AlphaAnimation(0.0f, 1.0f)
        anim.duration = 500
        view.startAnimation(anim)
    }
}