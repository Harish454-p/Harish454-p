package com.greenlightplanet.kazi.incentive.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.incentive.model.StarClubResponseModel
import com.greenlightplanet.kazi.task.model.dialogIntent.FeedbackModel
import com.greenlightplanet.kazi.task.model.dialogIntent.NotAnsweredModel
import com.greenlightplanet.kazi.task.model.response.CallDetail
import com.greenlightplanet.kazi.task.model.response.TaskMddel
import com.greenlightplanet.kazi.task.model.response.firstCall

import io.reactivex.Single

@Dao
interface StarClubDao {

    @Query("SELECT * FROM StarClubResponseModel")
    fun getAllStartClubData(): Single<StarClubResponseModel>


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(dialogModel: StarClubResponseModel): Long

    @Query("DELETE FROM StarClubResponseModel")
    fun deleteAll(): Int

    ///------
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertNotAnsweredCall(notAnsweredModel: NotAnsweredModel)

    @Query("SELECT * FROM StarClubResponseModel")
    fun getAllNotAnswered(): List<StarClubResponseModel>

    @Query("DELETE FROM StarClubResponseModel")
    fun deleteAllNotAnswered()



}
