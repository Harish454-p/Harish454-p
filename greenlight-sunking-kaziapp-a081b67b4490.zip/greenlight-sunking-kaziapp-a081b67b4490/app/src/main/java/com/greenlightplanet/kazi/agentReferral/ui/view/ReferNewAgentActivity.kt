package com.greenlightplanet.kazi.agentReferral.ui.view

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.countryCode
import com.greenlightplanet.kazi.agentReferral.viewmodel.ReferNewAgentViewModel
import com.greenlightplanet.kazi.databinding.ActivityReferNewAgentBinding
import com.greenlightplanet.kazi.leads.view.activity.CustomerLeadsFeedbackActivity
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener

class ReferNewAgentActivity : BaseActivity() {

    private val TAG : String = "RefNewAgentActivity"
    private lateinit var binder : ActivityReferNewAgentBinding
    private lateinit var viewModel : ReferNewAgentViewModel
    private lateinit var preference: GreenLightPreference
    private var mHomeWatcher: HomeWatcher? = null
    private var countryCode : String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binder = ActivityReferNewAgentBinding.inflate(layoutInflater)
        setContentView(binder.root)

        preference = GreenLightPreference.getInstance(this)
        Util.setToolbar(this, binder.toolbar)

        viewModel = ViewModelProvider(this)[ReferNewAgentViewModel::class.java]

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(CustomerLeadsFeedbackActivity.TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()

        viewModelHandler()
    }

    private fun viewModelHandler() {
        viewModel.run {
            binder.run {
                showLastSync()
                countryCode = countryCode(preference.getLoginResponseModel()?.country!!)
                obsResponseSms.observe(this@ReferNewAgentActivity, Observer { sms ->
                    showLastSync()
                    validateSms(
                        message = sms.sms?.message,
                        phone = sms.sms?.mobileNumbers,
                        dialogMessage = sms.responseMessage
                    )
                })

                obsErrorResponse.observe(this@ReferNewAgentActivity, Observer { message ->
                    showLastSync()
                    Util.customFseRationaleDialog(
                        context = this@ReferNewAgentActivity,
                        title = "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = message,
                        positveSelected = {
                            it.dismiss()
                            onBackPressed()
                        },
                        negativeSeleted = {
                            it.dismiss()
                            onBackPressed()
                        }
                    )
                    this@ReferNewAgentActivity.cancelProgressDialog()
                })

                btnSubmitPhone.setOnClickListener {
                    Util.addEvent(
                            id = "378",
                            name ="New referral sumit button",
                            event ="user_click_on_new_referral_submit"
                    )
                    showProgressDialog(this@ReferNewAgentActivity)
                    submitAgent(
                        countryCode = countryCode!!,
                        phoneNumber = etxtPhone.text.toString().trimStart().trimEnd(),
                        name = etxtName.text.toString(),
                        referNewAgentActivity = this@ReferNewAgentActivity
                    )
                }
                txtCountryCode.text = countryCode!!
            }
        }
    }

    private fun validateSms(
        phone: String?,
        message: String?,
        dialogMessage : String?
    ){
        when(phone) {
            null, "" -> {
                Util.customFseRationaleDialog(
                    context = this,
                    title = "",
                    hideNegative = true,
                    titleSpanned = null,
                    hideTitle = true,
                    message = "Error! please try again",
                    positveSelected = {
                        it.dismiss()
                        onBackPressed()
                    },
                    negativeSeleted = {
                        it.dismiss()
                        onBackPressed()
                    }
                )
                this@ReferNewAgentActivity.cancelProgressDialog()
            }
            else -> {
                when(message) {
                    null, "" -> {
                        Util.customFseRationaleDialog(
                            context = this,
                            title = "",
                            hideNegative = true,
                            titleSpanned = null,
                            hideTitle = true,
                            message = "Error! please try again",
                            positveSelected = {
                                it.dismiss()
                            },
                            negativeSeleted = {
                                it.dismiss()
                            }
                        )
                        this@ReferNewAgentActivity.cancelProgressDialog()
                    }
                    else -> {
                        Util.customFseRationaleDialog(
                            context = this,
                            title = "",
                            hideNegative = true,
                            titleSpanned = null,
                            hideTitle = true,
                            message = dialogMessage ?: "Error! please try again",
                            positveSelected = {
                                it.dismiss()
                                onBackPressed()
                            },
                            negativeSeleted = {
                                it.dismiss()
                                onBackPressed()
                            }
                        )
                        this@ReferNewAgentActivity.cancelProgressDialog()
                        sendSMS(
                            phone = phone,
                            message = message
                        )
                    }
                }
            }
        }
    }

    private fun showLastSync() {
        binder.run {
            txtAppVersion.text = this@ReferNewAgentActivity.getString(R.string.app_version, BuildConfig.VERSION_NAME)
            txtLastSync.text = this@ReferNewAgentActivity.getString(R.string.last_sync, preference.getAgentReferralSubmitLastSync())
        }
    }

    private fun sendSMS(
        phone: String,
        message: String
    ) {
        Log.i(TAG,"initiate Send SMS")
        val uri = Uri.parse("smsto:$phone")
        val smsIntent = Intent(Intent.ACTION_SENDTO, uri)
        smsIntent.putExtra("sms_body", message)
        try {
            Log.i(TAG, "launching SMS app...")
            startActivity(smsIntent)
        } catch (ex: ActivityNotFoundException) {
            Log.e(TAG,"sms failed with error : ${ex.localizedMessage}")
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        mHomeWatcher?.stopWatch()
        super.onDestroy()
        finish()
    }
}