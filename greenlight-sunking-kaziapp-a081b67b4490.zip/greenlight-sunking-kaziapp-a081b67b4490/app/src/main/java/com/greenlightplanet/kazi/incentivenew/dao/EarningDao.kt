package com.greenlightplanet.kazi.incentivenew.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.incentive.model.StarClubResponseModel
import com.greenlightplanet.kazi.incentivenew.model.earning.EarningResponseData
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryResponseData
import com.greenlightplanet.kazi.task.model.dialogIntent.FeedbackModel
import com.greenlightplanet.kazi.task.model.dialogIntent.NotAnsweredModel
import com.greenlightplanet.kazi.task.model.response.CallDetail
import com.greenlightplanet.kazi.task.model.response.TaskMddel
import com.greenlightplanet.kazi.task.model.response.firstCall

import io.reactivex.Single

@Dao
interface EarningDao {

    @Query("SELECT * FROM EarningResponseData")
    fun getAllEarningData(): Single<EarningResponseData>


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(earningResponseData: EarningResponseData): Long

    @Query("DELETE FROM EarningResponseData")
    fun deleteAll(): Int




}
