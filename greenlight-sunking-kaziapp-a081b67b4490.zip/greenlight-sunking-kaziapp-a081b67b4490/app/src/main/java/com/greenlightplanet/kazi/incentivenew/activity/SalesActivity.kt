package com.greenlightplanet.kazi.incentivenew.activity

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.viewpager.widget.ViewPager
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityIncentiveBinding
import com.greenlightplanet.kazi.databinding.ActivitySalesBinding
import com.greenlightplanet.kazi.incentive.adapter.IncentivePagerAdapter
import com.greenlightplanet.kazi.incentivenew.fragment.EligibleFragment
import com.greenlightplanet.kazi.incentivenew.fragment.InEligibleFragment
import com.greenlightplanet.kazi.incentivenew.model.incentive.AgentIncentiveResponseData
import com.greenlightplanet.kazi.incentivenew.viewmodel.SalesViewModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener

/**
 * Created by Rahul on 07/12/20.
 */
class SalesActivity : BaseActivity() {

private lateinit var binding:ActivitySalesBinding

    var loginResponseModel: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    var isFromNotification = false
    var mHomeWatcher: HomeWatcher? = null
    var viewModel: SalesViewModel? = null
    val TAG = "SalesActivity"
    var adapter: ArrayAdapter<String>? = null
    var productList: MutableList<String>? = null
    var salesList: AgentIncentiveResponseData? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_sales)
        binding = ActivitySalesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvAppbottomVersions.text = "V:" + BuildConfig.VERSION_NAME

        initialize()

        APICall()

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }

    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();
    }


    fun initialize() {

        Util.setToolbar(this, binding.toolbar2!!)



        showProgressDialog(this)
        viewModel = ViewModelProviders.of(this).get(SalesViewModel::class.java)

        preference = GreenLightPreference.getInstance(this)
        Util.addEvent("308", "SalesScreen", "EarningScreen_to_SalesScreen")

    }

    private fun setupViewPager(viewPager: ViewPager, agentIncentiveResponseData: AgentIncentiveResponseData) {
        val adapter = IncentivePagerAdapter(supportFragmentManager)

        val eigibleBundel = Bundle()
        eigibleBundel.putParcelable("eligible", agentIncentiveResponseData)

        val eigible = EligibleFragment()
        eigible.arguments = eigibleBundel

        val inEligibleBundel = Bundle()
        inEligibleBundel.putParcelable("inEligible", agentIncentiveResponseData)

        val inEligible = InEligibleFragment()
        inEligible.arguments = inEligibleBundel

        adapter.addFragment(eigible, getString(R.string.eligible_account))
        adapter.addFragment(inEligible, getString(R.string.ineligible_account))


      //  viewPager.adapter = adapter

        val currentPosition: Int = viewPager.currentItem
        adapter.notifyDataSetChanged()
        viewPager.adapter = null
        viewPager.adapter = adapter
        viewPager.currentItem = currentPosition
    }


    fun APICall() {

        //http://rahultyagi.in/agent-incentive-sales.json //US015055

        viewModel?.getIncentiveAgent(this, preference?.getLoginResponseModel()?.angazaId)?.observe(this, Observer { response ->
            if (response != null) {

                if (response.success) {
                    cancelProgressDialog()
                    val incentiveResponseModel = response.responseData
                    loginResponseModel = preference?.getLoginResponseModel()
                    if (incentiveResponseModel != null) {
                        setIncentives(incentiveResponseModel)

                        salesList = incentiveResponseModel
                        productList = response.responseData?.accounts?.distinctBy { it.product }?.mapNotNull { it.product }?.toMutableList()

                        setProductSpinner(incentiveResponseModel)
                    }
                    updateSharedPref(true)

                } else {
                    cancelProgressDialog()
                   // Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show()
                }
            }

        })
    }


    fun setProductSpinner(spinnerSelectionList: AgentIncentiveResponseData) {

        productList!!.add(0, getString(R.string.all))
        adapter = productList?.let { ArrayAdapter(this, android.R.layout.simple_spinner_item, it) }
        adapter?.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)


        binding.productSpinner?.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View, which: Int, id: Long) {

                val product: String = productList?.get(which) ?: ""
                if (spinnerSelectionList.accounts.isEmpty()) {
                    //Util.showToast("No Products Available", this@SalesActivity)
                } else {

                    if (which == 0) {
                        setIncentives(spinnerSelectionList)
                    } else {

                        val value = salesList?.accounts?.filter { it.product == product }?.let { AgentIncentiveResponseData(it) }

                        if (value != null) {
                            setIncentives(value)
                        }

                    }

                }


            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })
        binding.productSpinner!!.setAdapter(adapter)

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()

        return true
    }


    fun setIncentives(agentIncentiveResponseData: AgentIncentiveResponseData) {

        loginResponseModel = preference?.getLoginResponseModel()
       // binding.tvCountry?.text = loginResponseModel?.country
       // binding.tvPhoneNo?.text = loginResponseModel?.phoneNumber
        setupViewPager(this.binding.viewpager!!, agentIncentiveResponseData)
        binding.tabs?.setupWithViewPager(binding.viewpager)
    }

    private fun updateSharedPref(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadIncentiveFromPref(this)

        if (data == null) {
            data = LastSaved()
            data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(this, data)
            binding.tvLastSaved.text = data.incentive

        } else {

            if (fromInternet) {
                data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(this, data)
                binding.tvLastSaved.text = data.incentive
            } else {
                binding.tvLastSaved.text = data.incentive

            }
        }

    }

}
