package com.greenlightplanet.kazi.collectiongoal.view.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.annotation.Keep
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.collectiongoal.model.pastweekincentive.LastWeekIncentiveModel
import com.greenlightplanet.kazi.collectiongoal.viewmodel.CommonWeekIncentiveViewmodel
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityPreviousWeekIncentiveBinding
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.summary.model.SummaryModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher

@Keep
class PastWeekIncentiveActivity : BaseActivity() {

    private lateinit var binding: ActivityPreviousWeekIncentiveBinding
    var preference: GreenLightPreference? = null
    var activity: AppCompatActivity? = null
    var loginResponseModel: LoginResponseModel? = null
    var isFromNotification = false
    var mHomeWatcher: HomeWatcher? = null
    var summaryModel: SummaryModel? = null
    var lastWeekIncentiveModel: LastWeekIncentiveModel? = null
    private val viewModel: CommonWeekIncentiveViewmodel by viewModels()
    var collectionGoalCommonWeek: SummaryModel.CollectionGoalCommonWeek? = null
    var bundle = Bundle()
    var flags: String = ""
    var nextPage: Int = 1

    val TAG = "PreviousWeekIncentiveActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPreviousWeekIncentiveBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Log.d("PastWeekIncen22","Done")
        initialize()
    }

    fun initialize() {

        activity = this
        Util.setToolbar(this, this.binding.toolbar)
        //bundle = intent.extras!!

        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        preference = GreenLightPreference.getInstance(this)
        loginResponseModel = preference?.getLoginResponseModel()

        binding.imgLoc.setOnClickListener{
            val intent = Intent(activity, AccountLastWeekAcitivity::class.java)
            intent.putExtra("angaza", preference?.getLoginResponseModel()?.angazaId)
            intent.putExtra("LWIncentive", lastWeekIncentiveModel)
            startActivity(intent)
        }

        Util.showProgressDialog(this)
        ApiCall(nextPage)

        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this)
        binding.tvTaskLastSaved.text = data?.accountLastSaved

    }

    private fun ApiCall(nextPage: Int) {


        Log.d("APICAllNEEDED","OK DONE")

        viewModel.getLWIncentiveFromServer(nextPage)
            .observe(this, Observer {

                if (it.success){

                    Util.cancelProgressDialog()

                    if (it.responseData?.next==null){
                        this.nextPage = 0
                    }
                    else {
                        this.nextPage = it.responseData?.next!!.toInt()
                    }

                    lastWeekIncentiveModel = it!!.responseData

                    lastWeekIncentiveModel?.collectionGoalLastWeek?.angazaID = preference?.getLoginResponseModel()?.angazaId!!


                    Log.d("CheckingLWIncentive",lastWeekIncentiveModel?.achievedAccounts?.size.toString())
                    if (lastWeekIncentiveModel != null) {

                        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this)
                        binding.tvTaskLastSaved.text = data?.accountLastSaved

                        Log.d("CheckingLWIncentive",lastWeekIncentiveModel?.collectionGoalLastWeek?.weekString.toString())

                        if (lastWeekIncentiveModel?.collectionGoalLastWeek != null){
                            setData(lastWeekIncentiveModel!!.collectionGoalLastWeek!!)
                        }

                    }
                }
                else {
                    Util.cancelProgressDialog()
                    //setData(lastWeekIncentiveModel!!.collectionGoalLastWeek)
                    Log.d("CheckForError1",it.error?.messageToUser.toString())
                    Util.showToast(this,it.error?.messageToUser.toString())
                    Log.d("CheckForError2",it.responseStatus.toString())
                }
            })

    }

    @SuppressLint("SetTextI18n")
    private fun setData(collectionGoalCommonWeek: LastWeekIncentiveModel.CollectionGoalCommonWeek) {

        val symbol = preference?.getCountryResponseModel()?.countryCurrency ?: "NA"

        binding.tvcustTarget.text = collectionGoalCommonWeek.targetAccount.toString()+"(A)"
        binding.tvCustomerAchievedCount.text = collectionGoalCommonWeek.doneAccount.toString()+"(B)"

        binding.tvcustTargetCompleted.text = Util.checkBlank(collectionGoalCommonWeek.percentage.toString(), context = this).toDouble()
                .let { Util.formatAmount(it) }

        binding.tvAmountCollected.text = Util.checkBlank(collectionGoalCommonWeek.weekCollection.toString(), context = this).toDouble()
            .let { Util.formatAmount(it) } + " " + symbol

        binding.tvCommission.text = collectionGoalCommonWeek.commissionPercentage.toString() +"%"

        binding.tvCommissionIncentive.text = Util.checkBlank(collectionGoalCommonWeek.commission.toString(), context = this).toDouble()
            .let { Util.formatAmount(it) } + " " + symbol

        binding.tvDate.text = collectionGoalCommonWeek.weekString.toString()


    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        finish()
        return true
    }

//    private val onBackPressedCallback: OnBackPressedCallback =
//        object : OnBackPressedCallback(true) {
//            override fun handleOnBackPressed() {
//                finish()
//            }
//        }

//    override fun onBackPressed() {
//        super.onBackPressed()
//        finish()
//    }

}