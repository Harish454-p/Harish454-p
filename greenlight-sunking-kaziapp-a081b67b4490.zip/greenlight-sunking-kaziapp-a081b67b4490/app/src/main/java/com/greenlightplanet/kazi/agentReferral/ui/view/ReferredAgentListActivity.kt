package com.greenlightplanet.kazi.agentReferral.ui.view

import android.content.Intent
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.datepicker.CalendarConstraints
import com.google.android.material.datepicker.DateValidatorPointBackward
import com.google.android.material.datepicker.MaterialDatePicker
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.fetchRangeDisplayDate
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.referred_agent_status
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_by_agent_number
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_current_status
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_none
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_referred_date
import com.greenlightplanet.kazi.agentReferral.model.referredagentlist.ReferredAgent
import com.greenlightplanet.kazi.agentReferral.ui.adapter.ReferredAgentAdapter
import com.greenlightplanet.kazi.agentReferral.viewmodel.ReferredAgentListViewModel
import com.greenlightplanet.kazi.databinding.ActivityReferredAgentListBinding
import com.greenlightplanet.kazi.leads.view.activity.CustomerLeadsFeedbackActivity
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import java.util.*

class ReferredAgentListActivity : BaseActivity(), ReferredAgentAdapter.OnReferredAgent {

    private lateinit var binder : ActivityReferredAgentListBinding
    private lateinit var viewModel : ReferredAgentListViewModel
    private var adapter : ReferredAgentAdapter? = null
    private var mHomeWatcher: HomeWatcher? = null
    private val TAG : String = "RefAgentListActivity"
    private var preference : GreenLightPreference? = null
    private var firstDate : Long = Calendar.getInstance(Locale.getDefault()).timeInMillis
    private var secondDate : Long = Calendar.getInstance(Locale.getDefault()).timeInMillis

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binder = ActivityReferredAgentListBinding.inflate(layoutInflater)
        setContentView(binder.root)

        Util.setToolbar(context = this, toolbar = binder.toolbar)
        preference = GreenLightPreference.getInstance(this)
        viewModel = ViewModelProvider(this)[ReferredAgentListViewModel::class.java]



        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(CustomerLeadsFeedbackActivity.TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()

        viewModelHandler()
    }

    private fun viewModelHandler() {
        viewModel.run {
            binder.run {
                lytRcReferredAgents.visibility = View.GONE
                btnCal.text = Html.fromHtml("<font color = #808080>" + "Select Date" + "</font>")
                showLastSync()
                sortReferredAgent(sort_none)
                showProgressDialog(this@ReferredAgentListActivity)
                fetchReferredAgents(
                    isOnline = Util.isOnline(this@ReferredAgentListActivity)
                ).observe(this@ReferredAgentListActivity, Observer { response ->
                    when(response) {
                        null -> {
                            lytRcReferredAgents.visibility = View.GONE
                            txtNoReferredAgents.visibility = View.VISIBLE
                            cancelProgressDialog()
                            Util.customFseRationaleDialog(
                                context = this@ReferredAgentListActivity,
                                title = "",
                                hideNegative = true,
                                titleSpanned = null,
                                hideTitle = true,
                                message = this@ReferredAgentListActivity.getString(R.string.no_data),
                                positveSelected = {
                                    it.dismiss()
                                },
                                negativeSeleted = {
                                    it.dismiss()
                                }
                            )
                        }
                        else -> {
                            when(response.success) {
                                true -> {
                                    when(response.responseData) {
                                        null -> {
                                            lytRcReferredAgents.visibility = View.GONE
                                            txtNoReferredAgents.visibility = View.VISIBLE
                                            cancelProgressDialog()
                                        }
                                        else -> {
                                            showLastSync()
                                            prepData(response.responseData!!)
                                        }
                                    }
                                }
                                else -> {
                                    lytRcReferredAgents.visibility = View.GONE
                                    txtNoReferredAgents.visibility = View.VISIBLE
                                    cancelProgressDialog()
                                    Util.customFseRationaleDialog(
                                        context = this@ReferredAgentListActivity,
                                        title = "",
                                        hideNegative = true,
                                        titleSpanned = null,
                                        hideTitle = true,
                                        message = this@ReferredAgentListActivity.getString(R.string.no_data),
                                        positveSelected = {
                                            it.dismiss()
                                        },
                                        negativeSeleted = {
                                            it.dismiss()
                                        }
                                    )
                                }
                            }
                        }
                    }
                })
                obsStatusPosition.observe(this@ReferredAgentListActivity, Observer { position ->
                    binder.spinStatus.setSelection(position)
                })
                obsReferredAgents.observe(
                    this@ReferredAgentListActivity,
                    Observer { referredAgents ->
                        when {
                            referredAgents.isEmpty() -> {
                                lytRcReferredAgents.visibility = View.GONE
                                txtNoReferredAgents.visibility = View.VISIBLE
                            }
                            else -> {
                                when (adapter) {
                                    null -> {
                                        adapter = ReferredAgentAdapter(
                                            referredAgentListActivity = this@ReferredAgentListActivity,
                                            list = referredAgents
                                        )
                                        rcReferredAgent.layoutManager =
                                            LinearLayoutManager(this@ReferredAgentListActivity)
                                        rcReferredAgent.adapter = adapter

                                    }
                                    else -> {
                                        adapter?.let { adapt ->
                                            adapt.list = referredAgents
                                            adapt.notifyDataSetChanged()
                                        }
                                    }
                                }
                                lytRcReferredAgents.visibility = View.VISIBLE
                                txtNoReferredAgents.visibility = View.GONE
                            }
                        }
                        showLastSync()
                        cancelProgressDialog()
                    })
                obsStagesList.observe(this@ReferredAgentListActivity, Observer { statuses ->
                    val statusAdapter = ArrayAdapter(
                        this@ReferredAgentListActivity,
                        android.R.layout.simple_spinner_dropdown_item,
                        statuses
                    )
                    statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    binder.spinStatus.adapter = statusAdapter
                })
                obsViewMore.observe(this@ReferredAgentListActivity, Observer { eodFile ->
                    when(eodFile) {
                        true -> txtViewMoreAgents.visibility = View.GONE
                        false -> txtViewMoreAgents.visibility = View.VISIBLE
                    }
                })

                svAgents.setIconifiedByDefault(false)
                val searchCloseButtonId: Int = binder.svAgents.getContext().getResources()
                    .getIdentifier("android:id/search_close_btn", null, null)
                val closeButton: ImageView = binder.svAgents.findViewById(searchCloseButtonId) as ImageView
                closeButton.setColorFilter(R.color.black)
                closeButton.setOnClickListener {
                    svAgents.setQuery("", true)
                    svAgents.clearFocus()
                    Util.hideKeyboard(this@ReferredAgentListActivity)

                }
                svAgents.queryHint = Html.fromHtml("<font color = #808080>" + "Search by child phone number" + "</font>")
                svAgents.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                    override fun onQueryTextChange(newText: String?): Boolean {
                        sortReferredAgents(sort_none)
                        applySearchFilter(searchQuery = newText)
                        return false
                    }

                    override fun onQueryTextSubmit(query: String?): Boolean {
                        sortReferredAgents(sort_none)
                        applySearchFilter(searchQuery = query)
                        return false
                    }
                })
                btnCal.setOnClickListener {
                    updateLangContext(
                        isEnglish = true,
                        context = this@ReferredAgentListActivity
                    )
                    Util.addEvent(
                            id = "380",
                            name ="referral details calendar option",
                            event ="user_click_calendar_option"
                    )
                    svAgents.clearFocus()
                    spinStatus.clearFocus()
                    val now = Calendar.getInstance(Locale.US).timeInMillis
                    Log.e(TAG, "found current date as $now")
                    val datePicker = MaterialDatePicker.Builder.dateRangePicker()
                        .setTitleText("Select Range")
                        .setTheme(R.style.ThemeOverlay_App_DatePicker)
                        .setCalendarConstraints(
                            CalendarConstraints.Builder()
                                .setValidator(DateValidatorPointBackward.now())
                                .build()
                        )
                        .setSelection(
                            androidx.core.util.Pair(firstDate, secondDate)
                        )
                        .setInputMode(MaterialDatePicker.INPUT_MODE_CALENDAR)
                        .build()
                    datePicker.addOnCancelListener {
                        updateLangContext(
                            context = this@ReferredAgentListActivity
                        )
                        datePicker.dismiss()
                    }
                    datePicker.addOnPositiveButtonClickListener { dateEpoch ->
                        updateLangContext(
                            context = this@ReferredAgentListActivity
                        )
                        sortReferredAgents(sort_none)
                        Log.e(TAG,"found current data as ${dateEpoch.first} and ${dateEpoch.second}")
                        firstDate = dateEpoch.first
                        secondDate = dateEpoch.second
                        btnCal.text = fetchRangeDisplayDate(
                            firstDate = firstDate,
                            secondDate = secondDate
                        )
                        applyDateFilter(
                            firstDate = firstDate,
                            secondDate = secondDate
                        )
                    }
                    datePicker.show(this@ReferredAgentListActivity.supportFragmentManager, "$TAG CAL")
                }
                spinStatus.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: AdapterView<*>?,
                        view: View?,
                        position: Int,
                        id: Long
                    ) {
                        Util.addEvent(
                                id = "381",
                                name ="referral details status filters",
                                event ="user_click_status_filter"
                        )
                        sortReferredAgents(sort_none)
                        svAgents.clearFocus()
                        btnCal.clearFocus()
                        applyStatusFilter(position = position)
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
                txtViewMoreAgents.setOnClickListener {
                    Util.addEvent(
                            id = "382",
                            name ="referral details view more for pagenation",
                            event ="user_view_more_referral_from_pagination"
                    )
                    showProgressDialog(this@ReferredAgentListActivity)
                    loadMoreAgents(referredAgentListActivity = this@ReferredAgentListActivity)
                }
                txtChildNumber.setOnClickListener {
                    sortReferredAgents(sort_by_agent_number)
                }
                txtRegisDate.setOnClickListener {
                    sortReferredAgents(sort_referred_date)
                }
                txtCurrentStatus.setOnClickListener {
                    sortReferredAgents(sort_current_status)
                }
            }
        }
    }

    private fun showLastSync() {
        binder.run {
            txtLastSync.text = this@ReferredAgentListActivity.getString(R.string.last_sync, preference?.getReferredAgentsLastSync())
            txtAppVersion.text = this@ReferredAgentListActivity.getString(R.string.app_version, BuildConfig.VERSION_NAME)
        }
    }

    private fun sortReferredAgents(sortType : Int) {
        binder.run {
            when(sortType) {
                sort_by_agent_number -> {
                    txtChildNumber.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.colorGrey)
                    txtRegisDate.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.black)
                    txtCurrentStatus.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.black)
                    viewModel.sortReferredAgent(sort_by_agent_number)
                }
                sort_referred_date -> {
                    txtChildNumber.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.black)
                    txtRegisDate.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.colorGrey)
                    txtCurrentStatus.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.black)
                    viewModel.sortReferredAgent(sort_referred_date)
                }
                sort_current_status -> {
                    txtChildNumber.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.black)
                    txtRegisDate.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.black)
                    txtCurrentStatus.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.colorGrey)
                    viewModel.sortReferredAgent(sort_current_status)
                }
                sort_none -> {
                    txtChildNumber.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.black)
                    txtRegisDate.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.black)
                    txtCurrentStatus.background = ContextCompat.getDrawable(this@ReferredAgentListActivity, R.color.black)
                }
            }
        }
    }

    override fun onAgentSelected(model: ReferredAgent) {
        Util.addEvent(
                id = "383",
                name ="referral details child number clicks",
                event ="user_click_child_number"
        )
        val intent : Intent = Intent(this, ReferralStatusActivity :: class.java)
        intent.putExtra(referred_agent_status, model.childPhoneNumber)
        startActivity(intent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onResume() {
        super.onResume()
        showLastSync()
        sortReferredAgents(sort_none)
    }

    override fun onDestroy() {
        mHomeWatcher?.stopWatch()
        super.onDestroy()
        finish()
    }
}