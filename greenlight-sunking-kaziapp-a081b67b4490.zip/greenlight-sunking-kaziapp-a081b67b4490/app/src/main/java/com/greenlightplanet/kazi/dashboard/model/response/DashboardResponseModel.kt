package com.greenlightplanet.kazi.dashboard.model.response


import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import com.google.gson.annotations.SerializedName
import com.greenlightplanet.kazi.location.worker.DEFAULT_INTERVAL

@Parcelize
@Entity(tableName = "%s")
data class DashboardResponseModel(
    @ColumnInfo(name = "forceLogout")
    @SerializedName("forceLogout")
    val forceLogout: Boolean,
    @ColumnInfo(name = "radius")
    @SerializedName("radius")
    val radius: Int,

    @ColumnInfo(name = "reassignmentsAvailable")
    @SerializedName("reassignmentsAvailable")
    val reassignmentsAvailable: Int? = 0,


    @ColumnInfo(name = "locationInterval")
    @SerializedName("locationInterval")
    val locationInterval: Long = DEFAULT_INTERVAL,

    @ColumnInfo(name = "territory")
    @SerializedName("territory")
    val territory: String,

    /*new Leads*/
    @ColumnInfo(name = "agentIneligibleMessage")
    @SerializedName("agentIneligibleMessage")
    val agentIneligibleMessage: String?,
    @ColumnInfo(name = "showNewLead")
    @SerializedName("showNewLead")
    val showNewLead: Boolean,

    /*new Added for task revamp*/
    @ColumnInfo(name = "taskReimbursementRevamp")
    @SerializedName("taskReimbursementRevamp")
    val taskReimbursementRevamp: Boolean,

    //added on fse merge
    @ColumnInfo(name = "isLite")
    @SerializedName("isLite")
    val isLite: Boolean,

    @ColumnInfo(name = "flyerId")
    @SerializedName("flyerId")
    val flyerId: Int,

    @ColumnInfo(name = "flyer")
    @SerializedName("flyer")
    val flyer: String,

    @ColumnInfo(name = "showCollectionRate")
    @SerializedName("showCollectionRate")
    val showCollectionRate: Boolean,

    @ColumnInfo(name = "replacement")
    @SerializedName("replacement")
    val replacement: Boolean,

    @ColumnInfo(name = "messageDate")
    @SerializedName("messageDate")
    val messageDate: String,

    @ColumnInfo(name = "message")
    @SerializedName("message")
    val message: String,

    @ColumnInfo(name = "loyaltyShow")
    @SerializedName("loyaltyShow")
    val loyaltyShow: Boolean,

    @ColumnInfo(name = "currentPoint")
    @SerializedName("currentPoint")
    val currentPoint: Int,

    @ColumnInfo(name = "current_time")
    @SerializedName("current_time")
    val current_time: String,

    @ColumnInfo(name = "useNewLocationLogic")
    @SerializedName("useNewLocationLogic")
    val useNewLocationLogic: Boolean,

    @ColumnInfo(name = "agentReferral")
    @SerializedName("agentReferral")
    val agentReferral: Boolean,
    @ColumnInfo(name = "showVisitModule")
    @SerializedName("showVisitModule")
    val showVisitModule: Boolean,
    @ColumnInfo(name = "showFeedback")
    @SerializedName("showFeedback")
    val showFeedback: Boolean,
    @ColumnInfo(name = "collectionGoal")
    @SerializedName("collectionGoal")
    val collectionGoal: Boolean?,
    @ColumnInfo(name = "enableRate30")
    @SerializedName("enableRate30")
    val enableRate30: Boolean?,
    @ColumnInfo(name = "enableRate182")
    @SerializedName("enableRate182")
    val enableRate182: Boolean?,

    @ColumnInfo(name = "isCommissionSplit")
    @SerializedName("isCommissionSplit")
    val isCommissionSplit: Boolean?,

    @ColumnInfo(name = "isV2CompletionRate")
    @SerializedName("isV2CompletionRate")
    val isV2CompletionRate: Boolean


) : Parcelable
