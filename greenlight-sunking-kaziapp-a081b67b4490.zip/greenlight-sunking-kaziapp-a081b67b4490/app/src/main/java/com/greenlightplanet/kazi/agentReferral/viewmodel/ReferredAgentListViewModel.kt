package com.greenlightplanet.kazi.agentReferral.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.all_stages
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_by_agent_number
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_current_status
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_referred_date
import com.greenlightplanet.kazi.agentReferral.model.referredagentlist.ReferralFilterModel
import com.greenlightplanet.kazi.agentReferral.model.referredagentlist.ReferredAgent
import com.greenlightplanet.kazi.agentReferral.model.referredagentlist.ReferredAgentModel
import com.greenlightplanet.kazi.agentReferral.repo.AgentReferralRepo
import com.greenlightplanet.kazi.agentReferral.ui.view.ReferredAgentListActivity
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.utils.Util
import kotlin.collections.ArrayList

class ReferredAgentListViewModel(application: Application) : AndroidViewModel(application) {

    private var statusPosition: Int = -1
    private var referralFilterModel : ReferralFilterModel = ReferralFilterModel(
        search = null,
        firstDate = null,
        secondDate = null,
        status = null
    )
    private var isFiltering : Boolean = true

    fun fetchReferredAgents(isOnline: Boolean) : MutableLiveData<NewCommonResponseModel<ReferredAgentModel>> {
        referredAgents.clear()
       return when(isOnline){
            true -> repo.getReferredAgentList(
                pageSize = pageSize,
                page = page
            )
            false -> repo.getReferredAgentListFromDB()
        }
    }

    fun prepData(responseData: ReferredAgentModel) {
        //pagination...
        responseData.pagination?.let { pag ->
            pag.page?.let { page = it.toInt() }
            pag.pageSize?.let { pageSize = it.toInt() }
            pag.endOfStream?.let {
                endOfStream = it
                obsViewMore.postValue(endOfStream)
            }
        }

        //referredList & statuses...
        responseData.referredAgents?.let { refList ->
            stages.clear()
            referredAgents.addAll(ArrayList(refList))
//            obsReferredAgents.postValue(referredAgents)

            referredAgents.distinctBy { it.currentStage }.map {
                it.currentStage?.let { stage -> stages.add(stage) }
            }
            stages.add(0, all_stages)
            obsStagesList.postValue(stages)

            when(statusPosition) {
                -1 -> obsReferredAgents.postValue(referredAgents)
                else -> obsStatusPosition.postValue(statusPosition)
            }
        }
    }

    fun loadMoreAgents(referredAgentListActivity: ReferredAgentListActivity) {
        when {
            Util.isOnline(referredAgentListActivity) -> {
                when(endOfStream) {
                    true -> {
                        Util.showToast(
                            context = referredAgentListActivity,
                            message = referredAgentListActivity.getString(R.string.no_data)
                        )
                        referredAgentListActivity.cancelProgressDialog()
                    }
                    false -> loadMoreReferredAgents(referredAgentListActivity = referredAgentListActivity)
                }
            }
            else -> {
                referredAgentListActivity.cancelProgressDialog()
            }
        }
    }

    private fun getNextPage(): Int? {
        return page?.plus(1)
    }

    private fun loadMoreReferredAgents(referredAgentListActivity: ReferredAgentListActivity) {
        repo.getReferredAgentList(
            page = getNextPage(),
            pageSize = pageSize
        ).observe(referredAgentListActivity, androidx.lifecycle.Observer { response ->
            when(response) {
                null -> {
                    Util.customFseRationaleDialog(
                        context = referredAgentListActivity,
                        title = "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = referredAgentListActivity.getString(R.string.no_data),
                        positveSelected = {
                            it.dismiss()
                        },
                        negativeSeleted = {
                            it.dismiss()
                        }
                    )
                    referredAgentListActivity.cancelProgressDialog()
                }
                else -> {
                    when(response.success) {
                        true -> {
                            when(response.responseData) {
                                null -> {
                                    Util.customFseRationaleDialog(
                                        context = referredAgentListActivity,
                                        title = "",
                                        hideNegative = true,
                                        titleSpanned = null,
                                        hideTitle = true,
                                        message = referredAgentListActivity.getString(R.string.no_data),
                                        positveSelected = {
                                            it.dismiss()
                                        },
                                        negativeSeleted = {
                                            it.dismiss()
                                        }
                                    )
                                    referredAgentListActivity.cancelProgressDialog()
                                }
                                else -> {
                                    prepData(responseData = response.responseData!!)
                                }
                            }
                        }
                        false -> {
                            Util.customFseRationaleDialog(
                                context = referredAgentListActivity,
                                title = "",
                                hideNegative = true,
                                titleSpanned = null,
                                hideTitle = true,
                                message = referredAgentListActivity.getString(R.string.no_data),
                                positveSelected = {
                                    it.dismiss()
                                },
                                negativeSeleted = {
                                    it.dismiss()
                                }
                            )
                            referredAgentListActivity.cancelProgressDialog()
                        }
                    }
                }
            }
        })
    }

    fun applySearchFilter(searchQuery : String?) {
        Util.addEvent(
                id = "379",
                name ="referral details search section",
                event ="user_search_referral_detail"
        )
        referralFilterModel.search = searchQuery
        Log.e(TAG,"applying search filter $referralFilterModel")
        initiateFilter()
    }

    fun applyDateFilter(firstDate : Long?, secondDate : Long?) {
        referralFilterModel.firstDate = firstDate
        referralFilterModel.secondDate = secondDate
        Log.e(TAG, "applying date filter $referralFilterModel")
        initiateFilter()
    }

    fun applyStatusFilter(position : Int) {
        statusPosition = position
        when(stages[position]) {
            all_stages -> {
                referralFilterModel.status = null
            }
            else -> {
                referralFilterModel.status = stages[position]
            }
        }
        Log.e(TAG, "applying status filter $referralFilterModel")
        initiateFilter()
    }

    private fun initiateFilter() {
        when(isFiltering) {
            true -> {
                referredFilteredAgents.clear()
                isFiltering = false
                val preFilterList : ArrayList<ReferredAgent> = ArrayList()
                preFilterList.clear()
                preFilterList.addAll(referredAgents)
                filterSearch(preFilterList)
            }else->{}
        }
    }

    private fun filterSearch(preFilterList: ArrayList<ReferredAgent>) {
        //search...
        var searchFilter: ArrayList<ReferredAgent> = ArrayList<ReferredAgent>()
        when(referralFilterModel.search) {
            null, "" -> searchFilter.addAll(preFilterList)
            else -> {
                val tempfilter : ArrayList<ReferredAgent> = ArrayList()
                preFilterList.forEach { referredAgent ->
                    referredAgent.childPhoneNumber?.let { number ->
                        when{
                            number.contains(referralFilterModel.search!!, true) -> {
                                tempfilter.add(referredAgent)
                            }
                        }
                    }
                }
                searchFilter.addAll(tempfilter)
            }
        }
        filterStatus(searchFilter)
    }

    private fun filterStatus(searchFilter: ArrayList<ReferredAgent>) {
        var statusFilter : ArrayList<ReferredAgent> = ArrayList()
        when(referralFilterModel.status) {
            null,"" -> statusFilter.addAll(searchFilter)
            else -> {
                referralFilterModel.status?.let {
                    statusFilter = ArrayList(
                        searchFilter.filter {
                            it.currentStage == referralFilterModel.status
                        }
                    )
                }
            }
        }
        filterDate(statusFilter)
    }

    private fun filterDate(statusFilter: List<ReferredAgent>) {
        //date...
        val dateFilter : ArrayList<ReferredAgent> = ArrayList<ReferredAgent>()
        when{
            referralFilterModel.firstDate == null && referralFilterModel.secondDate == null -> {
                dateFilter.addAll(statusFilter)
            }
            else -> {
                val dateFil = statusFilter.filter {
                    it.referredDateTimestamp?.let { refDate ->
                        val date = (refDate.toDouble().toLong())*1000
                        Log.e(TAG, "receives dates as ${referralFilterModel.firstDate!!}, ${referralFilterModel.secondDate!!}, $date")
                        date > referralFilterModel.firstDate!! && date < referralFilterModel.secondDate!!
                    } == true
                }
                dateFilter.addAll(ArrayList(dateFil))
            }
        }
        isFiltering = true
        referredFilteredAgents.clear()
        referredFilteredAgents.addAll(dateFilter)
        obsReferredAgents.postValue(referredFilteredAgents)
    }

    fun sortReferredAgent(sortType : Int) {
        when(sortType) {
            sort_by_agent_number -> {
                when(childNumberASC) {
                    true -> {
                        when {
                            referredFilteredAgents.isNullOrEmpty() -> {
                                val list = referredAgents.sortedWith(compareBy { it.childPhoneNumber })
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                            else -> {
                                val list = referredFilteredAgents.sortedWith(compareBy { it.childPhoneNumber })
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                        }

                    }
                    false -> {
                        when {
                            referredFilteredAgents.isNullOrEmpty() -> {
                                val list = referredAgents.sortedWith(compareBy { it.childPhoneNumber }).asReversed()
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                            else -> {
                                val list = referredFilteredAgents.sortedWith(compareBy { it.childPhoneNumber }).asReversed()
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                        }
                    }
                }
                childNumberASC = !childNumberASC
            }
            sort_referred_date -> {
                when(childReferredDateASC) {
                    true -> {
                        when {
                            referredFilteredAgents.isNullOrEmpty() -> {
                                val list = referredAgents.sortedWith(compareBy { it.referredDateTimestamp?.toDouble() })
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                            else -> {
                                val list = referredFilteredAgents.sortedWith(compareBy { it.referredDateTimestamp?.toDouble() })
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                        }
                    }
                    false -> {
                        when {
                            referredFilteredAgents.isNullOrEmpty() -> {
                                val list = referredAgents.sortedWith(compareBy { it.referredDateTimestamp?.toDouble() }).asReversed()
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                            else -> {
                                val list = referredFilteredAgents.sortedWith(compareBy { it.referredDateTimestamp?.toDouble() }).asReversed()
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                        }
                    }
                }
                childReferredDateASC = !childReferredDateASC
            }
            sort_current_status -> {
                when(childCurrentStatusASC) {
                    true -> {
                        when {
                            referredFilteredAgents.isNullOrEmpty() -> {
                                val list = referredAgents.sortedWith(compareBy { it.currentStage })
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                            else -> {
                                val list = referredFilteredAgents.sortedWith(compareBy { it.currentStage })
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                        }
                    }
                    false -> {
                        when {
                            referredFilteredAgents.isNullOrEmpty() -> {
                                val list = referredAgents.sortedWith(compareBy { it.currentStage }).asReversed()
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                            else -> {
                                val list = referredFilteredAgents.sortedWith(compareBy { it.currentStage }).asReversed()
                                obsReferredAgents.postValue(ArrayList(list))
                            }
                        }
                    }
                }
                childCurrentStatusASC = !childCurrentStatusASC
            }
        }
    }

    private val TAG : String = "ReferredAgentListVM"
    private var stages : ArrayList<String> = ArrayList()
    private var referredAgents : ArrayList<ReferredAgent> = ArrayList()
    private var referredFilteredAgents : ArrayList<ReferredAgent> = ArrayList()
    private var repo : AgentReferralRepo = AgentReferralRepo(context = application.applicationContext)
    private var pageSize : Int? = 20
    private var page : Int? = 1
    private var endOfStream : Boolean = true
    private var childNumberASC : Boolean = true
    private var childReferredDateASC : Boolean = true
    private var childCurrentStatusASC : Boolean = true

    var obsStagesList : MutableLiveData<ArrayList<String>> = MutableLiveData()
    var obsReferredAgents : MutableLiveData<ArrayList<ReferredAgent>> = MutableLiveData()
    var obsViewMore : MutableLiveData<Boolean> = MutableLiveData()
    var obsStatusPosition : MutableLiveData<Int> = MutableLiveData()

}