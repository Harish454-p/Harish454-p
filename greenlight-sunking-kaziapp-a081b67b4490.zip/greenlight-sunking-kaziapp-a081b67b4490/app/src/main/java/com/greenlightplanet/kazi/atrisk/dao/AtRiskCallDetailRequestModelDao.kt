package com.greenlightplanet.kazi.atrisk.dao

import androidx.room.*
import com.greenlightplanet.kazi.atrisk.model.AtRiskCallDetailRequestModel
import io.reactivex.Single


@Dao
interface AtRiskCallDetailRequestModelDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(summaryCallDetailRequestModel: List<AtRiskCallDetailRequestModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(summaryCallDetailRequestModel: AtRiskCallDetailRequestModel): Long

    @Delete
    fun delete(summaryCallDetailRequestModel: AtRiskCallDetailRequestModel): Int

    @Query("DELETE FROM AtRiskCallDetailRequestModel")
    fun deleteAll(): Int

    @Query("SELECT * FROM AtRiskCallDetailRequestModel")
    fun getAll(): Single<List<AtRiskCallDetailRequestModel>>

    @Query("SELECT * FROM AtRiskCallDetailRequestModel LIMIT 1")
    fun get(): Single<AtRiskCallDetailRequestModel>

    @Query("SELECT COUNT(*) from AtRiskCallDetailRequestModel")
    fun count(): Int


}

