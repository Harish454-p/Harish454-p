package com.greenlightplanet.kazi.collectiongoal.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistoryModel
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.collectiongoal.model.pastweekincentive.LastWeekIncentiveModel
import com.greenlightplanet.kazi.summary.model.SummaryModel
import io.reactivex.Single

@Dao
interface PastWeekIncentiveDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(lastWeekIncentiveModel: LastWeekIncentiveModel): Long

    @Query("SELECT * FROM LastWeekIncentiveModel where angazaID = :angazaId")
    fun getAll(angazaId :String): Single<LastWeekIncentiveModel>

    @Query("DELETE FROM LastWeekIncentiveModel")
    fun deleteAll(): Int

}