package com.greenlightplanet.kazi.dashboard.model.request



import android.os.Parcelable
import androidx.room.*
import kotlinx.android.parcel.Parcelize
import com.google.gson.annotations.SerializedName

@Parcelize
@Entity(tableName = "%s")
data class SecurityKeyRequestModel(
    @ColumnInfo(name = "angazaId")
    @SerializedName("angazaId")
    var angazaId: String,
    @ColumnInfo(name = "name")
    @SerializedName("name")
    var name: String,
    @ColumnInfo(name = "phoneNumber")
    @SerializedName("phoneNumber")
    var phoneNumber: String
):Parcelable