package com.greenlightplanet.kazi.collectiongoal.model.callhistory

import android.os.Parcelable
import androidx.annotation.Keep
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize
@Keep
@Parcelize
@Entity(tableName = "CallHistoryModel")
data class CallHistoryModel(

    @ColumnInfo(name = "accountNumber")
    @PrimaryKey
    val accountNumber:Int,

    @ColumnInfo(name = "callHistory")
    var callHistory: List<CallHistory> = listOf(),

    @ColumnInfo(name = "pageNo")
    val pageNo: Int?,

    @ColumnInfo(name = "next", defaultValue = "")
    var next: Int?
) : Parcelable