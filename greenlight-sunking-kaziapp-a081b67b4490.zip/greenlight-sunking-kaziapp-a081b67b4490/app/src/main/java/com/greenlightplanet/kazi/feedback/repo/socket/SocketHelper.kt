package com.greenlightplanet.kazi.feedback.repo.socket

import android.annotation.SuppressLint
import android.util.Log
import com.google.gson.Gson
import com.greenlightplanet.kazi.feedback.repo.model.response.ChatData
import com.greenlightplanet.kazi.feedback.repo.model.response.MessageData
import com.greenlightplanet.kazi.networking.RetrofitInstance
import io.reactivex.Completable
import io.reactivex.CompletableSource
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.functions.Predicate
import io.reactivex.schedulers.Schedulers
import ua.naiksoftware.stomp.Stomp
import ua.naiksoftware.stomp.StompClient
import ua.naiksoftware.stomp.dto.LifecycleEvent
import java.lang.ref.WeakReference
/** This class Handles Socket Connection for receiving realtime Chat Data*/
@SuppressLint("LogNotTimber")
class SocketHelper(val listener: WeakReference<NewMessageListener>) {

    companion object {
        private val TAG = "SocketHelper"
    }

    var compositeDisposable = CompositeDisposable()

    var mStompClient = Stomp.over(
        Stomp.ConnectionProvider.OKHTTP,
        "ws://kazi-feedback.glpapps.com/kazi/feedback/feedback-websocket"
    )
    val gson = Gson()

    fun makeConnection() {
        try {
            if (RetrofitInstance.isOnProduction) {
//            mStompClient = Stomp.over(Stomp.ConnectionProvider.OKHTTP, "ws://kazi-feedback.glpapps.com/kazi/feedback/feedback-websocket")
            } else {
//              mStompClient = Stomp.over(Stomp.ConnectionProvider.OKHTTP, "ws://dev.glpapps.com:8090/feedback-websocket")
            }
            mStompClient.withClientHeartbeat(1000)
            mStompClient.connect()
            Log.d(TAG, "Make connection Called: ${mStompClient}")
        } catch (e: java.lang.Exception) {
            Log.d(TAG, "Exception While connecting: ${mStompClient}")
        }

    }

    /** Observes Socket Connectivity States: OPENED/ERROR/CLOSED */
    @SuppressLint("CheckResult")
    fun observers(ticketId: String) {
//        val TICKET_ID = "142831"
        var topicDisposable =
            mStompClient.topic("/user/$ticketId/send").subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread()).subscribe({ topicMessage ->
                val messageData = gson.fromJson(topicMessage.payload, MessageData::class.java)
                Log.d(
                    TAG, "Received Parsed:  $messageData ||ORIGINAL : ${topicMessage.getPayload()}"
                )
                messageData?.let {
                    val chatData = ChatData(
                        message = it.message,
                        sender = it.sender,
                        senderType = it.senderType,
                        ticketId = it.ticketId,
                        timestamp = it.timestamp
                    )
                    listener.get()?.onNewMessageReceived(chatData)
                }
                Log.d(
                    TAG, "Received: ${topicMessage.getPayload()}"
                )

            }, {
                Log.d(
                    TAG,
                    "Received Exception: While parsing Msg to Data Class|| RX Throwable: ${it.localizedMessage}}"
                )
            })

        compositeDisposable.add(topicDisposable)


        var eventObserver =
            mStompClient.lifecycle().subscribeOn(Schedulers.io()).observeOn(Schedulers.io())
                .subscribe(
                    { lifecycleEvent: LifecycleEvent ->
                        when (lifecycleEvent.type) {
                            LifecycleEvent.Type.OPENED -> {
                                Log.d(TAG, "Stomp connection opened")
                                listener.get()?.onSocketConnected()
                            }
                            LifecycleEvent.Type.ERROR -> {
                                Log.e(TAG, "Error", lifecycleEvent.exception)
                                listener.get()?.onSocketError()
                            }
                            LifecycleEvent.Type.CLOSED -> {
                                Log.d(TAG, "Stomp connection closed")
                                listener.get()?.onSocketClosed()
                            }
                            else -> {
                                Log.d(TAG, "Stomp connection Else")
                            }
                        }
                    },
                    {
                        Log.d(
                            TAG,
                            "Stomp connection: Exception is thrown: RX Throwable: ${it.localizedMessage}"
                        )
                    }
                )

        compositeDisposable.add(eventObserver)
    }

    fun sendMessage(messageData: MessageData) {
        /*val data = MessageData(
            ticketId = "142831",
            sender = "US032809",
            senderType = "EO",
            message = "This is a test Message",
            attachments = mutableListOf<String>(),
            timestamp = "21-12-2022 12:00:01")*/
//        mStompClient.send("/app/message", getDataToJson(messageData)).subscribeOn(Schedulers.io()).subscribe()
//        Log.d(TAG, "Send Message Called with Data: ${getDataToJson(messageData)}")
    }

    /** Disconnects and Disposes Socket Connection*/
    fun disconnect() {
        try {
            listener.clear()
            mStompClient.disconnect()
            compositeDisposable.dispose()
            Log.d(TAG, "Disconnect connection Called")
        } catch (e: java.lang.Exception) {
            Log.d(TAG, "Disconnect Exception")
        }

    }


    fun getDataToJson(chatData: MessageData): String {
        return gson.toJson(chatData)
    }

    interface NewMessageListener {
        fun onNewMessageReceived(chatData: ChatData)
        fun onSocketConnected()
        fun onSocketError()
        fun onSocketClosed()
    }
}

