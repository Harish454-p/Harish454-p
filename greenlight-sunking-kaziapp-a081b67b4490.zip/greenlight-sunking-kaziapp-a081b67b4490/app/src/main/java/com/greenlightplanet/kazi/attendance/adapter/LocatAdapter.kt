package com.greenlightplanet.kazi.attendance.adapter

import android.content.Intent
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.attendance.activity.AttendanceActivity
import com.greenlightplanet.kazi.attendance.activity.MapsActivity
import com.greenlightplanet.kazi.attendance.model.AttendanceRequestModel
import com.greenlightplanet.kazi.attendance.model.AttendanceResponseModel
import com.greenlightplanet.kazi.attendance.model.checkins
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.Util


class LocatAdapter(activity: AttendanceActivity, checkInList: ArrayList<AttendanceResponseModel.Checkin>) : RecyclerView.Adapter<LocatAdapter.MyViewHolder>() {


    var actvity = activity
    val latLongList = ArrayList<String>()
    var attendanceList: List<AttendanceResponseModel.Checkin>? = null

    var checkInList = checkInList

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {


        fun bindItems(checkInList: List<AttendanceResponseModel.Checkin>, position: Int) {

            val txtDate: TextView = itemView.findViewById(R.id.title)
            val txtTime: TextView = itemView.findViewById(R.id.genre)
            val location: ImageView = itemView.findViewById(R.id.year)
            val customer: ImageView = itemView.findViewById(R.id.ivCustomer)
            val customerName: TextView = itemView.findViewById(R.id.tvCustomerName)
            val llParent: LinearLayout = itemView.findViewById(R.id.ll_attView)


            if (checkInList.get(position).checkinType == "CUSTOMER") {
                customer.visibility = View.VISIBLE
                llParent.isClickable = true
                llParent.setOnClickListener {
                    if (customerName.visibility == View.VISIBLE) {
                        customerName.visibility = View.GONE
                    } else {
                        customerName.text = checkInList.get(position).customerName
                        customerName.visibility = View.VISIBLE
                    }
                }

            } else {
                llParent.isClickable = false
                //llParent.isClickable = false
                customer.visibility = View.INVISIBLE
                customerName.visibility = View.GONE

            }

            location.setOnClickListener(View.OnClickListener {

                val data = checkInList.get(position)

                if (checkInList.isNotEmpty()) {

                    Util.addEvent("271", "Attendance", "attendance_map_opened_event")

                    val firstDate = checkInList.get(position).date


                    val presentDate: Long = Util.timeadd(data.time!!)

                    val lastDate: Long = Util.timeneg(data.time!!)
                    attendanceList = AppDatabase.getAppDatabase(actvity).attendanceDao().getAttend(presentDate, lastDate)

                    val i = Intent(actvity, MapsActivity::class.java)
                    val attendaceModel = AttendanceResponseModel(attendanceList!!)
                    attendaceModel.checkins = attendanceList!!
                    i.putExtra("mapData", attendaceModel.checkins as ArrayList)
                    actvity.startActivity(i)

                }

            })

        }

        var title: TextView
        var genre: TextView
        var customerName: TextView
        var year: ImageView
        var customer: ImageView
        var llParent: LinearLayout

        init {
            title = view.findViewById(R.id.title) as TextView
            genre = view.findViewById(R.id.genre) as TextView
            customerName = view.findViewById(R.id.tvCustomerName) as TextView
            year = view.findViewById(R.id.year) as ImageView
            customer = view.findViewById(R.id.ivCustomer) as ImageView
            llParent = view.findViewById(R.id.ll_attView) as LinearLayout
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.attendance_list_row, parent, false)

        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val locat = checkInList[position]
        holder.title.text = Util.convertUTCtoLocatTimeDDMMYYYYY(checkInList[position].time!!)
        val timez = (Util.convertUTCtoLocatTimeHHMMAMPM(checkInList[position].time!!.replace("am", "AM").replace("pm", "PM")))

        holder.genre.text = timez
        holder.bindItems(checkInList, position)

    }


    override fun getItemCount(): Int {
        return checkInList.size

    }


}
