package com.greenlightplanet.kazi.collectiongoal.adapter

import android.util.Log
import androidx.annotation.Keep
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.PagerAdapter
import com.greenlightplanet.kazi.collectiongoal.model.pastweekincentive.LastWeekIncentiveModel
import com.greenlightplanet.kazi.collectiongoal.view.fragment.AchievedFragment
import com.greenlightplanet.kazi.collectiongoal.view.fragment.NotAchievedFragment

@Keep
class AccountLastWeekPagerAdapter(fm: FragmentManager, var AchievedList: List<LastWeekIncentiveModel.AchievedAccount>,
                                  var notAchievedList: List<LastWeekIncentiveModel.AchievedAccount>)
    : FragmentPagerAdapter(fm) {



       companion object {
           const val TAG = "AccountLastWeekPagerAdapter"
       }

       var achievedFragment: AchievedFragment? = null
       var notAchievedFragment: NotAchievedFragment? = null


       override fun getCount(): Int {
           return 2
       }

       override fun getItem(position: Int): Fragment {
           val fragment: Fragment? = null


           when (position) {
               0 -> {
                   if(achievedFragment == null){
                       Log.d("AchievedListPagerAdp", "success: ${AchievedList}")
                       achievedFragment = AchievedFragment.newInstance(AchievedList, true)
                   }
                   return achievedFragment as Fragment
               }
               1 -> {
                   if(notAchievedFragment == null){
                       Log.d("NotAchievedListPagerAdp", "success: ${notAchievedList}")
                       notAchievedFragment = NotAchievedFragment.newInstance(notAchievedList, false)
                   }
                   return notAchievedFragment as Fragment
               }
               else ->
                   return fragment!!
           }
       }

       override fun getItemPosition(`object`: Any): Int {
           return PagerAdapter.POSITION_NONE
       }

}