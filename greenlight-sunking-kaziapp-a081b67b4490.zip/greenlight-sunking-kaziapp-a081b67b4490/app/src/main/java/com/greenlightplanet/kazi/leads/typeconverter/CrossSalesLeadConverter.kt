package com.greenlightplanet.kazi.leads.typeconverter

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead

class CrossSalesLeadConverter {


    @TypeConverter
    fun fromLeadsCallDetail(callDetail: ArrayList<LeadsCrossSalesLead>?): String? {
        if (callDetail == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<LeadsCrossSalesLead>>() {

        }.type
        return gson.toJson(callDetail, type)
    }

    @TypeConverter
    fun toLeadsCallDetail(callDetail: String?): ArrayList<LeadsCrossSalesLead>? {
        if (callDetail == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<LeadsCrossSalesLead>>() {

        }.type
        return gson.fromJson(callDetail, type)
    }

}
