package com.greenlightplanet.kazi.loyalty.converter.store

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.loyalty.model.store.StoreItem

class StoreItemConverter {

    @TypeConverter
    fun fromStoreItemList(list: List<StoreItem>?): String? {
        if (list == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<StoreItem>>() {

        }.type
        return gson.toJson(list, type)
    }

    @TypeConverter
    fun toStoreItemList(string: String?): List<StoreItem>? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<StoreItem>>() {

        }.type
        return gson.fromJson(string, type)
    }

}


