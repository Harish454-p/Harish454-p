package com.greenlightplanet.kazi.fse.dao

import androidx.room.*
import com.greenlightplanet.kazi.fse.model.Fse
import io.reactivex.Single

@Dao
interface FseDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(Fses: List<Fse?>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(Fse: Fse): Long

    @Delete
    fun delete(Fse: Fse): Int

    @Query("DELETE FROM Fse")
    fun deleteAll(): Int

    @Query("SELECT * FROM Fse")
    fun getAll(): Single<List<Fse>>


    @Query("SELECT * FROM Fse LIMIT 1")
    fun get(): Single<Fse>


    @Query("SELECT * FROM fse WHERE accountNumber=:accountNumber LIMIT 1")
    fun getNameById(accountNumber: String): Single<Fse>

    @Query("SELECT COUNT(*) from Fse")
    fun count(): Single<Int>

}


