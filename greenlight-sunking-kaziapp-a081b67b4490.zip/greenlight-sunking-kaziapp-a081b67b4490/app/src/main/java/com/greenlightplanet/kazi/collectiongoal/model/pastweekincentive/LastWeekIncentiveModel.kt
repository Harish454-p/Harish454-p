package com.greenlightplanet.kazi.collectiongoal.model.pastweekincentive

import android.os.Parcelable
import androidx.annotation.Keep
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize
@Keep
@Parcelize
@Entity(tableName = "LastWeekIncentiveModel")
data class LastWeekIncentiveModel(

    @ColumnInfo(name = "angazaID")
    @PrimaryKey(autoGenerate = false)
    var angazaID:String,

    @ColumnInfo(name = "achievedAccounts")
    val achievedAccounts: List<AchievedAccount>? = listOf(),

    @ColumnInfo(name = "collectionGoalLastWeek")
    val collectionGoalLastWeek: CollectionGoalCommonWeek?,

    @ColumnInfo(name = "isCollectionGoal")
    val isCollectionGoal: Boolean?,

    @ColumnInfo(name = "notAchievedAccounts")
    val notAchievedAccounts: List<AchievedAccount>?,

    @ColumnInfo(name = "next", defaultValue = "")
    val next: String?,

    @ColumnInfo(name = "pageNo")
    val pageNo: Int?


) : Parcelable {
    @Keep
    @Parcelize
    data class AchievedAccount(
        @ColumnInfo(name = "status")
        var status: Boolean,
        @ColumnInfo(name = "collectedAmount")
        val collectedAmount: Double?,
        @ColumnInfo(name = "customerName")
        val customerName: String?,
        @ColumnInfo(name = "expectedAmount")
        val expectedAmount: Double?
    ) : Parcelable

    @Keep
    @Parcelize
    data class CollectionGoalCommonWeek(
        @ColumnInfo(name = "commissionPercentage")
        val commissionPercentage: Double?,
        @ColumnInfo(name = "angazaID")
        @PrimaryKey(autoGenerate = false)
        var angazaID: String,
        @ColumnInfo(name = "commission")
        val commission: Double?,
        @ColumnInfo(name = "doneAccount")
        val doneAccount: Int?,
        @ColumnInfo(name = "percentage")
        val percentage: Double,
        @ColumnInfo(name = "targetAccount")
        val targetAccount: Int?,
        @ColumnInfo(name = "weekCollection")
        val weekCollection: Double?,
        @ColumnInfo(name = "weekId")
        val weekId: String?,
        @ColumnInfo(name = "weekString")
        val weekString: String?
    ) : Parcelable


}