package com.greenlightplanet.kazi.attendance.activity

import android.Manifest
import android.app.Activity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.attendance.adapter.LocatAdapter
import com.greenlightplanet.kazi.attendance.extra.AttendanceUtils
import com.greenlightplanet.kazi.attendance.model.AttendanceResponseModel
import com.greenlightplanet.kazi.attendance.model.Locat
import com.greenlightplanet.kazi.attendance.viewmodel.AttendanceVM
import com.greenlightplanet.kazi.dashboard.activity.DashBoardActivity
import com.greenlightplanet.kazi.databinding.ActivityAttendanceBinding
import com.greenlightplanet.kazi.fse.extras.custom.CustomProgress
import com.greenlightplanet.kazi.fse.repo.FseCommitmentRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.tvinstallation.model.FseCustomerResponse
import com.greenlightplanet.kazi.utils.*
import com.greenlightplanet.kazi.utils.GPSTracker.GpsTrackerz
import com.greenlightplanet.kazi.utils.MultiSelectDialog.MultiSelectModel
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


class AttendanceActivity : BaseActivity()/*, APIInterface<CommonResponseModel<AttendanceRequestModel>> */ {

    private val bag: CompositeDisposable = CompositeDisposable()

    val fseRepo = FseCommitmentRepo.getInstance(this)
    private lateinit var progressBar: CustomProgress
    var fseList: List<FseCustomerResponse.ResponseData.Fse>? = null
    var isFromNotification = false
    //
    var Selected_days: String? = null
    var Sel_day: Int? = null
    var checkinDay: String? = null
    private var recyclerView: RecyclerView? = null
    private var mAdapter: LocatAdapter? = null
    private val LocatList = ArrayList<Locat>()
    var checInList = ArrayList<AttendanceResponseModel.Checkin>()
    var preference: GreenLightPreference? = null
    var todayDate: String? = null
    var fromDate: String? = null
    var gps: GpsTrackerz? = null
    var latitude: Double = 0.toDouble()
    var longitude: Double = 0.toDouble()
    var activity: Activity? = null
    var context: Context? = null

    var boolCheckInDisabled: Boolean? = true
    var viewModel: AttendanceVM? = null
    var angazaId = ""
    var attendanceSetList: MutableList<AttendanceResponseModel.Checkin>? = mutableListOf()

	var mHomeWatcher: HomeWatcher? = null

	companion object {
        var TAG = "AttendanceActivity |==| "
    }
    private lateinit var binding: ActivityAttendanceBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_attendance)
        binding = ActivityAttendanceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (intent.hasExtra("fromNotification")) {
            isFromNotification = intent.getBooleanExtra("fromNotification", false)
        }
        progressBar = CustomProgress.getInstance(this)

        initialize()
        onClick()

		mHomeWatcher = HomeWatcher(this)
		mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
			override fun onHomePressed() {
				Log.i(TAG, "onHomePressed")
				finish()
			}
		})
		mHomeWatcher!!.startWatch()
    }

    fun initialize() {
        activity = this
        context = activity
        recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        Util.setToolbar(this, this.binding.toolbar3)
        // Util.setToolbar(this,toolbar!!)
        preference = GreenLightPreference.getInstance(this)
        gps = GpsTrackerz(this.context!!)


        viewModel = ViewModelProvider(this)[AttendanceVM::class.java]

        recyclerView!!.layoutManager = LinearLayoutManager(this)
        mAdapter = LocatAdapter(activity = this, checkInList = checInList)
        recyclerView!!.adapter = mAdapter

        setAdapter(binding.spinnerAttd, resources.getStringArray(R.array.attendance))

        Util.requestAllPermission(this, arrayListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))

        //todo check here
        if (preference?.getLoginResponseModel()?.country.equals("Nigeria", true)) {
            getFseIfNot()
        }

        if (preference?.getLoginResponseModel()?.country.equals("Nigeria", true)) {

            binding. ivSync.visibility = View.VISIBLE
            binding.ivSync.setOnClickListener {
                if (Util.isOnline(this)) {
                    syncFse()
                } else {
                    Util.customFseRationaleDialog(this, "",
                            hideNegative = true,
                            titleSpanned = null,
                            hideTitle = true,
                            message = getString(R.string.no_internet_connection),
                            positveSelected = { it.dismiss() },
                            negativeSeleted = { it.dismiss() }
                    )
                }
            }
        }

        if (Util.isOnline(this)) {
            sendCheckIn()
        }

    }

    fun onClick() {

        binding.checkIn.setOnClickListener {

            if (preference?.getLoginResponseModel()?.country.equals("Nigeria", true)) {

                Util.customDialog(context = this, message = getString(R.string.is_it_customer_check_in)/*"Is it a Customer check-in?"*/, poitiveSelected = {

                    showFseDialog()
                    it.dismiss()

                }, negetiveSelected = {
                    onCheckIn()
                    it.dismiss()
                })
            } else {
                onCheckIn()
            }

        }

        binding. spinnerAttd.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {
            }
            override fun onItemSelected(adapterView: AdapterView<*>?, view: View?,
                                        position: Int, id: Long) {
                onItemSelected(position)
            }
        }

    }

    fun setAdapter(spinner: Spinner, array: Array<String>) {
        val spinnerArrayAdapter = ArrayAdapter<String>(
                this, R.layout.spinner_item, array
        )
        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_filter_text)
        spinner.setAdapter(spinnerArrayAdapter)
    }

    fun onCheckIn(account_number: String = "", checkin_type: String = "GENERAL") {

        if (this.boolCheckInDisabled!!) {
            AttendanceUtils.requestAllPermission(this, arrayListOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))

            if (gps!!.canGetLocation()) {
                run {
                    if (gps != null) {
                        latitude = gps!!.getLatitude()
                        longitude = gps!!.getLongitude()
                        val doubleInstance = latitude
                        val doubleIns = longitude
                        val latlong = doubleInstance.toString() + "_" + doubleIns.toString()
                        val datee = Date()
                        val dateFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
                        dateFormat.timeZone = TimeZone.getTimeZone("UTC")
                        val dt: Date
                        try {
                            if (latlong != "0.0_0.0") {

                                Util.addEvent("266", "Attendance", "attendance_checked_in_clicked")
                                val txt_latlng = latlong.split("_".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
                                val txt_lat = txt_latlng[0]
                                val txt_lng = txt_latlng[1]
                                val checkinRequest = AttendanceResponseModel.Checkin(time = dateFormat.format(datee))
                                checkinRequest.latitude = txt_lat.toDouble().toString()
                                checkinRequest.longitude = txt_lng.toDouble().toString()
                                checkinRequest.time = dateFormat.format(datee)
                                checkinRequest.date = dateFormat.parse(checkinRequest.time)
                                checkinRequest.isOnlineAdded = false
                                checkinRequest.checkinType = checkin_type

                                if (checkin_type == "CUSTOMER") {
                                    checkinRequest.accountNumber = account_number
                                }

                                val txtDateFF = Util.getDDMMYYYY(value = datee)
                                val txtTimeFF = Util.getHHMM(value = datee)
                                val txtTimePP = Util.getAMPM(value = datee)

//                                viewModel!!.getAttendanceSS().observe(this, android.arch.lifecycle.Observer {
//                                    checInList.clear()
//                                    Log.e("MAz = IT", "===$it")
//                                    checInList.addAll(it as ArrayList<AttendanceResponseModel.Checkin>)
//                                    checInList.add(checkinRequest)
//                                    viewModel!!.insertAttendance(checInList)
                                viewModel!!.insertSingleAttendance(checkinRequest)
//                                    Log.e("MAz = checkinRequest", "===$checkinRequest")
//                                })

                                viewModel!!.getOfflineAttendance(false)
                                        .observe(this, androidx.lifecycle.Observer {
                                            val offlineList = it!!.toMutableList()
                                            Log.e(TAG, "${AttendanceUtils.getLineNumber()} = offlineList:$offlineList")
//                                            val attendanceRequestModel = AttendanceRequestModel()
                                            val attendanceResponseModel = AttendanceResponseModel(offlineList)
                                            attendanceResponseModel.checkins = offlineList as java.util.ArrayList<AttendanceResponseModel.Checkin>
                                            val angazaId = preference?.getLoginResponseModel()?.angazaId
//                                            val checkInOflineRespone = CheckInPostResponse(this, viewModel!!)

                                            if (!attendanceResponseModel.checkins.isNullOrEmpty()) {
                                                if (Util.isOnline(this)) {
//                                                    ServiceInstance.getInstance(this).service?.attendancePost(angazaId!!, attendanceResponseModel)
//                                                            ?.enqueue(object : APICallback<CommonResponseModel<BaseResponseModel>>(checkInOflineRespone, this) {})
                                                    viewModel!!.attendanceRXPost(this, angazaId!!, attendanceResponseModel)
                                                            .observe(this, androidx.lifecycle.Observer {
                                                        if (it!!.Success!!) {
                                                            Log.e(TAG, "Alpha222: ")
                                                            viewModel!!.updateOfflineList(false, true)

                                                            selectDay(Sel_day!!)
//                                                            setListForAttendance()
                                                            cancelProgressDialog()
                                                        } else {
                                                            Log.e("MAz = onError", "==CheckInPostResponse==onError==")
                                                            setListForAttendance()
                                                            cancelProgressDialog()
                                                        }
                                                    })
                                                } else {
                                                    setListForAttendance()
                                                    cancelProgressDialog()
                                                }

                                            }
                                            else {
                                                Log.d(TAG, getString(R.string.something_went_wrong));
                                                selectDay(Sel_day!!)
//                                                mAdapter?.notifyDataSetChanged()
                                            }
                                        })
                                val latLongT = Locat(txtDateFF, txtTimeFF + " " + txtTimePP, txt_lat + "_" + txt_lng)
                                LocatList.add(latLongT)
                                Util.showToast(resources.getString(R.string.check_in_done), activity!!)
                                boolCheckInDisabled = false
                                object : CountDownTimer(20000, 1000) {
                                    override fun onTick(millisUntilFinished: Long) {}
                                    override fun onFinish() {
                                        boolCheckInDisabled = true
                                    }
                                }.start()
                            } else {
                                Util.customFseRationaleDialog(this, "",
                                        hideNegative = true,
                                        titleSpanned = null,
                                        hideTitle = true,
                                        message = resources.getString(R.string.title_please_try_again),
                                        positveSelected = { it.dismiss() },
                                        negativeSeleted = { it.dismiss() }
                                )
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            } else {
                gps!!.showSettingsAlert()
            }

        } else {
            Util.showToast(resources.getString(R.string.please_wt_check_in_again), context!!)
        }
    }

    fun setListForAttendance() {

        if (Sel_day == 0) {
            val date = Util.getDaysAgo(0, true)
            viewModel!!.getAttendance(date.firstDate!!, date.secondDate!!).observe(this, CommonSpinSetListAttendanceObserver)

        } else if (Sel_day == 1) {
            val date = Util.getDaysAgo(-1, false)
            viewModel!!.getAttendance(date.firstDate!!, date.secondDate!!).observe(this, CommonSpinSetListAttendanceObserver)

        } else if (Sel_day == 2) {
            val date = Util.getDaysAgo(-7, true)
            viewModel!!.getAttendance(date.firstDate!!, date.secondDate!!).observe(this, CommonSpinSetListAttendanceObserver)

        } else if (Sel_day == 3) {
            val date = Util.getDaysAgo(-14, true)
            viewModel!!.getAttendance(date.firstDate!!, date.secondDate!!).observe(this, CommonSpinSetListAttendanceObserver)

        } else {
            viewModel!!.getAttendanceSS().observe(this, CommonSpinSetListAttendanceObserver)
        }
    }

    var CommonSpinSetListAttendanceObserver: Observer<List<AttendanceResponseModel.Checkin>> = androidx.lifecycle.Observer { data ->

        attendanceSetList = data!!.toMutableList()
        Log.e(TAG + "${AttendanceUtils.getLineNumber()}", "getAttendance === $attendanceSetList")

        if (preference?.getLoginResponseModel()?.country.equals("Nigeria", true)) {
            attendanceSetList!!.forEach { checkin ->
                if (checkin.checkinType == "CUSTOMER") {

                    bag.add(
                            AppDatabase.getAppDatabase(context).fseCustomerResponseDataDao().get()
                                    .observeOn(Schedulers.io())
                                    .subscribeOn(Schedulers.io())
                                    .subscribe({

                                        try {
                                            val fseCustomer = it?.fseList?.filter { it?.accountNumber == checkin.accountNumber }?.get(0)
                                            checkin.customerName = fseCustomer?.customerName
                                        } catch (e: Exception) {
                                            Log.e(TAG, "${AttendanceUtils.getLineNumber()} = getNameById-ERROR:${e.printStackTrace()} ");
                                        }

                                    }, {
                                        Log.e(TAG, "${AttendanceUtils.getLineNumber()} = getNameById-ERROR:${it.localizedMessage} ");
                                    })

                    )

                }
            }

        }

        attendanceSetList.let { refreshLocationList(data!!.toMutableList()) }
    }

    fun refreshLocationList(checkInListz: List<AttendanceResponseModel.Checkin>) {

        checInList.clear()
        checInList.addAll(checkInListz)

        Collections.sort(checInList, DateComparator())
        Collections.reverse(checInList)

        if (mAdapter?.checkInList?.size!! > 0) {
            binding.recyclerView?.visibility = View.VISIBLE
            binding.tvNoCheckIns?.visibility = View.GONE

        } else {
            binding.recyclerView?.visibility = View.GONE
            binding.tvNoCheckIns?.visibility = View.VISIBLE
            binding.tvNoCheckIns?.text = resources.getString(R.string.no_check_in) + " " + binding.spinnerAttd?.selectedItem
        }

        mAdapter!!.notifyDataSetChanged()
    }

    //Rajiv
    fun sendCheckIn() {

        viewModel!!.getOfflineAttendance(false).observe(this, androidx.lifecycle.Observer {
            val offlineList = it
            Log.e(TAG, "${AttendanceUtils.getLineNumber()} =getOfflineAttendance== offlineList:$offlineList")
            val attendanceResponseModel = AttendanceResponseModel(offlineList!!)
            attendanceResponseModel.checkins = offlineList as java.util.ArrayList<AttendanceResponseModel.Checkin>
            val angazaId = preference?.getLoginResponseModel()?.angazaId
//            val checkInOflineRespone = CheckInPostResponse(this, viewModel!!)

            if (!attendanceResponseModel.checkins.isNullOrEmpty()) {
//                ServiceInstance.getInstance(this).service?.attendancePost(angazaId!!, attendanceRequestModel)
//                        ?.enqueue(object : APICallback<CommonResponseModel<BaseResponseModel>>(checkInOflineRespone, this) {})

                if (Util.isOnline(this)) {
//                    ServiceInstance.getInstance(this).service?.attendancePost(angazaId!!, attendanceResponseModel!!)
//                            ?.enqueue(object : APICallback<CommonResponseModel<BaseResponseModel>>(checkInOflineRespone, this) {})

                    viewModel!!.attendanceRXPost(this, angazaId!!, attendanceResponseModel).observe(this, androidx.lifecycle.Observer {
                        if (it!!.Success!!) {
                            Log.e(TAG, "Alpha222: ")
                            viewModel!!.updateOfflineList(false, true)

                            setListForAttendance()
                            cancelProgressDialog()
                        } else {
                            Log.e("MAz = onError", "==CheckInPostResponse==onError==")
                            setListForAttendance()
                            cancelProgressDialog()
                        }

                    })

                } else {
                    setListForAttendance()
                    cancelProgressDialog()
                }
            }
            /*else{
                Toast.makeText(this,"Something went wrong, please try again",Toast.LENGTH_SHORT).show()
            }*/
        })

    }

    fun onItemSelected(position: Int) {
        Selected_days = resources.getStringArray(R.array.attendance)[position]
        Sel_day = position
        selectDay(position)

    }

    private fun selectDay(position: Int) {

        val calendar = Calendar.getInstance()
        val mdformat = SimpleDateFormat("dd-MM-yyyy")
        todayDate = mdformat.format(calendar.time)
        angazaId = preference?.getLoginResponseModel()?.angazaId!!
        showProgressDialog(this)

        if (position.equals(0)) {
            Util.addEvent("267", "Attendance", "attendance_today_filter_chosen")
            fromDate = todayDate
            val date = Util.getDaysAgo(0, true)
            //            viewModel!!.getAttendance(date.firstDate!!, date.secondDate!!).observe(this, CommonAttendaceSpinnerObserver)
            viewModel!!.getRXCheckINList(this, angazaId, fromDate.toString(), todayDate.toString(), date.firstDate!!, date.secondDate!!).observe(this, CustomGetRXCheckINList)

        } else if (position.equals(1)) {
            Util.addEvent("268", "Attendance", "attendance_yesterday_filter_chosen")
            fromDate = AttendanceUtils.getDaysAgo(1)
            val date = Util.getDaysAgo(-1, false)
            //            viewModel!!.getAttendance(date.firstDate!!, date.secondDate!!).observe(this, CommonAttendaceSpinnerObserver)
            //            viewModel!!.getRXCheckINList(this, angazaId, date.firstDate!!.toString(), date.secondDate!!.toString()).observe(this, CustomGetRXCheckINList)
            viewModel!!.getRXCheckINList(this, angazaId, fromDate.toString(), todayDate.toString(), date.firstDate!!, date.secondDate!!).observe(this, CustomGetRXCheckINList)
        } else if (position.equals(2)) {
            Util.addEvent("269", "Attendance", "attendance_last_seven_days_filter_chosen")
            fromDate = AttendanceUtils.getDaysAgo(7)
            val date = Util.getDaysAgo(-7, true)
            //            viewModel!!.getAttendance(date.firstDate!!, date.secondDate!!).observe(this, CommonAttendaceSpinnerObserver)
            viewModel!!.getRXCheckINList(this, angazaId, fromDate.toString(), todayDate.toString(), date.firstDate!!, date.secondDate!!).observe(this, CustomGetRXCheckINList)

        } else if (position.equals(3)) {
            Util.addEvent("270", "Attendance", "attendance_last_fourteen_filter_chosen")
            fromDate = AttendanceUtils.getDaysAgo(14)
            val date = Util.getDaysAgo(-14, true)
            //            viewModel!!.getAttendance(date.firstDate!!, date.secondDate!!).observe(this, CommonAttendaceSpinnerObserver)
            viewModel!!.getRXCheckINList(this, angazaId, fromDate.toString(), todayDate.toString(), date.firstDate!!, date.secondDate!!).observe(this, CustomGetRXCheckINList)

        }

    }

    var CommonAttendaceSpinnerObserver: androidx.lifecycle.Observer<List<AttendanceResponseModel.Checkin>> = androidx.lifecycle.Observer { data ->

        val attendanceList = data!!.toMutableList()

        Log.e(TAG, "attendanceList ${AttendanceUtils.getLineNumber()}=== $attendanceList")
//                ServiceInstance.getInstance(this).service?.getCheckINList(angazaId!!, fromDate.toString(), todayDate.toString())?.enqueue(object : APICallback<CommonResponseModel<AttendanceRequestModel>>(this as APIInterface<CommonResponseModel<AttendanceRequestModel>>, activity!!) {})


//        viewModel!!.getRXCheckINList(this, angazaId!!, fromDate.toString(), todayDate.toString())
//                .observe(this, android.arch.lifecycle.Observer {
//
//                    if (it!!.success) {
//
//                        val attendanceResponseModel = it!!.responseData!!
//
//                        if (attendanceResponseModel!!.checkins != null) {
//
//                            val checkInResponse = it!!.responseData!!.checkins!!
//                            val checkInList = Util.setCheckInList(checkInResponse as ArrayList<AttendanceResponseModel.Checkin>)
//                            Log.e(TAG, "${attendanceResponseModel!!.checkins!!.size} =============")
//                            viewModel!!.insertAttendance(checkInList)
//                        }
//                        Log.e(TAG, "Alpha111 : get ")
//                        setListForAttendance()
//                        cancelProgressDialog()
//                    } else {
//                        var attendResponseModel: List<AttendanceResponseModel.Checkin> = mutableListOf()
//                        cancelProgressDialog()
//                        viewModel!!.insertAttendance(checInList)
//                        viewModel!!.getAttendanceSS().observe(this, android.arch.lifecycle.Observer {
//                            attendResponseModel = it!!.toMutableList()
//                            if (attendResponseModel != null) {
//                                setListForAttendance()
//                            } else {
//                                Util.showToast(resources.getString(R.string.no_data_available), this)
//                                onBackPressed()
//                            }
//
//                        })
//
//                    }
//
//                })


    }

    var CustomGetRXCheckINList: androidx.lifecycle.Observer<NewCommonResponseModel<AttendanceResponseModel>> = androidx.lifecycle.Observer {

        if (it!!.success) {

            val attendanceResponseModel = it!!.responseData!!

            if (attendanceResponseModel!!.checkins != null) {

                val checkInResponse = it!!.responseData!!.checkins!!
                val checkInList = Util.setCheckInList(checkInResponse as ArrayList<AttendanceResponseModel.Checkin>)
                Log.e(TAG, "${attendanceResponseModel!!.checkins!!.size} =============")
                viewModel!!.insertAttendance(checkInList)
            }
//            Log.e(TAG, "Alpha111 : get ")
            setListForAttendance()
            cancelProgressDialog()
        } else {
            var attendResponseModel: List<AttendanceResponseModel.Checkin> = mutableListOf()
            cancelProgressDialog()
            viewModel!!.insertAttendance(checInList)
            setListForAttendance()
//            viewModel!!.getAttendanceSS().observe(this, android.arch.lifecycle.Observer {
//                attendResponseModel = it!!.toMutableList()
//                if (attendResponseModel != null) {
//                    setListForAttendance()
//                } else {
//                    Util.showToast(resources.getString(R.string.no_data_available), this)
//                    onBackPressed()
//                }
//
//            })

        }

        cancelProgressDialog()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

/*
    override fun onResponse(response: CommonResponseModel<AttendanceRequestModel>) =
            if (response.Success!!) {

                val attendanceRequestModel = response.ResponseData

                if (attendanceRequestModel!!.checkins != null) {

                    val checkInResponse = response.ResponseData!!.checkins!!
                    val checkInList = Util.setCheckInList(checkInResponse as ArrayList<AttendanceResponseModel.Checkin>)
                    Log.e(TAG, "${attendanceRequestModel!!.checkins!!.size} =============")
                    viewModel!!.insertAttendance(checkInList)
                }
                Log.e(TAG, "Alpha111 : get ")
                setListForAttendance()
                cancelProgressDialog()

            } else {
                cancelProgressDialog()
                Log.e(TAG, "response.Error?.MessageToUser")
//                Toast.makeText(activity, "" + response.Error?.MessageToUser, Toast.LENGTH_LONG).show()
                setListForAttendance()

            }

    override fun onError() {
        var attendResponseModel: List<AttendanceResponseModel.Checkin> = mutableListOf()
        cancelProgressDialog()
        viewModel!!.insertAttendance(checInList)
        viewModel!!.getAttendanceSS().observe(this, android.arch.lifecycle.Observer {
            attendResponseModel = it!!.toMutableList()
            if (attendResponseModel != null) {
                setListForAttendance()
            } else {
                Util.showToast(resources.getString(R.string.no_data_available), this)
                onBackPressed()
            }

        })

    }

    class CheckInPostResponse(activity: Activity, viewModel: AttendanceVM) : APIInterface<CommonResponseModel<BaseResponseModel>> {
        var activity = activity
        var vm = viewModel

        override fun onResponse(response: CommonResponseModel<BaseResponseModel>) {
            if (response.Success!!) {
                Log.e(TAG, "Alpha222: ")
//                AppDatabase.getAppDatabase(activity).userDao().updateOfflineList(false, true)

                vm.updateOfflineList(false, true)
                val activityz = activity as AttendanceActivity
                activityz.setListForAttendance()
                activityz.cancelProgressDialog()
            }
        }

        override fun onError() {
            val activityz = activity as AttendanceActivity
            Log.e("MAz = onError", "==CheckInPostResponse==onError==")
            activityz.setListForAttendance()
            activityz.cancelProgressDialog()
        }
    }
*/

    //region FSE for Nigeria

    fun getFseIfNot() {

        fseRepo.getFseCount().observe(this, androidx.lifecycle.Observer {

            it?.let { count ->

                Log.e(TAG, "count:$count ");
                if (count <= 0) {

                    //if (Util.isInternetAvailable() && Util.isOnline(context)) {
                    if (Util.isOnline(this)) {
                        //todo new
                        fseRepo.getNewFseCustomerFromServer(preference?.getLoginResponseModel()?.angazaId!!)?.observe(this, androidx.lifecycle.Observer {
                            mAdapter?.let {
                                setListForAttendance()
                            }
                        })
                    }
                }
            }
        })
    }

    //for Nigeria
    fun showFseDialog() {
        progressBar.showProgressDialog()
        fseRepo.getFseCount().observe(this, androidx.lifecycle.Observer {

            Log.e(TAG, "count1: $it ");

            it?.let { count ->

                if (count <= 0) {
                    if (Util.isOnline(this)) {
                        Toast.makeText(this, "Syncing new fse data", Toast.LENGTH_LONG).show()
                        //todo new
                        fseRepo.getNewFseCustomerFromServer(preference?.getLoginResponseModel()?.angazaId!!).observe(this, androidx.lifecycle.Observer {

                            it?.let { responseData ->
                                responseData.fseList?.let {
                                    fseLogic(it.filterNotNull())
                                }
                            }
                        })
                    } else {
                        Toast.makeText(this, "No data available", Toast.LENGTH_LONG).show()
                        progressBar.cancelProgressDialog()
                    }
                } else {

                    fseRepo.getNewFseCustomerFromDatabase().observe(this, androidx.lifecycle.Observer {

                        it?.let { responseData ->
                            responseData.fseList?.let {
                                fseLogic(it.filterNotNull())
                            }
                        }
                    })
                }

            }
        })

    }

    //for Nigeria

    fun fseLogic(fses: List<FseCustomerResponse.ResponseData.Fse>) {

        //got old data from database
        progressBar.cancelProgressDialog()
        //showData
        fseList = fses

        Log.e(TAG, "getFseCommitmentFromDatabase: $fses ")
        AttendanceUtils.makeDailog(getMultiSelectListFromFseList(fses), { name ->

            var isValid = true
            val calendar = Calendar.getInstance()
            val mdformat = SimpleDateFormat("dd-MM-yyyy")
            val currentDate = mdformat.format(calendar.time)

            val selectedFse = fseList?.filter { it.customerName.equals(name, false) }?.get(0)

            Log.e(TAG, "selectedFse: $selectedFse ")

            val sameAccountNumbers = checInList.filter { it.accountNumber == selectedFse!!.accountNumber }

            for (accountNumber in sameAccountNumbers) {

                val newFormatted = mdformat.format(accountNumber.date)

                if (currentDate.equals(newFormatted)) {
                    isValid = false
                    Util.customFseRationaleDialog(activity!!, "",
                            hideNegative = true,
                            titleSpanned = null,
                            hideTitle = true,
                            message = "Cannot Check-In twice on same day",
                            positveSelected = { it.dismiss() },
                            negativeSeleted = { it.dismiss() }
                    )
                    break
                }
            }

            if (isValid) {
                onCheckIn(account_number = selectedFse?.accountNumber!!, checkin_type = "CUSTOMER")
            }

        })?.show(this.supportFragmentManager, "fse_dialog")

    }

    fun syncFse() {
        showProgressDialog(context)
        //todo new
        fseRepo.getNewFseCustomerFromServer(preference?.getLoginResponseModel()?.angazaId!!)?.observe(this, androidx.lifecycle.Observer {
            //got new data from server for sync
            cancelProgressDialog()
            Toast.makeText(this, "Sync Completed", Toast.LENGTH_LONG).show()

            setListForAttendance()
        })
    }

    fun getMultiSelectListFromFseList(
            fseList: List<FseCustomerResponse.ResponseData.Fse>
    ): java.util.ArrayList<MultiSelectModel> {

        val list = java.util.ArrayList<MultiSelectModel>()

        val customerNameList = fseList.distinctBy { k -> k.customerName }

        for (index in customerNameList.indices) {
            list.add(MultiSelectModel(index, customerNameList[index].customerName, customerNameList[index].accountNumber))
        }

        return list

    }


    //endregion

    override fun onDestroy() {
        progressBar.cancelProgressDialog()
        progressBar.destroy()
        bag.clear()
        fseRepo.destroy()
		mHomeWatcher?.stopWatch();

		super.onDestroy()
    }

    override fun onBackPressed() {
        if (isFromNotification) {

            val intent = Intent(this, DashBoardActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        } else {
            super.onBackPressed()
        }
    }

}
