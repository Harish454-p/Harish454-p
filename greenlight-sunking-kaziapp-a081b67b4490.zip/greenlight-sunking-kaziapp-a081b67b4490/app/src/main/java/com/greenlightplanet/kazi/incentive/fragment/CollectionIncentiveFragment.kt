package com.greenlightplanet.kazi.incentive.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.greenlightplanet.kazi.databinding.FragmentCollectionIncentiveBinding


import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.incentive.model.collection
import com.greenlightplanet.kazi.utils.Util


class CollectionIncentiveFragment : Fragment() {

private var _binding:FragmentCollectionIncentiveBinding ? = null
    private val binding get() = _binding!!

    var preference: GreenLightPreference? = null


    var collection: collection? = null



    fun setCollectionDetails() {
        var symbol = preference?.getCountryResponseModel()?.countryCurrency ?: "NA"


        binding.tvTotalCollection?.text = Util.checkBlank(collection?.totalCollection?.toDouble()?.let { Util.formatAmount(it) } + " " + symbol, context = context)
        binding. tvCollectionDuration?.text = Util.checkBlankNA(collection?.duration, context)



        if(preference?.getShowCollectionRate()?:false){
            binding. tvCollectionRate?.text = Util.checkBlank(collection?.collectionRate, context = context)
            binding. llCollectionRate.visibility = View.VISIBLE
            binding. llCollectionScore.visibility = View.GONE
        }else{
            binding.tvCollectionScore?.text = Util.checkBlank(collection?.collectionScore, context = context)
            binding. llCollectionScore.visibility = View.VISIBLE
            binding.llCollectionRate.visibility = View.GONE
        }


        var preTax = "" + collection?.preTax?.toDouble()?.let { Util.formatAmount(it) }
        binding.tvPreTax?.text = Util.checkBlank(preTax + " " + symbol, context = context)
        binding. tvCommision?.text = Util.checkBlank(collection?.commission?.toDouble()?.times(100)?.let { Math.round(it) }.toString(), context = context) + "%"
        binding. tvPostTax?.text = Util.checkBlank(collection?.postTax?.toDouble()?.let { Util.formatAmount(it) } + " " + symbol, context = context)

    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        _binding = FragmentCollectionIncentiveBinding.inflate(inflater, container, false)



        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val bundlesales = arguments
        collection = bundlesales?.getSerializable("collection") as collection?
        preference = GreenLightPreference.getInstance(requireContext())
        setCollectionDetails()


    }


}
