package com.greenlightplanet.kazi.fseProspective.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import androidx.room.EmptyResultSetException
import com.google.gson.Gson
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.fseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.fseProspective.model.*
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.util.*

class VerificationRepo(val context: Context) {

    companion object :
        SingletonHolderUtil<VerificationRepo, Context>(::VerificationRepo) {
        public const val TAG = "VerificationRepo"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    var gson: Gson? = null
    var country: String? = null

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context!!)
            country = preference?.getLoginResponseModel()?.country
            gson = Gson()

        } catch (e: Exception) {
            Log.d(TAG, ":Error ");
        }
    }

    private val territory: String? by lazy {
        preference?.getLoginResponseModel()?.territory
    }

    fun getCombineRequestModel(prospectId: String): MutableLiveData<CombineRequestModel?> {

        val data = MutableLiveData<CombineRequestModel?>()
        val combineModel = CombineRequestModel()

        try {
            bag.add(
                localDb?.fseProspectResponseDao()?.getByProspectId(prospectId)!!
                    .flatMap {
                        combineModel.fseProspectResponseModel = it
                        localDb?.otpApprovalRequestDao()?.getByProspectId(prospectId)
                    }.flatMap {
                        combineModel.otpApprovalRequestModel = it
                        localDb?.fseErrorDao()?.getByProspectId(prospectId)!!
                    }
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .doFinally { data.postValue(combineModel) }

                    .onErrorResumeNext {
                        if (it is EmptyResultSetException) Single.just(
                            FseError(
                                prospectId,
                                "No Data Available",
                                500,
                                TAG,
                                "No Data Available",
                                "No Data Available"
                            )
                        ) //<< an empty container is returned.
                        else Single.error(it)
                    }
                    .doOnError {
                        Log.d(TAG, "Error-1: ${it.localizedMessage}");
                        it.printStackTrace()
                    }
                    .subscribe({
                        combineModel.fseError = it
                    }, {
                        it.printStackTrace()
                        Log.d(TAG, "ERROR:${it.localizedMessage} ");
                    })
            )
        } catch (e: Exception) {
            Log.e("error", "${e}")
        }
        return data


        /*   .onErrorResumeNext {
               if (it is EmptyResultSetException) Single.just(FseError(prospectId,"No Data Available",500,TAG,"No Data Available","No Data Available")) //<< an empty container is returned.
               else Single.error(it)
           }*/
    }


    //Valid and InValid
    //step-0
    private fun getOtpApprovalRequestFromDBIfExist(prospectId: String): Single<OtpApprovalRequestModel> {

        return localDb!!.otpApprovalRequestDao().getByProspectId(prospectId)!!
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
    }

    fun getOtpApprovalRequestFromDB(prospectId: String): MutableLiveData<OtpApprovalRequestModel> {
        val data: MutableLiveData<OtpApprovalRequestModel> = MutableLiveData()

        bag.add(
            getOtpApprovalRequestFromDBIfExist(prospectId)
                .subscribe({
                    data.postValue(it)
                }, {
                    it.printStackTrace()
                    data.postValue(null)
                })
        )
        return data
    }

    /////////////////


    //InValid
    //step-1

    fun onInvalidOtp(
        isOnline: Boolean,
        prospectId: String,
        angazaId: String,
        unsuccessfulAttempt: Int,
        country: String
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {
        val data: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> = MutableLiveData()
        localDb?.let { appDatabase ->
            bag.add(
                getOtpApprovalRequestFromDBIfExist(prospectId).subscribe({

                    //  if (it != null) {
                    //it.unsuccessfulAttempts = it.unsuccessfulAttempts.inc()
                    it.unsuccessfulAttempts = unsuccessfulAttempt.inc()
                    processOtp(data, isOnline, false, it)
                    Log.d(TAG, "DB-EO-List: ${""}")
                    //     }


                }, { t ->

                    val newOtpApprovalRequestModel = OtpApprovalRequestModel(
                        prospectId = prospectId,
                        unsuccessfulAttempts = unsuccessfulAttempt.inc(),
                        otpVerificationTime = "",
                        angazaId = angazaId,
                        country = country
                            ?: ""
                    )
                    processOtp(data, isOnline, false, newOtpApprovalRequestModel)
                    Log.d(TAG, "API-Error: ${t.localizedMessage}")
                })

            )
        }
        return data

    }


    //Valid
    //step-1
    fun onValidOtp(
        isOnline: Boolean,
        prospectId: String,
        angazaId: String,
        country: String
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {
        val data: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> = MutableLiveData()
        localDb?.let { appDatabase ->
            bag.add(
                getOtpApprovalRequestFromDBIfExist(prospectId).subscribe({

                    it.otpVerificationTime = Util.fseDateToUtcFormatted(Date())!!
                    processOtp(data, isOnline, true, it)
                    Log.d(TAG, "DB-EO-List: ${""}")

                }, { t ->

                    val newOtpApprovalRequest = OtpApprovalRequestModel(
                        prospectId = prospectId,
                        unsuccessfulAttempts = 0,
                        otpVerificationTime = Util.fseDateToUtcFormatted(Date())!!,
                        angazaId = angazaId,
                        country = country
                            ?: ""
                    )
                    processOtp(data, isOnline, true, newOtpApprovalRequest)
                    Log.d(TAG, "API-Error: ${t.localizedMessage}")
                })

            )
        }
        return data

    }


    //Valid and InValid
    //step-2
    private fun processOtp(
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        isOnline: Boolean,
        isValid: Boolean,
        otpApprovalRequestModel: OtpApprovalRequestModel
    ) {
        if (isOnline) {
            return processOtpToServer(liveData, isValid, otpApprovalRequestModel)
        } else {
            return processOtpToDatabase(liveData, isValid, otpApprovalRequestModel)
        }
    }

    //Valid and InValid
    //step-3
    private fun processOtpToDatabase(
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        isValid: Boolean,
        otpApprovalRequest: OtpApprovalRequestModel
    ) {


        bag.add(

            insertOtpApprovalToDatabase(otpApprovalRequest)
                .flatMapCompletable {
                    performIsChanged(
                        otpApprovalRequest.prospectId,
                        true,
                        !isValid,
                        otpApprovalRequest.otpVerificationTime
                    )
                }
                .subscribe({

                    liveData.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            success = true
                        )
                    )
                }, {
                    //error
                    liveData.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )

                })
        )


    }

    //Valid and InValid
    //step-3
    private fun processOtpToServer(
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        isValid: Boolean,
        otpApprovalRequest: OtpApprovalRequestModel
    ) {


        bag.add(

            insertOtpApprovalToDatabase(otpApprovalRequest)
                .subscribe({
                    sendOtpApprovalToServer(liveData, isValid, otpApprovalRequest)
                }, {
                    //error
                    liveData.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )

                })
        )


    }

    fun sendOtpApprovalToServerForceUpload(
        isValid: Boolean,
        otpApprovalRequest: OtpApprovalRequestModel
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {

        val data: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> = MutableLiveData()

        var response: NewCommonResponseModel<NewEmptyParcelable>? = null

        bag.add(
            ServiceInstance.getInstance(context).service?.postOtpApproval(
                //url = "http://demo4291977.mockable.io/otp-approval",
                otpApprovalRequestModel = otpApprovalRequest
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable {
                    response = it
                    if (it.success) {

                        performIsChanged(
                            otpApprovalRequest.prospectId,
                            false,
                            !isValid,
                            otpApprovalRequest.otpVerificationTime
                        )
                    } else {
                        //data.postValue(it)
                        performIsChanged(
                            prospectId = otpApprovalRequest.prospectId,
                            isChanged = false,
                            increment = !isValid,
                            errorOccurred = true,
                            errorModel = it.error
                        )
                    }

                }
                .subscribe({

                    data.postValue(response)

                }, {


                    /*val error = it as HttpException
                    val errorBody = error.response().errorBody()?.string()
                    val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)*/

                    val isApi = it is retrofit2.HttpException

                    var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                    if (isApi) {
                        val error = it as HttpException
                        val errorBody = error.response().errorBody()?.string()
                        errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(
                            errorBody,
                            NewCommonResponseModel::class.java
                        )

                    } else {


                        errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = it.localizedMessage
                            ),
                            success = false

                        )

                    }


                    bag.add(
                        performIsChanged(
                            prospectId = otpApprovalRequest.prospectId,
                            isChanged = false,
                            increment = !isValid,
                            errorOccurred = true,
                            errorModel = errorModel?.error
                        ).subscribe()
                    )

                    data.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )
                    Log.d(TAG, "Error:${it.localizedMessage} ");

                })

            /*.subscribe({ success ->
                success?.let { responseData ->

                    Log.d(TAG, "Response: ${success}")

                    liveData.postValue(responseData)
                    //todo There is some logic here
                }

            }, { t ->

                Log.d(TAG, "API-Error3: ${t.localizedMessage}")

                liveData.postValue(null)
            })*/
        )

        return data
    }

    //Valid and InValid
    //step-4
    private fun sendOtpApprovalToServer(
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        isValid: Boolean,
        otpApprovalRequest: OtpApprovalRequestModel
    ) {

        bag.add(
            ServiceInstance.getInstance(context).service?.postOtpApproval(
                //url = "http://demo4291977.mockable.io/otp-approval",
                otpApprovalRequestModel = otpApprovalRequest
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable {
                    if (it.success) {
                        liveData.postValue(it)
                        performIsChanged(
                            otpApprovalRequest.prospectId,
                            false,
                            !isValid,
                            otpApprovalRequest.otpVerificationTime
                        )
                    } else {
                        liveData.postValue(it)
                        performIsChanged(
                            prospectId = otpApprovalRequest.prospectId,
                            isChanged = false,
                            increment = !isValid,
                            errorOccurred = true,
                            errorModel = it.error
                        )
                    }

                }
                .subscribe({}, {


                    /*val error = it as HttpException
                    val errorBody = error.response().errorBody()?.string()
                    val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)
*/

                    val isApi = it is retrofit2.HttpException

                    var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                    if (isApi) {
                        val error = it as HttpException
                        val errorBody = error.response().errorBody()?.string()
                        errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(
                            errorBody,
                            NewCommonResponseModel::class.java
                        )

                    } else {


                        errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = it.localizedMessage
                            ),
                            success = false

                        )

                    }


                    bag.add(
                        performIsChanged(
                            prospectId = otpApprovalRequest.prospectId,
                            isChanged = false,
                            increment = !isValid,
                            errorOccurred = true,
                            errorModel = errorModel?.error
                        ).subscribe({
                            Log.d(TAG, " on Success ===");
                        }, {
                            Log.d(TAG, " Error:${it.printStackTrace()}");
                        })
                    )


                    liveData.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )



                    Log.d(TAG, "Error:${it.localizedMessage} ");

                })


        )
    }

    //Valid and InValid
    //step-4
    private fun insertOtpApprovalToDatabase(otpApprovalRequestModel: OtpApprovalRequestModel): Single<OtpApprovalRequestModel> {

        return Single.create { emitter ->

            try {
                val result = localDb!!.otpApprovalRequestDao().insert(otpApprovalRequestModel)
                result.let {
                    emitter.onSuccess(otpApprovalRequestModel)
                }

            } catch (e: Exception) {
                emitter.onError(e)
            }
        }
    }


    private fun performIsChanged(
        prospectId: String,
        isChanged: Boolean,
        increment: Boolean,
        date: String = "",
        errorOccurred: Boolean = false,
        errorModel: NewCommonResponseModel.Error? = null
    ): Completable {
        //bag.add(
        Log.d(TAG, "performIsChanged-:isChanged =$prospectId= ${isChanged} ")
        return localDb!!.fseProspectResponseDao().getByProspectId(prospectId)!!
            .flatMapCompletable {
                val value = it
                Log.d(TAG, "performIsChanged-:value == ${it.prospectId} ")
                value.isChanged = isChanged
                value.errorOccurred = errorOccurred


                if (increment) {
                    value.unsuccessfulOtpAttempts = value.unsuccessfulOtpAttempts + 1
                } else {
                    value.statusUpdateTime?.otpApproved = date
                    value.status = FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                }

                val fseError = FseError(
                    prospectId = prospectId,
                    errorType = FseProspectiveConstant.ProspectiveType.VERIFICATION,
                    code = errorModel?.code,
                    errorClass = errorModel?.errorClass,
                    errorTrace = errorModel?.errorTrace,
                    messageToUser = errorModel?.messageToUser
                )

                /* Completable.fromAction {
                     localDb!!.fseProspectResponseDao().insert(value)
                 }.mergeWith {
                     if (errorOccurred) {
                         Completable.fromAction {
                             localDb!!.fseErrorDao().insert(fseError)
                         }
                     }
                 }*/

                val list = mutableListOf<Completable>()

                list.add(
                    Completable.fromAction {
                        localDb!!.fseProspectResponseDao().insert(value)
                        Log.d(
                            TAG,
                            "performIsChanged-:value |${value.isChanged}| insert== ${value.prospectId} "
                        )
                    }
                )
                if (errorOccurred) {
                    list.add(
                        Completable.fromAction {
                            localDb!!.fseErrorDao().insert(fseError)
                        }
                    )
                }


                Completable.merge(list)


            }
    }

    fun destroy() {

        Log.d(TAG, "Repo : Distroyed");
        bag.clear()

    }

    ///new

    private fun syncServerOtpApprovalRequestModel(otpApprovalRequest: OtpApprovalRequestModel): Single<NewCommonResponseModel<NewEmptyParcelable>> {

        return ServiceInstance.getInstance(context).service?.postOtpApproval(
            otpApprovalRequestModel = otpApprovalRequest
        )!!
            .subscribeOn(Schedulers.newThread())
            .flatMap {
                Single.create<NewCommonResponseModel<NewEmptyParcelable>> { emitter ->
                    try {

                        //performIsChanged(registrationCheckinRequestModel.prospectId, false).subscribe({ emitter.onSuccess(it) }, { emitter.onError(it) })
                        if (it.success) {
                            performIsChanged(
                                otpApprovalRequest.prospectId,
                                false,
                                true,
                                date = otpApprovalRequest.otpVerificationTime!!
                            ).subscribe({ emitter.onSuccess(it) }, { emitter.onError(it) })
                        } else {
                            performIsChanged(
                                otpApprovalRequest.prospectId,
                                false,
                                true,
                                date = otpApprovalRequest.otpVerificationTime!!,
                                errorModel = it.error
                            ).subscribe({ emitter.onSuccess(it) }, { emitter.onError(it) })
                        }


                    } catch (e: Exception) {
                        emitter.onError(e)
                    }
                }

            }
            .doOnSuccess {
                bag.add(
                    Completable.fromAction {
                        // logic
                        Log.d(TAG, " inserting:${otpApprovalRequest.prospectId}");
                        performIsChanged(otpApprovalRequest.prospectId, false, false)
                    }
                        .subscribeOn(Schedulers.newThread())
//                        .observeOn(Schedulers.io())
                        .subscribe({
                            Log.d(TAG, "performIsChanged on Success ===");
                        }, {
                            Log.d(TAG, " Error:${it.printStackTrace()}");
                        })
                )
            }
            .onErrorResumeNext { it ->

                val isApi = it is retrofit2.HttpException

                var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                if (isApi) {
                    val error = it as HttpException
                    val errorBody = error.response().errorBody()?.string()
                    errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(
                        errorBody,
                        NewCommonResponseModel::class.java
                    )

                } else {


                    errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                        error = NewCommonResponseModel.Error(
                            messageToUser = it.localizedMessage
                        ),
                        success = false

                    )

                }


                performIsChanged(
                    prospectId = otpApprovalRequest.prospectId,
                    isChanged = false,
                    increment = otpApprovalRequest.otpVerificationTime.isNullOrBlank(),
                    errorOccurred = true,
                    errorModel = errorModel?.error
                )
                    .toSingleDefault(true)
                    .onErrorReturnItem(false)
                    .flatMap {
                        Single.just(NewCommonResponseModel<NewEmptyParcelable>())
                    }


            }


    }


    private fun syncLoopOtpApprovalRequestModel(otpApprovalRequestModels: List<OtpApprovalRequestModel>): Single<List<OtpApprovalRequestModel>> {


        val requests = mutableListOf<Single<NewCommonResponseModel<NewEmptyParcelable>>>()

        otpApprovalRequestModels.forEach {
            requests.add(syncServerOtpApprovalRequestModel(it))
        }

        return Single.zip(requests) {
            otpApprovalRequestModels
        }
    }


    private fun syncAllInsertOtpApprovalRequestModel(allSingles: Single<List<OtpApprovalRequestModel>>): Single<List<OtpApprovalRequestModel>> {
        return allSingles.flatMap {
            insertAllOtpApprovalToDatabase(it)
        }

    }

    private fun insertAllOtpApprovalToDatabase(otpApprovalRequestModels: List<OtpApprovalRequestModel>): Single<List<OtpApprovalRequestModel>> {

        return Single.create { emitter ->

            try {
                val result = localDb!!.otpApprovalRequestDao().insertAll(otpApprovalRequestModels)
                result.let {
                    emitter.onSuccess(otpApprovalRequestModels)
                }

            } catch (e: Exception) {
                emitter.onError(e)
            }
        }
    }

    fun processAll(otpApprovalRequestModels: List<OtpApprovalRequestModel>): Single<List<OtpApprovalRequestModel>> {
        return syncLoopOtpApprovalRequestModel(otpApprovalRequestModels).flatMap {
            insertAllOtpApprovalToDatabase(it)
        }
    }

    fun getFseProspectiveFromServer(
        angazaId: String,
        prospectId: String
    ): MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>? {

        val data = MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>()

        var value: NewCommonResponseModel<FseProspectItemResponseModel>? = null

        bag.add(

            localDb!!.fseProspectResponseDao().getByProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable { prospectFromDatabase ->
                    // here delete all data from database
                    Completable.fromAction {
                        localDb!!.fseProspectResponseDao().delete(prospectFromDatabase)
                    }.doOnError {
                        Log.d(TAG, "Error-2: ${it.localizedMessage}");
                        data.postValue(
                            NewCommonResponseModel<FseProspectResponseModel>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from server"
                                ),
                                success = false
                            )
                        )
                        it.printStackTrace()
                    }.doOnComplete {
                        //ServiceInstance.getInstance(context).service?.getFseProspectives()!!
                        ServiceInstance.getInstance(context).service?.getFseProspective(
                            angazaId,
                            prospectId,
                            territory!!
                        )!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                value = it!!

                                val fromDatabase = prospectFromDatabase

                                var fromServer = value!!.responseData!!.prospect!!

                                var oldChangedData: FseProspectResponseModel? = null

                                //notNewAddedServerValue.forEach { itemServer ->

                                val sameDataInDatabase = fromDatabase

                                fun statusUpdateTimeHandler(
                                    oldStatus: FseProspectResponseModel.StatusUpdateTime,
                                    newStatus: FseProspectResponseModel.StatusUpdateTime,
                                    oldFseProspectResponseModel: FseProspectResponseModel
                                ): FseProspectResponseModel.StatusUpdateTime {
                                    var revisedStatus = oldStatus

                                    if (!newStatus.prospect.isNullOrEmpty()) {
                                        revisedStatus.prospect = newStatus.prospect
                                    }


                                    if (!newStatus.otpApproved.isNullOrEmpty()) {
                                        revisedStatus.otpApproved = newStatus.otpApproved
                                    }


                                    if (!newStatus.preApprovedProspect.isNullOrEmpty()) {
                                        revisedStatus.preApprovedProspect =
                                            newStatus.preApprovedProspect
                                    }

                                    if (!newStatus.checkedIn.isNullOrEmpty()) {
                                        revisedStatus.checkedIn = newStatus.checkedIn
                                    }

                                    if (!newStatus.threeWayCallVerification.isNullOrEmpty()) {
                                        revisedStatus.threeWayCallVerification =
                                            newStatus.threeWayCallVerification
                                    }

                                    if (!newStatus.installationPending.isNullOrEmpty()) {
                                        revisedStatus.installationPending =
                                            newStatus.installationPending
                                    }


                                    if (oldFseProspectResponseModel.reattemptedStage != 1 || oldFseProspectResponseModel.reattemptedStage != 2) {
                                        if (!newStatus.installed.isNullOrEmpty()) {
                                            revisedStatus.installed = newStatus.installed
                                        }

                                        if (!newStatus.installationVerified.isNullOrEmpty()) {
                                            revisedStatus.installationVerified =
                                                newStatus.installationVerified
                                        }
                                    }

                                    return revisedStatus
                                }

                                fun statusHandler(oldStatus: String, newStatus: String): String {
                                    var revisedStatus = ""

                                    when (oldStatus) {
                                        FseProspectiveConstant.ProspectStatus.PROSPECT -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.OTP_APPROVED) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PROSPECT
                                            }

                                        }

                                        FseProspectiveConstant.ProspectStatus.OTP_APPROVED -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.CHECKED_IN) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.CHECKED_IN -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            } else if (newStatus == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLED) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLED
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.INSTALLED -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                            } else if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLED
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                            }
                                        }

                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            }
                                        }

                                        else -> {
                                            revisedStatus =
                                                FseProspectiveConstant.ProspectStatus.PROSPECT
                                        }

                                    }

                                    return revisedStatus
                                }

                                sameDataInDatabase?.let {

                                    sameDataInDatabase.approved = fromServer.approved
                                    sameDataInDatabase.message = fromServer.message
                                    sameDataInDatabase.customerAddress = fromServer.customerAddress

                                    sameDataInDatabase.name = fromServer.name
                                    sameDataInDatabase.otp = fromServer.otp
                                    sameDataInDatabase.productName = fromServer.productName
                                    sameDataInDatabase.status = statusHandler(
                                        sameDataInDatabase.status!!,
                                        fromServer.status!!
                                    )
                                    sameDataInDatabase.statusUpdateTime = statusUpdateTimeHandler(
                                        sameDataInDatabase.statusUpdateTime!!,
                                        fromServer.statusUpdateTime!!,
                                        sameDataInDatabase
                                    )
                                    sameDataInDatabase.ticketType = fromServer.ticketType
                                    sameDataInDatabase.accountNumber = fromServer.accountNumber
                                    sameDataInDatabase.installationPicture =
                                        fromServer.installationPicture
                                    sameDataInDatabase.customerPhoneNumber =
                                        fromServer.customerPhoneNumber
                                    sameDataInDatabase.area = fromServer.area

                                    oldChangedData = sameDataInDatabase

                                }
                                //need to add some new attributes here
                                //}


                                val resultData = oldChangedData


                                if (resultData != null) {

                                    //data.postValue(value)
                                    fromServer = resultData
                                    fseProspectiveFromServerLogic(
                                        data,
                                        NewCommonResponseModel(
                                            responseData = fromServer,
                                            success = true
                                        )
                                    )
                                    //add to database

                                } else {
                                    data.postValue(
                                        NewCommonResponseModel<FseProspectResponseModel>(
                                            error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable get data from server"
                                            ),
                                            success = false
                                        )
                                    )
                                }
                            }, {
                                Log.d(TAG, "Error-1: ${it.localizedMessage}");

                                data.postValue(
                                    NewCommonResponseModel<FseProspectResponseModel>(
                                        error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable get data from server"
                                        ),
                                        success = false
                                    )
                                )

                                it.printStackTrace()
                            })
                    }
                }.doOnError {
                    Log.d(TAG, "Error-1: ${it.localizedMessage}");
                    data.postValue(
                        NewCommonResponseModel<FseProspectResponseModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from server"
                            ),
                            success = false
                        )
                    )
                    it.printStackTrace()
                }.subscribe({
                    Log.d(TAG, " on Success ===");
                }, {
                    Log.d(TAG, " Error:${it.printStackTrace()}");
                })

        )

        return data
    }

    private fun fseProspectiveFromServerLogic(
        liveData: MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>,
        responseData: NewCommonResponseModel<FseProspectResponseModel>
    ) {

        bag.add(
            Completable.fromAction {
                localDb?.fseProspectResponseDao()?.insert(responseData.responseData!!)
            }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Insertion:Completed ")
                    preference?.setFseProspectLastSynced(Util.getCurrentLocalFormattedDateForSync())
                    liveData.postValue(responseData)
                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })
        )

    }
}
