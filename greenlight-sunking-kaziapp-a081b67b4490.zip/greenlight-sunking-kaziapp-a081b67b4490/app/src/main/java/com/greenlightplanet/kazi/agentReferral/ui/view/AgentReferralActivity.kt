package com.greenlightplanet.kazi.agentReferral.ui.view

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_by_mtd
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_by_name
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_by_regis_date
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_none
import com.greenlightplanet.kazi.agentReferral.model.agentreferral.SuccessfullyReferredAgent
import com.greenlightplanet.kazi.agentReferral.ui.adapter.AgentReferralAdapter
import com.greenlightplanet.kazi.agentReferral.viewmodel.AgentReferralViewModel
import com.greenlightplanet.kazi.databinding.ActivityAgentReferralBinding
import com.greenlightplanet.kazi.leads.view.activity.CustomerLeadsFeedbackActivity
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import java.text.NumberFormat
import java.util.*

class AgentReferralActivity : BaseActivity(), AgentReferralAdapter.OnAgentReferral {

    private lateinit var binder: ActivityAgentReferralBinding
    private lateinit var viewModel: AgentReferralViewModel
    private var adapter : AgentReferralAdapter? = null
    private var preference: GreenLightPreference? = null
    private var mHomeWatcher: HomeWatcher? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binder = ActivityAgentReferralBinding.inflate(layoutInflater)
        setContentView(binder.root)

        viewModel = ViewModelProvider(this)[AgentReferralViewModel::class.java]

        preference = GreenLightPreference.getInstance(arg = this)
        Util.setToolbar(this, binder.toolbar)

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(CustomerLeadsFeedbackActivity.TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()

        sortTab(sort_none)
        viewModelHandler()
    }

    private fun viewModelHandler() {
        viewModel.run {
            binder.apply {
                lytRcChildAgents.visibility = View.GONE
                showProgressDialog(this@AgentReferralActivity)
                agentReferral(isOnline = Util.isOnline(this@AgentReferralActivity))
                    .observe(this@AgentReferralActivity, Observer { response ->
                        when(response) {
                            null -> {
                                lytRcChildAgents.visibility = View.GONE
                                txtNoAgents.visibility = View.VISIBLE
                                cancelProgressDialog()
                                Util.customFseRationaleDialog(
                                    context = this@AgentReferralActivity,
                                    title = "",
                                    hideNegative = true,
                                    titleSpanned = null,
                                    hideTitle = true,
                                    message = this@AgentReferralActivity.getString(R.string.no_data),
                                    positveSelected = {
                                        it.dismiss()
                                    },
                                    negativeSeleted = {
                                        it.dismiss()
                                    }
                                )
                            }
                            else -> {
                                when(response.success) {
                                    true -> {
                                        when(response.responseData) {
                                            null -> {
                                                lytRcChildAgents.visibility = View.GONE
                                                txtNoAgents.visibility = View.VISIBLE
                                                cancelProgressDialog()
                                            }
                                            else -> {
                                                updateLastSync()
                                                prepData(responseData = response.responseData!!)
                                            }
                                        }
                                    }
                                    else -> {
                                        lytRcChildAgents.visibility = View.GONE
                                        txtNoAgents.visibility = View.VISIBLE
                                        cancelProgressDialog()
                                        Util.customFseRationaleDialog(
                                            context = this@AgentReferralActivity,
                                            title = "",
                                            hideNegative = true,
                                            titleSpanned = null,
                                            hideTitle = true,
                                            message = this@AgentReferralActivity.getString(R.string.no_data),
                                            positveSelected = {
                                                it.dismiss()
                                            },
                                            negativeSeleted = {
                                                it.dismiss()
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    })

                obsAgentChildList.observe(this@AgentReferralActivity, Observer { list ->
                    when {
                        list.isEmpty() -> {
                            txtNoAgents.visibility = View.VISIBLE
                            lytRcChildAgents.visibility = View.GONE
                        }
                        else -> {
                            when(adapter) {
                                null -> {
                                    adapter = AgentReferralAdapter(
                                        agentReferralActivity = this@AgentReferralActivity,
                                        list = list
                                    )
                                    rcChildAgents.layoutManager = LinearLayoutManager(this@AgentReferralActivity)
                                    rcChildAgents.adapter = adapter
                                }
                                else -> {
                                    adapter?.list = list
                                    adapter?.notifyDataSetChanged()
                                }
                            }
                            txtNoAgents.visibility = View.GONE
                            lytRcChildAgents.visibility = View.VISIBLE
                        }
                    }
                    updateLastSync()
                    cancelProgressDialog()
                })
                obsSuccessfulReferred.observe(this@AgentReferralActivity, Observer { succesful ->
                    when(succesful) {
                        null -> this@AgentReferralActivity.getString(R.string.na)
                        else -> txtSuccessfulReferred.text = NumberFormat.getNumberInstance(Locale.getDefault()).format(succesful)
                    }
                })
                obsTotalReferred.observe(this@AgentReferralActivity, Observer { totalRefered ->
                    when(totalRefered) {
                        null -> {
                            this@AgentReferralActivity.getString(R.string.na)
                        }
                        else -> {
                            txtTotalReferred.text = NumberFormat.getNumberInstance(Locale.getDefault()).format(totalRefered)
                            Util.addUnderline2(txtTotalReferred)
                        }
                    }
                })
                obsReferredLastMonth.observe(this@AgentReferralActivity, Observer { lastMonth ->
                    when(lastMonth) {
                        null, "" -> this@AgentReferralActivity.getString(R.string.na)
                        else -> txtReferredLastMonth.text = NumberFormat.getNumberInstance(Locale.getDefault()).format(lastMonth.toInt())
                    }
                })
                obsLastMonthReferredIncentive.observe(this@AgentReferralActivity, Observer { lastMonthIncentive ->
                    when(lastMonthIncentive) {
                        null, "" -> this@AgentReferralActivity.getString(R.string.na)
                        else -> txtLastMonthIncentive.text = lastMonthIncentive
                    }
                })
                obsViewMore.observe(this@AgentReferralActivity, Observer { eof ->
                    when(eof) {
                        true -> txtAgentsViewMore.visibility = View.GONE
                        false -> txtAgentsViewMore.visibility = View.VISIBLE
                        else -> txtAgentsViewMore.visibility = View.GONE
                    }
                })

                btnReferAgent.setOnClickListener {
                    Util.addEvent(
                            id = "375",
                            name ="Refer new child agent button",
                            event ="user_refer_new_child_agent_button"
                    )
                    val intent : Intent = Intent(this@AgentReferralActivity, ReferNewAgentActivity :: class.java)
                    startActivity(intent)
                }
                txtAgentName.setOnClickListener {
                    sortTab(sortType = sort_by_name)
                }
                txtMtdSales.setOnClickListener {
                    sortTab(sortType = sort_by_mtd)
                }
                txtRegisDate.setOnClickListener {
                    sortTab(sortType = sort_by_regis_date)
                }
                txtAgentsViewMore.setOnClickListener {
                    Util.addEvent(
                            id = "376",
                            name ="View more button for pagenation",
                            event ="user_view_more_button_for_pagination"
                    )
                    sortTab(sort_none)
                    this@run.callAgentReferralApi(agentReferralActivity = this@AgentReferralActivity)
                }
                txtTotalReferred.setOnClickListener {
                    Util.addEvent(
                            id = "377",
                            name ="Total referred agents drill down button",
                            event ="user_click_total_referral_drill_down"
                    )
                    val intent : Intent = Intent(this@AgentReferralActivity, ReferredAgentListActivity :: class.java)
                    startActivity(intent)
                }
                updateLastSync()
            }
        }
    }

    private fun updateLastSync() {
        binder.txtLastSync.text = this@AgentReferralActivity.getString(R.string.last_sync, preference?.getAgentReferralLastSync())
        binder.txtAppVersion.text = this@AgentReferralActivity.getString(R.string.app_version, BuildConfig.VERSION_NAME)
    }

    private fun sortTab(sortType: Int) {
        binder.run {
            when(sortType) {
                sort_by_name -> {
                    txtAgentName.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorGrey)
                    txtRegisDate.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorBlack)
                    txtMtdSales.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorBlack)
                    viewModel.sortAgentReferrals(sortType = sort_by_name)
                }
                sort_by_regis_date -> {
                    txtAgentName.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorBlack)
                    txtRegisDate.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorGrey)
                    txtMtdSales.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorBlack)
                    viewModel.sortAgentReferrals(sortType = sort_by_regis_date)
                }
                sort_by_mtd -> {
                    txtAgentName.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorBlack)
                    txtRegisDate.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorBlack)
                    txtMtdSales.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorGrey)
                    viewModel.sortAgentReferrals(sortType = sort_by_mtd)
                }
                sort_none -> {
                    txtAgentName.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorBlack)
                    txtRegisDate.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorBlack)
                    txtMtdSales.background = ContextCompat.getDrawable(this@AgentReferralActivity, R.color.colorBlack)
                }
            }
        }
    }

    override fun onAgentReferralClick(model: SuccessfullyReferredAgent) {
//        val agentIntent = Intent(this, ReferredAgentListActivity :: class.java)
//        startActivity(agentIntent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onResume() {
        super.onResume()
        sortTab(sort_none)
    }

    override fun onDestroy() {
        mHomeWatcher?.stopWatch()
        super.onDestroy()
        finish()
    }

}
