package com.greenlightplanet.kazi.feedback.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.greenlightplanet.kazi.feedback.repo.repository.NewTicketFeedbackRepository
import com.greenlightplanet.kazi.feedback.repo.model.request.CreateNewTicketRequest
import com.greenlightplanet.kazi.feedback.repo.model.request.SendRequest
import com.greenlightplanet.kazi.feedback.repo.model.response.ChatData
import com.greenlightplanet.kazi.feedback.repo.model.response.Field
import com.greenlightplanet.kazi.feedback.repo.repository.ChatFeedbackRepository
import com.greenlightplanet.kazi.utils.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ChatFeedbackViewModel @Inject constructor(val repo: ChatFeedbackRepository): ViewModel() {

    private val _chatResponseLiveData = MutableLiveData<NetworkResult<List<ChatData>>>()
    val chatResponseLiveData get() = _chatResponseLiveData

    private val _sendMessageLiveData = MutableLiveData<NetworkResult<Boolean>>()
    val sendMessageLiveData get() = _sendMessageLiveData

    var isClosed = false
    var isPending = false
    var ticketId = ""
    var status = ""

    val allImageUploadedLiveData = MutableLiveData<Boolean>()

    var imageListFromS3 = mutableListOf<String>()

    val currentRvList = mutableListOf<ChatData>()
    var currentChatData: ChatData? = null

    fun invokeConversationData(url: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.getConversationData(url).onEach { result ->
                _chatResponseLiveData.postValue(result)
            }.launchIn(viewModelScope)
        }

    }

    fun invokeSendMessageData(country: String, sendRequest: SendRequest) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.sendChatMessageData(country, sendRequest).onEach { result ->
                _sendMessageLiveData.postValue(result)
            }.launchIn(viewModelScope)
        }

    }




}