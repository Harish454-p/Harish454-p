package com.greenlightplanet.kazi.leads.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.leads.model.LeadsIntent
import com.greenlightplanet.kazi.leads.repo.CustomerLeadsFeedbackRepo

class CustomerLeadsFeedbackViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "CustomerLeadsFeedbackViewModel"

    }

    val repo = CustomerLeadsFeedbackRepo.getInstance(application)

    fun getLeadsIntentFromDb(showProgress: () -> Unit = {}): MutableLiveData<List<LeadsIntent>> {
        showProgress()
        return repo.getLeadsIntentFromDb()
    }

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }
}
