package com.greenlightplanet.kazi.fseProspective.view.fragment


import android.Manifest
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.lifecycle.ViewModelProvider

import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentVerificationBinding
import com.greenlightplanet.kazi.fseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseModel
import com.greenlightplanet.kazi.fseProspective.view.activity.ProspectDetailActivity
import com.greenlightplanet.kazi.fseProspective.view.activity.adapter.VerificationAdapter
import com.greenlightplanet.kazi.fseProspective.view.activity.mapActivity.FseProsMapsActivity
import com.greenlightplanet.kazi.fseProspective.viewmodel.VerificationViewModel


/**
 * A simple [Fragment] subclass.
 *
 */
class VerificationFragment : Fragment(), VerificationAdapter.VerificationAdapterCallback {

	val array = mutableListOf<String>()
    private var _binding: FragmentVerificationBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel : VerificationViewModel
    
	override fun onTapped(position: Int, value: FseProspectResponseModel) {

//        val intent = Intent(activity, VerificationActivity::class.java)
		val intent: Intent = Intent(activity, ProspectDetailActivity::class.java)
        intent.putExtra("data", value)
        startActivity(intent)
        binding.etsearch.text.clear()

    }


    companion object {

        const val TAG = "VerificationFragment"

        fun newInstance(
                //type: Int,
                //user: LoginResponseModel.ResponseData,
                //countryModel: CountryModel,
//                list: List<FseProspectResponseModel>?,
                allowedDistance: Int
        ): VerificationFragment {
            val myFragment = VerificationFragment()

            val args = Bundle()
            //args.putInt("type", type)
            //args.putParcelable("user", user)
            //args.putParcelable("countryModel", countryModel)
//            args.putParcelableArrayList("list", ArrayList(list!!))
            args.putInt("allowedDistance", allowedDistance)
            myFragment.arguments = args

            return myFragment
        }
    }

    var verificationAdapter: VerificationAdapter? = null

    var adapterList: MutableList<FseProspectResponseModel> = mutableListOf()

    private var list: MutableList<FseProspectResponseModel>? = mutableListOf()
    private var allowedDistance: Int = 0
    var rootView: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewModel = ViewModelProvider(this)[VerificationViewModel :: class.java]
        arguments?.let {

            if (it.containsKey("list")) {
                list = it.getParcelableArrayList("list")
            }

            if (it.containsKey("allowedDistance")) {
                allowedDistance = it.getInt("allowedDistance")
            }
        }

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment

//        rootView = inflater.inflate(R.layout.fragment_verification, container, false)
        _binding = FragmentVerificationBinding.inflate(inflater, container, false)

		return binding.root
	}

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.getFseProspectiveFromDatabase().observe(viewLifecycleOwner, Observer { response ->
            when(response) {
                null -> {

                }
                else -> {
                    val mmList = response.responseData!!.prospects!!
                    list =
                        mmList.filter {
                            it.ticketType == FseProspectiveConstant.ProspectiveType.VERIFICATION
                        }.toMutableList()
                    if (!list.isNullOrEmpty()) {
                        binding!!.tvNoData.visibility = View.GONE
                        binding!!.VerRecycler.visibility = View.VISIBLE
                        setAdapter(list!!.toMutableList())
                    } else {
                        binding!!.tvNoData.visibility = View.VISIBLE
                        binding!!.VerRecycler.visibility = View.GONE
                    }
                    val distinct = list?.distinctBy { it.status }
                    array.add(requireContext().getString(R.string.all) ?: "All")
                    distinct?.map { array.add(it.status?.replace("_", " ") ?: "") }
                    setAdapter(binding!!.spinner!!, array.toTypedArray())
                }
            }
        })

        val layoutManager = LinearLayoutManager(activity)

        binding.VerRecycler.layoutManager = layoutManager

//        setAdapter(list!!.toMutableList())
        if (!list.isNullOrEmpty()) {
            binding.tvNoData.visibility = View.GONE
            binding.VerRecycler.visibility = View.VISIBLE
            setAdapter(list!!.toMutableList())
        } else {
            binding.tvNoData.visibility = View.VISIBLE
            binding.VerRecycler.visibility = View.GONE
        }
        binding.btnMap.setOnClickListener {
            if (checkPersmission()) {
                val intent = Intent(activity, FseProsMapsActivity::class.java)
                intent.putExtra("radius", allowedDistance)
                startActivity(intent)
            } else {
                requestPermission()
            }

        }
        watcher()

//        val distinct = list?.distinctBy {it.status }
//        array.add(context?.getString(R.string.all) ?: "All")
//        distinct?.map { array.add(it.status?.replace("_"," ")?:"") }
//        setAdapter(binding.spinner!!, array.toTypedArray())

        clickHandler()
    }

	fun setAdapter(spinner: Spinner, array: Array<String>) {
		val spinnerArrayAdapter = ArrayAdapter<String>(
			requireContext(), R.layout.spinner_item, array
		)
		spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_filter_text)
		spinner.setAdapter(spinnerArrayAdapter)
	}

	private fun clickHandler() {

		binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
			override fun onNothingSelected(p0: AdapterView<*>?) {
				Log.d(TAG, "Nothing selected");

			}


			override fun onItemSelected(adapterView: AdapterView<*>?, view: View?,
										position: Int, id: Long) {
				filterLogic(position,array[position])
			}
		}
	}

	fun filterLogic(position: Int, selectedStatus: String) {
		Log.d(TAG, "filterLogic=> postion:$position || selectedStatus=> $selectedStatus ");
		val filteredList: List<FseProspectResponseModel>? = when (selectedStatus) {
			"PROSPECT" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.PROSPECT }
			}
			"OTP APPROVED" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.OTP_APPROVED }
			}
			"PRE APPROVED PROSPECT" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT }
			}
			"CHECKED IN" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.CHECKED_IN }
			}
			"THREE WAY CALL" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL }
			}
			"INSTALLATION PENDING" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING }
			}
			"INSTALLED" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.INSTALLED }
			}
			"INSTALLATION VERIFIED" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED }
			}
			"INSTALLATION REATTEMPT" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT }
			}
			else -> {
				list
			}
		}

		setAdapter(filteredList!!.toMutableList())
	}


	private val PERMISSION_REQUEST_CODE: Int = 101
    private fun checkPersmission(): Boolean {
        return (ContextCompat.checkSelfPermission(requireActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED)
    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(
                requireActivity(), arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    val intent = Intent(activity, FseProsMapsActivity::class.java)
                    startActivity(intent)
                }
            }
        }
    }


    fun setAdapter(mutableList: MutableList<FseProspectResponseModel>) {
        adapterList.clear()
		val sortedList = mutableList.sortedByDescending { it.prospectUpdatedAtLong }
		adapterList.addAll(sortedList)

        if (verificationAdapter == null) {
            Log.e("|| =inadapter= ", adapterList.toString())
            verificationAdapter = VerificationAdapter(requireActivity(), adapterList)
            verificationAdapter?.verificationAdapterCallback = this
            binding.VerRecycler.adapter = verificationAdapter
        }
        verificationAdapter?.notifyDataSetChanged()

    }

    private var textWatcher = object : TextWatcher {

        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
        override fun afterTextChanged(s: Editable) {

            val searchEOList = list!!.filter {
                val name = "${it.name}"
                name.contains(
                        s.toString(),
                        true
                )
            }.toMutableList()

            val mutablePostList: MutableLiveData<List<FseProspectResponseModel>> = MutableLiveData()

            mutablePostList.value = searchEOList

            mutablePostList.observe(requireActivity(), searchEOObserver)

        }

    }

    val searchEOObserver: Observer<List<FseProspectResponseModel>> = Observer { data ->

        if (data != null) {

            val collectionEoResponse = data

            if (collectionEoResponse.isNullOrEmpty()) {
                binding.tvNoData.visibility = View.VISIBLE
                binding.VerRecycler.visibility = View.GONE
            } else {
                binding.tvNoData.visibility = View.GONE
                binding.VerRecycler.visibility = View.VISIBLE
            }

            collectionEoResponse.let {

                setAdapter(data.toMutableList())
                Log.e("|| =data= ", data.toString())
                watcher()
            }
        } else {
            Log.e("|| No data= ", "NNNOOO")
        }

    }

    fun watcher() {
        binding.etsearch.removeTextChangedListener(textWatcher)
        binding.etsearch.addTextChangedListener(textWatcher)
    }
}
