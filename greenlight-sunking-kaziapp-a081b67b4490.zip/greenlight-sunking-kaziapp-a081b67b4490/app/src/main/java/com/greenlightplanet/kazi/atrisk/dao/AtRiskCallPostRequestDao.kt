package com.greenlightplanet.kazi.atrisk.dao

import androidx.room.*
import com.greenlightplanet.kazi.atrisk.model.AtRiskCall
import com.greenlightplanet.kazi.summary.model.post.SummaryCall
import io.reactivex.Single

@Dao
interface AtRiskCallPostRequestDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(call: List<AtRiskCall>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(call: AtRiskCall): Long

    @Delete
    fun delete(call: AtRiskCall): Int

    @Query("DELETE FROM AtRiskCall")
    fun deleteAll(): Int

    @Query("SELECT * FROM AtRiskCall")
    fun getAll(): Single<List<AtRiskCall>>

    @Query("SELECT * FROM AtRiskCall LIMIT 1")
    fun get(): Single<AtRiskCall>

    @Query("SELECT COUNT(*) from AtRiskCall")
    fun count(): Int

}
