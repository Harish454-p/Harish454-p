package com.greenlightplanet.kazi.fseProspective.view.activity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.DrawableCompat
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import androidx.appcompat.content.res.AppCompatResources
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.google.android.gms.location.LocationRequest
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityProspectDetailBinding
import com.greenlightplanet.kazi.fseProspective.extras.AmazonS3Helper
import com.greenlightplanet.kazi.fseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.fseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.fseProspective.model.*
import com.greenlightplanet.kazi.fseProspective.view.activity.checkInMap.CheckInMapActivity
import com.greenlightplanet.kazi.fseProspective.viewmodel.ProspectDetailViewModel
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.Constants
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import com.jama.carouselview.CarouselScrollListener
import com.jama.carouselview.enums.IndicatorAnimationType
import com.jama.carouselview.enums.OffsetType
import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import pl.charmas.android.reactivelocation2.ReactiveLocationProvider
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

class ProspectDetailActivity : BaseActivity(), AmazonS3Helper.AmazonS3HelperCallback {

    companion object {
        val TAG = "ProspectDetailActivity"
    }

    //all
    var fseProspectResponseModel: FseProspectResponseModel? = null
    var loginResponseData: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    lateinit var viewModel: ProspectDetailViewModel
    var mHomeWatcher: HomeWatcher? = null

    //verification
    var otpApprovalRequestModel: OtpApprovalRequestModel? = null

    //registration
    var registrationCheckinRequestModel: RegistrationCheckinRequestModel? = null
    var checkInAccuracy: Double? = null
    private val REGISTRATION_PERMISSION_REQUEST_CODE: Int = 102

    //installation
    var amazonS3Helper: AmazonS3Helper? = AmazonS3Helper(this)
    var installationRequestModel: InstallationRequestModel? = null
    var circularProgressDrawable: CircularProgressDrawable? = null
    var currentLocation: Location? = null
    private val bag: CompositeDisposable = CompositeDisposable()
    var imageList: MutableList<String> = mutableListOf()
    var productNameList: MutableList<String> = mutableListOf()

    private val REQUEST_CAMERA: Int = 110
    private val INSTALLATION_PERMISSION_REQUEST_CODE: Int = 101
    private var outputImgUri: String? = null
    private lateinit var binding: ActivityProspectDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_prospect_detail)
        binding = ActivityProspectDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        Util.setToolbar(this, toolbar)
        preference = GreenLightPreference.getInstance(this)
        loginResponseData = preference?.getLoginResponseModel()
        checkInAccuracy = preference?.getCheckInAccuracy()?.toDouble()

        viewModel = ViewModelProviders.of(this).get(ProspectDetailViewModel::class.java)
        circularProgressDrawable = CircularProgressDrawable(this)
        binding.tvAppBottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        binding.tvLastSavedDetails.text = "${getString(R.string.last_saved_key)} ${preference?.getFseProspectLastSynced()}"

        initializeExtras()
        initialize()
        clickHandlerVerification()
        clickHandlerRegistration()
        clickHandlerInstallation()

        fseProspectResponseModel?.let {
            generalClickHandler(it.ticketType, it)
        }


        Log.d(TAG, "Country: ${preference!!.getLoginResponseModel()!!.country}")

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }

    private fun initializeExtras() {
        if (intent.hasExtra("data")) {
            fseProspectResponseModel = intent.getParcelableExtra("data")
        }
    }

    fun initialize() {
        amazonS3Helper?.initializer()
        amazonS3Helper?.amazonS3HelperCallback = this
        fseProspectResponseModel?.let {
            setUI(it.ticketType, it)
        }
    }

    private fun setUI(type: String?, fseProspectResponseModel: FseProspectResponseModel) {

        binding.otpView.visibility = View.GONE
        binding.SubmitOk.visibility = View.GONE
        binding.btnCheckIn.visibility = View.GONE
        binding.tvStep1.visibility = View.GONE
//        imageView.visibility = View.GONE
        binding.tvLastSavedDetails.text =
            "${getString(R.string.last_saved_key)} ${preference?.getFseProspectLastSynced()}"
        when (type) {

            FseProspectiveConstant.ProspectiveType.VERIFICATION -> {
                binding.toolbarTitle.text = "Verification"
                setValueVerification(fseProspectResponseModel)
            }

            FseProspectiveConstant.ProspectiveType.REGISTRATION -> {
                binding.toolbarTitle.text = "Registration"
                setValueRegistration(fseProspectResponseModel)
            }

            FseProspectiveConstant.ProspectiveType.INSTALLATION -> {
                binding.toolbarTitle.text = "Installation"
                setValueInstallation(fseProspectResponseModel)
            }

            else -> {
                binding.toolbarTitle.text = "Verification"
                setValueVerification(fseProspectResponseModel)
            }
        }
    }

    private fun generalClickHandler(
        type: String?,
        fseProspectResponseModel: FseProspectResponseModel
    ) {
        binding.ivSync.setOnClickListener {
            when (type) {
                FseProspectiveConstant.ProspectiveType.VERIFICATION -> {
                    verificationSync()
                }
                FseProspectiveConstant.ProspectiveType.REGISTRATION -> {
                    registrationSync()
                }
                FseProspectiveConstant.ProspectiveType.INSTALLATION -> {
                    installationSync()
                }
                else -> {
                    verificationSync()
                }
            }
        }

    }

    //region start Verification
    private fun setValueVerification(fseProspectResponseModel: FseProspectResponseModel) {

        binding.toolbarTitle.text = "Verification"


        binding.tvCustomerName.text = fseProspectResponseModel.name
        binding.tvCustomerAddress.text = fseProspectResponseModel.customerAddress
        binding.tvPhoneNumber.text = fseProspectResponseModel.customerPhoneNumber
        binding.tvProspectID.text = fseProspectResponseModel.prospectId
        binding.tvAccountNumberID.text = fseProspectResponseModel.accountNumber ?: ""
        binding.llAccountNumberID.visibility = View.GONE
        binding.llProspectID.visibility = View.VISIBLE
//        if (fseProspectResponseModel.status == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL || fseProspectResponseModel.status == FseProspectiveConstant.ProspectStatus.PROSPECT) {
//            binding.llAccountNumberID.visibility = View.GONE
//            binding.llProspectID.visibility = View.VISIBLE
//        } else {
//            binding.llAccountNumberID.visibility = View.VISIBLE
//            binding.llProspectID.visibility = View.GONE
//        }
        alphaMethodVerification(fseProspectResponseModel)
        if (!(fseProspectResponseModel.statusUpdateTime?.otpApproved.isNullOrBlank())) {
            binding.otpView.visibility = View.GONE
            binding.SubmitOk.visibility = View.GONE
        } else {
            binding.otpView.visibility = View.VISIBLE
            binding.SubmitOk.visibility = View.VISIBLE
        }
        setProspectProgressVerification(fseProspectResponseModel.statusUpdateTime)
    }

    private fun clickHandlerVerification() {
        binding.SubmitOk.setOnClickListener {
            Log.d(TAG, "Otp-Entered: ${binding.otpView?.text.toString()}")
            if (binding.otpView.text.isNullOrBlank()) {
                Toast.makeText(this, "Please enter OTP", Toast.LENGTH_SHORT).show()
            } else {
                validateVerification(this@ProspectDetailActivity, binding.otpView?.text.toString())
            }
        }
//		ivSync.setOnClickListener {
//			verificationSync()
//		}
    }

    fun verificationSync() {
        if (Util.isOnline(this@ProspectDetailActivity)) {
            if ((otpApprovalRequestModel != null) && fseProspectResponseModel!!.isChanged) {
                //you have data to sync
                viewModel.sendOtpApprovalToServerForceUpload((!otpApprovalRequestModel!!.otpVerificationTime.isNullOrBlank()),
                    otpApprovalRequestModel!!,
                    showProgress = {
                        showProgressDialog(this)
                    }).observe(this, Observer {
                    refreshVerification()
                })
            } else {
                //you don't have data to sync
//                    Util.showToast("Sync not required", this)
                refreshVerification()
            }
        } else {
//                Util.showToast("No Internet", this)
            Util.customFseRationaleDialog(this, "",
                hideNegative = true,
                titleSpanned = null,
                hideTitle = true,
                message = "Please check internet connection",
                positveSelected = {
                    it.dismiss()
                },
                negativeSeleted = {
                    it.dismiss()
                }
            )
        }
    }

    private fun alphaMethodVerification(fseProspectResponseModel: FseProspectResponseModel) {
        viewModel.getCombineRequestModelVerification(fseProspectResponseModel.prospectId)
            .observe(this, Observer {
                it?.fseProspectResponseModel?.let {
                    this.fseProspectResponseModel = it
                    Log.d(TAG, "it-isChanged:${it} ")
                }
                if ((it?.otpApprovalRequestModel == null) && !(this.fseProspectResponseModel!!.isChanged)) {
                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                    binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                } else {
                    otpApprovalRequestModel = it?.otpApprovalRequestModel
                    if (this.fseProspectResponseModel!!.isChanged) {
                        val backgroundDrawable =
                            ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                        DrawableCompat.setTint(backgroundDrawable!!, Color.RED)
                        binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                    } else {
                        val backgroundDrawable =
                            ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                        DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                        binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                    }
                    if (!it?.otpApprovalRequestModel?.otpVerificationTime.isNullOrEmpty()) {
                        binding.imgOtp.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.double_check
                            )
                        )
                        binding.tvOTPDate.text =
                            Util.fseUiDateFormatter(it!!.otpApprovalRequestModel?.otpVerificationTime!!)
                        binding.otpView.visibility = View.GONE
                        binding.SubmitOk.visibility = View.GONE
                    }
                }
                it?.fseError?.let {
                    if (this.fseProspectResponseModel!!.errorOccurred && (it.errorType == FseProspectiveConstant.ProspectiveType.VERIFICATION)) {
                        binding.llError.visibility = View.VISIBLE
                        binding.tvErrorMessage.text = it.messageToUser
                    }
                }
            })
    }

    private fun setProspectProgressVerification(statusUpdateTime: FseProspectResponseModel.StatusUpdateTime?) {
        if (!statusUpdateTime?.prospect.isNullOrEmpty()) {
            binding.tvProspectDate.text = Util.fseUiDateFormatter(statusUpdateTime!!.prospect!!)
            //binding.tvProspectDate.text = statusUpdateTime?.prospect
            //binding.imgProspect
            //binding.imgProspect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
            if (!fseProspectResponseModel!!.approved) {
                if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.PROSPECT) {
                    binding.imgProspect.setImageDrawable(
                        ContextCompat.getDrawable(
                            this,
                            R.drawable.ic_cancel
                        )
                    )
                    binding.otpView.visibility = View.GONE
                    binding.SubmitOk.visibility = View.GONE
                    binding.imgProspect.setOnClickListener {
                        errorMessage(fseProspectResponseModel!!)
                    }
                } else {
                    binding.imgProspect.setImageDrawable(
                        ContextCompat.getDrawable(
                            this,
                            R.drawable.double_check
                        )
                    )
                }
            } else {
                binding.imgProspect.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            }
        } else {
            binding.tvProspectDate.text = ""
            binding.imgProspect.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.exclamation_mark
                )
            )
        }
        if (!statusUpdateTime?.otpApproved.isNullOrEmpty()) {
//            binding.tvOTPDate.text = statusUpdateTime?.otpApproval
            binding.tvOTPDate.text = Util.fseUiDateFormatter(statusUpdateTime!!.otpApproved!!)
            if (!statusUpdateTime.otpApproved.isNullOrEmpty()) {
                binding.tvOTPDate.text = Util.fseUiDateFormatter(statusUpdateTime.otpApproved!!)
                //binding.imgOtp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                if (!fseProspectResponseModel!!.approved) {
                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.OTP_APPROVED) {
                        binding.imgOtp.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.ic_cancel
                            )
                        )
                        binding.otpView.visibility = View.GONE
                        binding.SubmitOk.visibility = View.GONE
                        binding.imgOtp.setOnClickListener {
                            errorMessage(fseProspectResponseModel!!)
                        }
                    } else {
                        binding.imgOtp.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.double_check
                            )
                        )
                    }
                } else {
                    binding.imgOtp.setImageDrawable(
                        ContextCompat.getDrawable(
                            this,
                            R.drawable.double_check
                        )
                    )
                }
            } else {
                binding.tvOTPDate.text = ""
                binding.imgOtp.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime.preApprovedProspect.isNullOrEmpty()) {
//            binding.tvPreApprovedDate.text = statusUpdateTime?.preApprovedProspect
                binding.tvPreApprovedDate.text =
                    Util.fseUiDateFormatter(statusUpdateTime.preApprovedProspect!!)
                //binding.imgPreApproved
                binding.imgPreApproved.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvPreApprovedDate.text = ""
                binding.imgPreApproved.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime.checkedIn.isNullOrEmpty()) {
//            binding.tvCheckedInDate.text = statusUpdateTime?.checkedIn
                binding.tvCheckedInDate.text = Util.fseUiDateFormatter(statusUpdateTime.checkedIn!!)
                //binding.imgCheckedIn
                binding.imgCheckedIn.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvCheckedInDate.text = ""
                binding.imgCheckedIn.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime.installed.isNullOrEmpty()) {
//            binding.tvInstallPendDate.text = statusUpdateTime?.installationPending
                binding.tvInstallPendDate.text =
                    Util.fseUiDateFormatter(statusUpdateTime.installed!!)
                //binding.imgIstallationP
                binding.imgIstallationP.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvInstallPendDate.text = ""
                binding.imgIstallationP.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime.installationVerified.isNullOrEmpty()) {
//            binding.tvInstallCompleteDate.text = statusUpdateTime?.installed
                binding.tvInstallCompleteDate.text =
                    Util.fseUiDateFormatter(statusUpdateTime.installationVerified!!)
                //binding.imgInstallComplete
                binding.imgInstallComplete.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvInstallCompleteDate.text = ""
                binding.imgInstallComplete.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime.threeWayCallVerification.isNullOrEmpty()) {
                binding.tvCCverif.text =
                    Util.fseUiDateFormatter(statusUpdateTime.threeWayCallVerification!!)
                //binding.imgInstallComplete
                binding.imgCCVerif.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvCCverif.text = ""
                binding.imgCCVerif.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
        }
    }

    private fun validateVerification(context: Context, enteredOtp: String) {
        val isValid = isValidOtp(enteredOtp)
        val isOnline = Util.isOnline(context)
        viewModel.processOtp(
            context = context,
            isOnline = isOnline,
            isValid = isValid,
            prospectID = fseProspectResponseModel?.prospectId!!,
            angazaId = loginResponseData?.angazaId!!,
            unsuccessfulAttempt = fseProspectResponseModel?.unsuccessfulOtpAttempts!!,
            country = preference!!.getLoginResponseModel()!!.country!!,
            showProgress = {
                showProgressDialog(context)
            }
        )?.observe(this, Observer {
            cancelProgressDialog()
            //Util.showToast("Completed Otp", this)
            //if (isOnline && isValid) {
            if (it!!.success) {
                if (isValid) {//going to change in feature
                    Util.customFseCompletionDialog(
                        context = this,
                        title = "OTP Verified",
                        message = "Please proceed to Check-In after 5 minutes.",
                        okSelected = {
                            it.dismiss()
                            //backpress //add your addditional logic here
                            //this@ProspectDetailActivity.onBackPressed()
                            //new added
                            if (Util.isOnline(this)) {

                            }
                        })
                }
            } else {
                Util.showToast("Unknown error occurred", this)
            }
            alphaMethodVerification(fseProspectResponseModel!!)
            //do further process after integrating with live/dev api
        })
        if (isValid.not()) {
            Util.customFseCompletionDialog(
                context = this,
                hideTitle = true,
                title = null,
                message = "Invalid OTP",
                okSelected = {
                    it.dismiss()
                    binding.otpView.text?.clear()
                }
            )
        }
    }

    fun refreshVerification() {
        viewModel.getFseProspectiveFromServerVerification(
            loginResponseData!!.angazaId!!,
            fseProspectResponseModel!!.prospectId
        )?.observe(this, Observer {
            if (it != null) {
                if ((it.success) && (it.responseData != null)) {
                    //setValueVerification(it.responseData!!)
                    setUI(it.responseData!!.ticketType, it.responseData!!)
                } else {
                    alphaMethodVerification(fseProspectResponseModel!!)
                }
            } else {
                alphaMethodVerification(fseProspectResponseModel!!)
            }
            cancelProgressDialog()
        })
    }

    private fun errorMessage(fseProspectResponseModel: FseProspectResponseModel) {
        Util.customFseCompletionDialog(
            context = this,
            hideTitle = true,
            title = null,
            message = fseProspectResponseModel.message,
            okSelected = {
                it.dismiss()
            }
        )
    }

    private fun isValidOtp(enteredOtp: String): Boolean {
        return enteredOtp == fseProspectResponseModel?.otp!!
    }
    //endregion Verification

    //region start Registration
    private fun clickHandlerRegistration() {
        binding.btnCheckIn.setOnClickListener {
            preference!!.setProspectAllowedDistance(fseProspectResponseModel!!.prospectAllowedDistance)
            if (checkPersmissionRegistration()) {
                if (!Util.enableGPSIfPossible(ProspectDetailActivity@ this)) {
                    startActivityForResult(Intent(this, CheckInMapActivity::class.java), 1109)
                }
            } else {
                requestPermissionRegistration()
            }
        }
//		ivSync.setOnClickListener {
//			registrationSync()
//		}
    }

    fun registrationSync() {
        if (Util.isOnline(this@ProspectDetailActivity)) {
            if ((registrationCheckinRequestModel != null) && fseProspectResponseModel!!.isChanged) {
                //you have data to sync
                viewModel.sendRegistrationCheckinRequestToServerForceUpload(
                    registrationCheckinRequestModel = registrationCheckinRequestModel!!,
                    showProgress = {
                        showProgressDialog(this)
                    }).observe(this, Observer {
                    refreshRegistration()
                })
            } else {
                refreshRegistration()
            }
        } else {
            Util.customFseRationaleDialog(this, "",
                hideNegative = true,
                titleSpanned = null,
                hideTitle = true,
                message = "Please Check your Internet",
                positveSelected = {
                    it.dismiss()
                },
                negativeSeleted = {
                    it.dismiss()
                }
            )
        }
    }

    fun refreshRegistration() {
        viewModel.getFseProspectiveFromServerRegistration(
            loginResponseData!!.angazaId!!,
            fseProspectResponseModel!!.prospectId
        )?.observe(this, Observer {
            Log.d(TAG, "it-getFseProspectiveFromServer-01:${it} ")
            if (it != null) {
                if ((it.success) && (it.responseData != null)) {
                    //setValueRegistration(it.responseData!!)
                    setUI(it.responseData!!.ticketType, it.responseData!!)
                } else {
                    alphaMethodRegistration(fseProspectResponseModel!!)
                }
            } else {
                alphaMethodRegistration(fseProspectResponseModel!!)
            }
            cancelProgressDialog()
        })
    }

    private fun setValueRegistration(fseProspectResponseModel: FseProspectResponseModel) {
        binding.tvCustomerName.text = fseProspectResponseModel.name
        binding.tvCustomerAddress.text = fseProspectResponseModel.customerAddress
        binding.tvPhoneNumber.text = fseProspectResponseModel.customerPhoneNumber
        binding.tvProspectID.text = fseProspectResponseModel.prospectId
        binding.tvAccountNumberID.text = fseProspectResponseModel.accountNumber ?: ""
        binding.llAccountNumberID.visibility = View.GONE
        binding.llProspectID.visibility = View.VISIBLE
        setProspectProgressRegistration(fseProspectResponseModel.statusUpdateTime)
//        if (fseProspectResponseModel.status == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL || fseProspectResponseModel.status == FseProspectiveConstant.ProspectStatus.PROSPECT) {
//            binding.llAccountNumberID.visibility = View.GONE
//            binding.llProspectID.visibility = View.VISIBLE
//        } else {
//            binding.llAccountNumberID.visibility = View.VISIBLE
//            binding.llProspectID.visibility = View.GONE
//        }
        alphaMethodRegistration(fseProspectResponseModel)
    }

    private fun alphaMethodRegistration(fseProspectResponseModel: FseProspectResponseModel) {
        viewModel.getCombineRequestModelRegistration(fseProspectResponseModel.prospectId)
            .observe(this, Observer {
                Log.d(TAG, " getCombineRequestModel:$it ")
                it?.fseProspectResponseModel?.let {
                    this.fseProspectResponseModel = it
                    if (!(it.statusUpdateTime?.checkedIn.isNullOrBlank())) {
                        binding.btnCheckIn.visibility = View.GONE
                        binding.tvCheckedInDate.text =
                            Util.fseUiDateFormatter(it.statusUpdateTime?.checkedIn!!)
                        //binding.imgCheckedIn
                        //binding.imgCheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                        if (!it.approved) {
                            if (it.status == FseProspectiveConstant.ProspectStatus.CHECKED_IN) {
                                binding.imgCheckedIn.setImageDrawable(
                                    ContextCompat.getDrawable(
                                        this,
                                        R.drawable.ic_cancel
                                    )
                                )
                                binding.imgCheckedIn.setOnClickListener {
                                    errorMessage(this.fseProspectResponseModel!!)
                                }
                            } else {
                                binding.imgCheckedIn.setImageDrawable(
                                    ContextCompat.getDrawable(
                                        this,
                                        R.drawable.double_check
                                    )
                                )
                            }
                        } else {
                            binding.imgCheckedIn.setImageDrawable(
                                ContextCompat.getDrawable(
                                    this,
                                    R.drawable.double_check
                                )
                            )
                        }
                    } else {
//					binding.btnCheckIn.visibility = View.VISIBLE
                        if (!it.approved) {
                            binding.btnCheckIn.visibility = View.GONE
                        } else {
                            binding.btnCheckIn.visibility = View.VISIBLE
                        }
                    }
                }
                if (it?.registrationCheckinRequestModel == null) {
                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                    binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                } else {
                    registrationCheckinRequestModel = it.registrationCheckinRequestModel
                    if (this.fseProspectResponseModel!!.isChanged) {
                        val backgroundDrawable =
                            ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                        DrawableCompat.setTint(backgroundDrawable!!, Color.RED)
                        binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                    } else {
                        val backgroundDrawable =
                            ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                        DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                        binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                    }
//				binding.btnCheckIn.visibility = View.GONE
                }
                it?.fseError?.let {
                    Log.d(TAG, " it?.fseError? :${this.fseProspectResponseModel!!.errorOccurred} ")
                    if (this.fseProspectResponseModel!!.errorOccurred && (it.errorType == FseProspectiveConstant.ProspectiveType.REGISTRATION)) {
                        binding.llError.visibility = View.VISIBLE
                        binding.tvErrorMessage.text = it.messageToUser
                    }
                }
            })
    }

    private fun setProspectProgressRegistration(statusUpdateTime: FseProspectResponseModel.StatusUpdateTime?) {
        if (!statusUpdateTime?.prospect.isNullOrEmpty()) {
//            binding.tvProspectDate.text = statusUpdateTime?.prospect
            binding.tvProspectDate.text = Util.fseUiDateFormatter(statusUpdateTime?.prospect!!)
            binding.imgProspect.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.double_check
                )
            )
        } else {
            binding.tvProspectDate.text = ""
            binding.imgProspect.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.exclamation_mark
                )
            )
        }
        if (!statusUpdateTime?.otpApproved.isNullOrEmpty()) {
            binding.tvOTPDate.text = statusUpdateTime?.otpApproved
            if (!statusUpdateTime?.otpApproved.isNullOrEmpty()) {
//            binding.tvOTPDate.text = statusUpdateTime?.otpApproval
                binding.tvOTPDate.text = Util.fseUiDateFormatter(statusUpdateTime?.otpApproved!!)
                binding.imgOtp.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvOTPDate.text = ""
                binding.imgOtp.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime?.preApprovedProspect.isNullOrEmpty()) {
                binding.tvPreApprovedDate.text =
                    Util.fseUiDateFormatter(statusUpdateTime!!.preApprovedProspect!!)
//            binding.tvPreApprovedDate.text = statusUpdateTime?.preApprovedProspect
                //binding.imgPreApproved
                //binding.imgPreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                if (!fseProspectResponseModel!!.approved) {
                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT) {
                        binding.imgPreApproved.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.ic_cancel
                            )
                        )
                        binding.btnCheckIn.visibility = View.GONE
                        binding.imgPreApproved.setOnClickListener {
                            errorMessage(fseProspectResponseModel!!)
                        }
                    } else {
                        binding.imgPreApproved.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.double_check
                            )
                        )
                    }
                } else {
                    binding.imgPreApproved.setImageDrawable(
                        ContextCompat.getDrawable(
                            this,
                            R.drawable.double_check
                        )
                    )
                }
            } else {
                binding.tvPreApprovedDate.text = ""
                binding.imgPreApproved.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime?.checkedIn.isNullOrEmpty()) {
//            binding.tvCheckedInDate.text = statusUpdateTime?.checkedIn
                binding.tvCheckedInDate.text =
                    Util.fseUiDateFormatter(statusUpdateTime?.checkedIn!!)
                //binding.imgCheckedIn
                //binding.imgCheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                if (!fseProspectResponseModel!!.approved) {
                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.CHECKED_IN) {
                        binding.imgCheckedIn.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.ic_cancel
                            )
                        )
                        binding.btnCheckIn.visibility = View.GONE
                        binding.imgCheckedIn.setOnClickListener {
                            errorMessage(fseProspectResponseModel!!)
                        }
                    } else {
                        binding.imgCheckedIn.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.double_check
                            )
                        )
                    }
                } else {
                    binding.imgCheckedIn.setImageDrawable(
                        ContextCompat.getDrawable(
                            this,
                            R.drawable.double_check
                        )
                    )
                }
            } else {
                binding.tvCheckedInDate.text = ""
                binding.imgCheckedIn.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime?.threeWayCallVerification.isNullOrEmpty()) {
//            binding.tvCCverif.text = statusUpdateTime?.threeWayCallVerificationx
                binding.tvCCverif.text =
                    Util.fseUiDateFormatter(statusUpdateTime?.threeWayCallVerification!!)
                //binding.imgCheckedIn
                //binding.imgCheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                if (!fseProspectResponseModel!!.approved) {
                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL) {
                        binding.imgCCVerif.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.ic_cancel
                            )
                        )
                        binding.btnCheckIn.visibility = View.GONE
                        binding.imgCCVerif.setOnClickListener {
                            errorMessage(fseProspectResponseModel!!)
                        }
                    } else {
                        binding.imgCCVerif.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.double_check
                            )
                        )
                    }
                } else {
                    binding.imgCCVerif.setImageDrawable(
                        ContextCompat.getDrawable(
                            this,
                            R.drawable.double_check
                        )
                    )
                }
            } else {
                binding.tvCCverif.text = ""
                binding.imgCCVerif.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime?.installed.isNullOrEmpty()) {
//            binding.tvInstallPendDate.text = statusUpdateTime?.installationPending
                binding.tvInstallPendDate.text =
                    Util.fseUiDateFormatter(statusUpdateTime?.installed!!)
                //binding.imgIstallationP
                binding.imgIstallationP.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvInstallPendDate.text = ""
                binding.imgIstallationP.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime?.installationVerified.isNullOrEmpty()) {
                binding.tvInstallCompleteDate.text =
                    Util.fseUiDateFormatter(statusUpdateTime?.installationVerified!!)
                //binding.imgInstallComplete
                binding.imgInstallComplete.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvInstallCompleteDate.text = ""
                binding.imgInstallComplete.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Constants.CLICK_REQUEST_CODE) {
            var bundle = Bundle()
            bundle = data!!.extras!!
            fseProspectResponseModel = bundle.getParcelable("fseProspectResponseModel")!!
            Log.e(TAG, "onActivityResult = = ===${fseProspectResponseModel!!.statusUpdateTime}")
            if (Util.isOnline(this)) {
                refreshInstallation()
            } else {
                alphaMethodInstallation(fseProspectResponseModel!!)
            }
        }
        if (requestCode == 1109) {
            if (resultCode == Activity.RESULT_OK) {
                val location = data?.getParcelableExtra<Location>("location_result")
                if (location != null) {
                    if (location.accuracy < checkInAccuracy!!) {
                        processCheckInRegistration(
                            this@ProspectDetailActivity,
                            Util.isOnline(this@ProspectDetailActivity),
                            fseProspectResponseModel!!,
                            location
                        )
                    } else {
                        showLowAccuracyDialogRegistration(location)
                    }
                } else {
                    Util.customFseCompletionDialog(
                        context = this,
                        hideTitle = true,
                        message = "Accuracy not detected\nPlease Check-In again",
                        okSelected = {
                            it.dismiss()
                            //upload image
                        },
                        title = null
                    )
                }
            } else if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
            }
        }
    }

    private fun processCheckInRegistration(
        context: Context,
        isOnline: Boolean,
        fseProspectResponseModel: FseProspectResponseModel,
        location: Location
    ) {
        viewModel.processCheckIn2(
            context = context,
            isOnline = isOnline,
            prospectID = fseProspectResponseModel.prospectId,
            angazaId = loginResponseData!!.angazaId!!,
            area = fseProspectResponseModel.area,
            location = location,
            prospectAllowedDistance = fseProspectResponseModel.prospectAllowedDistance,
            showProgress = {
                showProgressDialog(context)
            }
        )?.observe(this, Observer {
            cancelProgressDialog()
            alphaMethodRegistration(fseProspectResponseModel)
            if (it!!.success) {
                Util.customFseCompletionDialog(
                    context = this,
                    title = "Check-In Successful",
                    //message = "Check-In done successfully.\n\nPlease start the installation process after Call center verification.",
                    message = " Please wait for call center verification and then proceed for angaza customer activation",
                    okSelected = {
                        it.dismiss()
                        //backpress //add your addditional logic here
//						this@ProspectDetailActivity.onBackPressed()
                        //new added
                        if (Util.isOnline(this)) {
                            refreshRegistration()
                        }
                    })

            } else {
                if (it.error?.code == 1001) {
                    Util.customFseCompletionDialog(
                        context = this,
                        hideTitle = true,
                        title = null,
                        message = "Your Check-In has failed the distance criteria check.\n" +
                                "This Prospect will now be re-assigned. Please contact your ABM",
                        okSelected = {
                            it.dismiss()
                            //backpress //add your addditional logic here
                            this@ProspectDetailActivity.onBackPressed()
                        })
                } else {
//                    Util.showToast("Unable to send registration to the server", this)
                    Util.customFseRationaleDialog(this, "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = "Unable to send registration to the server",
                        positveSelected = {
                            it.dismiss()
                        },
                        negativeSeleted = {
                            it.dismiss()
                        }
                    )
                }
            }
        })
    }

    private fun checkPersmissionRegistration(): Boolean {
        return (ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED)
    }


    private fun requestPermissionRegistration() {
        ActivityCompat.requestPermissions(
            this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            REGISTRATION_PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REGISTRATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (!Util.enableGPSIfPossible(ProspectDetailActivity@ this)) {
                        startActivityForResult(Intent(this, CheckInMapActivity::class.java), 1109)
                    }
                }
            }
            INSTALLATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && grantResults[1] == PackageManager.PERMISSION_GRANTED
                    && grantResults[2] == PackageManager.PERMISSION_GRANTED
                ) {
                    if (!Util.enableGPSIfPossible(ProspectDetailActivity@ this)) {
                        takePicture()
                    }
                }
            }
        }
    }

    private fun showLowAccuracyDialogRegistration(location: Location) {
        val title = "Accuracy is Low"
        val spannable = SpannableString(title)
        spannable.setSpan(
            StyleSpan(Typeface.BOLD),
            0, title.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        Util.customFseCompletionDialog(
            context = this,
            hideTitle = false,
            message = "Please click Check-In again for better results.",
            titleSpanned = spannable,
            okSelected = {
                it.dismiss()
                //upload image
                //bag.clear()
            },
            title = null
        )
    }
    //endregion

    //region start Installation
    private fun clickHandlerInstallation() {
        binding.tvStep1.setOnClickListener {
            if (!fseProspectResponseModel!!.sampleImages.isNullOrEmpty()) {
                val intent = Intent(this, ClickImagesOldFseActivity::class.java)
                intent.putExtra("prospectId", fseProspectResponseModel!!.prospectId)
                startActivityForResult(intent, Constants.CLICK_REQUEST_CODE)
            } else {
                Util.showToast(this, "No data available")
            }

        }

//        imageView.setOnClickListener {
//            Util.CustomLeaderImageDialog(this, imageView.drawable)
//        }

    }

    private fun loadImageForOffline(installPics: List<FseProspectResponseModel.InstallationPictures>) {
        if (Util.isOnline(this)) {
            for (ins in installPics) {
                if (!ins.sampleimage.isNullOrBlank()) {
                    GlobalScope.launch { // launch a new coroutine in background and continue
                        try {
                            Glide.with(this@ProspectDetailActivity)
                                .downloadOnly()
                                .diskCacheStrategy(DiskCacheStrategy.DATA) // Cache resource before it's decoded
                                .load(ins.sampleimage)
                                .submit(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL)
                                .get() // Called on background thread
                        } catch (e: Exception) {
                            Log.d(TAG, "RAJIV - 3: ${e.localizedMessage}")
                            e.printStackTrace()
                        }
                    }

                    Log.e(TAG, "====done====${ins.sampleimage}")
                }
            }
        }
    }


    private fun installationSync() {
        if (Util.isOnline(this)) {
            if ((installationRequestModel != null) && fseProspectResponseModel!!.isChanged) {
                //you have data to sync
                viewModel.getAllAwsImageModelByProspectId(fseProspectResponseModel!!.prospectId)
                    .observe(this, Observer { awsModels ->

                        Log.e(TAG, "abc2: $awsModels")
                        val validToUpload = awsModels?.filter {
                            !it.uploadedToAws &&
                                    !it.uploadedToGLPServer &&
                                    !it.fileUri.isNullOrEmpty()
                        }
                        if (!validToUpload.isNullOrEmpty()) {
                            showProgressDialog(this)
                            awsImageUploadHandler(validToUpload, true)
                        } else {
                            viewModel.sendInstallationRequestToServerForce(
                                installationRequestModel!!,
                                validToUpload!!,
                                showProgress = {
                                    showProgressDialog(this)
                                }).observe(this, Observer {
//                                    cancelProgressDialog()
                                refreshInstallation()
                            })
                        }
                    })
            } else {
                refreshInstallation()
            }
        } else {
            //Util.showToast("No Internet", this)
            Util.customFseRationaleDialog(this, "",
                hideNegative = true,
                titleSpanned = null,
                hideTitle = true,
                message = "Please check internet connection",
                positveSelected = {
                    it.dismiss()
                },
                negativeSeleted = {
                    it.dismiss()
                }
            )
        }
    }


    private fun setValueInstallation(fseProspectResponseModel: FseProspectResponseModel) {
        val createdList: MutableList<FseProspectResponseModel.InstallationPictures> =
            mutableListOf()
        circularProgressDrawable?.strokeWidth = 5f
        circularProgressDrawable?.centerRadius = 30f
        circularProgressDrawable?.start()

        if (fseProspectResponseModel.installationPictures.isNullOrEmpty()) {
            fseProspectResponseModel.sampleImages!!.forEach {
                createdList.add(
                    FseProspectResponseModel.InstallationPictures(
                        name = it.name,
                        sampleimage = it.url,
                        phoneUrl = "",
                        isRejected = false,
                        isNewImage = false,
                        attempt = 0,
                        url = ""
                    )
                )
            }
            fseProspectResponseModel.installationPictures = createdList
        }
//        runOnUiThread {
        // Here, use glide or do your things on UiThread
        loadImageForOffline(fseProspectResponseModel.installationPictures!!)
//        }


        binding.tvCustomerName.text = fseProspectResponseModel.name
        binding.tvCustomerAddress.text = fseProspectResponseModel.customerAddress//not available
        binding.tvAccountNo.text = fseProspectResponseModel.accountNumber
        binding.tvPhoneNumber.text = fseProspectResponseModel.customerPhoneNumber
        binding.tvProspectID.text = fseProspectResponseModel.prospectId
        binding.tvAccountNumberID.text = fseProspectResponseModel.accountNumber ?: ""
//        if (fseProspectResponseModel.status == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL || fseProspectResponseModel.status == FseProspectiveConstant.ProspectStatus.PROSPECT) {
//            binding.llAccountNumberID.visibility = View.GONE
//            binding.llProspectID.visibility = View.VISIBLE
//        } else {
        binding.llAccountNumberID.visibility = View.VISIBLE
        binding.llProspectID.visibility = View.GONE
//        }
        alphaMethodInstallation(fseProspectResponseModel)

    }

    private fun alphaMethodInstallation(fseProspectResponseModel: FseProspectResponseModel) {
        viewModel.getCombineRequestModelInstallation(fseProspectResponseModel.prospectId)
            .observe(this, Observer {
                Log.d(TAG, "combineRequest:$it ")
                it?.fseProspectResponseModel?.let {
                    this.fseProspectResponseModel = it
                    setProspectProgressInstallation(it.statusUpdateTime)
                } ?: run {
                    setProspectProgressInstallation(fseProspectResponseModel.statusUpdateTime)
                }
                if (it?.installationRequestModels == null) {
                    //do your logic
                    //change to green
                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                    binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                    if (!this.fseProspectResponseModel!!.statusUpdateTime!!.installed.isNullOrEmpty()) {
                        Log.d(TAG, "Tempo:1 ")
                        handleButtonVisibility(this.fseProspectResponseModel)
                    }
                    if (fseProspectResponseModel.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
//                        if (!it.statusTime.isNullOrEmpty()) {
                        Log.d(TAG, "Tempo:2 ")
                        binding.tvStep1.visibility = View.VISIBLE
//                        }
                    }
//                    else {
//                        binding.tvStep1.visibility = View.VISIBLE
//                    }
                } else {
                    installationRequestModel = it.installationRequestModels!!
                    Log.d(
                        TAG,
                        "Tempo:2 : fseProspectResponseModel.reattemptedStag = ${fseProspectResponseModel.reattemptedStage}"
                    )
                    if (this.fseProspectResponseModel!!.reattemptedStage != 1) {
                        handleButtonVisibility(this.fseProspectResponseModel)
                    }
                    if (this.fseProspectResponseModel!!.isChanged) {
                        //change to green to red
                        val backgroundDrawable =
                            ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                        DrawableCompat.setTint(backgroundDrawable!!, Color.RED)
                        binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                    } else {
                        val backgroundDrawable =
                            ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                        DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                        binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                    }
                }
                it?.fseError?.let {
                    if (this.fseProspectResponseModel!!.errorOccurred && (it.errorType == FseProspectiveConstant.ProspectiveType.INSTALLATION)) {
                        binding.llError.visibility = View.VISIBLE
                        binding.tvErrorMessage.text = it.messageToUser
                    }
                }
            })
    }

    fun takePicture() {
        Util.CustomInstallationDialog(context = this,
            onDialogShow = { Dialog, image, gotItBtn ->
//                val okbutton = it.findViewById<Button>(R.id.btnGotIT)
                gotItBtn.isEnabled = false
                val unwrappedDrawable =
                    AppCompatResources.getDrawable(this, R.drawable.button_background)
                val wrappedDrawable = DrawableCompat.wrap(unwrappedDrawable!!)
                DrawableCompat.setTint(wrappedDrawable, Color.GRAY)
                gotItBtn.background = wrappedDrawable
                fetchAccuray()
                bag.add(
                    Completable.timer(3000, TimeUnit.MILLISECONDS)
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe({
                            gotItBtn.isEnabled = true
                            val unwrappedDrawable =
                                AppCompatResources.getDrawable(this, R.drawable.button_background)
                            val wrappedDrawable = DrawableCompat.wrap(unwrappedDrawable!!)
                            DrawableCompat.setTint(wrappedDrawable, Color.BLACK)
                            gotItBtn.background = wrappedDrawable
                        }, {
                            Log.d(TAG, "error:${it.localizedMessage} ")
                        })
                )
            },
            onCancel = {
                bag.clear()
                dialog?.dismiss()
            },
            imgGotSample = {
                bag.clear()
                val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                val fileaa: File = createFile()
                outputImgUri = fileaa.absolutePath
                val Prouri: Uri = FileProvider.getUriForFile(
                    this,
                    "com.greenlightplanet.kazi.update.FileImageProvider", fileaa
                )
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Prouri)
                startActivityForResult(cameraIntent, REQUEST_CAMERA)
                it.dismiss()
            })
    }

    @Throws(IOException::class)
    fun createFile(): File {
        // Create an image file name
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "Kazi_${System.currentTimeMillis()}", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        ).apply {
            // Save a file: path for use with ACTION_VIEW intents
            outputImgUri = absolutePath
        }

    }

    private fun handleButtonVisibility(fseProspectResponseModel: FseProspectResponseModel?) {
        Log.d(
            TAG,
            "handleButtonVisibility: fseProspectResponseModel!!.installationPictures => ${fseProspectResponseModel!!.installationPictures}"
        )
        try {
            binding.tvStep1.visibility = View.GONE
            imageList.clear()
            productNameList.clear()
            fseProspectResponseModel!!.installationPictures!!.forEach {
                if (it.phoneUrl.isNullOrEmpty()) {
                    imageList.add(it.url!!)
                } else {
                    imageList.add(it.phoneUrl!!)
                }
                productNameList.add(it.name ?: "NA")

            }
            Log.d(TAG, "handleButtonVisibility: imageList : $imageList")
            setCarousel(imageList, productNameList)
            binding.carouselView.visibility = View.VISIBLE
        } catch (e: Exception) {
            e.printStackTrace()
            Log.d(TAG, "RAJIV - 2: ${e.localizedMessage}")
        }

    }

    private fun setProspectProgressInstallation(statusUpdateTime: FseProspectResponseModel.StatusUpdateTime?) {
        if (!statusUpdateTime?.prospect.isNullOrEmpty()) {
//            binding.tvProspectDate.text = statusUpdateTime?.prospect
            binding.tvProspectDate.text = Util.fseUiDateFormatter(statusUpdateTime?.prospect!!)
            binding.imgProspect.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.double_check
                )
            )
        } else {
            binding.tvProspectDate.text = ""
            binding.imgProspect.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.exclamation_mark
                )
            )
        }
        if (!statusUpdateTime?.otpApproved.isNullOrEmpty()) {
            binding.tvOTPDate.text = statusUpdateTime?.otpApproved
            if (!statusUpdateTime?.otpApproved.isNullOrEmpty()) {
//            binding.tvOTPDate.text = statusUpdateTime?.otpApproval
                binding.tvOTPDate.text = Util.fseUiDateFormatter(statusUpdateTime?.otpApproved!!)
                binding.imgOtp.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvOTPDate.text = ""
                binding.imgOtp.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime?.preApprovedProspect.isNullOrEmpty()) {
                binding.tvPreApprovedDate.text =
                    Util.fseUiDateFormatter(statusUpdateTime?.preApprovedProspect!!)
                //binding.imgPreApproved
                binding.imgPreApproved.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvPreApprovedDate.text = ""
                binding.imgPreApproved.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime?.checkedIn.isNullOrEmpty()) {
                binding.tvCheckedInDate.text =
                    Util.fseUiDateFormatter(statusUpdateTime?.checkedIn!!)
                //binding.imgCheckedIn
                binding.imgCheckedIn.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvCheckedInDate.text = ""
                binding.imgCheckedIn.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime?.installed.isNullOrEmpty()) {
                binding.tvInstallPendDate.text =
                    Util.fseUiDateFormatter(statusUpdateTime?.installed!!)
//            binding.tvInstallPendDate.text = statusUpdateTime?.installationPending
                //binding.imgIstallationP
                if (!fseProspectResponseModel!!.approved) {
                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.INSTALLED) {
                        binding.imgIstallationP.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.ic_cancel
                            )
                        )
                        binding.tvStep1.visibility = View.GONE
                        binding.imgIstallationP.setOnClickListener {
                            errorMessageInstallation(fseProspectResponseModel!!)
                        }
                    } else {
                        binding.imgIstallationP.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.double_check
                            )
                        )
                    }
                } else {
                    binding.imgIstallationP.setImageDrawable(
                        ContextCompat.getDrawable(
                            this,
                            R.drawable.double_check
                        )
                    )
                }
            } else {
                binding.tvInstallPendDate.text = ""
                binding.imgIstallationP.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime?.installationVerified.isNullOrEmpty()) {
//            binding.tvInstallCompleteDate.text = statusUpdateTime?.installed
                binding.tvInstallCompleteDate.text =
                    Util.fseUiDateFormatter(statusUpdateTime?.installationVerified!!)
                //binding.imgInstallComplete
                if (!fseProspectResponseModel!!.approved) {
                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED || fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                        binding.imgInstallComplete.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.ic_cancel
                            )
                        )
                        binding.tvStep1.visibility = View.GONE
                        binding.imgInstallComplete.setOnClickListener {
                            errorMessageInstallation(fseProspectResponseModel!!)
                        }
                    } else {
                        binding.imgInstallComplete.setImageDrawable(
                            ContextCompat.getDrawable(
                                this,
                                R.drawable.double_check
                            )
                        )
                    }
                } else {
                    binding.imgInstallComplete.setImageDrawable(
                        ContextCompat.getDrawable(
                            this,
                            R.drawable.double_check
                        )
                    )
                }
            } else {
                binding.tvInstallCompleteDate.text = ""
                binding.imgInstallComplete.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
            if (!statusUpdateTime?.threeWayCallVerification.isNullOrEmpty()) {
                binding.tvCCverif.text =
                    Util.fseUiDateFormatter(statusUpdateTime?.threeWayCallVerification!!)
                binding.imgCCVerif.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.double_check
                    )
                )
            } else {
                binding.tvCCverif.text = ""
                binding.imgCCVerif.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.exclamation_mark
                    )
                )
            }
        }
    }

    private fun errorMessageInstallation(fseProspectResponseModel: FseProspectResponseModel) {
        if (fseProspectResponseModel.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
            Util.customDialog(
                context = this,
                message = fseProspectResponseModel.message,
                positiveText = "Proceed",
                negetiveText = "Cancel",
                poitiveSelected = {
                    //add logic
                    updateFseProspect(fseProspectResponseModel, 1)
                    it.dismiss()
                },
                negetiveSelected = {
                    it.dismiss()
                }
            )
        } else {
            Util.customFseCompletionDialog(
                context = this,
                hideTitle = true,
                title = null,
                message = fseProspectResponseModel.message,
                okSelected = {
                    it.dismiss()
                }
            )
        }
    }

    private fun updateFseProspect(
        fseProspectResponseModel: FseProspectResponseModel,
        reattemptedStage: Int
    ) {
        when (reattemptedStage) {
            1 -> {
                fseProspectResponseModel.reattemptedStage = 1
                fseProspectResponseModel.statusUpdateTime?.installed = ""
                fseProspectResponseModel.statusUpdateTime?.installationVerified = ""
                fseProspectResponseModel.status =
                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                fseProspectResponseModel.isInstallationChanged = true
                this.fseProspectResponseModel = fseProspectResponseModel
                binding.imgInstallComplete.setOnClickListener(null)
            }
        }
        viewModel.updateFseProspect(fseProspectResponseModel).observe(this, Observer {
            initialize()
            binding.tvStep1.visibility = View.VISIBLE
//			grp_step1.visibility = View.GONE
//            imageView.setImageResource(0)
//            imageView.visibility = View.GONE
            binding.ivLeft.visibility = View.GONE
            binding.ivRight.visibility = View.GONE
            binding.carouselView.visibility = View.GONE
        })
    }

    fun showLowAccuracyDialogInstallation() {
        Log.d(TAG, "ACCURRACY - showLowAccuracyDialog :${currentLocation?.accuracy} ");
        //show accuracy here inside dialog
        fetchAccuray()

        val title = "Your Image accuracy is Low"
        val spannable = SpannableString(title)
        spannable.setSpan(
            StyleSpan(Typeface.BOLD),
            0, title.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        Util.customFseCompletionDialog(
            context = this@ProspectDetailActivity,
            hideTitle = false,
            message = "Please click the image again for better results.",
            titleSpanned = spannable,
            okSelected = {
                it.dismiss()
                //upload image
                bag.clear()
            },
            title = null
        )
    }

    fun getCurrentLoc(): MutableLiveData<Location> {
        val data = MutableLiveData<Location>()
        bag.add(
            newGetCurrentLocation(this)!!.subscribe({
                data.postValue(it)
            }, {
                data.postValue(null)
            })
        )
        return data
    }

    fun fetchAccuray() {
        getCurrentLoc().observe(this, Observer {
            it?.let {
                currentLocation = it
                Log.d(TAG, "ACCURRACY :${currentLocation?.accuracy} ")
                Log.e("|| == ", "${it.latitude},${it.longitude}")
            }
        })
    }

    @SuppressLint("MissingPermission")
    fun newGetCurrentLocation(context: Context): Observable<Location>? {
        val request = LocationRequest.create() //standard GMS LocationRequest
            .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            .setNumUpdates(50).setInterval(20)
        val locationProvider = ReactiveLocationProvider(context)
        return locationProvider.getUpdatedLocation(request)
    }

    override fun onAllUploadCompleted(fileModelsList: List<AwsImageModel>) {
        //override fun onAllUploadCompleted(fileModelsList: List<AmazonS3Helper.FileModel>) {
        cancelProgressDialog()
        //send Data to server
        fileModelsList.forEach { it.tried = false }
        Log.d(TAG, "onAllUploadCompleted:fileModelsList2 = $fileModelsList ")
        val isOnline = Util.isOnline(this)
        //
        fseProspectResponseModel!!.installationPictures!!.map { data ->
            fileModelsList.find { it.imageName == data.name }?.let {
                data.url = it.awsLink
            }
        }
        //
        viewModel.insertAwsImageModelToDatabase(fileModelsList, true).observe(this, Observer {

            Log.d(
                TAG,
                "fseProspectResponseModel!!.installationAttempted:${fseProspectResponseModel!!.installationAttempted} "
            )
            viewModel.performInstallation2(
                context = this,
                isOnline = isOnline,
                fseProspectResponseModel = fseProspectResponseModel,
                prospectId = fseProspectResponseModel!!.prospectId,
                fileModel = fileModelsList,
                //location = currentLocation!!,
                showProgress = {
                    if (!isProgressShowing()) {
                        showProgressDialog(this)
                    }
                }
            ).observe(this, Observer {
                alphaMethodInstallation(fseProspectResponseModel!!)
                cancelProgressDialog()
                Log.d(TAG, ":step2$it")

                if (Util.isOnline(this)) {
                    refreshInstallation()
                }
            })

        })

    }

    private fun refreshInstallation() {
        viewModel.getFseProspectiveFromServerInstallation(
            loginResponseData!!.angazaId!!,
            fseProspectResponseModel!!.prospectId,
            showProgress = {
                showProgressDialog(this)
            })?.observe(this, Observer {
            if (it != null) {
                if ((it.success) && (it.responseData != null)) {
                    setUI(it.responseData!!.ticketType, it.responseData!!)
                } else {
                    alphaMethodInstallation(fseProspectResponseModel!!)
                }
            } else {
                alphaMethodInstallation(fseProspectResponseModel!!)
            }
            cancelProgressDialog()
        })
    }

    //endregion

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private fun awsImageUploadHandler(fileModels: List<AwsImageModel>, isForService: Boolean) {
        if (preference?.getAwsAccess().isNullOrEmpty() || preference?.getAwsSecret()
                .isNullOrEmpty()
        ) {
            viewModel.awsRX(this, BaseRequestModel().apply {
                this.angazaId = loginResponseData?.angazaId
                this.country = loginResponseData?.country
            }).observe(this, Observer {


                if (it == null || it.Success == false || it.ResponseData?.accessKey.isNullOrEmpty() || it.ResponseData?.secretKey.isNullOrEmpty()) {
                    Util.customFseCompletionDialog(
                        context = this,
                        hideTitle = true,
                        title = null,
                        message = "Unable to upload images please try again later",
                        okSelected = {
                            it.dismiss()
                        }
                    )
                } else {
                    preference?.setAwsAccess(it.ResponseData?.accessKey!!)
                    preference?.setAwsSecret(it.ResponseData?.secretKey!!)
                    amazonS3Helper?.startUploadProcess(fileModels, isForService)
                }
            })
        } else {
            amazonS3Helper?.startUploadProcess(fileModels, isForService)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        amazonS3Helper?.amazonS3HelperCallback = null
        amazonS3Helper = null
        bag.clear()
        mHomeWatcher?.stopWatch()
    }

    //region carousel
    private fun setCarousel(imagesCList: List<String>, productName: List<String>) {
        circularProgressDrawable?.strokeWidth = 5f
        circularProgressDrawable?.centerRadius = 30f
        circularProgressDrawable?.start()
        var currentItem = 0
        var pos = 0
        try {

            if (imagesCList.isNotEmpty()) {
                /*binding.ivRight.visibility = View.VISIBLE
                binding.ivLeft.visibility = View.VISIBLE*/
                if (imagesCList.size > 1) {
                    binding.ivRight.visibility = View.VISIBLE
                    binding.ivLeft.visibility = View.VISIBLE
                } else {
                    binding.ivRight.visibility = View.GONE
                    binding.ivLeft.visibility = View.GONE
                }
            } else {
                binding.ivRight.visibility = View.GONE
                binding.ivLeft.visibility = View.GONE
            }


            if (!imagesCList.isNullOrEmpty()) {
                binding.carouselView?.apply {

                    Log.d(TAG, "setCarousel: imagesCList${imagesCList.size} : $imagesCList")
                    size = imagesCList.size
                    resource = R.layout.carousel_item
                    autoPlay = true
                    indicatorAnimationType = IndicatorAnimationType.THIN_WORM
                    carouselOffset = OffsetType.CENTER

                    carouselViewListener = null
                    setCarouselViewListener { view, position ->
                        // Example here is setting up a full image carousel
                        val imView = view.findViewById<ImageView>(R.id.imageCView)
                        val tvProductName = view.findViewById<TextView>(R.id.tvProductName)
                        tvProductName.text = productName.get(position).replace("_", " ")
                            .capitalize()/*?.toLowerCase()*/
                        Glide.with(context)
                            .load(imagesCList.get(position))
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .apply(
                                RequestOptions()
                                    .centerCrop()
                                    .placeholder(circularProgressDrawable)
                                    .error(R.mipmap.ic_launcher_round)
                            ).into(imView)

                        imView.setOnClickListener {
                            ImageUploadUtil.ImageEnlargeDialog(
                                this@ProspectDetailActivity,
                                imagesCList.get(position)
                            )
                        }

                    }
                    currentItem = this.currentItem

                    carouselScrollListener = object : CarouselScrollListener {
                        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                        }

                        override fun onScrollStateChanged(
                            recyclerView: RecyclerView,
                            newState: Int,
                            position: Int
                        ) {
                            pos = position
                //                            Log.e(TAG, "Position === $position ==currentItem==${currentItem}")
                        }
                    }
                    // After you finish setting up, show the CarouselView
                    if (!binding.carouselView.isShown) {
                        show()
                    }
                }
                binding.ivLeft.setOnClickListener {
                    binding.carouselView.currentItem =
                        changeLeftCarouselView(imagesCList, pos, currentItem)
                }

                binding.ivRight.setOnClickListener {
                    binding.carouselView.currentItem =
                        changeRightCarouselView(imagesCList, pos, currentItem)
                }
                binding.carouselView.visibility = View.VISIBLE
            } else {
                binding.carouselView.visibility = View.GONE
            }

        } catch (e: Exception) {
            e.printStackTrace()
            Log.d(TAG, "RAJIV - 1: ${e.localizedMessage}")
        }
    }

    fun changeRightCarouselView(imagesList: List<String>, position: Int, currentItem: Int): Int {
        return if (position != imagesList.size && position != currentItem) {
            position + 1
        } else {
            position + 1
        }
    }

    fun changeLeftCarouselView(imagesList: List<String>, position: Int, currentItem: Int): Int {
        return if (position != imagesList.size && position != currentItem) {
            position - 1
        } else {
            position - 1
        }
    }
    //endregion

}
