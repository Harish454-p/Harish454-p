package com.greenlightplanet.kazi.dashboard.dao

import androidx.room.*
import com.greenlightplanet.kazi.dashboard.model.call_sms.ContactRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.SmsRequest
import io.reactivex.Single

@Dao
interface SmsRequestDao {

	@Insert(onConflict = OnConflictStrategy.IGNORE)
	fun insertAllIgnore(SmsRequest: List<SmsRequest>): List<Long>

	@Insert(onConflict = OnConflictStrategy.REPLACE)
	fun insertAllReplace(SmsRequest: List<SmsRequest>): List<Long>

	@Insert(onConflict = OnConflictStrategy.REPLACE)
	fun insert(SmsRequest: SmsRequest): Long

	@Delete
	fun delete(SmsRequest: SmsRequest): Int

	@Query("DELETE FROM SmsRequest")
	fun deleteAll(): Int

	@Query("SELECT * FROM SmsRequest")
	fun getAll(): Single<List<SmsRequest>>

	@Query("SELECT * FROM SmsRequest WHERE uploadedToServer = :uploadedToServer")
	fun getAllForUpload(uploadedToServer: Boolean = false): Single<List<SmsRequest>>

	@Query("SELECT * FROM SmsRequest LIMIT 1")
	fun get(): Single<SmsRequest>

	@Query("SELECT COUNT(*) from SmsRequest")
	fun count(): Single<Int>

}
