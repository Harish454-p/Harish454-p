package com.greenlightplanet.kazi.agentReferral.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_by_mtd
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_by_name
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_by_regis_date
import com.greenlightplanet.kazi.agentReferral.model.agentreferral.AgentReferralModel
import com.greenlightplanet.kazi.agentReferral.model.agentreferral.SuccessfullyReferredAgent
import com.greenlightplanet.kazi.agentReferral.repo.AgentReferralRepo
import com.greenlightplanet.kazi.agentReferral.ui.view.AgentReferralActivity
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.utils.Util

class AgentReferralViewModel(application: Application) : AndroidViewModel(application) {

    fun agentReferral(
        isOnline: Boolean,
    ) : MutableLiveData<NewCommonResponseModel<AgentReferralModel>> {
        agentReferralList.clear()
        return when(isOnline) {
            true -> {
                repository.agentReferralListFromServer(
                    pageSize = pageSize,
                    page = page
                )
            }
            else -> {
                repository.agentReferralListFromDb()
            }
        }
    }

    fun prepData(responseData: AgentReferralModel) {

        //pagination...
        responseData.pagination?.let { pagin ->
            pagin.page?.let { it -> page = it.toInt() }
            pagin.pageSize?.let { it -> pageSize = it.toInt() }
            pagin.endOfStream?.let { it ->
                endOfPage = it
                obsViewMore.postValue(endOfPage)
            }
        }

        //metrics...
        responseData.referredAgentsMetrics?.let { metrics ->
            metrics.successfullyReferredAgentsCount?.let { it -> obsSuccessfulReferred.postValue(it) }
            metrics.totalReferredAgentsCount?.let { it -> obsTotalReferred.postValue(it) }
            metrics.totalSalesByReferredAgentsLastMonth?.let { it -> obsReferredLastMonth.postValue(it) }
            metrics.totalReferralIncentiveLastMonth?.let { it -> obsLastMonthReferredIncentive.postValue(it) }
        }

        //successfulReferredAgents...
        responseData.successfullyReferredAgents?.let { referredAgents ->
            agentReferralList.addAll(ArrayList(referredAgents))
            obsAgentChildList.postValue(agentReferralList)
//            obsAgentChildList.postValue(ArrayList(referredAgents))
        }
    }

    fun callAgentReferralApi(agentReferralActivity: AgentReferralActivity) {
        when(Util.isOnline(agentReferralActivity)) {
            true -> {
                when(endOfPage) {
                    true -> {
                        Util.showToast(
                            context = agentReferralActivity,
                            message = agentReferralActivity.getString(R.string.no_data)
                        )
                        agentReferralActivity.cancelProgressDialog()
                    }
                    false -> loadMoreData(agentReferralActivity)
                }
            }
            else -> agentReferralActivity.cancelProgressDialog()
        }
    }

    private fun loadMoreData(agentReferralActivity: AgentReferralActivity) {
        repository.agentReferralListFromServer(
            pageSize = pageSize,
            page = getNextPage()
        ).observe(agentReferralActivity, Observer { response ->
            when(response) {
                null -> {
                    Util.customFseRationaleDialog(
                        context = agentReferralActivity,
                        title = "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = agentReferralActivity.getString(R.string.no_data),
                        positveSelected = {
                            it.dismiss()
                        },
                        negativeSeleted = {
                            it.dismiss()
                        }
                    )
                    agentReferralActivity.cancelProgressDialog()
                }
                else -> {
                    when(response.success) {
                        true -> {
                            when(response.responseData) {
                                null -> {
                                    Util.customFseRationaleDialog(
                                        context = agentReferralActivity,
                                        title = "",
                                        hideNegative = true,
                                        titleSpanned = null,
                                        hideTitle = true,
                                        message = agentReferralActivity.getString(R.string.no_data),
                                        positveSelected = {
                                            it.dismiss()
                                        },
                                        negativeSeleted = {
                                            it.dismiss()
                                        }
                                    )
                                    agentReferralActivity.cancelProgressDialog()
                                }
                                else -> {
                                    prepData(responseData = response.responseData!!)
                                }
                            }
                        }
                        false -> {
                            Util.customFseRationaleDialog(
                                context = agentReferralActivity,
                                title = "",
                                hideNegative = true,
                                titleSpanned = null,
                                hideTitle = true,
                                message = agentReferralActivity.getString(R.string.no_data),
                                positveSelected = {
                                    it.dismiss()
                                },
                                negativeSeleted = {
                                    it.dismiss()
                                }
                            )
                            agentReferralActivity.cancelProgressDialog()
                        }
                    }
                }
            }
        })
    }

    private fun getNextPage(): Int? {
        return page?.plus(1)
    }

    fun sortAgentReferrals(sortType: Int) {
        when(sortType) {
            sort_by_name -> {
                when(sortAgentNameASC) {
                    true -> {
                        val list = agentReferralList.sortedWith(compareBy { it.agentName })
                        obsAgentChildList.postValue(ArrayList(list))
                    }
                    false -> {
                        val list = agentReferralList.sortedWith(compareBy { it.agentName }).asReversed()
                        obsAgentChildList.postValue(ArrayList(list))
                    }
                }
                sortAgentNameASC = !sortAgentNameASC
            }
            sort_by_regis_date -> {
                when(sortDateAsc) {
                    true -> {
                        val list = agentReferralList.sortedWith(compareBy { it.registeredDateTimestamp?.toDouble() })
                        obsAgentChildList.postValue(ArrayList(list))
                    }
                    false -> {
                        val list = agentReferralList.sortedWith(compareBy { it.registeredDateTimestamp?.toDouble() }).asReversed()
                        obsAgentChildList.postValue(ArrayList(list))
                    }
                }
                sortDateAsc = !sortDateAsc
            }
            sort_by_mtd -> {
                when(sortMTDASC) {
                    true -> {
                        val list = agentReferralList.sortedWith(compareBy { it.mtdSales })
                        obsAgentChildList.postValue(ArrayList(list))
                    }
                    false -> {
                        val list = agentReferralList.sortedWith(compareBy { it.mtdSales }).asReversed()
                        obsAgentChildList.postValue(ArrayList(list))
                    }
                }
                sortMTDASC = !sortMTDASC
            }
        }
    }

    val TAG : String = "AgentReferralViewModel"
    val repository : AgentReferralRepo = AgentReferralRepo(context = application.applicationContext)
    var page : Int? = 1
    var endOfPage : Boolean = true
    var pageSize : Int? = 20
    var agentReferralList : ArrayList<SuccessfullyReferredAgent> = ArrayList()
    var sortAgentNameASC : Boolean = true
    var sortDateAsc : Boolean = true
    var sortMTDASC : Boolean = true

    var obsAgentChildList : MutableLiveData<ArrayList<SuccessfullyReferredAgent>> = MutableLiveData()
    var obsSuccessfulReferred : MutableLiveData<Int> = MutableLiveData()
    var obsTotalReferred : MutableLiveData<Int> = MutableLiveData()
    var obsReferredLastMonth : MutableLiveData<String> = MutableLiveData()
    var obsLastMonthReferredIncentive : MutableLiveData<String> = MutableLiveData()
    var obsViewMore : MutableLiveData<Boolean> = MutableLiveData()
}