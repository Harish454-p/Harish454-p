package com.greenlightplanet.kazi.heroboard.extras

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.os.Build
import android.text.SpannableString
import android.text.style.UnderlineSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ImagePopWindowBinding


class LeaderBoardUtil {

    object Month {
        val CURRENT = "CURRENT"
        val PREVIOUS = "PREVIOUS"
    }

    object Geography {
        val AREA = "AREA"
        val REGION = "REGION"
    }

    companion object {

        fun addUnderline(context: Context, textView: TextView, underlineData: String) {

//        val spannable = SpannableString(textView.text)
//        spannable.setSpan(DrawableSpan(context.resources.getDrawable(R.drawable.text_underline)), 0, textView.text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
//        textView.setText(spannable, TextView.BufferType.SPANNABLE)
//        textView.setTextColor(Color.parseColor("#3792e5"))
//        textView.setOnClickListener { v -> view.performClick() }

            val content = SpannableString(underlineData)
            content.setSpan(UnderlineSpan(), 0, underlineData.length, 0)
// 0 specify start index and underlineData.length() specify end index of styling
            textView.setTextColor(Color.parseColor("#3792e5"))
            textView.setText(content)
        }

        fun isNetworkConnected(context: Context): Boolean {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager?
            return cm!!.activeNetworkInfo != null
        }

        fun CustomLeaderImageDialog(context: Activity, url: String): Dialog {

             var itemBinding:ImagePopWindowBinding ?= null
            var parent: ViewGroup
            val dialog = Dialog(context)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            itemBinding = ImagePopWindowBinding.inflate(LayoutInflater.from(context))
            dialog.setContentView(itemBinding.root)
            dialog.setCanceledOnTouchOutside(true)
            var width = 0
            var height = 0

            dialog.setCancelable(true)
            val size = Point()
            val w = context.windowManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
                w.defaultDisplay.getSize(size)
                width = size.x - 30
                height = size.y - 40
            } else {
                val d = w.defaultDisplay
                width = d.width - 30
                height = d.height - 40
            }

            parent = itemBinding.image.parent as ViewGroup
            dialog.setCancelable(true)
            dialog.setCanceledOnTouchOutside(true)
            Glide.with(context)
                    .load(url)
                    .error(R.drawable.ic_man_user)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .listener(object : RequestListener<Drawable> {
                        override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Drawable>?, isFirstResource: Boolean): Boolean {
                            Log.e("|| ---=== ","Failed == $isFirstResource ==== $e")
                            dialog.dismiss()
                            Toast.makeText(context,"Image not available",Toast.LENGTH_SHORT).show()
                            return false
                        }

                        override fun onResourceReady(resource: Drawable?, model: Any?, target: Target<Drawable>?, dataSource: DataSource?, isFirstResource: Boolean): Boolean {
//                            val bitmapaaa: BitmapDrawable = resource as BitmapDrawable
//                            parent.background = BitmapDrawable(context.getResources(), IConstants.fastblur(bitmapaaa.bitmap))// ));
                            return false
                        }
                    }).into(itemBinding.image)


            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT)

            itemBinding.ibClose.setOnClickListener {
                dialog.dismiss()
            }

            if (dialog != null)
                dialog.show()

            return dialog
        }

    }

}

