package com.greenlightplanet.kazi.incentivenew.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.CollectionAccounts
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.CollectionBreakdownData
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.Content
import kotlinx.coroutines.flow.Flow

@Dao
interface CollectionBreakdownDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(data: CollectionBreakdownData): Long

    @Query("SELECT * FROM collectionBreakdownData WHERE angazaId LIKE :angazaId LIMIT 1")
    fun getSingleCollectionData(angazaId: String) : CollectionBreakdownData?

    @Query("SELECT COUNT(*) FROM collectionBreakdownData WHERE angazaId LIKE :angazaId")
    suspend fun getCountAllPagesCollectionData(angazaId: String) : Int?

    @Query("DELETE FROM collectionBreakdownData")
    suspend fun deleteAll() :Int

    @Query("DELETE FROM collectionBreakdownData WHERE angazaId LIKE :angazaId")
    suspend fun deleteExisting(angazaId: String) :Int

    @Transaction
    suspend fun replace(data: CollectionBreakdownData): Long? {
        data.angazaId?.let {
            deleteExisting(it)
        }
        return insert(data)
    }

    @Transaction
    suspend fun replaceAll(data: CollectionBreakdownData): Long? {
        deleteAll()
        return insert(data)
    }

}