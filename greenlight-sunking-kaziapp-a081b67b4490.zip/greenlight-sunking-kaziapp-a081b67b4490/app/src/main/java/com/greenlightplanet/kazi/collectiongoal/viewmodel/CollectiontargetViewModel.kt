package com.greenlightplanet.kazi.collectiongoal.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.newtasks.repo.TaskRepo
import com.greenlightplanet.kazi.summary.model.CollectionRateAccount
import com.greenlightplanet.kazi.summary.model.SummaryModel
import com.greenlightplanet.kazi.summary.repo.SummaryRepo

class CollectiontargetViewModel(application: Application) : AndroidViewModel(application) {

    var summaryRepo: SummaryRepo? = SummaryRepo.getInstance(application)


    fun getSummaryData(angazaId: String): MutableLiveData<NewCommonResponseModel<SummaryModel>>? {
        return summaryRepo?.getSummaryData(angazaId)
    }


}