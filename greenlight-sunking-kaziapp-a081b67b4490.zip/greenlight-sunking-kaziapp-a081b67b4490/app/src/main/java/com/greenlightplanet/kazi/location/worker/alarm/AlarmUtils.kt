package com.example.alarms

import android.app.AlarmManager
import android.app.AlarmManager.RTC_WAKEUP
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.greenlightplanet.kazi.location.worker.CAN_CALL_WM_DURATION
import com.greenlightplanet.kazi.location.worker.DEFAULT_INTERVAL
import com.greenlightplanet.kazi.location.worker.PENDING_REQUEST_ID
import com.greenlightplanet.kazi.location.worker.alarm.HourAlarmWorkReceiver


object AlarmUtils {

    fun setAlarm(context: Context, minutes: Long = 1, requestCode: Int = PENDING_REQUEST_ID) {


        /*val minute = 60000

        val timeOfAlarm = minute * minutes

        val serviceIntent = Intent(context, HourAlarmWorkReceiver::class.java)


        val pIntent = PendingIntent.getBroadcast(
                context,
                0,
                serviceIntent,
                0
        )



        val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmMgr.setExactAndAllowWhileIdle(RTC_WAKEUP, System.currentTimeMillis() + timeOfAlarm, pIntent)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            alarmMgr.setAlarmClock(
                    AlarmManager.AlarmClockInfo(
                            System.currentTimeMillis() + timeOfAlarm,
                            pIntent
                    ), pIntent
            )


        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            alarmMgr.setExact(
                    AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + timeOfAlarm,
                    pIntent
            )
        } else {
            alarmMgr.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + timeOfAlarm, pIntent)
        }*/

    }

    /*fun setAlarm(context: Context, minutes: Long = 1 , requestCode:Int=9141) {


        val minute = 60000

        val timeOfAlarm = minute * minutes

        val serviceIntent = Intent(context, HourAlarmWorkReceiver::class.java)


        val pIntent = PendingIntent.getBroadcast(
                context,
                0,
                serviceIntent,
                0
        )



        val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            alarmMgr.setAlarmClock(
                    AlarmManager.AlarmClockInfo(
                            System.currentTimeMillis() + timeOfAlarm,
                            pIntent
                    ), pIntent
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            alarmMgr.setExact(
                    AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + timeOfAlarm,
                    pIntent
            )
        } else {
            alarmMgr.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + timeOfAlarm, pIntent)
        }

    }*/


    //Working fine
    /*@RequiresApi(Build.VERSION_CODES.KITKAT)
    fun setOldAlarm(context: Context, minutes: Long = 1) {


        val minute = 60000

        val timeOfAlarm = minute * minutes

        val serviceIntent = Intent(context, HourAlarmWorkReceiver::class.java)

        *//* val pIntent = PendingIntent.getService(
             context,
             0,
             serviceIntent,
             0
         )*//*


        val pIntent = PendingIntent.getBroadcast(
                context,
                0,
                serviceIntent,
                0
        )

        // Setting up AlarmManager

        val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

//         Set alarm manager
//        alarmMgr.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + timeOfAlarm, pIntent)
//        alarmMgr.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + timeOfAlarm, pIntent)
//        alarmMgr.setAlarmClock(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + timeOfAlarm, pIntent)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            alarmMgr.setAlarmClock(
                    AlarmManager.AlarmClockInfo(
                            System.currentTimeMillis() + timeOfAlarm,
                            pIntent
                    ), pIntent
            )
        } else {
            alarmMgr.setExact(
                    AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + timeOfAlarm,
                    pIntent
            )
        }

        *//*if (System.currentTimeMillis() < timeOfAlarm) {

            alarmMgr.setRepeating(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() ,
                timeOfAlarm,
                pIntent
            )

        }*//*

    }*/


    fun setNewAlarm(context: Context, minutes: Long = DEFAULT_INTERVAL) {

        val minute = 60000

        val timeOfAlarm = minute * minutes

        val pIntent = getPendingIntent(context)

        val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        /* when {
             Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP -> alarmMgr.setAlarmClock(AlarmManager.AlarmClockInfo(timeOfAlarm, pIntent), pIntent)
             Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT -> alarmMgr.setExact(AlarmManager.RTC_WAKEUP, timeOfAlarm, pIntent)
             else -> alarmMgr.set(AlarmManager.RTC_WAKEUP, timeOfAlarm, pIntent)
         }*/

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            alarmMgr.setAlarmClock(
                    AlarmManager.AlarmClockInfo(
                            System.currentTimeMillis() + timeOfAlarm,
                            pIntent
                    ), pIntent
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            alarmMgr.setExact(
                    AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + timeOfAlarm,
                    pIntent
            )
        } else {
            alarmMgr.set(AlarmManager.RTC_WAKEUP, timeOfAlarm, pIntent)
        }


    }

    private fun getPendingIntent(context: Context, requestCode: Int = PENDING_REQUEST_ID): PendingIntent {

        val serviceIntent = Intent(context, HourAlarmWorkReceiver::class.java)

        return PendingIntent.getBroadcast(
                context,
//                0,
                requestCode,
                serviceIntent,
                0
        )
    }


    fun shouldUseWorkManager(lastWorkCalled: Long?): Boolean {

        if (lastWorkCalled != null) {

            val lastWorkCalledCheck = System.currentTimeMillis() - lastWorkCalled

            if (lastWorkCalledCheck > CAN_CALL_WM_DURATION) {
                return true
            } else {
                return false
            }
        } else {
            return true
        }

    }


}
