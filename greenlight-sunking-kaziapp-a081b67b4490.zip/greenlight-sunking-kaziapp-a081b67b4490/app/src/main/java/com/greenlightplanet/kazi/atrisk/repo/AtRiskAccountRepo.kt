package com.greenlightplanet.kazi.atrisk.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.greenlightplanet.kazi.atrisk.model.AtRiskAccountModel
import com.greenlightplanet.kazi.atrisk.model.AtRiskCall
import com.greenlightplanet.kazi.atrisk.model.AtRiskCallDetailRequestModel
import com.greenlightplanet.kazi.atrisk.model.AtRiskCallPostRequest
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.leads.extras.LEAD_INTENT
import com.greenlightplanet.kazi.leads.extras.LEAD_STATUS
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.new_attendance.extras.ErrorUtils
import com.greenlightplanet.kazi.newtasks.Status
import com.greenlightplanet.kazi.newtasks.model.CallDetailModel
import com.greenlightplanet.kazi.newtasks.model.CommonTaskModel
import com.greenlightplanet.kazi.summary.model.CollectionRateAccount
import com.greenlightplanet.kazi.summary.model.SummaryCallDetailRequestModel
import com.greenlightplanet.kazi.summary.model.post.SummaryCall
import com.greenlightplanet.kazi.summary.repo.SummaryRepo
import com.greenlightplanet.kazi.task.TaskUtils
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.util.*

class AtRiskAccountRepo(context: Context) {
    var context: Context? = null
    val bag = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var gson: Gson? = null
    var preference: GreenLightPreference? = null

    init {
        this.context = context
        localDb = AppDatabase.getAppDatabase(context)
        preference = GreenLightPreference.getInstance(context)
        gson = Gson()
    }

    private val angazaId: String? by lazy {
        preference?.getLoginResponseModel()?.angazaId
    }


    companion object : SingletonHolderUtil<AtRiskAccountRepo, Context>(::AtRiskAccountRepo) {
        public const val TAG = "AtRiskAccountRepo"
    }

    fun getAtRiskAccount(
        context: Context,
        url: String,
        angaza: String
    ): MutableLiveData<NewCommonResponseModel<AtRiskAccountModel>> {

        val newsData = MutableLiveData<NewCommonResponseModel<AtRiskAccountModel>>()

        if (Util.isOnline(context)) {

            bag.add(
                ServiceInstance.getInstance(context).service?.getAtRiskAccountsCollectionrx(url)
                !!.subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        Log.e("$TAG", "" + it.responseData?.collectionAccount?.size)
                        insertAtRiskAccount(newsData, it.responseData!!)

                    }, { t ->

                        newsData.postValue(
                            NewCommonResponseModel<AtRiskAccountModel>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from server"
                                ),
                                success = false
                            )
                        )
                    })
            )
            return newsData
        } else {


            bag.add(
                localDb!!.atRiskDao().getAccountAngaza(angaza)!!
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        newsData.postValue(
                            NewCommonResponseModel<AtRiskAccountModel>(
                                success = true,
                                responseData = AtRiskAccountModel(it)
                            )
                        )
                    }, { t ->
                        newsData.postValue(
                            NewCommonResponseModel<AtRiskAccountModel>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from server"
                                ),
                                success = false
                            )
                        )
                    })
            )
            return newsData
        }
    }


    private fun insertAtRiskAccount(
        liveData: MutableLiveData<NewCommonResponseModel<AtRiskAccountModel>>,
        responseData: AtRiskAccountModel
    ): Disposable {
        return Completable.fromAction {
            responseData.collectionAccount.forEach { collectionAccount: AtRiskAccountModel.CollectionAccount ->
                collectionAccount.syncDate = Util.getCurrentLocalFormattedDate()
            }
            localDb!!.atRiskDao().insertAtRiskAccount(responseData.collectionAccount)
        }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe({

                liveData.postValue(
                    NewCommonResponseModel<AtRiskAccountModel>(
                        success = true,
                        responseData = responseData
                    )
                )
            }, { t ->
                liveData.postValue(
                    NewCommonResponseModel<AtRiskAccountModel>(
                        error = NewCommonResponseModel.Error(
                            messageToUser = "Unable get data from server"
                        ),
                        success = false
                    )
                )
            })

    }


    fun insertCallDetailRequestToDb(
        callRequest: AtRiskCallDetailRequestModel,
        isPresent: Boolean
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        bag.add(
            insertAtRiskCalledDetails(callRequest, isPresent)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "insertCallDetailRequestToDb - success: ${it}")
                    data.postValue(
                        NewCommonResponseModel(
                            success = true,
                            responseData = NewEmptyParcelable()
                        )
                    )

                }, { t ->
                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertCallDetailRequestToDb",
                        "Unable to save data to database",
                        data
                    )
                })
        )

        return data
    }


    fun solveTaskCallDetailRequest(
        callRequest: AtRiskCallDetailRequestModel,
        isPresent: Boolean
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        bag.add(
            /*insertSummaryCalledDetails(callRequest, isPresent)*/
            insertAtRiskCalledDetails(callRequest, isPresent)
                .flatMap { solveRateCalledDetails(angazaId!!) }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "solveTaskCallDetailRequest - success: ${it}")
                    data.postValue(it)
                }, { t ->
                    ErrorUtils.errorDatabase(
                        t,
                        TAG,
                        "solveCallDetailRequest",
                        "Unable to save data to database",
                        data
                    )
                })
        )

        return data
    }


    //For saving Call details
    private fun insertSummaryCalledDetails(
        callRequest: AtRiskCallDetailRequestModel,
        isPresent: Boolean
    ): Single<Any?> {
        var atRiskAccount: AtRiskAccountModel.CollectionAccount? = null
//not present in Task
        return Single.fromCallable {
            localDb?.atRiskCallDetailRequestModelDao()?.insert(callRequest)
        }.flatMap {
            Log.e(
                TAG,
                "commonTaskDetails - else - accountNumber:${callRequest.accountNumber.toString()} "
            )
            localDb?.atRiskDao()
                ?.getByAccountNumber(callRequest.accountNumber.toString())
        }.flatMap {
            atRiskAccount = it
            var date: Date? = null
            date = Util.getCurrentDate()

            if (date == null) {
                date = Calendar.getInstance().time
            }
            if (atRiskAccount?.callDetail != null) {
                atRiskAccount?.callDetail?.add(
                    CallDetailModel(
                        attempt = callRequest.attempt!!,
                        callDetailId = 0,
                        calledNumber = callRequest.contactedNumber,
                        date = TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!),
                        duration = callRequest.callDuration.toString(),
                        extraParamCallDetail = "",
                        feedbackId = callRequest.feedbackId,
                        followupDate = callRequest.newVisitDate,
                        intentId = callRequest.intentId,
                        otherReason = callRequest.otherReason,
                        isVisit = false,
                        visitDetail = null
                    )
                )
            } 
            else {
                atRiskAccount?.callDetail = mutableListOf()
                atRiskAccount?.callDetail?.add(
                    CallDetailModel(
                        attempt = callRequest.attempt ?: 1,
                        callDetailId = 0,
                        calledNumber = callRequest.contactedNumber,
                        date = TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!),
                        duration = callRequest.callDuration.toString(),
                        extraParamCallDetail = "",
                        feedbackId = callRequest.feedbackId,
                        followupDate = callRequest.newVisitDate,
                        intentId = callRequest.intentId,
                        otherReason = callRequest.otherReason,
                        isVisit = false,
                        visitDetail = null
                    )
                )
            }

            Log.e(TAG, "atRiskAccount -1 - else - => :$atRiskAccount ");

            val newSummaryCall = AtRiskCall(
                accountAngazaId = atRiskAccount?.accountAngazaId!!,
                accountNumber = atRiskAccount?.accountNumber,
                attempt = callRequest.attempt,
                callDuration = callRequest.callDuration,
                callType = "AT_RISK_CALL",
                calledAt = Util.formateDatetoDDMMYYYYHHMMSS(date!!),
                contactedNumber = callRequest.contactedNumber,
                country = preference!!.getLoginResponseModel()!!.country,
                customerIntent = callRequest.intentId,
                feedbackCode = callRequest.feedbackId,
                followUpDate = callRequest.newVisitDate,
                imei = callRequest.imei,
                isTask = atRiskAccount!!.isTask ?: false,
                otherReason = callRequest.otherReason ?: "",
                taskId = atRiskAccount?.taskId!!,
                ticketType = atRiskAccount!!.taskStatus ?: "1st Call"
            )


            Single.fromCallable {
                localDb?.atRiskCallPostRequestDao()?.insert(newSummaryCall)
            }

        }.flatMap {
            Log.e(TAG, "atRiskAccount -2 => :$atRiskAccount ")
            Single.fromCallable {
                localDb?.atRiskDao()
                    ?.insertAtRisk(atRiskAccount!!)
            }
        }
        
    }

    private fun insertAtRiskCalledDetails(
        callRequest: AtRiskCallDetailRequestModel,
        isPresent: Boolean
    ): Single<Any?> {
        var atRiskAccount: AtRiskAccountModel.CollectionAccount? = null
        var commonTaskDetails: CommonTaskModel? = null
        if (isPresent) {
            return Single.fromCallable {
                localDb?.atRiskCallDetailRequestModelDao()?.insert(callRequest)
            }.flatMap {
                Log.e(
                    TAG,
                    "commonTaskDetails - accountNumber:${callRequest.accountNumber.toString()} "
                )
                localDb?.atRiskDao()
                    ?.getByAccountNumber(callRequest.accountNumber.toString())
            }.flatMap {
                atRiskAccount = it
                var date: Date? = null
                date = Util.getCurrentDate()

                if (date == null) {
                    date = Calendar.getInstance().time
                }
                if (atRiskAccount?.callDetail != null) {
                    atRiskAccount?.callDetail?.add(
                        CallDetailModel(
                            attempt = callRequest.attempt!!,
                            callDetailId = 0,
                            calledNumber = callRequest.contactedNumber,
                            date = TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!),
                            duration = callRequest.callDuration.toString(),
                            extraParamCallDetail = "",
                            feedbackId = callRequest.feedbackId,
                            followupDate = callRequest.newVisitDate,
                            intentId = callRequest.intentId,
                            otherReason = callRequest.otherReason,
                            isVisit = false,
                            visitDetail = null
                        )
                    )
                } else {
                    atRiskAccount?.callDetail = mutableListOf()
                    atRiskAccount?.callDetail?.add(
                        CallDetailModel(
                            attempt = callRequest.attempt!!,
                            callDetailId = 0,
                            calledNumber = callRequest.contactedNumber,
                            date = TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!),
                            duration = callRequest.callDuration.toString(),
                            extraParamCallDetail = "",
                            feedbackId = callRequest.feedbackId,
                            followupDate = callRequest.newVisitDate,
                            intentId = callRequest.intentId,
                            otherReason = callRequest.otherReason,
                            isVisit = false,
                            visitDetail = null
                        )
                    )
                }

                Log.e(TAG, "atRiskAccount -1 => :$atRiskAccount ");

                val newSummaryCall = AtRiskCall(
                    accountAngazaId = atRiskAccount?.accountAngazaId!!,
                    accountNumber = atRiskAccount?.accountNumber,
                    attempt = callRequest.attempt,
                    callDuration = callRequest.callDuration,
                    callType = "AT_RISK_CALL",
                    calledAt = Util.formateDatetoDDMMYYYYHHMMSS(date!!),
                    contactedNumber = callRequest.contactedNumber,
                    country = preference!!.getLoginResponseModel()!!.country,
                    customerIntent = callRequest.intentId,
                    feedbackCode = callRequest.feedbackId,
                    followUpDate = callRequest.newVisitDate,
                    imei = callRequest.imei,
                    isTask = atRiskAccount!!.isTask ?: false,
                    otherReason = callRequest.otherReason ?: "",
                    taskId = atRiskAccount?.taskId!!,
                    ticketType = atRiskAccount!!.taskStatus ?: "1st Call"
                )

                if (atRiskAccount!!.taskStatus.equals("VISIT", true)) {
                    atRiskAccount!!.eligibleForReimbursement = false
                } else {
                    if (callRequest.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
                        atRiskAccount?.taskStatus = LEAD_STATUS.CALLED
                        atRiskAccount!!.eligibleForReimbursement = false
                    }
                    if (newSummaryCall.ticketType != "CALLED") {
                        val oldCallMade = preference?.getNewTaskCallMade() ?: 0
                        preference?.setNewTaskCallMade(oldCallMade + 1)
                    }
                }


                Single.fromCallable {
                    localDb?.atRiskCallPostRequestDao()?.insert(newSummaryCall)
                }

            }.flatMap {
                Log.e(TAG, "atRiskAccount -2 => :$atRiskAccount ")
                Single.fromCallable {
                    localDb?.atRiskDao()
                        ?.insertAtRisk(atRiskAccount!!)
                }
            } ///new Added to migrate Customer to Task
                .flatMap {

                    Log.e(
                        TAG,
                        "commonTaskDetails - accountNumber 22:${callRequest.accountNumber} "
                    )
                    localDb?.commonTaskModelDao()
                        ?.getByAccountNumber(callRequest.accountNumber.toString())

                }.flatMap {
                    if (isPresent) {
                        var date: Date? = null
                        date = Util.getCurrentDate()

                        if (date == null) {
                            date = Calendar.getInstance().time
                        }

                        if (it == null) {
                            commonTaskDetails = CommonTaskModel(
                                status = /*atRiskAccount!!.taskStatus!!*/Status.CALLED,
                                accountNumber = atRiskAccount!!.accountNumber!!,
                                latitude = atRiskAccount!!.latitude!!,
                                longitude = atRiskAccount!!.longitude!!,
                                migrationCount = /*atRiskAccount!!.taskMigrationCount*/0,
                                accountAngazaId = atRiskAccount!!.accountAngazaId,
                                addedDaysAgo = /*atRiskAccount!!.taskAddedDaysAgo*/0,
                                address = atRiskAccount!!.address,
                                alternateContacts = atRiskAccount!!.alternateContacts!!,
                                attempt = atRiskAccount!!.taskAttempt!!,
                                balanceAmount = atRiskAccount!!.balanceAmount!!.toInt(),
                                callDetail = atRiskAccount!!.callDetail,
                                daysDisabled = atRiskAccount!!.daysDisabled,
                                expectedPaid = atRiskAccount!!.accountExpectedPaid!!.toString(),
                                extraParamTask = /*atRiskAccount!!.extraParamTask*/"",
                                groupName = atRiskAccount!!.product_name,
                                latestPayment = atRiskAccount!!.lastPaidDate,
                                ownerName = atRiskAccount!!.customerName,
                                ownerPhoneNumber = atRiskAccount!!.ownerPhoneNumber,
                                registrationDate = atRiskAccount!!.registrationDate,
                                secondaryPhoneNumber = atRiskAccount!!.secondaryPhoneNumber,
                                taskId = atRiskAccount!!.taskId,
                                ticketType = atRiskAccount!!.taskStatus/*Status.CALLED*/,
                                totalPaid = atRiskAccount!!.totalPaid!!.toInt(),
                                weekPaid = /*atRiskAccount!!.weekPaid*/0,
                                // for visits
                                barcode = false,
                                imageCapture = false,
                                visitDoneControl = 0,
                                visitMigrationCount = 0,
                                //region dynamic question for visits...
                                dynamicQuestions = emptyList(),

                                paymentAmount = 0,
                                resolvedType = "",

                                //endregion
                            )

                        } else {
                            commonTaskDetails = it

                            if (commonTaskDetails?.callDetail != null) {
                                commonTaskDetails?.callDetail?.add(
                                    CallDetailModel(
                                        attempt = callRequest.attempt!!,
                                        callDetailId = 0,
                                        calledNumber = callRequest.contactedNumber,
                                        date = TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!),
                                        duration = callRequest.callDuration.toString(),
                                        extraParamCallDetail = "",
                                        feedbackId = callRequest.feedbackId,
                                        followupDate = callRequest.newVisitDate,
                                        intentId = callRequest.intentId,
                                        otherReason = callRequest.otherReason,
                                        isVisit = false,
                                        visitDetail = null
                                    )
                                )
                            } else {
                                commonTaskDetails?.callDetail = mutableListOf()
                                commonTaskDetails?.callDetail?.add(
                                    CallDetailModel(
                                        attempt = callRequest.attempt!!,
                                        callDetailId = 0,
                                        calledNumber = callRequest.contactedNumber,
                                        date = TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!),
                                        duration = callRequest.callDuration.toString(),
                                        extraParamCallDetail = "",
                                        feedbackId = callRequest.feedbackId,
                                        followupDate = callRequest.newVisitDate,
                                        intentId = callRequest.intentId,
                                        otherReason = callRequest.otherReason,
                                        isVisit = false,
                                        visitDetail = null
                                    )
                                )
                            }
                            Log.e(TAG, "commonTaskDetails -1 => :$commonTaskDetails ")
                            if (commonTaskDetails!!.ticketType.equals("Visit", true)) {
                                Log.e(TAG, "commonTaskDetails -Visits => :$commonTaskDetails ")
                            } else {
                                if (callRequest.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
                                    commonTaskDetails!!.status = Status.CALLED
                                    commonTaskDetails!!.ticketType = Status.CALLED
                                }
                            }
                        }
                        Single.fromCallable {
                            localDb?.commonTaskModelDao()?.insert(commonTaskDetails!!)
                        }
                    } else {
                        null
                    }

                }

        }

        else {
//not present in Task
            return Single.fromCallable {
                localDb?.atRiskCallDetailRequestModelDao()?.insert(callRequest)
            }.flatMap {
                Log.e(
                    TAG,
                    "commonTaskDetails - else - accountNumber:${callRequest.accountNumber.toString()} "
                )
                localDb?.atRiskDao()
                    ?.getByAccountNumber(callRequest.accountNumber.toString())
            }.flatMap {
                atRiskAccount = it
                var date: Date? = null
                date = Util.getCurrentDate()

                if (date == null) {
                    date = Calendar.getInstance().time
                }
                if (atRiskAccount?.callDetail != null) {
                    atRiskAccount?.callDetail?.add(
                        CallDetailModel(
                            attempt = callRequest.attempt!!,
                            callDetailId = 0,
                            calledNumber = callRequest.contactedNumber,
                            date = TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!),
                            duration = callRequest.callDuration.toString(),
                            extraParamCallDetail = "",
                            feedbackId = callRequest.feedbackId,
                            followupDate = callRequest.newVisitDate,
                            intentId = callRequest.intentId,
                            otherReason = callRequest.otherReason,
                            isVisit = false,
                            visitDetail = null
                        )
                    )
                } else {
                    atRiskAccount?.callDetail = mutableListOf()
                    atRiskAccount?.callDetail?.add(
                        CallDetailModel(
                            attempt = callRequest.attempt ?: 1,
                            callDetailId = 0,
                            calledNumber = callRequest.contactedNumber,
                            date = TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!),
                            duration = callRequest.callDuration.toString(),
                            extraParamCallDetail = "",
                            feedbackId = callRequest.feedbackId,
                            followupDate = callRequest.newVisitDate,
                            intentId = callRequest.intentId,
                            otherReason = callRequest.otherReason,
                            isVisit = false,
                            visitDetail = null
                        )
                    )
                }

                Log.e(TAG, "atRiskAccount -1 - else - => :$atRiskAccount ");

                val newSummaryCall = AtRiskCall(
                    accountAngazaId = atRiskAccount?.accountAngazaId!!,
                    accountNumber = atRiskAccount?.accountNumber,
                    attempt = callRequest.attempt,
                    callDuration = callRequest.callDuration,
                    callType = "AT_RISK_CALL",
                    calledAt = Util.formateDatetoDDMMYYYYHHMMSS(date!!),
                    contactedNumber = callRequest.contactedNumber,
                    country = preference!!.getLoginResponseModel()!!.country,
                    customerIntent = callRequest.intentId,
                    feedbackCode = callRequest.feedbackId,
                    followUpDate = callRequest.newVisitDate,
                    imei = callRequest.imei,
                    isTask = atRiskAccount!!.isTask ?: false,
                    otherReason = callRequest.otherReason ?: "",
                    taskId = atRiskAccount?.taskId!!,
                    ticketType = atRiskAccount!!.taskStatus ?: "1st Call"
                )


                if (atRiskAccount!!.taskStatus.equals("VISIT", true)) {
                    atRiskAccount!!.eligibleForReimbursement = false
                } else {
                    if (callRequest.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
                        atRiskAccount?.taskStatus = LEAD_STATUS.CALLED
                        atRiskAccount!!.eligibleForReimbursement = false
                    }
                    if (newSummaryCall.ticketType != "CALLED") {
                        val oldCallMade = preference?.getNewTaskCallMade() ?: 0
                        preference?.setNewTaskCallMade(oldCallMade + 1)
                    }
                }

                Single.fromCallable {
                    localDb?.atRiskCallPostRequestDao()?.insert(newSummaryCall)
                }

            }.flatMap {
                Log.e(TAG, "atRiskAccount -2 => :$atRiskAccount ")
                Single.fromCallable {
                    localDb?.atRiskDao()
                        ?.insertAtRisk(atRiskAccount!!)
                }
            }
        }

    }


    private fun solveRateCalledDetails(angazaId: String): Single<NewCommonResponseModel<NewEmptyParcelable>?> {

        return localDb?.atRiskCallPostRequestDao()?.getAll()!!
            .flatMap {
                if (it.isNullOrEmpty()) {
                    Single.just(
                        NewCommonResponseModel(
                            success = false,
                            error = NewCommonResponseModel.Error(messageToUser = "No Calls to solve")
                        )
                    )
                } else {
                    sendCallDetailRequestToServer(angazaId, AtRiskCallPostRequest(it))
                }
            }
    }

    //Post and delete
    private fun sendCallDetailRequestToServer(
        angazaId: String,
        callPostRequest: AtRiskCallPostRequest
    ): Single<NewCommonResponseModel<NewEmptyParcelable>?> {

        var response: NewCommonResponseModel<NewEmptyParcelable>? = null

        return ServiceInstance.getInstance(context!!).service?.solveAtRiskCall(
            angazaId,
            callPostRequest
        )!!
            .flatMap {
                response = it
                Single.fromCallable {
                    localDb?.atRiskCallPostRequestDao()?.deleteAll()
                }
            }
            .flatMap { Single.just(response) }
    }

    fun solveAllAtRisk(): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        bag.add(
            solveRateCalledDetails(angazaId!!)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "solveTaskCallDetailRequest - success: ${it}")
                    data.postValue(it)
                }, { t ->
                    ErrorUtils.errorDatabase(
                        t,
                        TAG,
                        "solveCallDetailRequest",
                        "Unable to save data to database",
                        data
                    )
                })
        )
        return data
    }
}
