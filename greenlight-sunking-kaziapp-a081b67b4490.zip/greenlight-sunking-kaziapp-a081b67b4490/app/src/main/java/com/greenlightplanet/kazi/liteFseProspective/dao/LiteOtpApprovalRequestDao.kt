package com.greenlightplanet.kazi.liteFseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.liteFseProspective.model.LiteOtpApprovalRequestModel
import io.reactivex.Single

@Dao
interface LiteOtpApprovalRequestDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(OtpApprovalRequest: List<LiteOtpApprovalRequestModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(OtpApprovalRequestModel: LiteOtpApprovalRequestModel): Long

    @Delete
    fun delete(OtpApprovalRequestModel: LiteOtpApprovalRequestModel): Int

    @Query("DELETE FROM LiteOtpApprovalRequest")
    fun deleteAll(): Int

    @Query("SELECT * FROM LiteOtpApprovalRequest")
    fun getAll(): Single<List<LiteOtpApprovalRequestModel>>

    @Query("SELECT * FROM LiteOtpApprovalRequest LIMIT 1")
    fun get(): Single<LiteOtpApprovalRequestModel>

    @Query("SELECT COUNT(*) from LiteOtpApprovalRequest")
    fun count(): Single<Int>

    @Query("SELECT * FROM LiteOtpApprovalRequest WHERE prospectId=:prospectId LIMIT 1")
    fun getByProspectId(prospectId: String): Single<LiteOtpApprovalRequestModel>?

    @Query("SELECT * FROM LiteOtpApprovalRequest WHERE prospectId IN (:prospectId)")
    fun getAllByProspectID(prospectId: List<String>): Single<List<LiteOtpApprovalRequestModel>?>

}
