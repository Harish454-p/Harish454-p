package com.greenlightplanet.kazi.dashboard.model


import androidx.room.ColumnInfo
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import com.google.gson.annotations.SerializedName

@Parcelize
data class PutBeforeLogoutModel(
    @ColumnInfo(name = "angazaId")
    @SerializedName("angazaId")
    var angazaId: String,
    @ColumnInfo(name = "forceLogOut")
    @SerializedName("forceLogOut")
    var forceLogOut: Boolean = false
) : Parcelable
