package com.greenlightplanet.kazi.incentivenew.model.summary

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import com.greenlightplanet.kazi.incentivenew.model.deduction.SubFields
import kotlinx.android.parcel.Parcelize

/**
 * Created by Rahul on 09/12/20.
 */

@Parcelize
@Entity
data class SummaryFields (

        @ColumnInfo
        @SerializedName("name") val name : String?,

        @ColumnInfo
        @SerializedName("value") val value : String?,

        @ColumnInfo
        @SerializedName("fieldType") val fieldType : String?,

        @ColumnInfo
        @SerializedName("displayCurrency") val displayCurrency : Boolean?,

        @PrimaryKey
        @ColumnInfo
        @SerializedName("id") val id : String,

        @ColumnInfo
        @SerializedName("fieldValueDataType") val fieldValueDataType : String?,

        @ColumnInfo
        @SerializedName("subFields") val subFields : List<SubFields>?
):Parcelable