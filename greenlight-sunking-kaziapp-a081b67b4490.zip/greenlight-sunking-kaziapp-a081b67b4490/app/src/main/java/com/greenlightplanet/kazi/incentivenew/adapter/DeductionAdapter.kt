package com.greenlightplanet.kazi.incentivenew.adapter


import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.DeductionListTemBinding
import com.greenlightplanet.kazi.incentivenew.model.deduction.DeductionFields
import com.greenlightplanet.kazi.utils.Constants
import com.greenlightplanet.kazi.utils.Util


/**
 * Created by Rahul on 03/12/20.
 */
class DeductionAdapter(
    private val listData: List<DeductionFields>,
   private var listener: MyDateData, var context: Context, private var webListener: WebCallBack
) : RecyclerView.Adapter<DeductionAdapter.ViewHolder?>() {

    private val TAG = "DeductionAdapter"
    private var lastPosition = -1

    override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
    ): ViewHolder {
        val itemBinding = DeductionListTemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(itemBinding,listener,webListener)
    }

    @SuppressLint("WrongConstant")
    override fun onBindViewHolder(
            holder: ViewHolder,
            position: Int
    ) {
        val myListData: DeductionFields = listData[position]

holder.bind(myListData)

    }

    override fun getItemCount(): Int {
        return listData.size
    }

    class ViewHolder(
        val itemBinding: DeductionListTemBinding,
      val listener: MyDateData,
       val webListener: WebCallBack
    ) : RecyclerView.ViewHolder(itemBinding.root) {

        private val viewPool = RecyclerView.RecycledViewPool()
        var hashmap: HashMap<String?, String?> = HashMap<String?, String?>()
        @SuppressLint("WrongConstant")
        fun bind(myListData: DeductionFields) {





            itemBinding.tvComponentValue?.text = myListData.name
            try {

                if (myListData.fieldValueDataType.equals("DOUBLE", true) ||
                    myListData.fieldValueDataType.equals("INTEGER", true)) {
                    itemBinding.tvAmountValue?.text = myListData.value?.toDouble()?.let { Util.formatAmount(it) }
                } else {
                    itemBinding.tvAmountValue?.text = myListData.value.toString()
                }
            } catch (e: Exception) {
                Log.e("DeductionAdapter", "onBindViewHolder: $e")
            }


            if (myListData.fieldType.equals(Constants.LOOKUP_RIGHT_ARROW_WEB_RENDER)) {
                itemBinding.imgWebIcon.visibility = View.VISIBLE
            } else {
                itemBinding.imgWebIcon.visibility = View.GONE
            }

            itemBinding.imgWebIcon.setOnClickListener {
                myListData.renderLink?.let { it1 -> webListener.getWebLink(it1) }
            }


            if (myListData.fieldType.equals(Constants.DOWN_ARROW)) {
                itemBinding.imgDownIcon.visibility = View.VISIBLE
            } else {
                itemBinding.imgDownIcon.visibility = View.GONE
            }


            itemBinding.imgDownIcon.setOnClickListener {
                myListData.id.let { it1 -> listener.selectedData(it1, position) }
            }

            itemBinding.imgDownIcon.setOnClickListener(null)
            if (hashmap.containsValue(myListData.id)) {
                itemBinding.rvChild?.visibility = View.VISIBLE

            } else {
                itemBinding.rvChild?.visibility = View.GONE

            }


            itemBinding.imgDownIcon.setOnClickListener {

                if (hashmap.containsValue(myListData.id)) {
                    hashmap.remove(myListData.id)
                    itemBinding.rvChild?.visibility = View.GONE
                    itemBinding.imgDownIcon.rotation = Constants.ROTATION_360


                } else {
                    itemBinding.imgDownIcon.rotation = Constants.ROTATION_180

                    hashmap.put(myListData.id, myListData.id)
                    itemBinding.rvChild?.visibility = View.VISIBLE


                }
            }


            val childLayoutManager = LinearLayoutManager(
                itemBinding.rvChild?.context, LinearLayout.VERTICAL, false
            )

            childLayoutManager.initialPrefetchItemCount = 4
            itemBinding.rvChild?.apply {
                layoutManager = childLayoutManager
                adapter = myListData.subFields?.let { DeductionChildAdapter(it) }
                setRecycledViewPool(viewPool)
            }



        }
    }

    interface MyDateData {

        fun selectedData(date: String, position: Int)

    }

    interface WebCallBack {
        fun getWebLink(link: String)

    }


}