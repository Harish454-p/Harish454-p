package com.greenlightplanet.kazi.liteFseProspective.extras

import androidx.lifecycle.MutableLiveData
import android.os.Parcelable
import android.util.Log
import com.google.gson.Gson
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import retrofit2.HttpException

class ErrorUtils {
    companion object {

        public const val TAG = "ErrorUtils"


        fun <T : Parcelable> errorHandler(
                gson: Gson?,
                t: Throwable,
                tag: String = TAG,
                errorTag: String,
                messageToUser: String = "",
                data: MutableLiveData<NewCommonResponseModel<T>?>?,
                customLogic: () -> Unit = {}
        ) {

            val isApi = t is HttpException

            if (isApi) {
                errorApi(gson, t, tag, errorTag, messageToUser, data, customLogic)
            } else {
                errorDatabase(t, tag, errorTag, messageToUser, data, customLogic)
            }
        }


        fun <T : Parcelable> errorApi(gson: Gson?, t: Throwable, tag: String = TAG, errorTag: String, messageToUser: String = "", data: MutableLiveData<NewCommonResponseModel<T>?>?, customLogic: () -> Unit = {}) {
            var error: HttpException? = null
            try {
                error = t as HttpException
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(TAG, "errorApi: ${e.localizedMessage}")
            }


            val errorBody = error?.response()?.errorBody()?.string()
                    ?: "Something went wrong, Please try again"
            val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)

            customLogic()

            val messageToUserResult = errorModel?.error?.messageToUser
                    ?: messageToUser

            data?.postValue(NewCommonResponseModel<T>(
                    error = NewCommonResponseModel.Error(
                            messageToUser = messageToUserResult
                    ),
                    success = false

            ))

            Log.d(tag, "$errorTag - error|errorBody : $errorBody")
            Log.d(tag, "$errorTag - error|messageToUser : $messageToUserResult")
            Log.d(tag, "$errorTag - error|errorMessage: ${t.localizedMessage}")
        }


        fun <T : Parcelable> errorDatabase(t: Throwable, tag: String = TAG, errorTag: String, messageToUser: String = "", data: MutableLiveData<NewCommonResponseModel<T>?>?, customLogic: () -> Unit = {}) {

            customLogic()

            data?.postValue(NewCommonResponseModel<T>(
                    error = NewCommonResponseModel.Error(
                            messageToUser = messageToUser
                    ),
                    success = false

            ))

            Log.d(tag, "$errorTag - error|errorBody : ${t.printStackTrace()}")
            Log.d(tag, "$errorTag - error|errorCause : ${t.cause}")
            Log.d(tag, "$errorTag - error|messageToUser : ${t.localizedMessage}")
            Log.d(tag, "$errorTag - error|errorMessage: ${t.message}")
        }


        @JvmName("errorDatabaseList")
        fun <T : Parcelable> errorDatabase(t: Throwable, tag: String = TAG, errorTag: String, messageToUser: String = "", data: MutableLiveData<List<T>>, customLogic: () -> Unit = {}) {

            customLogic()

            data.postValue(null)

            Log.d(tag, "$errorTag - error|errorBody : ${t.printStackTrace()}")
            Log.d(tag, "$errorTag - error|errorCause : ${t.cause}")
            Log.d(tag, "$errorTag - error|messageToUser : ${t.localizedMessage}")
            Log.d(tag, "$errorTag - error|errorMessage: ${t.message}")
        }
    }


}
