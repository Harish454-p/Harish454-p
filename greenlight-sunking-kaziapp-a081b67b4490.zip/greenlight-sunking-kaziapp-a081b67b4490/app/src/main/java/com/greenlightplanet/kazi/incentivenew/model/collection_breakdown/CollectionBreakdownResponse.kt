package com.greenlightplanet.kazi.incentivenew.model.collection_breakdown

import android.os.Parcelable
import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.IgnoredOnParcel
import kotlinx.parcelize.Parcelize

@Keep
@Parcelize
data class CollectionBreakdownResponse(
    val Request: Request?,
    val ResponseData: CollectionBreakdownData?,
    val ResponseStatus: Int?,
    val Success: Boolean?,
    val serverIp: String?,
    val serverPort: String?
): Parcelable

@Keep
@Parcelize
data class Request(
    val ExecutionTime: Double?
): Parcelable

@Keep
@Parcelize
@Entity(tableName = "collectionBreakdownData")
data class CollectionBreakdownData(
    val collectionSummary: List<Content>? = null,
    val incentiveWeek: String?,
    val totalCommision: Int?,
    var angazaId: String? = null
): Parcelable {
    @IgnoredOnParcel
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0
}