package com.greenlightplanet.kazi.feedback.feedback_utils

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.Toast
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ImagePopWindowBinding
import com.greenlightplanet.kazi.liteFseProspective.extras.resizer.Resizer
import io.reactivex.Flowable
import io.reactivex.Single
import java.io.File

class ImageUploadUtil {

    companion object {
        public const val TAG = "ImageUploadUtil"


        fun resizeFlowable(context: Context, file: File): Flowable<File> {

            return Resizer(context)
                    .setQuality(80)
                    .setOutputFormat("JPEG")
                    .setOutputFilename(file.nameWithoutExtension)
                    //.setOutputDirPath("/sdcard/DCIM/")//change the location to the application's own folder so that user wont be able to access it from gallery
                    .setOutputDirPath(context.getFilesDir().path)//change the location to the application's own folder so that user wont be able to access it from gallery
                    .setSourceImage(file)
                    .resizedFileAsFlowable

        }


        fun compress(context: Context, listFile: List<File>): Single<MutableList<File>>? {

            //bag.add(
            return Flowable.just(listFile)
                    .flatMapIterable { file -> listFile }
                    .flatMap { resizeFlowable(context, it) }
                    .toList()


            /* .subscribe({
                 val fileModel = mutableListOf<AmazonS3Helper.FileModel>()

                 for (file in it) {
                     Log.d(TAG, "Success: ${file.path}\n");
                     fileModel.add(AmazonS3Helper.FileModel(fileName = file.name, file = file, awsLink = null))
                 }



                 amazonS3Helper.startUploadProcess(fileModel)

             }, {
                 Log.d(TAG, "Error:${it.localizedMessage} ");
                 it.printStackTrace()
             })*/
            //)

        }

        fun ImageEnlargeDialog(context: Activity, url: String): Dialog {
            var parent: ViewGroup

            var itemBinding:ImagePopWindowBinding ? = null
            val dialog = Dialog(context)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            itemBinding = ImagePopWindowBinding.inflate(LayoutInflater.from(context))
            dialog.setContentView(itemBinding.root)
           // dialog.setContentView(R.layout.image_pop_window)
            dialog.setCanceledOnTouchOutside(true)
            var width = 0
            var height = 0

            dialog.setCancelable(true)
            val size = Point()
            val w = context.windowManager

            w.defaultDisplay.getSize(size)
            width = size.x - 30
            height = size.y - 40

            parent = itemBinding.image.parent as ViewGroup
            dialog.setCancelable(true)
            dialog.setCanceledOnTouchOutside(true)
            Glide.with(context)
                    .load(url)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .listener(object : RequestListener<Drawable> {
                        override fun onLoadFailed(
                                e: GlideException?,
                                model: Any?,
                                target: Target<Drawable>?,
                                isFirstResource: Boolean
                        ): Boolean {
                            Log.e("Mazhar ---=== ", "Failed == $isFirstResource ==== $e")
                            dialog.dismiss()
                            Toast.makeText(context, "Image not available", Toast.LENGTH_SHORT).show()
                            return false
                        }

                        override fun onResourceReady(
                                resource: Drawable?,
                                model: Any?,
                                target: Target<Drawable>?,
                                dataSource: DataSource?,
                                isFirstResource: Boolean
                        ): Boolean {
//                            val bitmapaaa: BitmapDrawable = resource as BitmapDrawable
//                            parent.background = BitmapDrawable(context.getResources(), IConstants.fastblur(bitmapaaa.bitmap))// ));
                            return false
                        }
                    }).into(itemBinding.image)


            itemBinding.image.setOnClickListener {
                dialog.dismiss()
            }
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT)

            itemBinding.ibClose.setOnClickListener {
                dialog.dismiss()
            }

            if (dialog != null)
                dialog.show()

            return dialog
        }

    }

    data class ImageModel(
            var file: File?, // File
            var angazaId: String,//
            var imageName: String = "" // 3
    )


}