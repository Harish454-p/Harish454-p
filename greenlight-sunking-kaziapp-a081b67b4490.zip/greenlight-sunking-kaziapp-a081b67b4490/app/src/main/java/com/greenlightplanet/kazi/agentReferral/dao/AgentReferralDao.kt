package com.greenlightplanet.kazi.agentReferral.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.agentReferral.model.agentreferral.AgentReferralModel
import io.reactivex.Single

@Dao
interface AgentReferralDao {
    @Query("SELECT * FROM AgentReferralModel")
    fun getAgentReferral() : Single<List<AgentReferralModel>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAgentReferral(agentReferralModel: AgentReferralModel)

    @Query("DELETE FROM AgentReferralModel")
    fun deleteAllAgentReferral() : Int
}