package com.greenlightplanet.kazi.agentReferral.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_error
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_failed
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_in_progress
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_prospect_resub
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_success
import com.greenlightplanet.kazi.agentReferral.model.referredagentlist.ReferredAgent
import com.greenlightplanet.kazi.agentReferral.ui.view.ReferredAgentListActivity
import com.greenlightplanet.kazi.databinding.AdapterReferredAgentBinding
import com.greenlightplanet.kazi.utils.Util

class ReferredAgentAdapter(val referredAgentListActivity: ReferredAgentListActivity, var list : ArrayList<ReferredAgent>) : RecyclerView.Adapter<ReferredAgentAdapter.ViewHold>() {

    class ViewHold(val binder : AdapterReferredAgentBinding) : RecyclerView.ViewHolder(binder.root) {
        fun bindInfo(model : ReferredAgent, referredAgentListActivity: ReferredAgentListActivity) {
            binder.run {
                txtChildNumber.text = when(model.childPhoneNumber) {
                    null -> referredAgentListActivity.getString(R.string.na)
                    else -> model.childPhoneNumber
                }
                Util.addUnderline2(txtChildNumber)
                txtRegisDate.text = when(model.referredDate) {
                    null -> referredAgentListActivity.getString(R.string.na)
                    else -> model.referredDate
                }
                txtChildStatus.text = when(model.currentStage) {
                    null -> referredAgentListActivity.getString(R.string.na)
                    else -> model.currentStage
                }
                when(model.status) {
                    status_success -> txtChildStatus.setTextColor(ContextCompat.getColor(referredAgentListActivity, R.color.green))
                    status_error, status_failed -> txtChildStatus.setTextColor(ContextCompat.getColor(referredAgentListActivity, R.color.red))
                    status_prospect_resub, status_in_progress -> txtChildStatus.setTextColor(ContextCompat.getColor(referredAgentListActivity, R.color.black))
                }
                txtChildNumber.setOnClickListener {
                    referredAgentListActivity.onAgentSelected(model = model)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHold {
        val binder : AdapterReferredAgentBinding = AdapterReferredAgentBinding.inflate(
            LayoutInflater.from(referredAgentListActivity),
            parent,
            false
        )
        return ViewHold(binder)
    }

    override fun onBindViewHolder(holder: ViewHold, position: Int) {
        holder.bindInfo(list[position], referredAgentListActivity)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    interface OnReferredAgent {
        fun onAgentSelected(model : ReferredAgent)
    }
}