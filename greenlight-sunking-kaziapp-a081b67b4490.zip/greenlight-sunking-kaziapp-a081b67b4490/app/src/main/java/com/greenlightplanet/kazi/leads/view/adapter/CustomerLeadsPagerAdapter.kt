package com.greenlightplanet.kazi.leads.view.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager.widget.PagerAdapter
import com.greenlightplanet.kazi.leads.extras.LEAD_TAB
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead
import com.greenlightplanet.kazi.leads.view.fragment.CustomerLeadsFragment

class CustomerLeadsPagerAdapter(fm: FragmentManager, var pendingList: List<LeadsCrossSalesLead>, var calledList: List<LeadsCrossSalesLead>)
    : FragmentStatePagerAdapter(fm) {


    companion object {
        public const val TAG = "CustomerLeadsPagerAdapter"

    }

    var pendingFragment: CustomerLeadsFragment? = null
    var calledFragment: CustomerLeadsFragment? = null

    override fun getCount(): Int {
        return 2
    }

    override fun getItem(position: Int): Fragment {
        val fragment: Fragment? = null

        when (position) {
            0 -> {
                pendingFragment = CustomerLeadsFragment.newInstance(pendingList, LEAD_TAB.PENDING)
                return pendingFragment as Fragment
            }
            1 -> {
                calledFragment = CustomerLeadsFragment.newInstance(calledList, LEAD_TAB.CALLED)
                return calledFragment as Fragment
            }
            else ->
                return fragment!!
        }
    }


    override fun getItemPosition(`object`: Any): Int {
        return PagerAdapter.POSITION_NONE
    }

    override fun getPageTitle(position: Int): CharSequence {
        var title: String? = null
        when (position) {
            0 -> {
                title = LEAD_TAB.PENDING
                return title
            }
            1 -> {
                title = LEAD_TAB.CALLED
                return title
            }
            else ->
                return title!!
        }
    }

}
