package com.greenlightplanet.kazi.collectiongoal.view.fragment

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.KaziApplication.Companion.preference
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.collectiongoal.adapter.AchievedListRecyclerAdapter
import com.greenlightplanet.kazi.collectiongoal.model.pastweekincentive.LastWeekIncentiveModel
import com.greenlightplanet.kazi.collectiongoal.view.activity.AccountLastWeekAcitivity
import com.greenlightplanet.kazi.collectiongoal.viewmodel.CommonWeekIncentiveViewmodel
import com.greenlightplanet.kazi.databinding.FragmentCommonLastWeekIncentiveBinding
import com.greenlightplanet.kazi.utils.BaseFragment
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util


class AchievedFragment : BaseFragment() {

    private var _binding: FragmentCommonLastWeekIncentiveBinding? = null
    private val binding get() = _binding!!
    val ARG_PARAM1 = "list"
    val ARG_PARAM2 = "type"

    private var type: Boolean = false
    private var list: MutableList<LastWeekIncentiveModel.AchievedAccount>? = null
    private var activityInstance: AccountLastWeekAcitivity? = null

    private val viewModel: CommonWeekIncentiveViewmodel by activityViewModels()

    private var adapterList: MutableList<LastWeekIncentiveModel.AchievedAccount> = mutableListOf()
    private var adapter: AchievedListRecyclerAdapter? = null

    var achievedListSize = 0

    var lastWeekIncentiveModel: LastWeekIncentiveModel? = null

    var tempList = mutableListOf<LastWeekIncentiveModel.AchievedAccount>()


    companion object {
        const val TAG = "NewTaskFragment"

        @JvmStatic
        fun newInstance(list: List<LastWeekIncentiveModel.AchievedAccount>?, type: Boolean) =
            AchievedFragment().apply {
                arguments = Bundle().apply {
                    putParcelableArrayList(ARG_PARAM1, ArrayList(list!!))
                    putBoolean(ARG_PARAM2, type)
                    arguments?.clear()
                }
            }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapterList.clear()
        arguments?.let {
            list = it.getParcelableArrayList<LastWeekIncentiveModel.AchievedAccount>(ARG_PARAM1)
            type = it.getBoolean(ARG_PARAM2)
            arguments?.clear()
        }
    }

    val observer1 = Observer<MutableList<LastWeekIncentiveModel.AchievedAccount>>{

        if (this.lifecycle.currentState== Lifecycle.State.RESUMED) {

            cancelProgressDialog()

            Util.hideKeyboard(requireActivity())

            if (it.isNullOrEmpty()){
                binding.tvBottom.visibility = View.GONE
            } else {
                val CommonList = mutableListOf<LastWeekIncentiveModel.AchievedAccount>()

                Log.d("CheckingSizeOnFragment2", "achievedListSize$achievedListSize ${adapterList.size}")
                CommonList.addAll(it)
                achievedListSize = adapterList.size
                Log.d("CheckingSizeOnFragment1", "achievedListSize: ${CommonList.size}  $achievedListSize")

                setAdapter(CommonList)
                val bottom: Int? = binding.recyclerView.adapter?.itemCount?.minus(1)
                binding.recyclerView.scrollToPosition(achievedListSize-1)
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (!viewModel.achievedListDataSend.hasActiveObservers()){
            viewModel.achievedListDataSend.observe(viewLifecycleOwner,observer1)
        }
    }

    @SuppressLint("LongLogTag")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        // Inflate the layout for this fragment

        _binding = FragmentCommonLastWeekIncentiveBinding.inflate(inflater, container, false)
        activityInstance = (activity as AccountLastWeekAcitivity?)!!
        preference = GreenLightPreference.getInstance(activityInstance!!)

        binding.llpastWeekIncentiveItem.setBackgroundResource(R.color.black)
        binding.tvExpectedAmount.setTextColor(Color.parseColor("#FFFFFF"))
        binding.tvCollectedAmount.setTextColor(Color.parseColor("#FFFFFF"))
        binding.tvCustomerName.setTextColor(Color.parseColor("#FFFFFF"))

        Log.d("LastWeekFragmentList", "success:   ${list?.size}")
        Log.d("LastWeekFragmentType", "success: ${type}")

        initRecyclerView(list)

        setAdapter(list?.toMutableList())

        savedInstanceState?.clear()
        return binding.root;

    }

    private fun initSearchView(): Boolean {

        // below line is to call set on query text listener method.
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener,
            android.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(msg: String): Boolean {
                // inside on query text change method we are
                // calling a method to filter our recycler view.
                filter(msg)
                return false
            }
        })
        return true

    }

    private fun filter(text: String) {
        // creating a new array list to filter our data.
        val filteredlist: ArrayList<LastWeekIncentiveModel.AchievedAccount> = ArrayList()

        // running a for loop to compare elements.
        for (item in adapterList) {
            // checking if the entered string matched with any item of our recycler view.
            if (item.customerName?.lowercase()?.contains(text.lowercase())!!) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(item)
            }
        }
        if (filteredlist.isEmpty()) {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            visibilityHandler(false, false, true)
        } else {
            // at last we are passing that filtered
            // list to our adapter class.
            visibilityHandler(true, false, false)
            adapter?.filterList(filteredlist)
        }
    }


    @SuppressLint("UseCompatLoadingForDrawables")
    private fun initRecyclerView(list: MutableList<LastWeekIncentiveModel.AchievedAccount>?) {

        val layoutManager = LinearLayoutManager(requireActivity())
        binding.recyclerView.layoutManager = layoutManager
        binding.recyclerView.addItemDecoration(
            DividerItemDecoration(
                requireContext(),
                DividerItemDecoration.VERTICAL
            ).apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    this.setDrawable(
                        resources.getDrawable(
                            R.drawable.line_divider,
                            requireContext().theme
                        )
                    )
                } else {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider))
                }
            })

        initSearchView()

    }

    @SuppressLint("NotifyDataSetChanged", "LongLogTag")
    private fun setAdapter(mutableList: MutableList<LastWeekIncentiveModel.AchievedAccount>?) {

        adapterList.clear()
        if (!mutableList.isNullOrEmpty()) {
            adapterList.addAll(mutableList)
            Log.d("CheckingSizeOn_LWI_Fragment4", "CommonList ${adapterList.size}")
            adapter = AchievedListRecyclerAdapter(requireActivity(), adapterList)
            binding.recyclerView.adapter = adapter
            visibilityHandler(true, false, false)
        }else {
            visibilityHandler(false, true, false)
        }
        adapter?.notifyDataSetChanged()

        if (!binding.searchView.query.isNullOrEmpty() ){
            filter(binding.searchView.query.toString())
        }
    }

    private fun visibilityHandler(
        showRecyclerView: Boolean = false,
        showNoData: Boolean = false,
        showSearchNoData: Boolean = false,
    ) {

        if (showRecyclerView) {
            binding.recyclerView.visibility = View.VISIBLE
        } else {
            binding.recyclerView.visibility = View.GONE
        }

        if (showNoData) {
            binding.tvNoData.visibility = View.VISIBLE
        } else {
            binding.tvNoData.visibility = View.GONE
        }

        if (showSearchNoData) {
            binding.tvSearchedData.visibility = View.VISIBLE
        } else {
            binding.tvSearchedData.visibility = View.GONE
        }
    }




}