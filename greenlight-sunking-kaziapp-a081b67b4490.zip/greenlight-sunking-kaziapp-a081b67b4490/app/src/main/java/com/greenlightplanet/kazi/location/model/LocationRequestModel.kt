package com.greenlightplanet.kazi.location.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import org.jetbrains.annotations.NotNull

@Parcelize
@Entity(tableName = "LocationRequestModel")
data class LocationRequestModel(
	@ColumnInfo(name = "angazaId")
	@SerializedName("angazaId")
	var angazaId: String?, // 123456789
	@ColumnInfo(name = "battery")
	@SerializedName("battery")
	var battery: String?, // 99
	@ColumnInfo(name = "imei")
	@SerializedName("imei")
	var imei: String?, // 23232323
	@ColumnInfo(name = "latitude")
	@SerializedName("latitude")
	var latitude: String?, // 10.101010
	@PrimaryKey


	@NotNull
	@ColumnInfo(name = "deviceTimeSeconds")
	@SerializedName("deviceTimeSeconds")
	var deviceTimeMilli: Long, // no idea


	@NotNull
	@ColumnInfo(name = "deviceTime")
	@SerializedName("deviceTime")
	var deviceTime: String, // 16-04-2019 08:08:08
	@ColumnInfo(name = "longitude")
	@SerializedName("longitude")
	var longitude: String?, // 20.2020
	@ColumnInfo(name = "locationType")
	@SerializedName("locationType")
	var locationType: String?, // 20.2020
	@ColumnInfo(name = "accuracy")
	@SerializedName("accuracy")
	var accuracy: String?, // 20.2020


	@ColumnInfo(name = "taskPerformer")
	@SerializedName("taskPerformer")
	var taskPerformer: String?, // ALARM

	@ColumnInfo(name = "androidApiNumber")
	@SerializedName("androidApiNumber")
	var androidApiNumber: Int?, // 21


	@ColumnInfo(name = "networkData")
	@SerializedName("networkData")
	var networkData: String? = null //

) : Parcelable


