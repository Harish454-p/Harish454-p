package com.greenlightplanet.kazi.feedback.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.greenlightplanet.kazi.feedback.repo.repository.SupportFeedbackClosedRepository
import com.greenlightplanet.kazi.feedback.repo.repository.SupportFeedbackPendingRepository
import com.greenlightplanet.kazi.feedback.repo.model.response.TicketResponseData
import com.greenlightplanet.kazi.utils.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

@HiltViewModel
class SupportFeedbackViewModel @Inject constructor(
    private val closedRepo: SupportFeedbackClosedRepository,
    private val pendingRepo: SupportFeedbackPendingRepository
    ): ViewModel() {

    private val _ticketResponseLiveData = MutableLiveData<NetworkResult<List<TicketResponseData>>>()
    val ticketResponseLiveData get() = _ticketResponseLiveData

    var filteredClosedList = mutableListOf<TicketResponseData>()
    var filteredPendingList = mutableListOf<TicketResponseData>()

    var currentClosedList = mutableListOf<TicketResponseData>()
    var currentPendingList = mutableListOf<TicketResponseData>()


    var closedSearchedList = mutableListOf<TicketResponseData>()
    var pendingSearchedList = mutableListOf<TicketResponseData>()
    var isFilterAppliedClosed = false
    var isFilterAppliedPending = false
    var isSearchFilteredClosed = false
    var isSearchFilteredPending = false



    fun fetchClosedTicketsData(): Flow<PagingData<TicketResponseData>> {
        return closedRepo.getTicketsData()
            .cachedIn(viewModelScope)
    }

    fun fetchPendingTicketsData(): Flow<PagingData<TicketResponseData>> {
        return pendingRepo.getTicketsData()
            .cachedIn(viewModelScope)
    }



}