package com.greenlightplanet.kazi.incentivenew.model.collection_breakdown

import android.os.Parcelable
import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import kotlinx.parcelize.Parcelize
import java.util.*

@Keep
@Parcelize
data class AmountCollectedResponse(
    val ResponseData: ResponseData?,
    val ResponseStatus: Int?,
    val Success: Boolean?
): Parcelable

@Keep
@Entity(tableName = "collectionAmount")
@Parcelize
data class CollectionAccounts(
    @PrimaryKey(autoGenerate = false)
    val number: Int,
    val content: List<Content>? = null,
    val empty: Boolean?,
    val first: Boolean?,
    val last: Boolean?,
    val numberOfElements: Int?,
    val pageable: Pageable?,
    val size: Int?,
    val sort: SortX?,
    val totalElements: Int?,
    val totalPages: Int?,
    var angazaId: String? = null
): Parcelable

@Keep
@Parcelize
data class Content(
    val accountNumber: Int?,
    val angazaId: String?,
    @SerializedName("commision")
    val commission: Int?,
    @SerializedName("commisionPercentage")
    val commissionPercentage: Double?,
    val productName: String?,
    val totalAmountCollected: Int?,
    val productGroup: String?,
    val totalCollection: Int?
): Parcelable

@Keep
@Parcelize
data class Pageable(
    val offset: Int?,
    val pageNumber: Int?,
    val pageSize: Int?,
    val paged: Boolean?,
    val sort: SortX?,
    val unpaged: Boolean?
): Parcelable

@Keep
@Parcelize
data class ResponseData(
    val collectionAccounts: CollectionAccounts?
): Parcelable

@Keep
@Parcelize
data class SortX(
    val empty: Boolean?,
    val sorted: Boolean?,
    val unsorted: Boolean?
): Parcelable

@Keep
class IncentiveContentConverter {
    var gson = Gson()

    @TypeConverter
    fun stringToObjectList(data: String?): List<Content> {
        if (data == null) {
            return Collections.emptyList()
        }
        var listType = object : TypeToken<List<Content>>() {
        }.type
        return gson.fromJson<List<Content>>(
            data,
            listType
        )
    }

    @TypeConverter
    fun objectListToString(list: List<Content>): String {
        return gson.toJson(list)
    }
}

@Keep
class IncentiveContentPageConverter {
    var gson = Gson()

    @TypeConverter
    fun stringToObjectList(data: String?): Pageable? {
        if (data == null) {
            return null
        }
        return gson.fromJson<Pageable>(
            data,
            Pageable::class.java
        )
    }

    @TypeConverter
    fun objectListToString(data: Pageable): String {
        return gson.toJson(data)
    }
}

@Keep
class IncentiveContentSortXConverter {
    var gson = Gson()

    @TypeConverter
    fun stringToObjectList(data: String?): SortX? {
        if (data == null) {
            return null
        }
        return gson.fromJson<SortX>(
            data,
            SortX::class.java
        )
    }

    @TypeConverter
    fun objectListToString(data: SortX): String {
        return gson.toJson(data)
    }
}