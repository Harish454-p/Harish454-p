package com.greenlightplanet.kazi.feedback.view.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackConstants
import com.greenlightplanet.kazi.feedback.view.fragments.SupportFeedbackFragment
import com.greenlightplanet.kazi.leads.extras.LEAD_TAB
import com.greenlightplanet.kazi.newtasks.view.fragment.NewTaskFragment

class FeedbackPagerAdapter(fragmentManager: FragmentManager, lifecycle: Lifecycle): FragmentStateAdapter(fragmentManager, lifecycle) {

    var supportFeedbackFragmentClosed: SupportFeedbackFragment? = null
    var supportFeedbackFragmentPending: SupportFeedbackFragment? = null

    override fun getItemCount(): Int {
        return FeedbackConstants.NUM_TABS
    }

    override fun createFragment(position: Int): Fragment {
        val fragment: Fragment? = null

        when (position) {
            0 -> {
                if(supportFeedbackFragmentClosed == null){
                    supportFeedbackFragmentClosed = SupportFeedbackFragment().apply {
                        this.isClosedFrag = true
                    }
                }

                return supportFeedbackFragmentClosed as Fragment
            }
            1 -> {
                if(supportFeedbackFragmentPending == null){
                    supportFeedbackFragmentPending = SupportFeedbackFragment().apply {
                        this.isPendingFrag = true
                    }
                }
                return supportFeedbackFragmentPending as Fragment
            }
            else ->
                return fragment!!
        }
    }

    override fun getItemId(position: Int): Long {
        return super.getItemId(position)

    }
}