package com.greenlightplanet.kazi.incentivenew.activity

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.Keep
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivityAmountCollectedBinding
import com.greenlightplanet.kazi.databinding.FeedbackTicketSuccessDialogBinding
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.incentivenew.adapter.AdapterClickListener
import com.greenlightplanet.kazi.incentivenew.adapter.CollectionBreakdownAdapter
import com.greenlightplanet.kazi.incentivenew.common_utils.Constants
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.Content
import com.greenlightplanet.kazi.incentivenew.viewmodel.AmountCollectedViewModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.NetworkResult
import com.greenlightplanet.kazi.utils.Util
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber
import java.lang.ref.WeakReference
@Keep
@AndroidEntryPoint
class AmountCollectedActivity : BaseActivity(), AdapterClickListener {
    private lateinit var binding: ActivityAmountCollectedBinding
    private val viewModel by viewModels<AmountCollectedViewModel>()
    val adapter = CollectionBreakdownAdapter()
    var preference: GreenLightPreference? = null
    lateinit var progressdialog: Dialog
    lateinit var customDialog: Dialog
    var symbol = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAmountCollectedBinding.inflate(layoutInflater)
        setContentView(binding.root)
        progressdialog = Dialog(this@AmountCollectedActivity)
        customDialog = Dialog(this@AmountCollectedActivity)
        binding.tvViewMore.visibility = View.GONE
        observer()
        setListener()
        initToolbar()
        initOther()
        initializeRv()
        resetPageValues()
        initIntentData()
        updateSharedPref(false)
        clickHandler()
        binding.tvCommission.text = "Commission ($symbol)"
    }

    private fun initIntentData() {
        val intent = intent
        intent?.let {
            it.getStringExtra(Constants.ANGAZA_ID_INTENT)?.let { it ->
                viewModel.angazaId = it
            }
            it.getStringExtra(Constants.PRODUCT_NAME_INTENT)?.let { it ->
                viewModel.productName = it
            }

            it.getStringExtra(Constants.INCENTIVE_WEEK_INTENT)?.let { it ->
                viewModel.incentiveWeek = it
                binding.tvIncentiveWeek.text = "Incentive Week " + it
            }

//            it.getStringExtra(Constants.TOTAL_COMMISSION_INTENT)?.let { it ->
//                viewModel.totalCommission = it
//                val commaSeparated = Util.getOneDecimal(it.toDouble())
//                binding.tvTotalCommission.text = "Total Commission ($symbol $commaSeparated)"
//            }
            it.getStringExtra(Constants.COMMISSION_INTENT)?.let { it ->
                viewModel.commission = it
                val commaSeparated = Util.getOneDecimal(it.toDouble())
                binding.tvTotalCommission.text = "Total Commission ($symbol $commaSeparated)"
            }
            if (viewModel.angazaId.isNotEmpty() && viewModel.productName.isNotEmpty()) {
                if (Helper.isNetworkConnected()) {
                    Timber.d("Activity: FirstApiMode: User API Data Fetch Invoked for page-> ${viewModel.firstPage} ")
                    viewModel.invokeAmountCollectedData(
                        angazaId = viewModel.angazaId,
                        productName = viewModel.productName,
                        page = viewModel.firstPage
                    )
                } else {
                    with(viewModel) {
                        lifecycleScope.launch(Dispatchers.IO) {
                            val totalCachedPagesAvailable = getCountAmountCollectedData(viewModel.angazaId)
                            Timber.d("Activity: FirstOfflineMode: Total Page Found $totalCachedPagesAvailable ||Current page -> ${viewModel.firstPage} ")
                            if (totalCachedPagesAvailable != null && totalCachedPagesAvailable != 0) {
                                updateSharedPref(false)
                                totalCount = totalCachedPagesAvailable ?: -1
                                if (viewModel.firstPage < totalCount) {
                                    getSingleAmountCollectedCachedData(
                                        angazaId = viewModel.angazaId,
                                        productName = viewModel.productName,
                                        pageNo = viewModel.firstPage
                                    )
                                    Timber.d("Activity: FirstOfflineMode: Total Page Found $totalCachedPagesAvailable ||  Cached Data Fount and Fetch Invoked for page-> ${viewModel.firstPage} ")
                                }
                            }
                            else {
                                Timber.d("Activity: FirstOfflineMode: User Cached Data Not Found ")
                                runOnUiThread {
                                    binding.tvViewMore.visibility = View.GONE
                                    setNoDataVisibility(true)
                                    resetPageValues()
                                }
                            }
                        }

                    }
                }

            }
        }
    }

    private fun initOther() {
        val loginResponse = preference?.getLoginResponseModel()
        loginResponse?.angazaId?.let {
            viewModel.angazaId = it
        }

    }

    private fun initToolbar() {
        preference = GreenLightPreference.getInstance(this)
        symbol = Util.getCurrencyCode(
            preference?.getLoginResponseModel()?.country!!.lowercase().capitalize()
        ) ?: "NA"
        Util.setToolbar(this, binding.toolbar, "")
        binding.tvAppbottomVersion.text = getString(R.string.app_version, BuildConfig.VERSION_NAME)
    }

    private fun initializeRv() {
        val layoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager
        binding.recyclerView.adapter = adapter
        binding.recyclerView.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                this.setDrawable(resources.getDrawable(R.drawable.line_divider, theme))
            } else {
                this.setDrawable(resources.getDrawable(R.drawable.line_divider))
            }
        })
        adapter.attachListener(WeakReference(this))
    }

    fun setNoDataVisibility(isVisible: Boolean) {
        if (isVisible) binding.tvNoData.visibility = View.VISIBLE
        else binding.tvNoData.visibility = View.GONE
    }

    fun navigateToAmountCollectedScreen(angazaId: String, productName: String) {
        val intent = Intent(this, AmountCollectedActivity::class.java)
        intent.putExtra(
            Constants.ANGAZA_ID_INTENT,
            angazaId
        )
        intent.putExtra(
            Constants.PRODUCT_NAME_INTENT,
            productName
        )
        startActivity(intent)
    }


    private fun updateSharedPref(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadIncentiveFromPref(this)

        if (data == null) {
            data = LastSaved()
            data.collectionBreakdown = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(this, data)
            binding.tvLastSaved.text = data.collectionBreakdown

        } else {

            if (fromInternet) {
                data.collectionBreakdown = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(this, data)
                binding.tvLastSaved.text = data.collectionBreakdown
            } else {
                binding.tvLastSaved.text = data.collectionBreakdown

            }
        }

    }

    override fun onItemClicked(data: Content) {


    }

    private fun observer() {
        with(viewModel) {
            //User Network Observer
            amountCollectedLiveData.observe(this@AmountCollectedActivity) { response ->
                when (response) {
                    is NetworkResult.Success -> {
                        response.data?.let { userResponse ->
                            Timber.d("Activity: API Success -> $userResponse ")
                            response.data.number?.let {
                                currentPage = it
                            }
                            response.data.totalElements?.let {
                                count = it
                            }
                        }
                        hideProgressDialog()
                    }
                    is NetworkResult.DbSuccess -> {
                        response.isSuccess?.let {
                            hideProgressDialog()
                            if (it) {
                                if (response.data?.totalElements != 0) {
                                    setNoDataVisibility(false)
                                    updateSharedPref(true)
                                    Timber.d("ApiData: Room Cache Success : ${response.data}")
                                    lifecycleScope.launch(Dispatchers.IO) {
                                        val totalCachedPageSize = getCountAmountCollectedData(angazaId)
                                        totalCount = totalCachedPageSize ?: 0
                                        if (currentPage < totalCount) {
                                            Timber.d("ApiData: Room Cache Success: Feching  Data for Page: ${viewModel.currentPage}")
                                            viewModel.getSingleAmountCollectedCachedData(
                                                angazaId = angazaId,
                                                pageNo = currentPage,
                                                productName = productName
                                            )
                                            Timber.d("ApiData: Room Cache Success: Data Count Found: $totalCachedPageSize")
                                        }
                                    }
                                }
                            } else {
                                setNoDataVisibility(true)
                                resetPageValues()
                                Timber.d("UserApiData: Room Cache Failed")
                            }
                        }
                        hideProgressDialog()
                    }
                    is NetworkResult.Error -> {
                        response.message?.let {
                            showCustomDialog( it)
                            Timber.d("Api ERROR: $it")
                        }
                        setNoDataVisibility(true)
                        hideProgressDialog()
                    }
                    is NetworkResult.Exception -> {
                        hideProgressDialog()
                        response.message?.let {
                            showCustomDialog( it)
                            Timber.d("UserApi Exception: $it")
                        }
                        setNoDataVisibility(true)
                    }
                    is NetworkResult.Loading -> {
                        showProgress()
                    }
                }
            }



            singleAmountCollectedLiveData.observe(this@AmountCollectedActivity) {
                it?.let { pageResponse ->
                    if (Helper.isNetworkConnected() && currentPage == pageResponse.number) {
                        Timber.e("Single Data Called: isConnected: CurrentPage: $currentPage: responsePage: ${it.number}")
                        it.totalElements?.let {
                            count = it
                        }
                        if (!pageResponse.content.isNullOrEmpty()) {
                            if (viewModel.lastObservableList != pageResponse.content && pageResponse.content != viewModel.currentListForRv) {
                                viewModel.lastObservableList.clear()
                                viewModel.lastObservableList.addAll(pageResponse.content)
                                pageResponse.number.let { pNo ->
                                    if (pNo == 0) {
                                        adapter.clearRvData()
                                        viewModel.currentListForRv.clear()
                                    }
                                }
                                viewModel.currentListForRv.addAll(pageResponse.content)
                                Timber.d("Activity: ViewModel New updated AdapterList -> ${viewModel.currentListForRv}")
                                setNoDataVisibility(false)
                                adapter.setRvData(pageResponse.content,true)
                            }

                        }
                        if (pageResponse.last == true) {
                            binding.tvViewMore.visibility = View.GONE
                        } else {
                            binding.tvViewMore.visibility = View.VISIBLE
                        }
                    }
                    if (!Helper.isNetworkConnected()) {
                        it.totalElements?.let {
                            count = it
                        }
                        if (!pageResponse.content.isNullOrEmpty()) {
                            pageResponse.number.let { pNo ->
                                if (pNo == 0) {
                                    adapter.clearRvData()
                                    viewModel.currentListForRv.clear()
                                    viewModel.lastObservableList.clear()
                                }
                            }
                        }
                        if (pageResponse.last != true) {
                            if (!pageResponse.content.isNullOrEmpty()) {
                                if (viewModel.lastObservableList != pageResponse.content) {
                                    viewModel.lastObservableList.clear()
                                    viewModel.lastObservableList.addAll(pageResponse.content)
                                    viewModel.currentListForRv.addAll(pageResponse.content)
                                    Timber.d("Activity: ViewModel New updated AdapterList -> ${viewModel.currentListForRv}")
                                    setNoDataVisibility(false)
                                    adapter.setRvData(pageResponse.content,true)
                                }
                            }

                            if (pageResponse.last == true) {
                                binding.tvViewMore.visibility = View.GONE
                            } else {
                                binding.tvViewMore.visibility = View.VISIBLE
                            }
                        }

                    }

                }
            }


        }
    }

    private fun hideProgressDialog() {
        progressdialog.dismiss()
    }

    private fun showProgress() {
        progressdialog.setContentView(R.layout.progress_dialog)
        progressdialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        progressdialog.setCancelable(true)
        progressdialog.setCanceledOnTouchOutside(false);

        progressdialog.setOnCancelListener {
            onBackPressed()
        }
        try {
            if (!progressdialog.isShowing)
                progressdialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showCustomDialog(message: String) {
        val dialogView = FeedbackTicketSuccessDialogBinding.inflate(layoutInflater)
        customDialog.setContentView(dialogView.root)
        customDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialogView.tvMessage.text = message
        customDialog.setCancelable(true)
        customDialog.setCanceledOnTouchOutside(false);
        customDialog.show()
        customDialog.setOnCancelListener {
            onBackPressed()
        }

        try {
            if (!customDialog.isShowing)
                customDialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun resetPageValues() {
        with(viewModel) {
            currentListForRv.clear()
            adapter.clearRvData()
            lastObservableList.clear()
            prevDataList.clear()
            isSearchFiltered = false
            viewModel.currentListForRv.clear()
            totalCount = 0
            currentPage = 0
        }
    }

    private fun clickHandler() {
        binding.tvViewMore.setOnClickListener {
            if (Helper.isNetworkConnected()) {
                with(viewModel) {
                    Timber.d("Activity: ViewMore Clicked: User API Fetch Invoked for page-> ${viewModel.currentPage + 1} ")
                    invokeAmountCollectedData(
                        angazaId = angazaId,
                        productName = productName,
                        page = viewModel.currentPage + 1
                    )
                }
            } else {
                with(viewModel) {
                    Timber.d("Activity: ViewMore Clicked: Offline User ")
                    if (totalCount > currentPage + 1) {
                        Timber.d("Activity: ViewMore Clicked: User Cached Data Fetch Invoked for page-> ${currentPage + 1} ")
                        getSingleAmountCollectedCachedData(
                            angazaId = angazaId,
                            pageNo = currentPage + 1,
                            productName = productName
                        )
                    } else if (viewModel.singleAmountCollectedLiveData.value != null
                        && viewModel.singleAmountCollectedLiveData.value?.last != false) {
                        Util.CustomToastDialog(this@AmountCollectedActivity,
                            "",
                            getString(R.string.no_internet_load_more),
                            true,
                            true,
                            { it.dismiss() },
                            { it.dismiss() })
                        Timber.d("Activity: ViewMore Clicked: Turn on Internet to load more Data-> ${viewModel.currentPage + 1} ")
                    }

                }
            }
        }
    }

    private fun setListener() {

        binding.etSearch.addTextChangedListener (object : TextWatcher {
            override fun afterTextChanged(text: Editable?) {
                if (!text?.trim().isNullOrEmpty()) {
                    with(viewModel) {
                        if (!currentListForRv.isNullOrEmpty()) {
                            val searchFilteredList = currentListForRv.filter {
//                                it.accountNumber!!.toString().contains(text) == text.toString().trim().toInt()
                                it.accountNumber!!.toString().contains(text!!)
                            }
                            if (!searchFilteredList.isNullOrEmpty()) {
                                isSearchFiltered = true
                                Timber.d("SearchView: $searchFilteredList")
                                adapter.clearRvData()
                                setNoDataVisibility(false)
                                adapter.setRvData(searchFilteredList,true)
                                binding.tvViewMore.visibility = View.GONE
                            } else {
                                isSearchFiltered = true
                                adapter.clearRvData()
                                setNoDataVisibility(true)
                                binding.tvViewMore.visibility = View.GONE
                            }
                        }
                    }
                } else if (viewModel.isSearchFiltered) {
                    viewModel.isSearchFiltered = false
                    Timber.d("SearchView: Empty")
                    adapter.clearRvData()
                    setNoDataVisibility(false)
                    adapter.setRvData(viewModel.currentListForRv,true)
                    if (Helper.isNetworkConnected()) {
                        if (viewModel.singleAmountCollectedLiveData.value?.last != true) {
                            binding.tvViewMore.visibility =
                                View.VISIBLE
                        }
                    } else {
                        if (viewModel.singleAmountCollectedLiveData.value?.last != true) {
                            binding.tvViewMore.visibility =
                                View.VISIBLE
                        }
                    }

                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })



    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

}

