package com.greenlightplanet.kazi.leads.view.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.AdapterChildReferralAgentBinding
import com.greenlightplanet.kazi.databinding.AdapterChoosePhonenoBinding


class ChoosePhoneNoAdapter(val activity: Activity, var phoneNumbers: List<String>)
    : RecyclerView.Adapter<ChoosePhoneNoAdapter.ViewHold>() {


    companion object {
        public const val TAG = "ChoosePhoneNoAdapter"
    }

    var choosePhoneNoAdapterCallback: ChoosePhoneNoAdapterCallback? = null

//    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
//       // val inflater = context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE) as LayoutInflater
//       // val itemBinding  =  inflater.inflate(R.layout.adapter_choose_phoneno, null)
//        val itemBinding = AdapterChoosePhonenoBinding.inflate(LayoutInflater.from(parent.context),parent, false)
//        bind(itemBinding, position)
//
//        return itemBinding.root
//    }
//
//
//    private fun bind(itemBinding: AdapterChoosePhonenoBinding, position: Int) {
//        val number = phoneNumbers.get(position)
//        itemBinding.tvPhoneNumberPosition.text = "${getCorrectNumber(position + 1)} ${context.getString(R.string.phone_number)} :"
//        itemBinding.btnPhoneNumber.text = number
//
//        itemBinding.btnPhoneNumber.setOnClickListener {
//            choosePhoneNoAdapterCallback?.numberSelected(position, number)
//        }
//    }

    interface ChoosePhoneNoAdapterCallback {
        fun numberSelected(position: Int, number: String)
    }

    class ViewHold(val binder : AdapterChoosePhonenoBinding) : RecyclerView.ViewHolder(binder.root) {
        fun bindInfo(activity : Activity, number : String, callback: ChoosePhoneNoAdapterCallback?) {
            binder.run {
                tvPhoneNumberPosition.text = "${getCorrectNumber(position + 1)} ${activity.getString(R.string.phone_number)} :"
                btnPhoneNumber.text = number

                btnPhoneNumber.setOnClickListener {
                    callback?.numberSelected(position, number)
                }
            }
        }

        private fun getCorrectNumber(num: Int): String {
            return when (num) {
                1 -> "1st "
                2 -> "2nd"
                3 -> "3rd"
                else -> "${num}th"
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHold {
        val binder : AdapterChoosePhonenoBinding = AdapterChoosePhonenoBinding.inflate(
            LayoutInflater.from(activity),
            parent,
            false
        )
        return ViewHold(binder)
    }

    override fun onBindViewHolder(holder: ViewHold, position: Int) {
        holder.bindInfo(
            activity = activity,
            number = phoneNumbers[position],
            callback = choosePhoneNoAdapterCallback
        )
    }

    override fun getItemCount(): Int {
        return phoneNumbers.size
    }


}

