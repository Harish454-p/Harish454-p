package com.greenlightplanet.kazi.feedback.di

import android.content.Context
import com.greenlightplanet.kazi.networking.NetworkService
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.feedback.repo.repository.NewTicketFeedbackRepository
import com.greenlightplanet.kazi.feedback.repo.paging.SupportDataPagingSource
import com.greenlightplanet.kazi.feedback.repo.repository.ChatFeedbackRepository
import com.greenlightplanet.kazi.feedback.repo.repository.SupportFeedbackClosedRepository
import com.greenlightplanet.kazi.feedback.repo.repository.SupportFeedbackPendingRepository
import com.greenlightplanet.kazi.incentivenew.repo.CollectionBreakdownRepo
import com.greenlightplanet.kazi.newtasks.repo.TaskCompletionRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Named
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
object AppModule {
    @Singleton
    @Provides
    fun provideRetrofit(@ApplicationContext context: Context): NetworkService {
        return ServiceInstance(context).service!!
    }

    @Singleton
    @Provides
    @Named("RetrofitServiceTask")
    fun provideRetrofitTaskService(@ApplicationContext context: Context): NetworkService {
        return ServiceInstance(context).serviceTask!!
    }

    @Singleton
    @Provides
    fun provideRoom(@ApplicationContext context: Context): AppDatabase {
        return AppDatabase.getAppDatabase(context)
    }

    @Singleton
    @Provides
    fun provideSupportFeedbackClosedRepository(
        db: AppDatabase,
        apiClient: NetworkService,
        preference: GreenLightPreference,
        pagingSource: SupportDataPagingSource
    )
            : SupportFeedbackClosedRepository =
        SupportFeedbackClosedRepository(db, apiClient, preference, pagingSource)

    @Singleton
    @Provides
    fun provideSupportFeedbackPendingRepository(
        db: AppDatabase,
        apiClient: NetworkService,
        preference: GreenLightPreference,
        pagingSource: SupportDataPagingSource
    )
            : SupportFeedbackPendingRepository =
        SupportFeedbackPendingRepository(db, apiClient, preference, pagingSource)

    @Singleton
    @Provides
    fun provideNewTicketFeedbackRepository(
        db: AppDatabase,
        apiClient: NetworkService,
        preference: GreenLightPreference
    )
            : NewTicketFeedbackRepository = NewTicketFeedbackRepository(db, apiClient, preference)

    @Singleton
    @Provides
    fun provideAmountCollectedRepository(
        db: AppDatabase,
        apiClient: NetworkService,
        preference: GreenLightPreference
    )
            : CollectionBreakdownRepo = CollectionBreakdownRepo(db, apiClient, preference)

    @Singleton
    @Provides
    fun provideChatFeedbackRepository(
        db: AppDatabase,
        apiClient: NetworkService,
        preference: GreenLightPreference
    )
            : ChatFeedbackRepository = ChatFeedbackRepository(db, apiClient, preference)

//    @Singleton
//    @Provides
//    fun provideTaskCompletionRepository(
//        db: AppDatabase,
//        @Named("RetrofitServiceTask") apiClient: NetworkService,
//        preference: GreenLightPreference
//    ): TaskCompletionRepository = TaskCompletionRepository(db, apiClient, preference)

    @Singleton
    @Provides
    fun provideAppPref(@ApplicationContext context: Context)
            : GreenLightPreference = GreenLightPreference(context)
}