package com.greenlightplanet.kazi.liteFseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.liteFseProspective.model.LiteRegistrationCheckinRequestModel
import io.reactivex.Single

@Dao
interface LiteRegistrationCheckInRequestDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(liteRegistrationCheckinRequestModel: List<LiteRegistrationCheckinRequestModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(liteRegistrationCheckinRequestModel: LiteRegistrationCheckinRequestModel): Long

    @Delete
    fun delete(liteRegistrationCheckinRequestModel: LiteRegistrationCheckinRequestModel): Int

    @Query("DELETE FROM LiteRegistrationCheckInRequest")
    fun deleteAll(): Int

    @Query("SELECT * FROM LiteRegistrationCheckInRequest")
    fun getAll(): Single<List<LiteRegistrationCheckinRequestModel>>

    @Query("SELECT * FROM LiteRegistrationCheckInRequest LIMIT 1")
    fun get(): Single<LiteRegistrationCheckinRequestModel>

    @Query("SELECT COUNT(*) from LiteRegistrationCheckInRequest")
    fun count(): Single<Int>

    @Query("SELECT * FROM LiteRegistrationCheckInRequest WHERE prospectId=:prospectId LIMIT 1")
    fun getByProspectId(prospectId: String): Single<LiteRegistrationCheckinRequestModel>?

    @Query("SELECT * FROM LiteRegistrationCheckInRequest WHERE prospectID IN (:prospectId)")
    fun getAllByProspectId(prospectId: List<String>): Single<List<LiteRegistrationCheckinRequestModel>>

}
