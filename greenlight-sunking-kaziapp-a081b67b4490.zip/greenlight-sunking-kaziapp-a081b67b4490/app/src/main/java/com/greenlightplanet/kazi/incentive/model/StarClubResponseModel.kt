package com.greenlightplanet.kazi.incentive.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity
data class StarClubResponseModel (
		@PrimaryKey(autoGenerate = true) var id: Int,

		@ColumnInfo
		@SerializedName("duration") val duration : String,

		@ColumnInfo
		@SerializedName("collectionScore") val collectionScore : Int,

		@ColumnInfo
		@SerializedName("ineternetBundle") val ineternetBundle : Int,

		@ColumnInfo
		@SerializedName("salesPreviousMonth") val salesPreviousMonth : Double,

		@ColumnInfo
		@SerializedName("tier") val tier : String,

		@ColumnInfo
		@SerializedName("travelIncentive") val travelIncentive : Int,

		@ColumnInfo
		@SerializedName("airtimeIncentive") val airtimeIncentive : Int
):Parcelable
