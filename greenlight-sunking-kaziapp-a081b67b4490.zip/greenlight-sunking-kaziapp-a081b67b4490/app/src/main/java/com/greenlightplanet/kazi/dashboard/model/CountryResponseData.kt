package com.greenlightplanet.kazi.dashboard.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "%s")
data class CountryResponseData(
    @ColumnInfo(name = "countryProfiles")
    @SerializedName("countryProfiles")
    var countryLit: List<CountryResponseModel>?
) : Parcelable


@Parcelize
@Entity(tableName = "countryProfiles")
data class CountryResponseModel(
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "id") val id: Long,
    @ColumnInfo(name = "countryAbbrivation")
    @SerializedName("countryAbbrivation")
    var countryAbbrivation: String?,
    @ColumnInfo(name = "country")
    @SerializedName("country")
    var country: String?,
    @ColumnInfo(name = "countryCode")
    @SerializedName("countryCode")
    var countryCode: String?,

    @ColumnInfo(name = "countryCurrency")
    @SerializedName("countryCurrency")
    var countryCurrency: String?,

    @ColumnInfo(name = "countryLength")
    @SerializedName("countryLength")
    var countryLength: Int?,

    @ColumnInfo(name = "languageShort")
    @SerializedName("languageShort")
    var languageShort: String?,

    @ColumnInfo(name = "languageFull")
    @SerializedName("languageFull")
    var languageFull: String?,

    @ColumnInfo(name = "phoneNumberLengthRegex")
    @SerializedName("phoneNumberLengthRegex")
    var phoneNumberLengthRegex: String?


) : Parcelable