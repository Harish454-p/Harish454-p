package com.greenlightplanet.kazi.leads.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.greenlightplanet.kazi.leads.repo.CustomerLeadsProfileRepo

class CustomerLeadsProfileViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "CustomerLeadsProfileViewModel"

    }

    val repo = CustomerLeadsProfileRepo.getInstance(application)


    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }
}
