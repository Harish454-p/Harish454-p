package com.greenlightplanet.kazi.agentReferral.model.submitAgent


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class NewAgentResponseModel(
    @SerializedName("ResponseData")
    var responseData: ResponseData?,
    @SerializedName("ResponseStatus")
    var responseStatus: Int?,
    @SerializedName("Success")
    var success: Boolean?
) : Parcelable