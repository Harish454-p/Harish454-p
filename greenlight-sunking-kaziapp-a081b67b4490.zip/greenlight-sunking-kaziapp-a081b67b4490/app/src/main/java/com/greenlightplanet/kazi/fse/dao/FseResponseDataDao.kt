package com.greenlightplanet.kazi.fse.dao

import androidx.room.*
import com.greenlightplanet.kazi.fse.model.FseDetailsResponse
import io.reactivex.Single

@Dao
interface FseResponseDataDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(FseResponseData: List<FseDetailsResponse.ResponseData?>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(FseResponseData: FseDetailsResponse.ResponseData): Long

    @Delete
    fun delete(Fse: FseDetailsResponse.ResponseData): Int

    @Query("DELETE FROM FseResponseData")
    fun deleteAll(): Int

    @Query("SELECT * FROM FseResponseData")
    fun getAll(): Single<List<FseDetailsResponse.ResponseData>>


    @Query("SELECT * FROM FseResponseData LIMIT 1")
    fun get(): Single<FseDetailsResponse.ResponseData>


    /*@Query("SELECT * FROM fse WHERE accountNumber=:accountNumber LIMIT 1")
    fun getNameById(accountNumber: String): Single<FseDetailsResponse.ResponseData>*/

    @Query("SELECT COUNT(*) from FseResponseData")
    fun count(): Single<Int>

}


