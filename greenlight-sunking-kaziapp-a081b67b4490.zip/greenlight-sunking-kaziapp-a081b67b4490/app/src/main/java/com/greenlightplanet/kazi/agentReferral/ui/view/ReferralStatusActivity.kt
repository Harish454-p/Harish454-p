package com.greenlightplanet.kazi.agentReferral.ui.view

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.referral_status_detail
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.referred_agent_status
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_none
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_parent_phone
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_referral_date
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_stage
import com.greenlightplanet.kazi.agentReferral.model.referralStatus.Referral
import com.greenlightplanet.kazi.agentReferral.ui.adapter.ReferralStatusAdapter
import com.greenlightplanet.kazi.agentReferral.viewmodel.ReferNewAgentViewModel
import com.greenlightplanet.kazi.agentReferral.viewmodel.ReferralStatusViewModel
import com.greenlightplanet.kazi.databinding.ActivityReferralStatusBinding
import com.greenlightplanet.kazi.leads.view.activity.CustomerLeadsFeedbackActivity
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener

class ReferralStatusActivity : BaseActivity(), ReferralStatusAdapter.OnReferredStatus {

    private lateinit var binder : ActivityReferralStatusBinding
    private lateinit var viewModel : ReferralStatusViewModel
    private var referredAgent : String? = null
    private var adapter : ReferralStatusAdapter? = null
    private var mHomeWatcher: HomeWatcher? = null
    private var preference : GreenLightPreference? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binder = ActivityReferralStatusBinding.inflate(layoutInflater)
        setContentView(binder.root)

        preference = GreenLightPreference.getInstance(this)
        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(CustomerLeadsFeedbackActivity.TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()

        Util.setToolbar(this, binder.toolbar)
        viewModel = ViewModelProvider(this)[ReferralStatusViewModel::class.java]
        viewModelHandler()
    }

    private fun viewModelHandler() {
        showLastSync()
        sortReferralStatus(sort_none)
        intent.extras?.let {
            referredAgent = it.getString(referred_agent_status)
        }
        viewModel.run {
            binder.run {
                showProgressDialog(this@ReferralStatusActivity)
                txtAgentTitle.visibility = View.INVISIBLE
                txtReferralChild.text = referredAgent.toString()
                getAgentStatus(
                    isOnline = Util.isOnline(context = this@ReferralStatusActivity),
                    childPhone = referredAgent!!
                ).observe(this@ReferralStatusActivity, Observer { response ->
                    when(response) {
                        null -> {
                            txtNoStatuses.visibility = View.VISIBLE
                            lytRcAgentStatus.visibility = View.GONE
                            cancelProgressDialog()
                        }
                        else -> {
                            when(response.success) {
                                true -> {
                                    showLastSync()
                                    when(response.responseData) {
                                        null -> {
                                            txtNoStatuses.visibility = View.VISIBLE
                                            lytRcAgentStatus.visibility = View.GONE
                                            cancelProgressDialog()
                                        }
                                        else -> {
                                            prepData(response.responseData!!)
                                        }
                                    }
                                }
                                false -> {
                                    txtNoStatuses.visibility = View.VISIBLE
                                    lytRcAgentStatus.visibility = View.GONE
                                    cancelProgressDialog()
                                    Util.customFseRationaleDialog(
                                        context = this@ReferralStatusActivity,
                                        title = "",
                                        hideNegative = true,
                                        titleSpanned = null,
                                        hideTitle = true,
                                        message = this@ReferralStatusActivity.getString(R.string.no_data),
                                        positveSelected = {
                                            it.dismiss()
                                        },
                                        negativeSeleted = {
                                            it.dismiss()
                                        }
                                    )
                                }
                            }
                        }
                    }
                })

                obsAgentStatuses.observe(this@ReferralStatusActivity, Observer { statuses ->
                    when {
                        statuses.isEmpty() -> {
                            txtAgentTitle.visibility = View.VISIBLE
                            txtAgentTitle.text = getString(R.string.agent_referred_time, "0")
                            txtNoStatuses.visibility = View.VISIBLE
                            lytRcAgentStatus.visibility = View.GONE
                            cancelProgressDialog()
                        }
                        else -> {
                            when(adapter) {
                                null -> {
                                    adapter = ReferralStatusAdapter(
                                        referralStatusActivity = this@ReferralStatusActivity,
                                        list = statuses
                                    )
                                    rcAgentReferralStatus.layoutManager = LinearLayoutManager(this@ReferralStatusActivity)
                                    rcAgentReferralStatus.adapter = adapter
                                    txtAgentTitle.visibility = View.VISIBLE
                                    when (statuses.size) {
                                        1, 0 -> txtAgentTitle.text = getString(R.string.agent_referred_time, statuses.size.toString())
                                        else -> txtAgentTitle.text = getString(R.string.agent_referred_times, statuses.size.toString())
                                    }
                                }
                                else -> {
                                    adapter?.let { adapt ->
                                        adapt.list = statuses
                                        adapt.notifyDataSetChanged()
                                    }
                                    txtAgentTitle.visibility = View.VISIBLE
                                    txtAgentTitle.text = getString(R.string.agent_referred_times, statuses.size.toString())
                                }
                            }
                            txtNoStatuses.visibility = View.GONE
                            lytRcAgentStatus.visibility = View.VISIBLE
                            cancelProgressDialog()
                            showLastSync()
                        }
                    }
                })

                txtParentPhone.setOnClickListener { sortReferralStatus(sort_parent_phone) }
                txtStage.setOnClickListener { sortReferralStatus(sort_stage) }
                txtRefDate.setOnClickListener { sortReferralStatus(sort_referral_date) }
            }
        }
    }

    private fun sortReferralStatus(sortType : Int) {
        binder.run {
            when(sortType) {
                sort_parent_phone -> {
                    txtParentPhone.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.gray)
                    txtStage.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.colorBlack)
                    txtRefDate.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.colorBlack)
                    viewModel.sortStatus(sort_parent_phone)
                }
                sort_stage -> {
                    txtParentPhone.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.colorBlack)
                    txtStage.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.gray)
                    txtRefDate.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.colorBlack)
                    viewModel.sortStatus(sort_stage)
                }
                sort_referral_date -> {
                    txtParentPhone.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.colorBlack)
                    txtStage.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.colorBlack)
                    txtRefDate.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.gray)
                    viewModel.sortStatus(sort_referral_date)
                }
                sort_none -> {
                    txtParentPhone.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.colorBlack)
                    txtStage.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.colorBlack)
                    txtRefDate.background = ContextCompat.getDrawable(this@ReferralStatusActivity, R.color.colorBlack)
                }
            }

        }
    }

    fun showLastSync() {
        binder.run {
            txtAppVersion.text = this@ReferralStatusActivity.getString(R.string.app_version, BuildConfig.VERSION_NAME)
            txtLastSync.text = this@ReferralStatusActivity.getString(R.string.last_sync, preference?.getReferralStatusLastSync())
        }
    }

    override fun onStatusSelected(model: Referral) {
        Util.addEvent(
                id = "384",
                name ="referral child details specific stage status click",
                event ="user_click_child_detail_specific_stage"
        )
        val intent : Intent = Intent(this, ReferralStatusDetailActivity :: class.java)
        intent.putExtra(referral_status_detail, model)
        startActivity(intent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onResume() {
        super.onResume()
        sortReferralStatus(sort_none)
    }

    override fun onDestroy() {
        mHomeWatcher?.stopWatch()
        super.onDestroy()
        finish()
    }
}