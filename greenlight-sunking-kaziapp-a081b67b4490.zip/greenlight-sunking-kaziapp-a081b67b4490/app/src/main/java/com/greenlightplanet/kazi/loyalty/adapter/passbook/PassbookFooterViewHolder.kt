package com.greenlightplanet.kazi.loyalty.adapter.passbook

import android.view.LayoutInflater
import android.view.View
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.ItemListFooterBinding
import com.greenlightplanet.kazi.loyalty.pagging.State

/**
 * Created by Rahul on 08/04/21.
 */
class PassbookFooterViewHolder(val itemBinding:  ItemListFooterBinding) : RecyclerView.ViewHolder(itemBinding.root) {

    fun bind(status: State?) {
        itemBinding.progressBar.visibility = if (status == State.LOADING) VISIBLE else View.INVISIBLE
        itemBinding.txtError.visibility = if (status == State.ERROR) VISIBLE else View.INVISIBLE
        itemBinding.txtNodata.visibility = if (status == State.OFFLINE) VISIBLE else View.INVISIBLE

    }

    companion object {
        fun create(retry: () -> Unit, parent: ViewGroup): PassbookFooterViewHolder {
            val itemBinding = ItemListFooterBinding.inflate(LayoutInflater.from(parent.context)
                    , parent, false)
            itemBinding.txtError.setOnClickListener { retry() }
            return PassbookFooterViewHolder(itemBinding)
        }
    }
}