package com.greenlightplanet.kazi.location.model.googlegeolocation


import com.google.gson.annotations.SerializedName

data class CellTower(
    @SerializedName("age")
    var age: Int?, // 0
    @SerializedName("cellId")
    var cellId: Int?, // 42
    @SerializedName("locationAreaCode")
    var locationAreaCode: Int?, // 415
    @SerializedName("mobileCountryCode")
    var mobileCountryCode: Int?, // 310
    @SerializedName("mobileNetworkCode")
    var mobileNetworkCode: Int?, // 410
    @SerializedName("signalStrength")
    var signalStrength: Int?, // -60
    @SerializedName("timingAdvance")
    var timingAdvance: Int? // 15
)
