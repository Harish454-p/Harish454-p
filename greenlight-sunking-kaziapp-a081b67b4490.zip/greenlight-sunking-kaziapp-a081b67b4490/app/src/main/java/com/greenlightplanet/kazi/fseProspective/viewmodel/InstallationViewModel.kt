package com.greenlightplanet.kazi.fseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.location.Location
import com.greenlightplanet.kazi.fseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.fseProspective.model.*
import com.greenlightplanet.kazi.fseProspective.repo.InstallationRepo
import com.greenlightplanet.kazi.fseProspective.repo.ProspectiveRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable

class InstallationViewModel(application: Application) : AndroidViewModel(application) {


    companion object {
        public const val TAG = "InstallationViewModel"
    }

    val repo = InstallationRepo.getInstance(application)
    private val repository = ProspectiveRepo(context = application.applicationContext)


    fun compressImageForAws(context: Context, files: List<ImageUploadUtil.ImageModel>, showProgress: () -> Unit = {}): MutableLiveData<List<AwsImageModel>?> {
        showProgress()
        return repo.compressImageForAws(context, files)
    }

    fun performInstallation(context: Context, fseProspectResponseModel: FseProspectResponseModel?, isOnline: Boolean, prospectId: String, angazaId: String, accountNumber: String, installationAttempted: Int, fileModel: List<AwsImageModel>, location: Location, imageName: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return repo.performInstallation(context, fseProspectResponseModel, isOnline, prospectId, angazaId, accountNumber, installationAttempted, fileModel/*, location*/)
    }

    fun performInstallation2(context: Context, fseProspectResponseModel: FseProspectResponseModel?, isOnline: Boolean, prospectId: String, fileModel: List<AwsImageModel>, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return repo.performInstallation2(context, fseProspectResponseModel, isOnline, prospectId, fileModel)
    }

    fun insertAwsImageModelToDatabase(inputFiles: List<AwsImageModel>, isUploadedToAws: Boolean): MutableLiveData<List<AwsImageModel>?> {
        return repo.insertAwsImageModelToDatabase(inputFiles, isUploadedToAws)
    }


    fun getCombineRequestModel(prospectId: String): MutableLiveData<CombineRequestModel> {
        return repo.getCombineRequestModel(prospectId)
    }


    fun getAwsImageModelByProspectId(prospectId: String): MutableLiveData<AwsImageModel> {
        return repo.getAwsImageModelByProspectId(prospectId)
    }

    fun sendInstallationRequestToServerForce(installationRequestModel: InstallationRequestModel, fileModel: List<AwsImageModel>, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return repo.sendInstallationRequestToServerForce(installationRequestModel, fileModel)
    }

    fun updateFseProspect(fseProspectResponseModel: FseProspectResponseModel): MutableLiveData<FseProspectResponseModel> {
        return repo.updateFseProspect(fseProspectResponseModel)
    }

    fun getFseProspectiveFromServer(angazaId:String,prospectId:String,showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>? {
        showProgress()
        return repo.getFseProspectiveFromServer(angazaId,prospectId)
    }

    //region installation list..
    fun getFseProspectiveFromDatabase() : MutableLiveData<NewCommonResponseModel<FseProspectResponseData>> {
        return repository.getFseProspectiveFromDatabase()!!
    }
    //endregion

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
        repository.destroy()
    }

}
