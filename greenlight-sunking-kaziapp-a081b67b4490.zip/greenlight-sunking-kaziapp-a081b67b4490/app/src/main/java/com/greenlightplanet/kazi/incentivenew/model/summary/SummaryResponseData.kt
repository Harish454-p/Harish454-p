package com.greenlightplanet.kazi.incentivenew.model.summary

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Created by Rahul on 09/12/20.
 */

@Parcelize
@Entity
data class SummaryResponseData (

        @PrimaryKey
        @ColumnInfo
        @SerializedName("area") val area : String,

        @ColumnInfo
        @SerializedName("currentRole") val currentRole : String?,

        @ColumnInfo
        @SerializedName("cluster") val cluster : String?,

        @ColumnInfo
        @SerializedName("summaryFields") val summaryFields : List<SummaryFields>?,

        @ColumnInfo
        @SerializedName("checkListFields") val checkListFields : List<CheckListFields>?
):Parcelable