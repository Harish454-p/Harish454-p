package com.greenlightplanet.kazi.feedback.feedback_utils

import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.Window
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.DialogFeedbackSupportFilterBinding
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*

class FeedbackSupportFilterDialog(context : Context, val listener : FilterDialogListener) : Dialog(context , R.style.Theme_Dialog_Feedback) {

    private lateinit var binding : DialogFeedbackSupportFilterBinding
    private val mainCalendar = Calendar.getInstance()
    val dateFormatter = SimpleDateFormat("dd-MM-yyyy")
    var mutableDisableTypeList = mutableListOf<String>()
    var dateSelected = ""


    override fun onCreate(savedInstanceState: Bundle?) {

        requestWindowFeature(Window.FEATURE_NO_TITLE)
        binding = DialogFeedbackSupportFilterBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val window = window
        val wlp = window!!.attributes
        window.attributes = wlp

        /*var dateListener =
            DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
                LanguageConstant.setLocale(lang = preference?.getLanguage()!!, context = context)
                mainCalendar.set(Calendar.YEAR, year)
                mainCalendar.set(Calendar.MONTH, monthOfYear)
                mainCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                Timber.d("DisableDialog: Date Found: ${dateFormatter.format(mainCalendar.time)}")
                val selected = dateFormatter.format(mainCalendar.time)
                dateSelected = selected
                binding.tvDisableDateValue.text = selected
            }*/

        binding.apply {
            tvReset.setOnClickListener {
                Timber.d("FeedbackDialog: Reset Clicked")
                tvDisableDateValue.text = ""
                dateSelected = ""
                tvDisableDateValue.hint = context.getString(R.string.all)
            }
            tvApply.setOnClickListener {
                Timber.d("FeedbackDialog: Apply Clicked: Date: $dateSelected ")
//                listener.onDialogApply(date = dateSelected, disableType = disableTypeSpinnerSelected)
            }
            /*disableDateRl.setOnClickListener {
                Timber.d("DisableDialog: DatePicker Clicked")
                    LanguageConstant.setLocale(lang = LanguageConstant.LANG_ENGLISH, context = context)
                    val dateCalender = Calendar.getInstance(Util.getDateLocale(context = context))
                    dateCalender.add(Calendar.DAY_OF_MONTH, 1)
                    val datePicker = DatePickerDialog(
                        context, dateListener, dateCalender[Calendar.YEAR], dateCalender[Calendar.MONTH],
                        dateCalender[Calendar.DAY_OF_MONTH]
                    )
                    datePicker.setOnCancelListener {
                        LanguageConstant.setLocale(lang = preference?.getLanguage()!!, context = context)
                    }
//                    datePicker.datePicker.minDate = dateCalender.timeInMillis
                    datePicker.show()
            }*/

        }


    }



}


interface  FilterDialogListener{
    fun onDialogApply(date: String)
}