package com.greenlightplanet.kazi.attendance.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.greenlightplanet.kazi.attendance.model.AttendanceResponseModel
import com.greenlightplanet.kazi.attendance.model.AttendanceResponseModel.Checkin
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.heroboard.extras.LeaderBoardUtil
import com.greenlightplanet.kazi.member.model.BaseResponseModel
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.Completable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

class AttendanceRepo(val context: Context) {

    companion object :
            SingletonHolderUtil<AttendanceRepo, Context>(::AttendanceRepo) {
        const val TAG = "AttendanceRepo"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    var gson: Gson? = null

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context)
            gson = Gson()

        } catch (e: Exception) {
            Log.d(TAG, ":Error ")
        }
    }

    fun getRXCheckINList(context: Context, angazaId: String, fromDate: String, toDate: String, fromDBDate: Long, toDBDate: Long): MutableLiveData<NewCommonResponseModel<AttendanceResponseModel>> {
        val data = MutableLiveData<NewCommonResponseModel<AttendanceResponseModel>>()

        if (LeaderBoardUtil.isNetworkConnected(context)) {
            bag.add(
                    ServiceInstance.getInstance(context).service!!.getRXCheckINList(angazaId, fromDate, toDate)
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.e(TAG, "||==getRXCheckINList=====${it}")
//                                data.postValue(it)
                                InsertAllCheckIN(data, it.responseData!!)

                            }, {
                                data.postValue(NewCommonResponseModel<AttendanceResponseModel>(
                                        error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable get data from server"
                                        ),
                                        success = false
                                ))
                            })
            )
            return data

        } else {
            localDb?.let { appDatabase ->
                bag.add(
//                        appDatabase.attendanceDao().getAttendance(fromDate = fromDate.toLongOrNull() ?: 0,toDate = toDate.toLongOrNull() ?: 0)
                        appDatabase.attendanceDao().getAttendance(fromDate = fromDBDate, toDate = toDBDate)
                                .subscribeOn(Schedulers.io())
                                .observeOn(Schedulers.io())
                                .subscribe({
                                    Log.d(TAG, "getAttendanceSS == DB-EO-List: ${it}")
                                    data.postValue(NewCommonResponseModel<AttendanceResponseModel>(
                                            responseData = AttendanceResponseModel(it),
                                            success = true
                                    ))
                                }, { t ->
                                    Log.d(TAG, "getAttendanceSS ==  DB-ERROR:")
                                    data.postValue(NewCommonResponseModel<AttendanceResponseModel>(
                                            error = NewCommonResponseModel.Error(
                                                    messageToUser = "Unable get data from server"
                                            ),
                                            success = false
                                    ))
                                })
                )
            }
            return data

        }

    }

    /*private fun InsertAllCheckIN(liveData: MutableLiveData<NewCommonResponseModel<AttendanceResponseModel>>, responseData: AttendanceResponseModel): Disposable {
        return Completable.fromAction {
            localDb?.attendanceDao()?.deleteAll()
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Deletion:Completed ")
                    localDb?.let {
                        bag.add(
                                Completable.fromAction {
                                    it.attendanceDao().insertAttendance(responseData.checkins)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            Log.d(TAG, "Insertion:Completed ")
//                                            liveData.postValue(responseData)
                                            liveData.postValue(NewCommonResponseModel<AttendanceResponseModel>(
                                                    responseData = responseData,
                                                    success = true
                                            ))
                                        }, { t ->
                                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                            liveData.postValue(NewCommonResponseModel<AttendanceResponseModel>(
                                                    error = NewCommonResponseModel.Error(
                                                            messageToUser = "Unable get data from server"
                                                    ),
                                                    success = false
                                            ))
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })

    }*/

    private fun InsertAllCheckIN(liveData: MutableLiveData<NewCommonResponseModel<AttendanceResponseModel>>, responseData: AttendanceResponseModel): Disposable {
//        return Completable.fromAction {
//            localDb?.attendanceDao()?.deleteAll()
//        }
//                .subscribeOn(Schedulers.io())
//                .observeOn(Schedulers.io())
//                .subscribe({
//                    Log.d(TAG, "Deletion:Completed ")
//                    localDb?.let {
//                        bag.add(
        return Completable.fromAction {
            localDb?.attendanceDao()!!.insertAttendance(responseData.checkins)
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Insertion:Completed ")
                    liveData.postValue(NewCommonResponseModel<AttendanceResponseModel>(
                            responseData = responseData,
                            success = true
                    ))
                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                    liveData.postValue(NewCommonResponseModel<AttendanceResponseModel>(
                            error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from server"
                            ),
                            success = false
                    ))
                })
//                        )
//                    }
//
//                }, { t ->
//                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
//                })

    }

    fun insertAttendance(user: List<Checkin>): Disposable {
        return Completable.fromAction {
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    localDb?.let {
                        bag.add(
                                //localDb.fseDao().insertAll(responseData.fseList!!).toSingle()
                                Completable.fromAction {
                                    //it.fseDao().insertAll(responseData.fseList!!)
                                    it.attendanceDao().insertAttendance(user)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            Log.e(TAG, " -insertAttendance-- Insertion:Completed --- ")

                                        }, { t ->

                                            Log.e(TAG, "-insertAttendance--Insertion:Error---")
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })
    }

    fun insertSingleAttendance(user: Checkin): Disposable {
        return Completable.fromAction {
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    localDb?.let {
                        bag.add(
                                //localDb.fseDao().insertAll(responseData.fseList!!).toSingle()
                                Completable.fromAction {
                                    //it.fseDao().insertAll(responseData.fseList!!)
                                    it.attendanceDao().insertSingleAttendance(user)
                                }
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            Log.e(TAG, " -insertSingleAttendance-- Insertion:Completed --- ")

                                        }, { t ->

                                            Log.e(TAG, "-insertSingleAttendance--Insertion:Error---")
                                        })
                        )
                    }

                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })
    }

    fun attendanceRXPost(context: Context, angazaId: String, attendanceRequestModel: AttendanceResponseModel?): MutableLiveData<CommonResponseModel<BaseResponseModel>> {
        val data = MutableLiveData<CommonResponseModel<BaseResponseModel>>()

        bag.add(
                ServiceInstance.getInstance(context).service!!.attendanceRXPost(angazaId, attendanceRequestModel)
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({
                            Log.e(TAG, "||==attendanceRXPost=====${it.ResponseData}")
                            data.postValue(it)
                        }, {
                            Log.e(TAG, "||==attendanceRXPost=====EROORRRR = $it")
                        })
        )
        return data
    }

    fun updateOfflineList(isOnlineAdded: Boolean, makeTrue: Boolean): Disposable {

        return Completable.fromAction {
            localDb!!.attendanceDao().updateOfflineList(isOnlineAdded, makeTrue)
        }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({ Log.e(TAG, " updateOfflineList--- Updated:Completed --- ") },
                        { Log.e(TAG, " updateOfflineList--- Updated:ERRROOOORRRRR --- ") })
    }

    fun getAttendanceSS(): MutableLiveData<List<AttendanceResponseModel.Checkin>> {
        val data = MutableLiveData<List<AttendanceResponseModel.Checkin>>()

        localDb?.let { appDatabase ->
            bag.add(
                    appDatabase.attendanceDao().getAttendanceSS()
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.d(TAG, "getAttendanceSS == DB-EO-List: ${it}")
                                data.postValue(it)
                            }, { t ->
                                Log.d(TAG, "getAttendanceSS ==  DB-ERROR:")
                            })
            )
        }

        return data
    }

    fun getAttendance(fromDate: Long, toDate: Long): MutableLiveData<List<AttendanceResponseModel.Checkin>> {
        val data = MutableLiveData<List<AttendanceResponseModel.Checkin>>()

        localDb?.let { appDatabase ->
            bag.add(
                    appDatabase.attendanceDao().getAttendance(fromDate, toDate)
                            .subscribeOn(AndroidSchedulers.mainThread())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe({
                                data.postValue(it)
                                Log.d(TAG, "getAttendance == DB-EO-List: ${it}")

                            }, { t ->
                                Log.d(TAG, "getAttendance ==  DB-ERROR:")
                            })
            )
        }

        return data
    }

    fun getOfflineAttendance(isOnlineAdded: Boolean): MutableLiveData<List<AttendanceResponseModel.Checkin>> {
        val data = MutableLiveData<List<AttendanceResponseModel.Checkin>>()

        localDb?.let { appDatabase ->
            bag.add(
                    appDatabase.attendanceDao().getRXOfflineAttendance(isOnlineAdded)
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.d(TAG, "getOfflineAttendance == DB-EO-List: ${it}")
                                data.postValue(it)
                            }, { t ->
                                Log.d(TAG, "getOfflineAttendance ==  DB-ERROR:")
                            })
            )
        }
        return data
    }


    fun destroy() {
        bag.clear()
    }

}
