package com.greenlightplanet.kazi.liteFseProspective.model


data class CombineRequestModel(
    var otpApprovalRequestModel: LiteOtpApprovalRequestModel? = null,
    var registrationCheckinRequestModel: LiteRegistrationCheckinRequestModel? = null,
    var installationRequestModels: LiteInstallationRequestModel? = null,
    var fseProspectResponseModel: LiteFseProspectResponseModel? = null,
    var fseError: LiteFseError? = null
)