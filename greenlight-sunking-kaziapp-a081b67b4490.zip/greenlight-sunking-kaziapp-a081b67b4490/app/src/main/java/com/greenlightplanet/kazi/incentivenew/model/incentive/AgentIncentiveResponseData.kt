package com.greenlightplanet.kazi.incentivenew.model.incentive

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Created by Rahul on 09/12/20.
 */


@Parcelize
@Entity
data class AgentIncentiveResponseData (

        @PrimaryKey
        @ColumnInfo
        @SerializedName("accounts") val accounts : List<Accounts>
):Parcelable