package com.greenlightplanet.kazi.collectiongoal.typeconverters

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistory
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistory


class PaymentHistoryTypeConverter {

    @TypeConverter
    fun fromCollection(crlist: List<PaymentHistory>?): String? {
        if (crlist == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<PaymentHistory>>() {

        }.type
        return gson.toJson(crlist, type)
    }

    @TypeConverter
    fun toCollectionList(clList: String?): List<PaymentHistory>? {
        if (clList == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<PaymentHistory>>() {

        }.type
        return gson.fromJson(clList, type)
    }
}