package com.greenlightplanet.kazi.attendance.model


import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import android.os.Parcelable
import androidx.annotation.NonNull
import kotlinx.android.parcel.Parcelize
import com.google.gson.annotations.SerializedName
import com.greenlightplanet.kazi.attendance.extra.AttendanceUtils
import com.greenlightplanet.kazi.task.model.response.DateConverter
import com.greenlightplanet.kazi.utils.Util
import java.text.SimpleDateFormat
import java.util.*

@Parcelize
@Entity(tableName = "attendance")
@TypeConverters(AttendanceConveter::class)
data class AttendanceResponseModel(
        @ColumnInfo(name = "checkins")
        @SerializedName("checkins")
        var checkins: List<Checkin>
) : Parcelable {
    @Parcelize

    @Entity(tableName = "checkins" /*,primaryKeys = arrayOf("time","accountNumber")*/)
    @TypeConverters(AttendanceConveter::class)
    data class Checkin(
            @ColumnInfo(name = "accountNumber")
            @SerializedName("accountNumber")
            var accountNumber: String? = null,
            @ColumnInfo(name = "checkinType")
            @SerializedName("checkinType")
            var checkinType: String? = null,
            @ColumnInfo(name = "latitude")
            @SerializedName("latitude")
            var latitude: String? = null,
            @ColumnInfo(name = "longitude")
            @SerializedName("longitude")
            var longitude: String? = null,

//            @NonNull
            @PrimaryKey
            @ColumnInfo(name = "time")
            @SerializedName("time")
            var time: String ,
            @ColumnInfo(name = "customer_name")
            @SerializedName("customer_name")
            var customerName: String? = null, // User Name
            @ColumnInfo(name = "is_online_added")
            @SerializedName("isOnlineAdded")
            var isOnlineAdded: Boolean? = true,


            @ColumnInfo(name = "date")
            @SerializedName("date")
            @TypeConverters(DateConverter::class)
            var date: Date? = time?.let { AttendanceUtils.getFormattedDatezz(it) }

    ) : Parcelable {

//        fun getFormattedDatezz(time: String): Date {
//
//            val sdf = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
//            val date: Date? = sdf.parse(time)
//            return date!!
//        }
    }


}
