package com.greenlightplanet.kazi.atrisk.activity

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.ViewModelProvider
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.atrisk.adapter.AtRiskAccountAdapter
import com.greenlightplanet.kazi.atrisk.extra.AtRiskCallDialog
import com.greenlightplanet.kazi.atrisk.model.AtRiskAccountModel
import com.greenlightplanet.kazi.atrisk.model.AtRiskCallDetailRequestModel
import com.greenlightplanet.kazi.atrisk.viewmodel.AtRiskAccountViewModel
import com.greenlightplanet.kazi.databinding.ActivityAtRiskAccountsBinding
import com.greenlightplanet.kazi.leads.extras.LEAD_INTENT
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.newtasks.extras.AdapterUtils
import com.greenlightplanet.kazi.newtasks.extras.PermissionHelper
import com.greenlightplanet.kazi.newtasks.extras.SendingCallStatus
import com.greenlightplanet.kazi.newtasks.model.CommonTaskModel
import com.greenlightplanet.kazi.newtasks.model.FeedbackIntentModel
import com.greenlightplanet.kazi.newtasks.model.TaskResponseModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import timber.log.Timber

class AtRiskAccountsActivity : BaseActivity(),
    AtRiskAccountAdapter.AtRiskAccountAdapterCallback,
    AtRiskCallDialog.CallIntentDialogCallback,SendingCallStatus {
    public val TAG = "AtRiskAccountsActivity"
    var mHomeWatcher: HomeWatcher? = null
    private lateinit var binding: ActivityAtRiskAccountsBinding

    var viewModel: AtRiskAccountViewModel? = null
    var bundle = Bundle()
    var angaza = ""
    var name = ""
    var sortType = 1
    var sortAttribute = 0
    var atRiskAccountAdapter: AtRiskAccountAdapter? = null
    var dbResponseList: MutableList<AtRiskAccountModel.CollectionAccount> = mutableListOf()
    var adapterList: MutableList<AtRiskAccountModel.CollectionAccount> = mutableListOf()

    var sortList: MutableList<AtRiskAccountModel.CollectionAccount> = mutableListOf()
    var productList: MutableList<AtRiskAccountModel.CollectionAccount> = mutableListOf()

    var product_name: String? = null
    var product_position: Int? = null
    private var callDialog: AtRiskCallDialog? = null
    private var taskFeedback: List<FeedbackIntentModel.Intents>? = null
    var permissionHelper: PermissionHelper? = null
    var preference: GreenLightPreference? = null
    var taskResponseModel: TaskResponseModel? = null
    private var callReceiver: BroadcastReceiver? = null
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //  setContentView(R.layout.activity_at_risk_accounts)
        binding = ActivityAtRiskAccountsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Util.setToolbar(this, binding.toolbar2)
        preference = GreenLightPreference.getInstance(this)
        viewModel = ViewModelProvider(this)[AtRiskAccountViewModel::class.java]
        callDialog = AtRiskCallDialog(this, this)
        permissionHelper = PermissionHelper(this)
        callDialog!!.callIntentDialogCallback = this
        setUpReceiver()
        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        initRecycler()
        clickHander()
        viewModel!!.getTaskIntentFromDb().observe(this, Observer {
            taskFeedback = it?.responseData?.intents
            viewModel!!.getNewTaskFromDb().observe(this, Observer {
                Log.e("Mazhar == ", "getNewTaskFromServer ${it!!.success}")
                taskResponseModel = it.responseData
            })
        })

        viewModel!!.solveAllAtRisk().observe(this, Observer {
            callApi()
        })

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }


    @SuppressLint("UseCompatLoadingForDrawables", "SetTextI18n")
    fun initRecycler() {

        binding.recyclerAtRiskAccount.layoutManager = LinearLayoutManager(this)
        binding.recyclerAtRiskAccount.setHasFixedSize(true)
        binding.recyclerAtRiskAccount.addItemDecoration(
            DividerItemDecoration(
                this,
                DividerItemDecoration.VERTICAL
            ).apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider, theme))
                } else {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider))
                }
            })

        bundle = intent.extras!!
        angaza = bundle.getString("angaza")!!
        name = bundle.getString("name")!!
        binding.tvName.text = "${name.lowercase().capitalize()} ${getString(R.string.risk_metrics)}"


        binding.spinnerRisk.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                adapterView: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                binding.etAccountsearch.text.clear()
                refreshSortBackground()
                onItemSelected(position, adapterView!!.selectedItem)
            }

        }

        binding.spinnerRisk.isFocusableInTouchMode = true
        binding.spinnerRisk.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                if (binding.spinnerRisk.windowToken != null) {
                    binding.spinnerRisk.performClick()
                }
            }
        }

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    fun onItemSelected(position: Int, productName: Any) {

        product_name = productName.toString()
        product_position = position
        selectProduct(position, productName)

    }

    @SuppressLint("SetTextI18n")
    fun callApi() {
        showProgressDialog(this)
        viewModel!!.getAtRiskAccount(this, angaza).observe(this, Observer { it ->
            cancelProgressDialog()
            if (it!!.success) {
                val list = it.responseData!!.collectionAccount
                if (!list.isNullOrEmpty()) {
                    resetList(list.toMutableList())
                    setAdapter(list.toMutableList())
                    sortList.clear()
                    sortList.addAll(list)
                    val tempModel = viewModel!!.getProductInit()
                    tempModel.productGroup = getString(R.string.all)
                    productList.add(0, tempModel)
                    productList.addAll(list)
                    binding.tvLastSavedRiskAccount.text =
                        "${getString(R.string.last_saved_key)} ${list[0].syncDate}"
                    setSpinnerAdapter(binding.spinnerRisk, productList.distinctBy {
                        it.productGroup
                    }.map { it.productGroup })

                    watcher()
                } else {
                    Util.showToast(this, "No Data")
                    finish()
                }
            } else {
                Util.showToast(this, "Something went wrong, Please try again")
                finish()
            }

        })
    }

    fun setAdapter(mutableList: MutableList<AtRiskAccountModel.CollectionAccount>) {
        adapterList.clear()
        adapterList.addAll(mutableList)

        if (atRiskAccountAdapter == null) {
            atRiskAccountAdapter = AtRiskAccountAdapter(adapterList, this)
            atRiskAccountAdapter?.atRiskAccountAdapterCallback = this

            binding.recyclerAtRiskAccount.adapter = atRiskAccountAdapter
        }
        atRiskAccountAdapter?.notifyDataSetChanged()

    }

    private fun setSpinnerAdapter(spinner: Spinner, array: List<String>) {

        val spinnerArrayAdapter = ArrayAdapter<String>(
            this, R.layout.spinner_item, array
        )
        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_filter_text)
        spinner.adapter = spinnerArrayAdapter
    }

    private fun selectProduct(position: Int, productName: Any) {

        if (position.equals(0)) {
            adapterList.clear()
            adapterList.addAll(sortList)
            setAdapter(sortList)
            resetList(sortList)

        } else if (position > 0) {
            adapterList.clear()
            adapterList.addAll(sortList)

//            val data = adapterList.filter { it -> it.product_name!!.equals(productName) }
            val data = adapterList.filter { it -> it.productGroup.equals(productName) }

            setAdapter(data as MutableList<AtRiskAccountModel.CollectionAccount>)
            resetList(data)

        }

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    fun watcher() {
        binding.etAccountsearch.removeTextChangedListener(AccounTextWatcher)
        binding.etAccountsearch.addTextChangedListener(AccounTextWatcher)
    }

    private var AccounTextWatcher = object : TextWatcher {

        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

        @SuppressLint("NotifyDataSetChanged")
        override fun afterTextChanged(s: Editable) {
            val searchEOList = when (s.toString()) {
                "" -> {
                    dbResponseList
                }
                else -> {
                    dbResponseList.filter {
                        val name = "${it.customerName}"
                        name.contains(
                            s.toString(),
                            true
                        )
                    }.toMutableList()
                }
            }
            val mutablePostList: MutableLiveData<List<AtRiskAccountModel.CollectionAccount>> =
                MutableLiveData()
            mutablePostList.value = searchEOList
            mutablePostList.observe(this@AtRiskAccountsActivity, Observer { data ->

                if (data != null) {

                    val account = data

                    account.let {

                        when (sortAttribute) {

                            1 -> {
                                byPendingAmountPermanent(data.toMutableList())
//                                sortByName(data as MutableList<Any>, sortType)
                                binding.tvPendingAmountPermanent.setBackgroundColor(Color.GRAY)
                                atRiskAccountAdapter?.notifyDataSetChanged()
                            }
                            2 -> {
                                byCustomerName(data.toMutableList())
//                                sortAccountAtRisk(data as MutableList<Any>, sortType)
                                binding.tvCustomerName.setBackgroundColor(Color.GRAY)
                                atRiskAccountAdapter?.notifyDataSetChanged()
                            }
                            3 -> {
                                byPendingAmount(data.toMutableList())
//                                sortRiskPercentageAccount(data as MutableList<Any>, sortType)
                                binding.tvPendingAmount.setBackgroundColor(Color.GRAY)
                                atRiskAccountAdapter?.notifyDataSetChanged()
                            }
                            else -> setAdapter(data.toMutableList())

                        }

                        setAdapter(data.toMutableList())
                        watcher()
                    }
                }

            })
        }
    }


    fun resetList(resetList: List<AtRiskAccountModel.CollectionAccount>) {
        dbResponseList.clear()
        dbResponseList.addAll(resetList)
    }

    //region Sorting Functions
    @SuppressLint("NotifyDataSetChanged")
    private fun byPendingAmount(mutableList: MutableList<AtRiskAccountModel.CollectionAccount>) {

        sortAttribute = 3
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    it.pendingPayment?.toDouble()
                }
            } else {
                sortType = 1
                mutableList.sortBy {
                    it.pendingPayment?.toDouble()
                }
            }

//            sortPendingAmount(mutableList, sortType)
            binding.tvPendingAmount.setBackgroundColor(Color.GRAY)
            atRiskAccountAdapter?.notifyDataSetChanged()

        }
    }

    private fun sortPendingAmount(
        mutableList: MutableList<AtRiskAccountModel.CollectionAccount>,
        sortType: Int
    ) {

        if (mutableList.size > 0) {
            if (sortType == 0) {

                mutableList.sortBy {
                    it.pendingPayment
                }
            } else {
                mutableList.sortByDescending {
                    it.pendingPayment
                }

            }

        }

    }

    fun byCustomerName(mutableList: MutableList<AtRiskAccountModel.CollectionAccount>) {

        sortAttribute = 2
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    it.customerName
                }

            } else {
                sortType = 1
                mutableList.sortBy {
                    it.customerName
                }
            }

//            sortCustomerName(mutableList, sortType)
            binding.tvCustomerName.setBackgroundColor(Color.GRAY)
            atRiskAccountAdapter?.notifyDataSetChanged()
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun byPendingAmountPermanent(mutableList: MutableList<AtRiskAccountModel.CollectionAccount>) {

        sortAttribute = 1
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    it.pendingToExitRiskPermanent?.toInt()
                }
            } else {
                sortType = 1
                mutableList.sortBy {
                    it.pendingToExitRiskPermanent?.toInt()
                }
            }

//            sortByAccountNumber(mutableList, sortType)
            binding.tvPendingAmountPermanent.setBackgroundColor(Color.GRAY)
            atRiskAccountAdapter?.notifyDataSetChanged()
        }
    }

    fun refreshSortBackground() {
        binding.tvCustomerName.setBackgroundColor(Color.BLACK)
        binding.tvPendingAmountPermanent.setBackgroundColor(Color.BLACK)
        binding.tvPendingAmount.setBackgroundColor(Color.BLACK)
    }

    private fun clickHander() {
        binding.tvCustomerName.setOnClickListener { v ->
            byCustomerName(adapterList)
            resetList(adapterList)
        }
        binding.tvPendingAmountPermanent.setOnClickListener { v ->
            byPendingAmountPermanent(adapterList)
            resetList(adapterList)
        }
        binding.tvPendingAmount.setOnClickListener { v ->
            byPendingAmount(adapterList)
            resetList(adapterList)
        }

    }

    //endregion

    override fun onCustomerSelected(collectionAccount: AtRiskAccountModel.CollectionAccount) {
        val bundle = Bundle()
        bundle.putParcelable("collectionAccount", collectionAccount)
        val intentz = Intent(this, AtRiskCustomerProfileActivity::class.java)
        intentz.putExtra("data", bundle)
        startActivity(intentz)
    }

    override fun makeCall(position: Int, account: AtRiskAccountModel.CollectionAccount) {
        val list = account.alternateContacts?.toMutableList()
        account.ownerPhoneNumber?.let {
            list?.add(0, it)
        }

        account.secondaryPhoneNumber?.let {
            list?.add(1, it)
        }

//        if (!list.isNullOrEmpty() && !taskFeedback.isNullOrEmpty()) {
        callDialog?.newShowPhoneNumberDialog(
            account,
            position,
            list!!.filterNot { it.isNullOrBlank() || it.equals("NA") || it.equals("NULL") },
            taskFeedback, account.eligibleForReimbursement!!
        )
    }

    override fun requestCallLogPermission(
        position: Int,
        account: AtRiskAccountModel.CollectionAccount
    ) {
        permissionHelper?.onPermissionGranted = { makeCall(position, account) }
        permissionHelper?.onPermissionRejected = {
            Util.customFseCompletionDialog(
                context = this,
                hideTitle = true,
                message = getString(R.string.please_allow_call),
                okSelected = {
                    it.dismiss()
                },
                title = null
            )
        }
        permissionHelper?.performPermissionCheck(this)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        permissionHelper?.onRequestPermissionsResult(requestCode, permissions, grantResults)
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }


    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();
    }

    override fun dialogCompleted(
        callDetailRequest: AtRiskCallDetailRequestModel,
        adapterPosition: Int
    ) {
        Log.e("MAzhar ==>", "dialogCompleted =$adapterPosition=> ${callDetailRequest}")
        if (callDetailRequest.callDuration < preference!!.getMinimumCallDuration()!!
            && callDetailRequest.intentId != LEAD_INTENT.DID_NOT_ANSWER
        ) {
            AdapterUtils.taskDurationDialog(
                context = this,
                message = "${getString(R.string.duration)} " + callDetailRequest.callDuration.toString() + "${
                    getString(
                        R.string.sec_time
                    )
                } " + AdapterUtils.durationFormat(
                    callDetailRequest.calledTime
                )!!,//"2021-06-03 07:00:00"
                dialogButton = {
                    it.dismiss()
                },
                title = getString(R.string.calls_duration_low)
            )


        } else {
            Log.e("MAzhar ==>", "Completed ==> ${callDetailRequest}")
            performTask(callDetailRequest)
        }

    }

    private fun performTask(callDetailRequest: AtRiskCallDetailRequestModel) {

        val observer = Observer<NewCommonResponseModel<NewEmptyParcelable>> {
            Log.e("TAG = performTask = ::", "dialogCompleted: $it ")
            cancelProgressDialog()
            if (callDetailRequest.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
                Util.customFseCompletionDialog(
                    context = this,
                    hideTitle = true,
                    message = getString(R.string.congrats_call_made),
                    okSelected = {
                        it.dismiss()
                        callApi()
                    },
                    title = null
                )
            }

        }

        val list: MutableList<CommonTaskModel> = mutableListOf()
        list.clear()
        list.addAll(taskResponseModel!!.called!!)
        list.addAll(taskResponseModel!!.firstCall!!)

        val aa = list.find { it.accountNumber == callDetailRequest.accountNumber }
        val isPresent = aa != null
        Log.e("Maz =$isPresent= ", "${aa}")


        if (Util.isOnline(this)) {
            viewModel!!.solveTaskCallDetailRequest(callDetailRequest, isPresent) {
                showProgressDialog(this)
            }.observe(this, observer)
        } else {
            viewModel!!.insertCallDetailRequestToDb(callDetailRequest, isPresent) {
                showProgressDialog(this)
            }.observe(this, observer)
        }
    }

    //region for call status
    private fun setUpReceiver() {
        val intentFilter = IntentFilter()

        callReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {

                try {
                    val state = intent?.getStringExtra(TelephonyManager.EXTRA_STATE);
                    if (state.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                        Timber.d("BROADCAST==: CALL STATE: RINGING")
                    }
                    if (state.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                        Timber.d("BROADCAST==: CALL STATE: Connected")
                    }
                    if (state.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                        // CALL ENDED
                        Timber.d("BROADCAST==: CALL STATE: Disconnected")
                        if (preference?.getIsOnCall()!!) {
                            preference?.setIsOnCall(false)
//                            viewModel.currentTask?.let {
//                                navigateToDynamicFeedbackActivity(task = it)
//                            }
                            isOnCall()

                        }
                    }
                } catch (e1: Exception) {
                    Timber.d("BROADCAST==: CALL STATE: EXCEPTION : $e1")
                    e1.printStackTrace();
                }
            }
        }

        intentFilter.addAction("android.intent.action.PHONE_STATE")
        registerReceiver(callReceiver, intentFilter)

    }

    override fun setOnCall(isOnCall: Boolean) {
        preference?.setIsOnCall(isOnCall)!!
    }

    override fun isOnCall(): Boolean {
        return preference?.getIsOnCall()!!
    }

    //endregion

}
