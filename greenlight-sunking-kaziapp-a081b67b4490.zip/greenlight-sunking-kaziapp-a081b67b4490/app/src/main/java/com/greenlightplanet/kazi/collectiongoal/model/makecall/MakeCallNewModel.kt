package com.greenlightplanet.kazi.collectiongoal.model.makecall

import android.os.Parcelable
import androidx.annotation.Keep
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

@Keep
@Entity(tableName = "makeCallNewModel")
@Parcelize
data class MakeCallNewModel(

    @ColumnInfo(name = "ID")
    @PrimaryKey(autoGenerate = false)
    var id: String,

    @ColumnInfo(name = "accounts")
    var accounts: List<ColGoalAccount> = listOf(),

    @ColumnInfo(name = "isCollectionGoal")
    var isCollectionGoal: Boolean?,

    @ColumnInfo(name = "pageNo")
    var pageNo: Int?,

    @ColumnInfo(name = "next", defaultValue = "")
    var next: Int?


) : Parcelable {
    @Keep
    @Parcelize
    data class ColGoalAccount(

        //Reference Variable Added For date sorting
        @ColumnInfo(name = "timestamp")
        var date_timestamp: Long?,

        @ColumnInfo(name = "accounAngazaId")
        var accounAngazaId: String?,

        @ColumnInfo(name = "accountNumber")
        var accountNumber: String?,

        @ColumnInfo(name = "address")
        var address: String?,

        @ColumnInfo(name = "alternateContact1")
        var alternateContact1: String?,

        @ColumnInfo(name = "alternateContact2")
        var alternateContact2: String?,

        @ColumnInfo(name = "alternateContact3")
        var alternateContact3: String?,

        @ColumnInfo(name = "alternateContact4")
        var alternateContact4: String?,

        @ColumnInfo(name = "alternateContact5")
        var alternateContact5: String?,

        @ColumnInfo(name = "attempt")
        var attempt: Int?,

        @ColumnInfo(name = "balanceAmount")
        var balanceAmount: Double?,

        @ColumnInfo(name = "collectedAmount")
        var collectedAmount: Double?,

        @ColumnInfo(name = "customerName")
        var customerName: String?,

        @ColumnInfo(name = "expectedAmount")
        var expectedAmount: Double?,

        @ColumnInfo(name = "isAchieved")
        var isAchieved: Boolean,

        @ColumnInfo(name = "isTask")
        var isTask: Boolean?,

        @ColumnInfo(name = "lastCallDate")
        var lastCallDate: String?,

        @ColumnInfo(name = "ownerPhoneNumber")
        var ownerPhoneNumber: String?,

        @ColumnInfo(name = "priority")
        var priority: Int?,

        @ColumnInfo(name = "productGroup")
        var productGroup: String?,

        @ColumnInfo(name = "productName")
        var productName: String?,

        @ColumnInfo(name = "registrationDate")
        var registrationDate: String?,

        @ColumnInfo(name = "secondaryPhoneNumber")
        var secondaryPhoneNumber: String?,

        @ColumnInfo(name = "successfulCallMessage")
        var successfulCallMessage: String?,

        @ColumnInfo(name = "status")
        var status: String?,

        @ColumnInfo(name = "taskId")
        var taskId: Int?,

        @ColumnInfo(name = "ticketType")
        var ticketType: String?,

        @ColumnInfo(name = "totalPaid")
        var totalPaid: Double?,

        @ColumnInfo(name = "unlockPrice")
        var unlockPrice: Double?,

        @ColumnInfo(name = "weeklyPaymentRate")
        var weeklyPaymentRate: Double?,

        @ColumnInfo(name = "minimumPaymentAmount")
        var minimumPaymentAmount: Double?,

        @ColumnInfo(name = "latitude")
        var latitude: Double?,

        @ColumnInfo(name = "longitude")
        var longitude: Double?,

        @ColumnInfo(name = "daysDisabled")
        var daysDisabled: Int?,

        @ColumnInfo(name = "lastPaidDate")
        var lastPaidDate: String?,

        @ColumnInfo(name = "isInTask")
        var isInTask: Boolean?,

        ) : Parcelable

}