package com.greenlightplanet.kazi.fseProspective.model


import androidx.room.ColumnInfo
import androidx.room.Entity
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class FseProspectItemResponseModel(
        @ColumnInfo(name = "prospect")
        @SerializedName("prospect")
        var prospect: FseProspectResponseModel?
) : Parcelable
