package com.greenlightplanet.kazi.location.worker

/*
import android.content.Context
import android.location.LocationManager
import android.util.Log
import com.greenlightplanet.kazi.location.dao.LocationRequestDao
import com.firebase.jobdispatcher.JobParameters
import com.firebase.jobdispatcher.JobService
import com.greenlightplanet.kazi.location.newworker.ProjectXLogic
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.disposables.CompositeDisposable

class ReminderService : JobService() {
	*/
/**
	 * This asynctask will run a job once conditions are met with the constraints
	 * As soon as user device gets connected with the power supply. it will generate
	 * a notification showing that condition is met.
	 *//*


	companion object {
		const val TAG = "AlarmService"
	}

	private var mContext: Context? = null

	var preference: GreenLightPreference? = null
	private var localDb: AppDatabase? = null
	private lateinit var dao: LocationRequestDao

	lateinit var projectXLogic: ProjectXLogic
	private val bag = CompositeDisposable()

	var lm: LocationManager? = null

	override fun onStartJob(jobParameters: JobParameters?): Boolean {
		initialize(this)

		return if (preference?.getLoginResponseModel() != null) {
			projectXLogic.performRxService(mContext!!, preference?.getLoginResponseModel()?.angazaId!!)
				.map {
					true
				}.blockingGet()
		} else {
//			nextTrigger(mContext!!)
			true
		}


	}

	override fun onStopJob(jobParameters: JobParameters?): Boolean {

		Log.i("TAG", "onStopJob")
		*/
/* true means, we're not done, please reschedule *//*
return true
	}


	fun initialize(context: Context) {

		mContext = context

		preference = GreenLightPreference.getInstance(mContext!!)
		localDb = AppDatabase.getAppDatabase(mContext!!)
		dao = localDb!!.locationRequestDao()
		preference?.setLastCalledWorker(System.currentTimeMillis())

		projectXLogic = ProjectXLogic(context, preference!!, dao)

	}

}
*/
