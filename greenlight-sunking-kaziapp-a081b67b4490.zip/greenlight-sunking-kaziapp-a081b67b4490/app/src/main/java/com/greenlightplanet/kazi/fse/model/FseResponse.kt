package com.greenlightplanet.kazi.fse.model

import androidx.room.*
import android.os.Parcelable
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import kotlinx.android.parcel.Parcelize

/*

@Parcelize
//@Entity(tableName = "FseResponse")
//@TypeConverters(FseConveter::class)
data class FseResponse(
        //@PrimaryKey(autoGenerate = true)
        //@ColumnInfo(name = "id")
        @ColumnInfo(name = "fseList")
        @SerializedName("fseList")
        var fseList: ArrayList<Fse?>?
) : Parcelable {

    */
/*@Parcelize
    @Entity(tableName = "Fse")
    data class Fse(
            @ColumnInfo(name = "accountNumber")
            @SerializedName("accountNumber")
            var accountNumber: String?, // 9282828
            @PrimaryKey
            @ColumnInfo(name = "angazaId")
            @SerializedName("angazaId")
            var angazaId: String, // US029933
            @ColumnInfo(name = "customerName")
            @SerializedName("customerName")
            var customerName: String?, // Yogesh Baid
            @ColumnInfo(name = "daysDisabled")
            @SerializedName("daysDisabled")
            var daysDisabled: Int? // 56
    ) : Parcelable*//*

}


class FseConveter {

    @TypeConverter
    fun fromTaskList(fseList: ArrayList<FseResponse.Fse>?): String? {
        if (fseList == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<FseResponse.Fse>>() {

        }.type
        return gson.toJson(fseList, type)
    }

    @TypeConverter
    fun toTaskList(fseListString: String?): ArrayList<FseResponse.Fse>? {
        if (fseListString == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<FseResponse.Fse>>() {

        }.type
        return gson.fromJson(fseListString, type)
    }

}

*/
