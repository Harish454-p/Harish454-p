package com.greenlightplanet.kazi.fse.extras.util

interface IOnBackPressed {
    fun onBackPressed(): Boolean
}