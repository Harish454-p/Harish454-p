package com.greenlightplanet.kazi.leads.dao

import androidx.room.*
import com.greenlightplanet.kazi.leads.model.LeadsResponseModel
import io.reactivex.Single

@Dao
interface LeadsResponseModelDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(LeadsResponseModel: List<LeadsResponseModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(LeadsResponseModel: LeadsResponseModel): Long

    @Delete
    fun delete(LeadsResponseModel: LeadsResponseModel): Int

    @Query("DELETE FROM LeadsResponseModel")
    fun deleteAll(): Int

    @Query("SELECT * FROM LeadsResponseModel")
    fun getAll(): Single<List<LeadsResponseModel>>

    @Query("SELECT * FROM LeadsResponseModel LIMIT 1")
    fun get(): Single<LeadsResponseModel>

    @Query("SELECT COUNT(*) from LeadsResponseModel")
    fun count(): Single<Int>

}
