package com.greenlightplanet.kazi.location.extras

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.Log
import com.google.android.gms.location.LocationRequest
import com.greenlightplanet.kazi.location.model.LocationRequestModel
import com.greenlightplanet.kazi.location.worker.TASK_TAG
import com.greenlightplanet.kazi.location.worker.alarm.HourAlarmWorkReceiver
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import org.threeten.bp.ZoneId
import org.threeten.bp.ZonedDateTime
import org.threeten.bp.format.DateTimeFormatter
import pl.charmas.android.reactivelocation2.ReactiveLocationProvider
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit


class FunctionalUtils {

    companion object {


        public const val TAG = "FunctionalUtils"

        //add permission check
        @SuppressLint("MissingPermission")
        fun getCurrentLocation(context: Context, angazaId: String): Single<LocationRequestModel> {

            val request = LocationRequest.create() //standard GMS LocationRequest
                    .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                    .setNumUpdates(1)

            /*val request = LocationRequest.create() //standard GMS LocationRequest
                    .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                    .setNumUpdates(50).setInterval(20)*/


            val locationProvider = ReactiveLocationProvider(context)

            return locationProvider.getUpdatedLocation(request)
                    .singleOrError()
                    .flatMap {

                        Log.d(TAG, "Success - flatMap getCurrentLocation: ")

                        val dateTime = FunctionalUtils.getCurrentUtcDateTime()
                        val dateTimeFormatted = FunctionalUtils.getCurrentUtcDateTimeFormatted(dateTime)

                        val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
                        utcFormat.timeZone = TimeZone.getTimeZone("UTC")

                        Log.d(TAG, ":dateTimeFormatted$dateTimeFormatted ");

                        val milliseconds = utcFormat.parse(dateTimeFormatted).time

                        Log.d(TAG, ":milliseconds $milliseconds");

                        it.accuracy
                        Single.just(
                                makeRequestModel(
                                        angazaId = angazaId,
                                        battery = getBatteryPercentage(context).toString(),
                                        imei = getImei(context),
                                        latitude = it.latitude.toString(),
                                        longitude = it.longitude.toString(),
                                        utcDateTimeMilli = milliseconds,
                                        utcDateTime = dateTimeFormatted,
                                        locationType = it.provider.toString(),
                                        accuracy = it.accuracy.toString(),
                                        taskPerformer = "taskPerformer-getCurrentLocation"
                                )
                        )

                    }.doOnError {
                        Log.d(TAG, "Error - getCurrentLocation: ${it.localizedMessage}")
                    }

        }

        fun getBatteryPercentage(context: Context): Int {

            val iFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, iFilter)

            val level = if (batteryStatus != null) batteryStatus!!.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) else -1
            val scale = if (batteryStatus != null) batteryStatus!!.getIntExtra(BatteryManager.EXTRA_SCALE, -1) else -1

            val batteryPct = level / scale.toFloat()

            return (batteryPct * 100).toInt()
        }

        fun getCurrentUtcDateTimeFormatted(zonedDateTime: ZonedDateTime): String {

            //Current Date and Time in UTC
            return zonedDateTime
                    .format(DateTimeFormatter.ofPattern("dd-MM-y HH:mm:ss")) //03-05-2019 14:52:32

        }

        fun getCurrentUtcDateTime(): ZonedDateTime {

            //Current Date and Time in UTC
            return ZonedDateTime.now(ZoneId.of("UTC"))

        }

        @SuppressLint("MissingPermission")
        fun getImei(context: Context): String {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager?
            val android_id: String = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID)
            Log.e("===getImei===", "-----$android_id----|||||||")
            if (Build.VERSION.SDK_INT < 29) {
                return telephonyManager!!.deviceId
            } else {
                return android_id
            }
        }


        fun makeRequestModel(
                angazaId: String,
                battery: String,
                imei: String,
                latitude: String,
                longitude: String,
                utcDateTime: String,
                utcDateTimeMilli: Long,
                locationType: String,
                accuracy: String,
                taskPerformer: String

        ): LocationRequestModel {


            return LocationRequestModel(
                    angazaId = angazaId,
                    battery = battery,
                    imei = imei,
                    latitude = latitude,
                    longitude = longitude,
                    deviceTime = utcDateTime,
                    deviceTimeMilli = utcDateTimeMilli,
                    locationType = locationType,
                    accuracy = accuracy,
                    taskPerformer = taskPerformer,
                    androidApiNumber = android.os.Build.VERSION.SDK_INT
            )

        }

        fun isNetworkConnected(context: Context): Boolean {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager?
            return cm!!.activeNetworkInfo != null
        }

        @SuppressLint("MissingPermission")
        fun newGetCurrentLocation(context: Context): Single<Location>? {
            //val data = MutableLiveData<Location?>()
            val request = LocationRequest.create() //standard GMS LocationRequest
                    .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                    .setNumUpdates(1)


            val locationProvider = ReactiveLocationProvider(context)


            return locationProvider.getUpdatedLocation(request)
                    .singleOrError()
            /*.subscribe({
                data.postValue(it)
            }, {
                data.postValue(null)
                Log.d(TAG, "Error")
            })*/

        }

        @SuppressLint("MissingPermission")
        fun newGetCurrentLocation12(context: Context): Observable<Location>? {
            val request = LocationRequest.create() //standard GMS LocationRequest
                    .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                    .setNumUpdates(50).setInterval(20)

            val locationProvider = ReactiveLocationProvider(context)
            return locationProvider.getUpdatedLocation(request)

        }


        @SuppressLint("MissingPermission")
        fun newGetCurrentLocationForAlarm(context: Context): Observable<Location>? {
            Log.d(HourAlarmWorkReceiver.TAG, "onReceive: CALLED-14");

            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

            val request = LocationRequest.create() //standard GMS LocationRequest
                    //.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY)
                    //.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                    .setNumUpdates(3).setInterval(10)

            val preference = GreenLightPreference.getInstance(context)

            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                Log.d(TASK_TAG, "anotherNewGetCurrentLocationForAlarm-gps");

                request.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            } else {
                Log.d(TASK_TAG, "anotherNewGetCurrentLocationForAlarm-gps-no");

                request.setPriority(LocationRequest.PRIORITY_NO_POWER)

            }

            val locationProvider = ReactiveLocationProvider(context)

            return if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                Log.d(TASK_TAG, "anotherNewGetCurrentLocationForAlarm-gps");

                locationProvider.getUpdatedLocation(request)

            } else {
                Log.d(TASK_TAG, "anotherNewGetCurrentLocationForAlarm-gps-no");

                //val la = locationProvider.lastKnownLocation.blockingSingle()
                //Log.d(TASK_TAG, "lastKnownLocation:${la}");

                var lastLocation = getLastKnownLocation(context)

                if (lastLocation == null) {
                    Log.d(TASK_TAG, "getLastLocation-gps-no");

                    lastLocation = preference.getLastLocation()



                }

                Observable.just(lastLocation)

            }

            /*var lastLocation = getLastKnownLocation(context)
            Log.d(TASK_TAG, "lastKnownLocation:${lastLocation}");

            val locationProvider = ReactiveLocationProvider(context)

            return locationProvider.getUpdatedLocation(request)*/


        }

        @SuppressLint("MissingPermission")
        fun anotherNewGetCurrentLocationForAlarm(context: Context): Single<Location>? {
            Log.d(TASK_TAG, "anotherNewGetCurrentLocationForAlarm");

            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager


            val request = LocationRequest.create() //standard GMS LocationRequest

            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                Log.d(TASK_TAG, "anotherNewGetCurrentLocationForAlarm-gps");

                request.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            } else {
                Log.d(TASK_TAG, "anotherNewGetCurrentLocationForAlarm-gps-no");

                request.setPriority(LocationRequest.PRIORITY_LOW_POWER)
            }
            //.setNumUpdates(3).setInterval(10)

            val locationProvider = ReactiveLocationProvider(context)

            //return locationProvider.getUpdatedLocation(request).single(Location("test").apply { accuracy = 10.1F })
            return locationProvider.getUpdatedLocation(request).singleOrError()

        }

        fun getLocation12(context: Context, angazaId: String, bag: CompositeDisposable, taskPerformer: String = ""): Single<LocationRequestModel> {

            val single: Single<LocationRequestModel> = Single.create { emitter ->

                bag.add(
                        getCurrentLoc12(context, bag)
                                .subscribe({

                                    Log.d(TAG, "Success - flatMap getCurrentLocation: ")

                                    val dateTime = getCurrentUtcDateTime()
                                    val dateTimeFormatted = getCurrentUtcDateTimeFormatted(dateTime)

                                    val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
                                    utcFormat.timeZone = TimeZone.getTimeZone("UTC")

                                    Log.d(TAG, ":dateTimeFormatted$dateTimeFormatted ")

                                    val milliseconds = utcFormat.parse(dateTimeFormatted).time

                                    Log.d(TAG, ":milliseconds $milliseconds")
                                    Log.d(TAG, ":it.accuracy ${it.accuracy}")

                                    emitter.onSuccess(makeRequestModel(
                                            angazaId = angazaId,
                                            battery = FunctionalUtils.getBatteryPercentage(context).toString(),
                                            //imei = FunctionalUtils.getImei(context),
                                            imei = "${android.provider.Settings.Secure.getString(
                                                    context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID)}",
                                            //imei = "kazi-techno",
                                            latitude = it.latitude.toString(),
                                            longitude = it.longitude.toString(),
                                            utcDateTimeMilli = milliseconds,
                                            utcDateTime = dateTimeFormatted,
                                            locationType = it.provider.toString(),
                                            accuracy = it.accuracy.toString(),
                                            taskPerformer = taskPerformer
                                    ))

                                }, {

                                    emitter.onError(it)
                                })
                )
            }

            return single

        }


        fun getLocationForAlarm(context: Context, angazaId: String, bag: CompositeDisposable, taskPerformer: String = ""): Single<LocationRequestModel> {

            val single: Single<LocationRequestModel> = Single.create { emitter ->

                bag.add(
                        getCurrentLocForAlarmChild(context, bag)
                                .subscribe({

                                    Log.d(TAG, "getLocationForAlarm-success: $it")

                                    val dateTime = getCurrentUtcDateTime()
                                    val dateTimeFormatted = getCurrentUtcDateTimeFormatted(dateTime)

                                    val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
                                    utcFormat.timeZone = TimeZone.getTimeZone("UTC")

                                    Log.d(TAG, ":dateTimeFormatted$dateTimeFormatted ")

                                    val milliseconds = utcFormat.parse(dateTimeFormatted).time

                                    Log.d(TAG, ":milliseconds $milliseconds")
                                    Log.d(TAG, ":it.accuracy ${it.accuracy}")

                                    emitter.onSuccess(makeRequestModel(
                                            angazaId = angazaId,
                                            battery = FunctionalUtils.getBatteryPercentage(context).toString(),
                                            //imei = FunctionalUtils.getImei(context),
                                            imei = "${android.provider.Settings.Secure.getString(
                                                    context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID)}",

                                            //imei = "kazi-techno",
                                            latitude = it.latitude.toString(),
                                            longitude = it.longitude.toString(),
                                            utcDateTimeMilli = milliseconds,
                                            utcDateTime = dateTimeFormatted,
                                            locationType = it.provider.toString(),
                                            accuracy = it.accuracy.toString(),
                                            taskPerformer = taskPerformer
                                    ))

                                }, {
                                    Log.d(TAG, "getLocationForAlarm-error: ${it.localizedMessage}")
                                    emitter.onError(it)
                                })
                )
            }

            return single

        }


        fun anotherGetLocationForAlarm(context: Context, angazaId: String, bag: CompositeDisposable, taskPerformer: String = ""): Single<LocationRequestModel> {

            val single: Single<LocationRequestModel> = Single.create { emitter ->

                bag.add(
                        anotherGetCurrentLocForAlarmChild(context, bag)
                                .subscribe({

                                    Log.d(TASK_TAG, "anotherGetLocationForAlarm-success: $it")

                                    val dateTime = getCurrentUtcDateTime()
                                    val dateTimeFormatted = getCurrentUtcDateTimeFormatted(dateTime)
                                    val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
                                    utcFormat.timeZone = TimeZone.getTimeZone("UTC")


                                    val milliseconds = utcFormat.parse(dateTimeFormatted).time

                                    Log.d(TASK_TAG, "anotherGetLocationForAlarm:dateTimeFormatted$dateTimeFormatted ")
                                    Log.d(TASK_TAG, "anotherGetLocationForAlarm:milliseconds $milliseconds")
                                    Log.d(TASK_TAG, "anotherGetLocationForAlarm:it.accuracy ${it.accuracy}")

                                    emitter.onSuccess(makeRequestModel(
                                            angazaId = angazaId,
                                            battery = FunctionalUtils.getBatteryPercentage(context).toString(),
                                            //imei = FunctionalUtils.getImei(context),
                                            imei = "${android.provider.Settings.Secure.getString(
                                                    context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID)}",
                                            //imei = "kazi-techno",
                                            latitude = it.latitude.toString(),
                                            longitude = it.longitude.toString(),
                                            utcDateTimeMilli = milliseconds,
                                            utcDateTime = dateTimeFormatted,
                                            locationType = it.provider.toString(),
                                            accuracy = it.accuracy.toString(),
                                            taskPerformer = taskPerformer
                                    ))

                                }, {
                                    Log.d(TASK_TAG, "anotherGetLocationForAlarm-error: ${it.localizedMessage}")
                                    emitter.onError(it)
                                })
                )
            }

            return single

        }


        fun abcdanotherGetLocationForAlarm(context: Context, angazaId: String, bag: CompositeDisposable, taskPerformer: String = ""): Single<LocationRequestModel> {

            return abcdanotherGetCurrentLocForAlarmChild(context, bag)
                    .map {
                        Log.d(TASK_TAG, "anotherGetLocationForAlarm-success: $it")

                        val dateTime = getCurrentUtcDateTime()
                        val dateTimeFormatted = getCurrentUtcDateTimeFormatted(dateTime)
                        val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
                        utcFormat.timeZone = TimeZone.getTimeZone("UTC")


                        val milliseconds = utcFormat.parse(dateTimeFormatted).time

                        Log.d(TASK_TAG, "anotherGetLocationForAlarm:dateTimeFormatted$dateTimeFormatted ")
                        Log.d(TASK_TAG, "anotherGetLocationForAlarm:milliseconds $milliseconds")
                        Log.d(TASK_TAG, "anotherGetLocationForAlarm:it.accuracy ${it.accuracy}")

                        makeRequestModel(
                                angazaId = angazaId,
                                battery = FunctionalUtils.getBatteryPercentage(context).toString(),
                                //imei = FunctionalUtils.getImei(context),
                                imei = "${android.provider.Settings.Secure.getString(
                                        context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID)}",
                                //imei = "kazi-techno",
                                latitude = it.latitude.toString(),
                                longitude = it.longitude.toString(),
                                utcDateTimeMilli = milliseconds,
                                utcDateTime = dateTimeFormatted,
                                locationType = it.provider.toString(),
                                accuracy = it.accuracy.toString(),
                                taskPerformer = taskPerformer
                        )
                    }
            /*val single: Single<LocationRequestModel> = Single.create { emitter ->

                bag.add(
                        abcdanotherGetCurrentLocForAlarmChild(context, bag)
                                .subscribe({

                                    Log.d(TASK_TAG, "anotherGetLocationForAlarm-success: $it")

                                    val dateTime = getCurrentUtcDateTime()
                                    val dateTimeFormatted = getCurrentUtcDateTimeFormatted(dateTime)
                                    val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
                                    utcFormat.timeZone = TimeZone.getTimeZone("UTC")


                                    val milliseconds = utcFormat.parse(dateTimeFormatted).time

                                    Log.d(TASK_TAG, "anotherGetLocationForAlarm:dateTimeFormatted$dateTimeFormatted ")
                                    Log.d(TASK_TAG, "anotherGetLocationForAlarm:milliseconds $milliseconds")
                                    Log.d(TASK_TAG, "anotherGetLocationForAlarm:it.accuracy ${it.accuracy}")

                                    emitter.onSuccess(makeRequestModel(
                                            angazaId = angazaId,
                                            battery = FunctionalUtils.getBatteryPercentage(context).toString(),
                                            //imei = FunctionalUtils.getImei(context),
                                            imei = "${android.provider.Settings.Secure.getString(
                                                    context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID)}",
                                            //imei = "kazi-techno",
                                            latitude = it.latitude.toString(),
                                            longitude = it.longitude.toString(),
                                            utcDateTimeMilli = milliseconds,
                                            utcDateTime = dateTimeFormatted,
                                            locationType = it.provider,
                                            accuracy = it.accuracy.toString(),
                                            taskPerformer = taskPerformer
                                    ))

                                }, {
                                    Log.d(TASK_TAG, "anotherGetLocationForAlarm-error: ${it.localizedMessage}")
                                    emitter.onError(it)
                                })
                )
            }

            return single*/

        }

        fun getCurrentLoc12(context: Context, bag: CompositeDisposable): Single<Location> {

            var location: Location? = null

            val data: Single<Location> = Single.create { emitter ->

                bag.add(
                        newGetCurrentLocation12(context)!!.subscribe({


                            val preference = GreenLightPreference.getInstance(context)
                            preference.setLastLocation(it)
                            //
                            //                            Log.d(TAG, ":location-from-gps = ${it.accuracy}")

                            Log.d(TAG, ":location-test-projecx= ${it}")
                            Log.d(HourAlarmWorkReceiver.TAG, "onReceive: CALLED-14.2 : ${it}");

                            if (location == null) {
                                location = it
                            } else {
                                if (location!!.accuracy > it.accuracy) {
                                    location = it
                                }
                            }

                            bag.add(

                                    Completable.timer(5, TimeUnit.SECONDS)
                                            .observeOn(Schedulers.io())
                                            .subscribeOn(Schedulers.io())
                                            .subscribe({
                                                emitter.onSuccess(location!!)
                                            }, {
                                                emitter.onError(NullPointerException())
                                            })
                            )

                        }, {
                            Log.d(HourAlarmWorkReceiver.TAG, "onReceive: CALLED-14.2-error : ${it.localizedMessage}");

                            emitter.onError(it)
                        })
                )

            }
            return data
        }


        fun getCurrentLocForAlarmChild(context: Context, bag: CompositeDisposable): Single<Location> {

            var location: Location? = null

            val data: Single<Location> = Single.create { emitter ->

                bag.add(
                        newGetCurrentLocationForAlarm(context)!!.subscribe({

                            val preference = GreenLightPreference.getInstance(context)
                            preference.setLastLocation(it)

                            Log.d(TAG, "getCurrentLocForAlarmChild-success: ${it}")
                            Log.d(HourAlarmWorkReceiver.TAG, "onReceive: CALLED-20 : $it");

                            if (location == null) {
                                location = it
                            } else {
                                if (location!!.accuracy > it.accuracy) {
                                    location = it
                                }
                            }

                            bag.add(

                                    Completable.timer(5, TimeUnit.SECONDS)
                                            .observeOn(Schedulers.io())
                                            .subscribeOn(Schedulers.io())
                                            .subscribe({
                                                emitter.onSuccess(location!!)
                                            }, {
                                                emitter.onError(NullPointerException())
                                            })
                            )

                        }, {
                            Log.d(TAG, "getCurrentLocForAlarmChild-error: ${it.localizedMessage}")
                            emitter.onError(it)
                        })
                )

            }
            return data
        }


        fun anotherGetCurrentLocForAlarmChild(context: Context, bag: CompositeDisposable): Single<Location> {

            var location: Location? = null

            val data: Single<Location> = Single.create { emitter ->

                bag.add(
                        anotherNewGetCurrentLocationForAlarm(context)!!
                                .observeOn(Schedulers.trampoline())
                                .subscribeOn(Schedulers.trampoline())
                                .subscribe({

                                    Log.d(TASK_TAG, "anotherGetCurrentLocForAlarmChild-success: ${it}")

                                    if (location == null) {
                                        location = it
                                    } else {
                                        if (location!!.accuracy > it.accuracy) {
                                            location = it
                                        }
                                    }

                                    bag.add(

                                            Completable.timer(5, TimeUnit.SECONDS)
                                                    .observeOn(Schedulers.io())
                                                    .subscribeOn(Schedulers.io())
                                                    .subscribe({
                                                        Log.d(TASK_TAG, "anotherGetCurrentLocForAlarmChild-Completable-success")
                                                        emitter.onSuccess(location!!)
                                                    }, {
                                                        Log.d(TASK_TAG, "anotherGetCurrentLocForAlarmChild-Completable-error: ${it.localizedMessage}")
                                                        emitter.onError(NullPointerException())
                                                    })
                                    )

                                }, {
                                    Log.d(TASK_TAG, "anotherGetCurrentLocForAlarmChild-error: ${it.localizedMessage}")
                                    emitter.onError(it)
                                })
                )

            }
            return data
        }


        fun abcdanotherGetCurrentLocForAlarmChild(context: Context, bag: CompositeDisposable): Single<Location> {

            var location: Location? = null

            val data: Single<Location> = Single.create { emitter ->

                bag.add(
                        newGetCurrentLocationForAlarm(context)!!
                                .observeOn(Schedulers.io())
                                .subscribeOn(Schedulers.io())
                                .subscribe({


                                    val preference = GreenLightPreference.getInstance(context)
                                    preference.setLastLocation(it)

                                    Log.d(TASK_TAG, "abcdanotherGetCurrentLocForAlarmChild-success: ${it}")

                                    if (location == null) {
                                        location = it
                                    } else {
                                        if (location!!.accuracy > it.accuracy) {
                                            location = it
                                        }
                                    }

                                    bag.add(

                                            Completable.timer(5, TimeUnit.SECONDS)
                                                    .observeOn(Schedulers.io())
                                                    .subscribeOn(Schedulers.io())
                                                    .subscribe({
                                                        Log.d(TASK_TAG, "abcdanotherGetCurrentLocForAlarmChild-Completable-success")
                                                        emitter.onSuccess(location!!)
                                                    }, {
                                                        Log.d(TASK_TAG, "abcdanotherGetCurrentLocForAlarmChild-Completable-error: ${it.localizedMessage}")
                                                        emitter.onError(NullPointerException())
                                                    })
                                    )

                                }, {
                                    Log.d(TASK_TAG, "abcdanotherGetCurrentLocForAlarmChild-error: ${it.localizedMessage}")
                                    emitter.onError(it)
                                })
                )

            }
            return data
        }


        @SuppressLint("MissingPermission")
        private fun getLastKnownLocation(context: Context): Location? {
            val mLocationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
//            val providers: List<String> = mLocationManager.getProviders(true)
            val providers: List<String> = mLocationManager.getProviders(true)

            var bestLocation: Location? = null
            for (provider in providers) {
                val l: Location = mLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                        ?: continue
                if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy()) { // Found best last known location: %s", l);
                    bestLocation = l
                }
            }
            return bestLocation
        }


        fun turnGPSOn(context: Context) {
            val provider = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED)
            if (!provider.contains("gps")) { //if gps is disabled
                val poke = Intent()
                poke.setClassName("com.android.settings", "com.android.settings.widget.SettingsAppWidgetProvider")
                poke.addCategory(Intent.CATEGORY_ALTERNATIVE)
                poke.data = Uri.parse("3")
                context.sendBroadcast(poke)
            }
        }


        fun turnGPSOff(context: Context) {
            val provider = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED)
            if (provider.contains("gps")) { //if gps is enabled
                val poke = Intent()
                poke.setClassName("com.android.settings", "com.android.settings.widget.SettingsAppWidgetProvider")
                poke.addCategory(Intent.CATEGORY_ALTERNATIVE)
                poke.data = Uri.parse("3")
                context.sendBroadcast(poke)
            }
        }
    }


}