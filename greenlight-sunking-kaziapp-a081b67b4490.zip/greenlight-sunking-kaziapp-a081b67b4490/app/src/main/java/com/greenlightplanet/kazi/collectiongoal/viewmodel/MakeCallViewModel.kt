package com.greenlightplanet.kazi.collectiongoal.viewmodel

import android.app.Application
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistoryModel
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.collectiongoal.repo.SummaryNewRepository
import com.greenlightplanet.kazi.dashboard.model.response.AppVersionResponse
import com.greenlightplanet.kazi.dashboard.repo.DashBoardRepo
import com.greenlightplanet.kazi.heroboard.extras.LeaderBoardUtil
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.newtasks.model.FeedbackIntentModel
import com.greenlightplanet.kazi.newtasks.model.TaskResponseModel
import com.greenlightplanet.kazi.newtasks.repo.TaskRepo
import com.greenlightplanet.kazi.summary.model.SummaryCallDetailRequestModel
import com.greenlightplanet.kazi.summary.repo.SummaryRepo
import com.greenlightplanet.kazi.utils.Util
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.roundToInt

class MakeCallViewModel(application: Application) : AndroidViewModel(application) {

    var summaryRepo: SummaryNewRepository? = SummaryNewRepository.getInstance(application)
    val taskRepo = TaskRepo.getInstance(application)
    var oldSummaryRepo: SummaryRepo? = SummaryRepo.getInstance(application)

    var pendingListData = MutableLiveData<MutableList<MakeCallNewModel.ColGoalAccount>>()
    var pendingListDataSend: LiveData<MutableList<MakeCallNewModel.ColGoalAccount>> = pendingListData

    var completedListData = MutableLiveData<MutableList<MakeCallNewModel.ColGoalAccount>>()
    var completedListDataSend: LiveData<MutableList<MakeCallNewModel.ColGoalAccount>> = completedListData


    fun updatePendingFragment(data: MutableList<MakeCallNewModel.ColGoalAccount>) {
        pendingListData.value = data
    }

    fun updateCompletedFragment(data: MutableList<MakeCallNewModel.ColGoalAccount>) {
        completedListData.value = data
    }

    fun getMakeCalldata(pageNumber: Int?): MutableLiveData<NewCommonResponseModel<MakeCallNewModel>>? {
        if (Util.isOnline(getApplication())) {
            return summaryRepo?.getMakeCallDataServer(pageNumber)
        } else {
            return summaryRepo?.getMakeCallDataDB()
        }
    }

//    fun insertFullWeeklyTargetResponseToDb(
//        it: NewCommonResponseModel<MakeCallNewModel>,
//        data: MutableLiveData<NewCommonResponseModel<MakeCallNewModel>>
//    ) {
//        summaryRepo?.insertFullWeeklyTargetResponseToDb(it, data)
//    }


    fun getCompletedTabList(
        list: List<MakeCallNewModel.ColGoalAccount>,
        search: Boolean = true,
        searchQuery: String = ""
    ): List<MakeCallNewModel.ColGoalAccount> {

        return if (search) {
            list.filter {
                it.isAchieved && it.customerName?.contains(
                    searchQuery,
                    true
                )!!
            }
        } else {
            list.filter { (it.isAchieved) }
        }

    }


    fun getPendingTabList(
        list: List<MakeCallNewModel.ColGoalAccount>,
        search: Boolean = false,
        searchQuery: String = ""
    ): List<MakeCallNewModel.ColGoalAccount> {

        return if (search) {
            list.filter {
                !it.isAchieved && it.customerName?.contains(
                    searchQuery,
                    true
                )!!
            }
        } else {
            list.filter { (!it.isAchieved) }
        }
    }

    fun getIsInTaskStatusFilter(
        isInTaskStatus: Boolean,
        pendingList: List<MakeCallNewModel.ColGoalAccount>
    ): MutableList<MakeCallNewModel.ColGoalAccount> {

        // creating a new array list to filter our data.
        var filteredlist = mutableListOf<MakeCallNewModel.ColGoalAccount>()

        when (isInTaskStatus) {
            true -> {
                filteredlist = pendingList.filter { it.isInTask == true }.toMutableList()
            }
            false -> {
                filteredlist = pendingList.filter { it.isInTask == false }.toMutableList()
            }
        }

        return filteredlist

    }

    fun getAccountFilter(
        accountStatusString: String,
        pendingList: List<MakeCallNewModel.ColGoalAccount>
    ): MutableList<MakeCallNewModel.ColGoalAccount> {
        // creating a new array list to filter our data.
        val filteredlist: ArrayList<MakeCallNewModel.ColGoalAccount> = ArrayList()

        // running a for loop to compare elements.
        for (item in pendingList) {
            // checking if the entered string matched with any item of our recycler view.

            item?.status?.let {
                if (item.status?.lowercase()?.contains(accountStatusString.lowercase().trim())!!) {
                    // if the item is matched we are
                    // adding it to our filtered list.
                    filteredlist.add(item)
                }
            }

        }

        return filteredlist
    }

    fun getProductFilter(
        productNameString: String,
        pendingList: List<MakeCallNewModel.ColGoalAccount>
    )
            : MutableList<MakeCallNewModel.ColGoalAccount> {
        // creating a new array list to filter our data.
        val filteredlist: ArrayList<MakeCallNewModel.ColGoalAccount> = ArrayList()

        // running a for loop to compare elements.

        for (item in pendingList) {
            // checking if the entered string matched with any item of our recycler view.

            item?.productName?.let {
                if (item.productName?.lowercase()?.contains(productNameString.lowercase().trim())!!) {
                    // if the item is matched we are
                    // adding it to our filtered list.
                    filteredlist.add(item)
                }
            }

        }

        return filteredlist
    }

    fun getLastCalledFilter(
        lastCalledDateString: String,
        pendingList: List<MakeCallNewModel.ColGoalAccount>,
        selectedLastCalled: Int
    ): MutableList<MakeCallNewModel.ColGoalAccount> {
        // creating a new array list to filter our data.
        val filteredlist: ArrayList<MakeCallNewModel.ColGoalAccount> = ArrayList()

        val formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH)
//        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH)
        val date1 = LocalDate.parse(lastCalledDateString, formatter).toEpochDay()

        val fil = pendingList.filter { !it.lastCallDate.isNullOrEmpty()}
        Log.d("CheckingEpochTIme", date1.toString())

        // running a for loop to compare elements.
        for (item in fil/*pendingList*/) {
            // checking if the entered string matched with any item of our recycler view.

            if (selectedLastCalled == 3) {
                if (item.date_timestamp!! <= date1) {
                    // if the item is matched we are
                    // adding it to our filtered list.
                    filteredlist.add(item)
                }
            } else {
                if (item.date_timestamp!! >= date1) {
                    // if the item is matched we are
                    // adding it to our filtered list.
                    filteredlist.add(item)
                }
            }

        }

        return filteredlist
    }

    //region call module Mazroid

    fun getTaskIntentFromDb(): MutableLiveData<NewCommonResponseModel<FeedbackIntentModel>> {
        return taskRepo.getTaskIntentFromDb()
    }

    fun getNewTaskFromDb(): MutableLiveData<NewCommonResponseModel<TaskResponseModel>> {
        return taskRepo.getNewTaskFromDb()
    }


    fun insertCallDetailRequestToDb(
        summaryCallDetailRequestModel: SummaryCallDetailRequestModel,
        isPresent: Boolean,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        showProgress()
        return summaryRepo!!.insertCallDetailRequestToDb(
            summaryCallDetailRequestModel,
            isPresent
        )
    }

    fun solveTaskCallDetailRequest(
        summaryCallDetailRequestModel: SummaryCallDetailRequestModel,
        isPresent: Boolean,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        showProgress()
        return summaryRepo!!.solveTaskCallDetailRequest(summaryCallDetailRequestModel, isPresent)
    }

    fun applySortCustomerName(
        sortAttribute: Int,
        adapterList: MutableList<MakeCallNewModel.ColGoalAccount>,
        sortType: Int,
    ): MutableList<MakeCallNewModel.ColGoalAccount> {

        var sortedList : MutableList<MakeCallNewModel.ColGoalAccount> = mutableListOf()
        when(sortAttribute) {
            1 -> {
                when(sortType) {
                    0 -> {
                        sortedList = adapterList.sortedBy { it.customerName?.trim()?.let { name ->
                            name.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
                        } }.toMutableList()
                    }
                    1 -> {
                        sortedList = adapterList.sortedBy { it.customerName?.trim()?.let { name ->
                            name.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
                        } }.asReversed().toMutableList()
                    }
                }
            }
            2 -> {
                when(sortType) {
                    0 -> {
                        sortedList = adapterList.sortedWith(compareBy { it.collectedAmount }).toMutableList()
                    }
                    1 -> {
                        sortedList = adapterList.sortedWith(compareBy { it.collectedAmount }).asReversed().toMutableList()
                    }
                }
            }

            3 -> {
                when(sortType) {
                    0 -> {
                        sortedList = adapterList.sortedWith(compareBy {
                            it.collectedAmount?.roundToInt()?.let { it1 ->
                                it.expectedAmount?.roundToInt()
                                    ?.minus(it1) }
                        }).toMutableList()
                    }
                    1 -> {

                        sortedList = adapterList.sortedWith(compareBy {
                            it.collectedAmount?.roundToInt()?.let { it1 ->
                                it.expectedAmount?.roundToInt()
                                    ?.minus(it1) }
                        }).asReversed().toMutableList()
                    }
                }
            }
        }

        return sortedList


    }

    //endregion
}