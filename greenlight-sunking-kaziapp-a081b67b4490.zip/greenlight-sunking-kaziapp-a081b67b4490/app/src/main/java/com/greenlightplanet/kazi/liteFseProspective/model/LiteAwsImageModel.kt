package com.greenlightplanet.kazi.liteFseProspective.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import org.jetbrains.annotations.NotNull

@Parcelize
@Entity(tableName = "LiteAwsImageModel",primaryKeys = ["prospectId","withoutExtension"])
data class LiteAwsImageModel(
        @ColumnInfo(name = "awsLink")
        @SerializedName("awsLink")
        var awsLink: String?, // https://kazi-userfiles-mobilehub-391300116.s3.eu-west-2.amazonaws.com/tablemeeting/Kazi_312325.jpeg
        @ColumnInfo(name = "fileName")
        @SerializedName("fileName")
        var fileName: String?, // Kazi_312325.jpeg
        @ColumnInfo(name = "withoutExtension")
        @SerializedName("withoutExtension")
        var withoutExtension: String, // Kazi_312325
        @ColumnInfo(name = "fileUri")
        @SerializedName("fileUri")
        var fileUri: String?, // /sdCard/DCIM/Kazi_312325.jpeg

        //@Ignore
        //var file: File?, // File

        @ColumnInfo(name = "imageName")
        @SerializedName("imageName")
        var imageName: String = "", // home 400

        @ColumnInfo(name = "installationAttempted")
        @SerializedName("installationAttempted")
        var installationAttempted: Int = 0, // 3


//        @PrimaryKey
        @NotNull
        @ColumnInfo(name = "prospectId")
        @SerializedName("prospectId")
        var prospectId: String, // PP1113
        @ColumnInfo(name = "tried")
        @SerializedName("tried")
        var tried: Boolean = false, // false
        @ColumnInfo(name = "savedInDatabase")
        @SerializedName("savedInDatabase")
        var savedInDatabase: Boolean = false, // false
        @ColumnInfo(name = "uploadedToAws")
        @SerializedName("uploadedToAws")
        var uploadedToAws: Boolean = false, // false
        @ColumnInfo(name = "uploadedToGLPServer")
        @SerializedName("uploadedToGLPServer")
        var uploadedToGLPServer: Boolean = false // false
) : Parcelable
