package com.greenlightplanet.kazi.incentivenew.fragment.tvinstallation


import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentEligibleBinding
import com.greenlightplanet.kazi.databinding.FragmentTvEligibleBinding
import com.greenlightplanet.kazi.incentive.model.collection
import com.greenlightplanet.kazi.incentivenew.adapter.tvinstallation.TvInstallationEligibleAdapter
import com.greenlightplanet.kazi.incentivenew.model.tvinstallation.AccountsList
import com.greenlightplanet.kazi.incentivenew.model.tvinstallation.Incentive_TvInstallation
import com.greenlightplanet.kazi.utils.GreenLightPreference
import java.util.*


class TvInstallationEligibleFragment : Fragment(), TvInstallationEligibleAdapter.MyDateData {

    private var _binding:FragmentTvEligibleBinding ? =null
    private val binding get() = _binding!!
   // var recyclerView: RecyclerView? = null

    var preference: GreenLightPreference? = null

    var collection: collection? = null
    var incentive_TvInstallation: Incentive_TvInstallation? = null
    var adapterList: MutableList<AccountsList> = mutableListOf()
    var adapter: TvInstallationEligibleAdapter? = null

    var sortType = 1
    var sortAttribute = 0
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
       _binding = FragmentTvEligibleBinding.inflate(inflater, container, false)
       // recyclerView = view.findViewById<View>(R.id.recyclerView) as RecyclerView
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        binding.tvProductNameKey.visibility = View.GONE
        val bundlesales = arguments
        incentive_TvInstallation = bundlesales?.getParcelable<Incentive_TvInstallation>("eligible")
        incentive_TvInstallation?.accountsList?.filter { it.isEligible == true }?.let { setAdapter(it) }


        clickHander()


    }

    override fun selectedData(date: String, position: Int) {

    }

    fun setAdapter(mutableList: List<AccountsList>) {
        adapterList.clear()
        adapterList.addAll(mutableList)
        if (adapterList.size > 0) {
           binding. tvNoData.visibility = View.GONE

        } else {
           binding. tvNoData.visibility = View.VISIBLE
        }

        if (adapter == null) {

            // adapter = adapterList.filter { it.isEligible!! }.let { EligibleAdapter(it, this, requireContext()) }
            adapter = TvInstallationEligibleAdapter(adapterList, this, requireContext())
            binding. recyclerView?.setHasFixedSize(true)
            binding. recyclerView?.layoutManager = LinearLayoutManager(requireContext())
            binding. recyclerView?.adapter = adapter
        }
        adapter?.notifyDataSetChanged()

    }

    //region Sorting Functions
    private fun byAccountNumber(mutableList: MutableList<AccountsList>) {

        sortAttribute = 3
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    it.accountNumber.toDouble()
                }
            } else {
                sortType = 1
                mutableList.sortBy {
                    it.accountNumber.toDouble()
                }
            }

//            sortPendingAmount(mutableList, sortType)
                binding. tvAccountNumerKey.setBackgroundColor(Color.GRAY)
            adapter?.notifyDataSetChanged()

        }
    }


    fun byRegistrationDate(mutableList: MutableList<AccountsList>) {

        sortAttribute = 2
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    // it.registrationDate
                    Date(it.registrationDate)
                }

            } else {
                sortType = 1
                mutableList.sortBy {
                    Date(it.registrationDate)
                }
            }

//            sortCustomerName(mutableList, sortType)
                binding.tvRegistrationDateKey.setBackgroundColor(Color.GRAY)
            adapter?.notifyDataSetChanged()
        }
    }


    fun refreshSortBackground() {
         binding.tvRegistrationDateKey.setBackgroundColor(Color.BLACK)
             binding. tvAccountNumerKey.setBackgroundColor(Color.BLACK)
                 binding. tvProductNameKey.setBackgroundColor(Color.BLACK)
    }

    private fun clickHander() {
        binding.tvRegistrationDateKey.setOnClickListener { v -> byRegistrationDate(adapterList) }
            binding.tvAccountNumerKey.setOnClickListener { v -> byAccountNumber(adapterList) }

    }

}
