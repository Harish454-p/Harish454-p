package com.greenlightplanet.kazi.fse.dao

import androidx.room.*
import com.greenlightplanet.kazi.fse.model.FseHistory
import io.reactivex.Single

@Dao
interface FseHistoryDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(FseHistorys: List<FseHistory?>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(FseHistory: FseHistory): Long

    @Delete
    fun delete(FseHistory: FseHistory): Int

    @Query("DELETE FROM FseHistory")
    fun deleteAll(): Int

    @Query("SELECT * FROM FseHistory")
    fun getAll(): Single<List<FseHistory>>


    @Query("SELECT * FROM FseHistory LIMIT 1")
    fun get(): Single<FseHistory>

    @Query("SELECT * FROM FseHistory WHERE date BETWEEN :fromDate AND :toDate")
    fun getByDate(fromDate: Long, toDate: Long): Single<List<FseHistory>>

    @Query("SELECT COUNT(*) from FseHistory")
    fun count(): Single<Int>


}
