package com.greenlightplanet.kazi.atrisk.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.atrisk.model.AtRiskAccountModel
import com.greenlightplanet.kazi.summary.model.CollectionRateAccount
import io.reactivex.Single

@Dao
interface AtRiskDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAtRisk(atRiskList: AtRiskAccountModel.CollectionAccount?)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAtRiskAccount(atRiskList: List<AtRiskAccountModel.CollectionAccount>?)

    @Query("select * from CollectionAtRiskAccount where angaza_id =:angazaId")
    fun getAccountAngaza(angazaId: String): Single<List<AtRiskAccountModel.CollectionAccount>>?

    @Query("SELECT * FROM CollectionAtRiskAccount WHERE account_number=:accountNumber LIMIT 1")
    fun getByAccountNumber(accountNumber: String): Single<AtRiskAccountModel.CollectionAccount>?

    @Query("DELETE FROM CollectionAtRiskAccount")
    fun deleteAll(): Int
}
