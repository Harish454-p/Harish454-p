package com.greenlightplanet.kazi.fse.extras.custom

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil


class CustomProgress(val context: Context) {

    companion object : SingletonHolderUtil<CustomProgress, Context>(::CustomProgress) {
        public const val TAG = "CustomProgress"
    }

    var dialog: Dialog? = null

    fun showProgressDialog() {

        dialog = Dialog(context)
        dialog?.setContentView(R.layout.progress_dialog)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog?.setCancelable(false)
        dialog.let {
            if (!dialog?.isShowing!!)
                if (!(context as Activity).isFinishing) {
                    //show dialog
                    dialog?.show()
                }
            else
            dialog?.dismiss()
        }
    }

    fun cancelProgressDialog() {
        if (dialog != null && dialog?.isShowing!!)
            dialog?.cancel()
    }

    fun destroy() {
        dialog = null
    }


}