package com.greenlightplanet.kazi.incentivenew.dao.converter

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryFields
import com.greenlightplanet.kazi.pricegroup.model.Pricing_group

class SummaryFieldConverter {

    @TypeConverter
    fun fromSummaryFieldsList(list: List<SummaryFields>?): String? {
        if (list == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<SummaryFields>>() {

        }.type
        return gson.toJson(list, type)
    }

    @TypeConverter
    fun toPSummaryFieldsList(string: String?): List<SummaryFields>? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<SummaryFields>>() {

        }.type
        return gson.fromJson(string, type)
    }

}


