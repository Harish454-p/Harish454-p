package com.greenlightplanet.kazi.dashboard.dao

import androidx.room.*
import com.greenlightplanet.kazi.dashboard.model.call_sms.ContactRequest
import io.reactivex.Single

@Dao
interface ContactRequestDao {

	@Insert(onConflict = OnConflictStrategy.IGNORE)
	fun insertAllIgnore(ContactRequest: List<ContactRequest>): List<Long>

	@Insert(onConflict = OnConflictStrategy.REPLACE)
	fun insertAllReplace(ContactRequest: List<ContactRequest>): List<Long>

	@Insert(onConflict = OnConflictStrategy.REPLACE)
	fun insert(ContactRequest: ContactRequest): Long

	@Delete
	fun delete(ContactRequest: ContactRequest): Int

	@Query("DELETE FROM ContactRequest")
	fun deleteAll(): Int

	@Query("SELECT * FROM ContactRequest")
	fun getAll(): Single<List<ContactRequest>>

	@Query("SELECT * FROM ContactRequest WHERE uploadedToServer = :uploadedToServer")
	fun getAllForUpload(uploadedToServer: Boolean = false): Single<List<ContactRequest>>

	@Query("SELECT * FROM ContactRequest LIMIT 1")
	fun get(): Single<ContactRequest>

	@Query("SELECT COUNT(*) from ContactRequest")
	fun count(): Single<Int>

	@Query("UPDATE ContactRequest SET serverId = :serverId  WHERE localId LIKE :localId ")
	fun updateContact(localId: String?, serverId: String?): Int
}
