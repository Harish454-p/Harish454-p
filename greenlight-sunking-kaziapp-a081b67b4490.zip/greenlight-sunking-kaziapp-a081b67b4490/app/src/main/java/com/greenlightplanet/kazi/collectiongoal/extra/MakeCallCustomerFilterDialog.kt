package com.greenlightplanet.kazi.collectiongoal.extra

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import androidx.annotation.Keep
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.aminography.primecalendar.PrimeCalendar
import com.aminography.primecalendar.common.CalendarFactory
import com.aminography.primecalendar.common.CalendarType
import com.aminography.primedatepicker.common.OnDayPickedListener
import com.aminography.primedatepicker.picker.PrimeDatePicker
import com.aminography.primedatepicker.picker.callback.MultipleDaysPickCallback
import com.aminography.primedatepicker.picker.theme.DarkThemeFactory
import com.aminography.primedatepicker.picker.theme.LightThemeFactory
import com.aminography.primedatepicker.picker.theme.base.ThemeFactory
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FilterDialogMakeCallCustomerBinding
import io.reactivex.disposables.CompositeDisposable
import java.text.SimpleDateFormat
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.*


@Keep
class MakeCallCustomerFilterDialog(
    val activity: Activity,
    var list: MutableList<String>,
    var selectedAccountStatusId: Int,
    var selectedProductGroupId: Int,
    var selectedLastCalledId: Int,
    var selectedIsInTaskStatusId: Int,
    val callback: MakeCallCustomerDialogCallbacks,
) : Dialog(activity) {

    companion object {
        const val PICKER_TAG = "PrimeDatePickerBottomSheet"
    }

    val bag = CompositeDisposable()

    private lateinit var itemBinding: FilterDialogMakeCallCustomerBinding

    var selectedAccountStatus: Int = 0
    var selectedProductGroup: Int = 0
    var selectedLastCalled: Int = 0
    var selectedIsInTaskStatus: Int = 0

    var adapterLastCalled: ArrayAdapter<String>? = null
    var adapterProductGroup: ArrayAdapter<String>? = null
    var adapterAccountStatus: ArrayAdapter<String>? = null
    var adapterIsInTaskStatus: ArrayAdapter<String>? = null

    var lastCalledAdapterList = arrayOf("All", "Today", "Yesterday", "Not Called", "Custom")
    var accountStatusAdapterList = arrayOf("All", "Disabled", "Enabled")
    var isInTaskStatusList = arrayOf("All", "True", "False")

    private var datePicker: PrimeDatePicker? = null

    var selectedMaxDate: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        super.onCreate(savedInstanceState)
        itemBinding = FilterDialogMakeCallCustomerBinding.inflate(layoutInflater)
        setContentView(itemBinding.root)

        Log.d("FilteredList", "success: $list")

        Log.d(
            "MakeCallFilterDialog0",
            " $selectedLastCalled $selectedProductGroup" +
                    " $selectedAccountStatus $selectedMaxDate $selectedIsInTaskStatus"
        )

        dialogInit()
        setAdapterLastCalled()
        setAdapterProductGroup()
        setAdapterAccountStatus()
        setAdapterIsInTaskStatus()
        onClickFun()

    }

    private fun setAdapterLastCalled() {

        val spinnerList = mutableListOf<String>()
        spinnerList.clear()
        spinnerList.addAll(lastCalledAdapterList)
        adapterLastCalled =
            ArrayAdapter(activity, android.R.layout.simple_spinner_item, spinnerList)
        adapterLastCalled?.setDropDownViewResource(R.layout.spinner_filter_text)
        itemBinding.spinnerLastCalled.adapter = adapterLastCalled

        if (selectedLastCalledId == 4) {
            itemBinding.spinnerLastCalled.setSelection(0)
        } else {
            itemBinding.spinnerLastCalled.setSelection(selectedLastCalledId)
        }


        itemBinding.spinnerLastCalled.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                @RequiresApi(Build.VERSION_CODES.O)
                @SuppressLint("SimpleDateFormat")
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View,
                    which: Int,
                    id: Long,
                ) {
                    selectedLastCalled = which

                    if (selectedLastCalled == 1) {
                        val today = LocalDate.now()
                        selectedMaxDate =
                            DateTimeFormatter.ofPattern("dd-MM-yyyy").format(today).toString()
                    } else if (selectedLastCalled == 2) {
                        val yesterday = LocalDate.now().minusDays(1)
                        selectedMaxDate =
                            DateTimeFormatter.ofPattern("dd-MM-yyyy").format(yesterday).toString()
                    } else if (selectedLastCalled == 3) {
                        var lastCalled =
                            LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                        selectedMaxDate =
                            DateTimeFormatter.ofPattern("dd-MM-yyyy").format(lastCalled).toString()
                    } else if (selectedLastCalled == 4) {
                        ShowDateDialog()
                        datePicker!!.show(
                            (activity as AppCompatActivity).supportFragmentManager,
                            PICKER_TAG
                        )
                    } else {
                        selectedLastCalled = 0
                    }
                    Log.e("MakeCallLastCalled", "Selected === $selectedLastCalled")

                }

                override fun onNothingSelected(parent: AdapterView<*>?) {

                }
            }
    }

    private fun setAdapterProductGroup() {

        val spinnerList = mutableListOf<String>()
        spinnerList.clear()
        spinnerList.addAll(list)
//        spinnerList.add(0,"All")
        adapterProductGroup =
            ArrayAdapter(activity, android.R.layout.simple_spinner_item, spinnerList)
        adapterProductGroup?.setDropDownViewResource(R.layout.spinner_filter_text)
        itemBinding.spinnerProductGroup.adapter = adapterProductGroup
        itemBinding.spinnerProductGroup.setSelection(selectedProductGroupId)

        itemBinding.spinnerProductGroup.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View,
                    which: Int,
                    id: Long,
                ) {
                    selectedProductGroup = which
                    Log.e("MakeCallProductGroup", "Selected === $selectedProductGroup")
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {

                }
            }
    }

    private fun setAdapterAccountStatus() {

        val spinnerList = mutableListOf<String>()
        spinnerList.clear()
        spinnerList.addAll(accountStatusAdapterList.toMutableList())
        adapterAccountStatus =
            ArrayAdapter(activity, android.R.layout.simple_spinner_item, spinnerList)
        adapterAccountStatus?.setDropDownViewResource(R.layout.spinner_filter_text)
        itemBinding.spinnerAccountStatus.adapter = adapterAccountStatus
        itemBinding.spinnerAccountStatus.setSelection(selectedAccountStatusId)

        itemBinding.spinnerAccountStatus.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View,
                    which: Int,
                    id: Long,
                ) {
                    selectedAccountStatus = which
                    Log.e("MakeCallAccountStatus", "Selected === $selectedAccountStatus")

                }

                override fun onNothingSelected(parent: AdapterView<*>?) {

                }
            }
    }

    private fun setAdapterIsInTaskStatus() {

        val spinnerList = mutableListOf<String>()
        spinnerList.clear()
        spinnerList.addAll(isInTaskStatusList.toMutableList())
        adapterIsInTaskStatus =
            ArrayAdapter(activity, android.R.layout.simple_spinner_item, spinnerList)
        adapterIsInTaskStatus?.setDropDownViewResource(R.layout.spinner_filter_text)
        itemBinding.spinnerIsInTaskStatus.adapter = adapterIsInTaskStatus
        itemBinding.spinnerIsInTaskStatus.setSelection(selectedIsInTaskStatusId)

        itemBinding.spinnerIsInTaskStatus.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View,
                    which: Int,
                    id: Long,
                ) {
                    selectedIsInTaskStatus = which
                    Log.e("MakeCallIsInTaskStatus", "Selected === $selectedIsInTaskStatus")

                }

                override fun onNothingSelected(parent: AdapterView<*>?) {

                }
            }
    }

    @SuppressLint("ObsoleteSdkInt")
    private fun dialogInit() {
        var width = 0
        var height = 0
        val size = Point()

        val w = activity.windowManager
        w.defaultDisplay.getSize(size)

        width = size.x - 40 - 40
        height = size.y
        setCancelable(true)
        setCanceledOnTouchOutside(true)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window!!.setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT)
    }

    private fun onClickFun() {

        itemBinding.btnClose.setOnClickListener { dismiss() }

        itemBinding.btnApply.setOnClickListener {

            Log.d(
                "MakeCallFilterDialog1",
                " $selectedLastCalled $selectedProductGroup" +
                        " $selectedAccountStatus $selectedMaxDate $selectedIsInTaskStatus"
            )
            callback.onFilter(
                selectedLastCalled,
                selectedProductGroup,
                selectedAccountStatus,
                selectedIsInTaskStatus,
                selectedMaxDate
            )
            dismiss()
        }

        itemBinding.btnReset.setOnClickListener {

            selectedLastCalled = 0
            selectedProductGroup = 0
            selectedAccountStatus = 0
            selectedIsInTaskStatus = 0
            selectedMaxDate = null

            callback.onFilter(
                selectedLastCalled,
                selectedProductGroup,
                selectedAccountStatus,
                selectedIsInTaskStatus,
                selectedMaxDate
            )

            dismiss()
        }

    }

    @Keep
    private fun ShowDateDialog() {

        val today = CalendarFactory.newInstance(
            CalendarType.CIVIL,
            CalendarFactory.newInstance(CalendarType.CIVIL).locale
        )

        val minDateCalendar = getMinDateCalendar(CalendarType.CIVIL)
        val maxDateCalendar = getMaxDateCalendar(CalendarType.CIVIL)
        val theme = getDefaultTheme()

        Log.d("getMin_Max_DATE", " $minDateCalendar $maxDateCalendar")

        datePicker = PrimeDatePicker.dialogWith(today).let {
            it.pickMultipleDays(multipleDaysPickCallback)

        }.let {
            minDateCalendar.let { minDate -> it.minPossibleDate(minDate) }
            maxDateCalendar.let { maxDate -> it.maxPossibleDate(maxDate) }
            it.applyTheme(theme)
            it.build()
        }
    }

    private fun getDefaultTheme(): ThemeFactory {
        return object : LightThemeFactory() {

            override val calendarViewDisabledDayLabelTextColor: Int
                get() = getColor(R.color.borderGrey)

            override val calendarViewPickedDayBackgroundColor: Int
                get() = getColor(R.color.clr_glp)

            override val calendarViewDayLabelTextColor: Int
                get() = getColor(R.color.colorBlack)

            override val actionBarNegativeTextColor: Int
                get() = getColor(R.color.borderGrey)

            override val calendarViewPickedDayLabelTextColor: Int
                get() = getColor(R.color.colorBlack)

            override val calendarViewPickedDayInRangeBackgroundColor: Int
                get() = getColor(R.color.borderGrey)

            override val selectionBarMultipleDaysItemBackgroundColor: Int
                get() = getColor(R.color.clr_glp)

            override val selectionBarMultipleDaysItemTopLabelTextColor: Int
                get() = getColor(R.color.colorBlack)

            override val selectionBarMultipleDaysItemBottomLabelTextColor: Int
                get() = getColor(R.color.colorBlack)

            override val selectionBarBackgroundColor: Int
                get() = getColor(R.color.borderGrey)

            override val calendarViewMonthLabelTextColor: Int
                get() = getColor(R.color.colorBlack)

        }
    }
    @Keep
    @SuppressLint("SimpleDateFormat")
    private val multipleDaysPickCallback = MultipleDaysPickCallback { multipleDays ->

        val maxDate3 = multipleDays.stream()
            .max(PrimeCalendar::compareTo)
            .get()

        try {
            var format = SimpleDateFormat("yyyy-MM-dd")
            val newDate: Date? = format.parse(maxDate3.shortDateString.replace("/", "-"))

            format = SimpleDateFormat("dd-MM-yyyy")
            selectedMaxDate = format.format(newDate!!)
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    @Keep
    private fun getMinDateCalendar(calendarType: CalendarType): PrimeCalendar {
        val minDateCalendar: PrimeCalendar?
        var firstDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val start: Int = firstDate.dayOfYear
        minDateCalendar = CalendarFactory.newInstance(calendarType)
        minDateCalendar.set(Calendar.DAY_OF_YEAR, start)

        return minDateCalendar
    }

    private fun getMaxDateCalendar(calendarType: CalendarType): PrimeCalendar {
        val maxDateCalendar: PrimeCalendar?

        var lastDate = LocalDate.now()
        val last: Int = lastDate.dayOfYear

        maxDateCalendar = CalendarFactory.newInstance(calendarType)
        maxDateCalendar.set(Calendar.DAY_OF_YEAR, last)
        return maxDateCalendar
    }

    override fun setOnDismissListener(listener: DialogInterface.OnDismissListener?) {
        bag.clear()
        super.setOnDismissListener(listener)
    }

    @Keep
    interface MakeCallCustomerDialogCallbacks {
        fun onFilter(
            lastCalled: Int,
            productGroup: Int,
            accountStatus: Int,
            isInTaskStatus: Int,
            selectedMaxDate: String?
        )
    }

}