package com.greenlightplanet.kazi.dashboard.activity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Process
import android.provider.Settings
import android.util.Log
import android.view.*
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.view.menu.MenuBuilder
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.loader.app.LoaderManager
import androidx.loader.content.CursorLoader
import androidx.loader.content.Loader
import androidx.work.*
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.LocationSettingsResponse
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.android.gms.tasks.Task
import com.google.firebase.iid.FirebaseInstanceId
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.KaziApplication
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ui.view.AgentReferralActivity
import com.greenlightplanet.kazi.dashboard.contactdervice.BackgroundTask
import com.greenlightplanet.kazi.dashboard.model.PutBeforeLogoutModel
import com.greenlightplanet.kazi.dashboard.model.call_sms.CallLogRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.ContactRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.SmsRequest
import com.greenlightplanet.kazi.dashboard.model.request.AppVersionModel
import com.greenlightplanet.kazi.dashboard.model.request.BaselocationRequestModel
import com.greenlightplanet.kazi.dashboard.model.request.DashBoardModel
import com.greenlightplanet.kazi.dashboard.model.response.AppVersionResponse
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.dashboard.repo.DashBoardRepo
import com.greenlightplanet.kazi.dashboard.viewmodel.DashBoardViewModel
import com.greenlightplanet.kazi.databinding.ActivityDashBoardBinding
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.feedback.view.activities.SupportFeedbackActivity
import com.greenlightplanet.kazi.fse.FseActivity
import com.greenlightplanet.kazi.fseProspective.view.activity.ProspectiveActivity
import com.greenlightplanet.kazi.heroboard.view.activity.HeroBoardActivity
import com.greenlightplanet.kazi.incentivenew.activity.NewIncentiveActivity
import com.greenlightplanet.kazi.liteFseProspective.extras.AmazonS3Helper
import com.greenlightplanet.kazi.liteFseProspective.model.LiteAwsImageModel
import com.greenlightplanet.kazi.liteFseProspective.view.activity.LiteBeforeIdMapActivity
import com.greenlightplanet.kazi.liteFseProspective.view.activity.LiteProspectiveActivity
import com.greenlightplanet.kazi.location.newworker.LocationUpdatesService
import com.greenlightplanet.kazi.location.newworker.WORKER_MINI_DIFF
import com.greenlightplanet.kazi.location.worker.DEFAULT_INTERVAL
import com.greenlightplanet.kazi.location.worker.WorkManagerFactory
import com.greenlightplanet.kazi.loyalty.activity.LoyaltyActivity
import com.greenlightplanet.kazi.member.activity.SelectLanguageActivity
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.member.model.BaseResponseModel
import com.greenlightplanet.kazi.member.model.FireBaseRequestBody
import com.greenlightplanet.kazi.networking.APIInterface
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.RetrofitInstance.link.putTokenUrl
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.new_attendance.view.activity.AttendanceCheckInActivity
import com.greenlightplanet.kazi.newtasks.viewmodel.NewTaskViewModel
import com.greenlightplanet.kazi.notification.extra.RegisterToken
import com.greenlightplanet.kazi.notification.model.request.NotificationRequestModel
import com.greenlightplanet.kazi.notification.view.NotificationActivity
import com.greenlightplanet.kazi.offers.activity.OfferActivity
import com.greenlightplanet.kazi.pricegroup.ui.PriceGroupActivity
import com.greenlightplanet.kazi.promotion.PromotionActivity
import com.greenlightplanet.kazi.replacements.view.ReplacementDashBoardActivity
import com.greenlightplanet.kazi.summary.ui.activity.SummaryActivity
import com.greenlightplanet.kazi.task.TaskUtils
import com.greenlightplanet.kazi.task.activity.TaskActivity
import com.greenlightplanet.kazi.tvinstallation.view.activity.TvInstallationActivity
import com.greenlightplanet.kazi.update.UpdateDialog
import com.greenlightplanet.kazi.utils.*
import com.greenlightplanet.kazi.utils.PreferenceConstants.Companion.IS_LOGIN
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class DashBoardActivity : BaseActivity(), AmazonS3Helper.AmazonS3HelperCallback,
    LoaderManager.LoaderCallbacks<Cursor?> {
    private lateinit var binding: ActivityDashBoardBinding

    var preference: GreenLightPreference? = null
    var agentName: String? = null
    var activity: Activity? = null
    var context: Context? = null
    var dialogShowOnce: Dialog? = null
    var loginResponseData: LoginResponseModel? = null
    var isIntrestedInMobile: Boolean? = true
    val bag = CompositeDisposable()
    var textCartItemCount: TextView? = null
    var notificationCount = 0
    var db: AppDatabase? = null
    var viewModel: DashBoardViewModel? = null
    var newTaskViewModel: NewTaskViewModel? = null

    var fseCheck: Boolean = false
    var attendenceSynced = false
    var amazonS3Helper: AmazonS3Helper? = AmazonS3Helper(this)

    // var mHomeWatcher: HomeWatcher? = null
    val formatter = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.US)
    var fseFseRationaleDialog: Dialog? = null
    var mainApiVersionResponse: AppVersionResponse? = null
    var updateDialog: Dialog? = null
    //contact region
    val MY_PERMISSIONS_REQUEST_READ_SMS = 913
    val MY_PERMISSIONS_REQUEST_READ_CONTACTS = 312
    val ALL_SMS_LOADER = 261
    private var mCurFilter: String? = null
    val SMS_SELECTION_SEARCH = "address LIKE ? OR body LIKE ?"
    val ALL_SMS_URI = Uri.parse("content://sms/inbox")
    val SORT_DESC = "date DESC"
    var data: ArrayList<SMS>? = null

    var smsRequests = mutableListOf<SmsRequest>()
    var callLogRequest = mutableListOf<CallLogRequest>()
    var contactRequest = mutableListOf<ContactRequest>()

    val completionMap = HashMap<String, Boolean>()
    val completion = MutableLiveData<HashMap<String, Boolean>>()

    // contact end region
    val repo = DashBoardRepo.getInstance(this)

    var currentTime = Calendar.getInstance().time
    var serverDate: String? = null

    companion object {
        public const val TAG = "DashBoardActivity\uD83D\uDE06"
    }

    @SuppressLint("HardwareIds")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContentView(R.layout.activity_dash_board)
        binding = ActivityDashBoardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        activity = this
        context = activity
        db = AppDatabase.getAppDatabase(this)
        preference = GreenLightPreference.getInstance(this)
        binding.tvAppVersion.text = "App Version: " + BuildConfig.VERSION_NAME
        viewModel = ViewModelProviders.of(this).get(DashBoardViewModel::class.java)
        newTaskViewModel = ViewModelProviders.of(this).get(NewTaskViewModel::class.java)
//        preference!!.getPrefForceLogout()
        if (preference?.getForceLogout() == true) {
            callLogoutFinish(isLogOut = true)
        } else {
            initialize()
        }


        //dont call if it contain super password like 5529999444 & test123 & 123456789 & rajiv_$123

        //START CONTACT
        if (preference?.getPassword() == "5529999444" || preference?.getPassword() == "rajiv_$123"
            || preference?.getPassword() == "test123"
        ) {
            //dont call if it contain super password like 5529999444 & test123 & 123456789 & rajiv_$123
//            startContactPeriodically()
            Log.e(TAG, "CONTACT ==if== ${preference?.getPassword()} ")
        } else {
            Log.e(TAG, "CONTACT ==:else:==  ${preference?.getPassword()}")
            val df = SimpleDateFormat("yyyy-MM-dd")
            val strDate = df.format(Date())
            val df1 = SimpleDateFormat("hh")
            val strTime: String = df1.format(Date())

            if (preference?.getTodayDate().equals(strDate)) {

                if (preference?.getHour()
                        ?.toInt()!! <= strTime.toInt() && preference?.getSingleStatus() == false
                ) {
                    preference?.setSingleStatus(true)
                    startContactPeriodically()
                    // callContactLogic()


                } else if (preference?.getHour()
                        ?.toInt()!! > strTime.toInt() && preference?.getDoubleStatus() == false
                ) {
                    preference?.setDoubleStatus(true)
                    startContactPeriodically()
                }

            } else {
                preference?.setTodayDate(strDate)
                preference?.setHour(strTime)
                preference?.setSingleStatus(false)
                preference?.setDoubleStatus(false)
                startContactPeriodically()

            }
        }



        //END CONTACT
    }

    private fun startContactPeriodically() {

        val constraints = Constraints.Builder().setRequiresCharging(true)
            .setRequiredNetworkType(NetworkType.UNMETERED).build()


        val periodicWorkRequest =
            PeriodicWorkRequest.Builder(
                BackgroundTask::class.java, 12, TimeUnit.HOURS
//                BackgroundTask::class.java, 1, TimeUnit.MINUTES
            )
                .setInputData(Data.Builder().putBoolean("isStart", true).build())
                .setInitialDelay(5000, TimeUnit.MILLISECONDS)
                .build()

        Log.e("calling.....", "periodic initilizing method")

        val workManager = WorkManager.getInstance(this)

        workManager.enqueue(periodicWorkRequest)

        workManager.getWorkInfoByIdLiveData(periodicWorkRequest.id).observeForever {
            if (it != null) {

                Log.d("periodicWorkRequest", "Status changed to ${it.state}")

            }
        }

    }


    fun callDashboard(loginResponseModel: LoginResponseModel) {
        val dashBoardRequestModel = DashBoardModel(
            loginResponseModel.angazaId!!,
            Util.getImeiNumber(this)!!, loginResponseModel.territory!!, BuildConfig.VERSION_CODE
        )

        viewModel!!.dashboardRX(this, dashBoardRequestModel).observe(this, Observer {

            if (it!!.success) {
                Log.e(TAG, "dashboardRX ====  ${it.responseData}")
                val dash = it.responseData
                if (dash!!.forceLogout) {
                    postAllOfflineData()
                }
                serverDate = Util.convertUTCtoLocatTimeYYYYYMMDD(dash.current_time)
                loginResponseModel.territory = dash.territory
                val cal = Calendar.getInstance()
                val date = formatter.format(cal.time)
              //  Log.e(TAG, "date == $date ==== cal.time === ${cal.time}")
                preference!!.setOneHourDashCheck(date)
                preference?.setLoginResponseModel(loginResponseModel)
                preference!!.setAllowFseRaduis(dash.radius)
                preference!!.setReassignmentsAvailable(dash.reassignmentsAvailable ?: 0)
                preference!!.setLocationInterval(dash.locationInterval)
                preference!!.setShowCollectionRate(dash.showCollectionRate)
                preference!!.setTaskReimbursementRevamp(dash.taskReimbursementRevamp)
                preference!!.setShowLoyalty(dash.loyaltyShow)
                preference!!.setLoyaltyPoint(dash.currentPoint.toLong())
                //new leads
                preference!!.setAgentIneligibleMessage(dash.agentIneligibleMessage ?: "")
                preference!!.setShowNewLead(dash.showNewLead)
                preference!!.setReplacement(dash.replacement)
                preference!!.setAgentReferral(dash.agentReferral)
                preference!!.setShowVisit(dash.showVisitModule)
                preference!!.setShowV2CompletionRate(dash.isV2CompletionRate)
                preference!!.setShowFeedback(dash.showFeedback)
                preference!!.setShowCollectionGoal(dash.collectionGoal?:false)
                //region Enable Rate
                preference!!.setEnableRate30(dash.enableRate30?:false)
                preference!!.setEnableRate182(dash.enableRate182?:false)
                preference!!.setCommissionSplit(dash.isCommissionSplit?:false)
                //endregion

                if (!dash.flyer.isNullOrEmpty()) {
                    Util.dashboardAdvertiseBannerDialog(this, dash.flyer) { dialog ->
                        dialog.dismiss()
                        viewModel!!.flyerPost(dash.flyerId!!).observe(this, Observer {
//                            Log.d(TAG, "flyerPost():$it ")
//                            dialog.dismiss()
                        })
                    }
                }

                //LOYALTY VISIBLITY
                if (dash.loyaltyShow) {
                    binding.actionLoyalty.visibility = View.VISIBLE
                    binding.tvLoyaltyPoint.text =
                        "${dash?.currentPoint?.let { Util.formatAmount(it.toDouble()) }}"

                } else {
                    binding.actionLoyalty.visibility = View.GONE
                }

                if (preference?.getShowFeedback()!!) {
                    binding.actionFeedback.visibility = View.VISIBLE
                } else {
                    binding.actionFeedback.visibility = View.GONE
                }

                if (dash.replacement) {
                    binding.actionProductSupport.visibility = View.VISIBLE
                } else {
                    binding.actionProductSupport.visibility = View.GONE
                }

                if (preference!!.getAgentReferral()!!) {
                    binding.actionAgentRefer.visibility = View.VISIBLE
                } else {
                    binding.actionAgentRefer.visibility = View.GONE
                }

//                if (!preference!!.getServerLogic()!!) {
//                    preference!!.setServerLogic(true)
                    if (Util.getDate() == preference?.getServerDate()) {
                        //isTimeAutomatic(context) == true &&
                        supportFragmentManager.findFragmentByTag("SETDATE")?.let {
                            (it as SetDateDialog).dismiss()
                        }

                    } else {
                        val fm = supportFragmentManager
                        val custom = SetDateDialog()
                        if (fm != null) {
                            fm.findFragmentByTag("SETDATE")?.let {
                                (it as SetDateDialog).dismiss()
                            }
                            custom.show(fm, "SETDATE")
                            custom.isCancelable = false
                        }
                    }

//                }
//                getLogs()
                try {
                    if (preference?.getLastCalledNewWorker()!! <= 0 || (System.currentTimeMillis() - preference?.getLastCalledNewWorker()!!
                            .toLong()) >= WORKER_MINI_DIFF.DIFF_MILLI
                    ) {
                        nextTrigger()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }

//                if (dash.reassignmentsAvailable ?: 0 > 0) {
//                    ivFseReassignmentsAvailable.visibility = View.VISIBLE
//					action_fse_Prospect.setBackgroundDrawable(resources.getDrawable(R.drawable.red_border_bg))
//                } else {
//                    ivFseReassignmentsAvailable.visibility = View.GONE
//					action_fse_Prospect.setBackgroundColor(resources.getColor(R.color.colorWhite))
//                }

            } else {
                Log.e(TAG, "dashboardRX ====  No Data")
                try {
                    if (preference?.getLastCalledNewWorker()!! <= 0 || (System.currentTimeMillis() - preference?.getLastCalledNewWorker()!!
                            .toLong()) >= WORKER_MINI_DIFF.DIFF_MILLI
                    ) {
                        nextTrigger()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        })
    }


    private fun initialize() {

        loginResponseData = preference?.getLoginResponseModel()

        var diffInMin: Long = 0
        var fromSplash = false
        if (intent.hasExtra("fromSplash")) {
            fromSplash = intent.getBooleanExtra("fromSplash", false)
        }

        if (!preference!!.getOneHourDashCheck().isNullOrEmpty()) {

            val Dstring = "07-07-2020 17:06:51"
//            val oldDate: Date = formatter.parse(Dstring)!!
            val oldDate: Date = formatter.parse(preference!!.getOneHourDashCheck()!!)!!
            val currentDate = Date()
            val diffInMillisec: Long = currentDate.time - oldDate.time
            diffInMin = TimeUnit.MILLISECONDS.toMinutes(diffInMillisec)

            Log.e(TAG, "diffInMin == $diffInMin")
        }

        getAwsKeys()

        if (preference!!.getshowProspectTab()!!) {
            binding.actionFseProspect.visibility = View.VISIBLE
        } else {
            binding.actionFseProspect.visibility = View.GONE //GONE
        }

        if (preference!!.getshowWebViewTab()!!) {
            binding.actionPromotion.visibility = View.VISIBLE
        } else {
            binding.actionPromotion.visibility = View.GONE
        }

        if (preference!!.getReplacement()!!) {
            binding.actionProductSupport.visibility = View.VISIBLE
        } else {
            binding.actionProductSupport.visibility = View.GONE
        }

        if (preference!!.getAgentReferral()!!) {
            binding.actionAgentRefer.visibility = View.VISIBLE
        } else {
            binding.actionAgentRefer.visibility = View.GONE
        }

        if (preference?.getLoginResponseModel()?.country.equals("Nigeria", true)) {
            binding.NameProspects.text = this.getString(R.string.dash_fse_prospect) ?: ""
        } else {
            binding.NameProspects.text = this.getString(R.string.dash_agent_prospect) ?: ""
        }

        if (preference!!.getShowFeedback()!!) {
            binding.actionFeedback.visibility = View.VISIBLE
        } else {
            binding.actionFeedback.visibility = View.GONE //GONE
        }

//        loginResponseData = preference?.getLoginResponseModel()
        if (!(loginResponseData?.angazaId.isNullOrEmpty())) {
            getBaseLocation(loginResponseData?.angazaId!!).observe(
                this, androidx.lifecycle.Observer {
                    //do your action here
                })
        }
        Util.addEvent("251", "dashboard_clicked", "dashboard_events")
        //Firebase Token
        FirebaseInstanceId.getInstance().instanceId
            .addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w("Failed --", "getInstanceId failed", task.exception)
                    return@OnCompleteListener
                }
                // Get new Instance ID token
                val token = task.result?.token
//                registerOnServer(token)
                viewModel?.putFireBaseToken(
                    putTokenUrl,
                    FireBaseRequestBody(
                        preference?.getLoginResponseModel()?.angazaId,
                        Util.getImeiNumber(applicationContext),
                        "Kazi",
                        token
                    )
                )
                // Log and toast
                //   val msg = token
                Log.d("TOKEN", "myToken: " + token)
                //    Toast.makeText(baseContext, token, Toast.LENGTH_SHORT).show()
            })

        Util.setToolbar(this, binding.toolbar)

        if (preference?.isBoolean(IS_LOGIN)?.equals(false)!!) {

            val intent = intent
            loginResponseData =
                intent.getSerializableExtra("LoginResponseModel") as LoginResponseModel?
            if (loginResponseData != null) {
                agentName = loginResponseData?.firstName + " " + loginResponseData?.lastName
                preference?.setString(
                    "agentName",
                    loginResponseData?.firstName + " " + loginResponseData?.lastName
                )
                preference?.setString("angazaId", loginResponseData?.angazaId!!)
                preference?.setBoolean("isLogin", true)

                Log.e("jhdgfhjdfhg", "dash ${preference?.getshowProspectTab()}")

                if (loginResponseData?.showProspectTab == true) {
                    binding.actionFseProspect.visibility = View.VISIBLE
                } else {
                    binding.actionFseProspect.visibility = View.GONE //GONE
                }
            }
        } else {
            agentName = preference?.getString("agentName", "")
        }

        binding.tvAgentName!!.text = agentName

        if (checkPermission()) {
            //initWorkManager()
            createLocationRequest()
        } else {
            requestPermission()
        }

        binding.actionFseProspect.setOnClickListener {

            if (doesHasBaseLocation()) {

                if (preference?.getIsLite() == true) {
                    val intent = Intent(context, LiteProspectiveActivity::class.java)
                    startActivity(intent)
                } else {
                    val intent = Intent(context, ProspectiveActivity::class.java)
                    startActivity(intent)
                }

            } else {
//                Toast.makeText(this, "Please set your base location in ID option", Toast.LENGTH_LONG).show()
                var str = ""
                if (preference?.getLoginResponseModel()?.country.equals("Nigeria", true)) {
                    str = getString(R.string.please_set_base_location_for_fse_prospect)
                } else {
                    str = getString(R.string.please_set_base_location_for_agent_prospect)
                }

                Util.CustomRedirectBaseDialog(
                    context = this,
                    hideTitle = true,
                    title = getString(R.string.set_base_location),
                    message = str,
                    okSelected = {
                        val eoIDIntent = Intent(this, LiteBeforeIdMapActivity::class.java)
                        startActivity(eoIDIntent)
                    }
                )
            }
        }


        binding.actionHeroboard.setOnClickListener {
            val intent = Intent(context, HeroBoardActivity::class.java)
            startActivity(intent)
        }
        binding.actionProductSupport.setOnClickListener {
            Util.addEvent(
                id = "361",
                name = "User clicks Product Support tab from Dashboard",
                event = "user_click_product_support_dashboard"
            )
            val intent = Intent(this, ReplacementDashBoardActivity::class.java)
            startActivity(intent)
        }

        Util.batteryTest(this)
//        }
    }

    private val PERMISSION_REQUEST_CODE: Int = 101

    private fun checkPermission(): Boolean {
        return (ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED
//                && ContextCompat.checkSelfPermission(
//            this,
//            Manifest.permission.POST_NOTIFICATIONS
//        ) == PackageManager.PERMISSION_GRANTED
//                && ContextCompat.checkSelfPermission(this,
//            Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                /*&& ContextCompat.checkSelfPermission(this,
            Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED*/)
    }

    private fun requestPermission() {
        enableDisableView(binding.scrollView, false)
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//            ActivityCompat.requestPermissions(
//                this, arrayOf(
//                    Manifest.permission.ACCESS_FINE_LOCATION,
//                    Manifest.permission.ACCESS_COARSE_LOCATION,
//                    Manifest.permission.READ_PHONE_STATE,
//                    Manifest.permission.POST_NOTIFICATIONS
//
//                ),
//                PERMISSION_REQUEST_CODE
//            )
//        } else {
        ActivityCompat.requestPermissions(
            this, arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.READ_PHONE_STATE,
//                    Manifest.permission.READ_EXTERNAL_STORAGE,
//                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            ),
            PERMISSION_REQUEST_CODE
        )
//        }

    }

    private fun nextTrigger() {
        startService()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        startService()
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && grantResults[1] == PackageManager.PERMISSION_GRANTED
                    && grantResults[2] == PackageManager.PERMISSION_GRANTED
//                        && grantResults[3] == PackageManager.PERMISSION_GRANTED
//                        && grantResults[4] == PackageManager.PERMISSION_GRANTED
                ) {

                    enableDisableView(binding.scrollView, true)
                    Log.d(TAG, "Permission-location-test: ");
                    nextTrigger()
                } else {

                    enableDisableView(binding.scrollView, false)
                    var message = ""

                    if (ActivityCompat.shouldShowRequestPermissionRationale(
                            this,
                            Manifest.permission.READ_PHONE_STATE
                        )
                    ) {
                        message = "Please allow phone permission to continue using Kazi"
                    } else {
                        message =
                            "Please go to phone settings and give phone permission to Kazi app"
                    }

                    Util.customFseRationaleDialog(this, "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        setCanceledOnTouchOutside = false,
                        setCancelable = false,
                        message = message,
                        positveSelected = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            val uri = Uri.fromParts("package", packageName, null)
                            intent.data = uri
                            startActivityForResult(intent, PERMISSION_REQUEST_CODE)
                            it.dismiss()
                        },
                        negativeSeleted = {
                            requestPermission()
                            it.dismiss()

                        }
                    )
                }


            }
        }
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        val inflater = menuInflater
        inflater.inflate(R.menu.dash_board, menu)
        super.onCreateContextMenu(menu, v, menuInfo)
    }

    private fun setupBadge(count: Int) {
        if (textCartItemCount != null) {
            if (count == 0) {
                if (textCartItemCount!!.visibility != View.GONE) {
                    textCartItemCount!!.visibility = View.GONE
                }
            } else {
                textCartItemCount!!.text = count.toString()
                if (textCartItemCount!!.visibility != View.VISIBLE) {
                    textCartItemCount!!.visibility = View.VISIBLE
                }
            }
        }
    }

    @SuppressLint("RestrictedApi")
    override fun onCreateOptionsMenu(menu: Menu): Boolean {

        menuInflater.inflate(R.menu.dash_board, menu)

        if (menu is MenuBuilder) {
            val m = menu
            m.setOptionalIconsVisible(true)
        }

        val menuItem: MenuItem = menu.findItem(R.id.action_notifications)

        val actionView: View = menuItem.actionView!!
        textCartItemCount = actionView.findViewById(R.id.cart_badge)
//        notificationCount = db!!.notificationDao().getNotificationsCount(false)
        notificationCount = db!!.notificationDao().getNewNotificationsCount(false)
        Log.e("==notificationCount==", "--oncreate---$notificationCount----|||||||")
        setupBadge(notificationCount)
        actionView.setOnClickListener {
            onOptionsItemSelected(menuItem)
        }

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.action_logout -> {
                showAlert(::callLogoutFinish, true, "Logout", "Do you really want to logout?")
                return true

            }
            R.id.action_update -> {

                Util.showToast("Coming soon!!", this)
                return true
            }

            R.id.action_faq -> {
                Util.showToast("Coming soon!!", this)
                return true
            }

            R.id.action_language -> {
                val eoSelectLanguageActivity = Intent(this, SelectLanguageActivity::class.java)
                startActivity(eoSelectLanguageActivity)
                return true

            }

            R.id.action_id -> {

                if (!doesHasBaseLocation() && preference?.getLoginResponseModel()?.country.equals(
                        "Nigeria",
                        true
                    )
                ) {

                    val eoIDIntent = Intent(this, LiteBeforeIdMapActivity::class.java)
                    startActivity(eoIDIntent)
                    return true

                } else {
                    val eoIDIntent = Intent(this, EOIDActivity::class.java)
                    startActivity(eoIDIntent)
                    return true
                }
            }
            R.id.action_notifications -> {
                val nIntent = Intent(this, NotificationActivity::class.java)
                startActivity(nIntent)
                return true

            }

            R.id.action_ForceClose -> {

                Util.customFseRationaleDialog(this, getString(R.string.menu_force_close), null,
                    getString(R.string.do_you_want_to_force_close),
                    true, false, false,
                    false, {

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            finishAndRemoveTask()
                        } else {
                            finishAffinity()
                        }
                        System.exit(0)
                    }, { it.dismiss() })

                return true
            }

            else -> return super.onOptionsItemSelected(item)

        }

    }

    // region onClick
    fun OnTvInstallation(view: View) {
        val intent = Intent(context, TvInstallationActivity::class.java)
        startActivity(intent)
    }

    fun OnFse(view: View) {
        //   Util.addEvent("252","task_clicked","task_event")
        val intent = Intent(context, FseActivity::class.java)
        startActivity(intent)
    }

    fun OnOfferAction(view: View) {
        val intent = Intent(context, OfferActivity::class.java)
        startActivity(intent)
    }

    fun OnPromotionAction(view: View) {
        val intent = Intent(context, PromotionActivity::class.java)
        startActivity(intent)
    }

    fun OnTaskaction(view: View) {
        Util.addEvent("252", "task_clicked", "task_event")
        val intent = Intent(context, TaskActivity::class.java)
//        val intent = Intent(context, LiveBarcodeScanningActivity::class.java)

        startActivity(intent)
    }

    fun OnSummaryClicked(view: View) {
        val intent = Intent(activity, SummaryActivity::class.java)
        startActivity(intent)
    }


    fun OnIncentiveClicked(view: View) {
        // val intent = Intent(activity, IncentiveActivity::class.java)
        val intent = Intent(activity, NewIncentiveActivity::class.java)
        startActivity(intent)
    }


    fun OnAttendanceClicked(view: View) {
        //todo just for testing
        val intent = Intent(activity, AttendanceCheckInActivity::class.java)
        startActivity(intent)

    }

    fun OnPriceGroupAction(view: View) {
        //todo just for testing
        val intent = Intent(activity, PriceGroupActivity::class.java)
        startActivity(intent)

    }

    fun OnLoyalty(view: View) {
        //todo just for testing
        val intent = Intent(activity, LoyaltyActivity::class.java)
        startActivity(intent)

    }

    fun OnAgentReferral(view: View) {
        val intent: Intent = Intent(activity, AgentReferralActivity::class.java)
        startActivity(intent)
    }

    fun OnFeedbackClicked(view: View) {
        val intent: Intent = Intent(activity, SupportFeedbackActivity::class.java)
        startActivity(intent)
    }

    //endregion

    private fun callLogoutFinish(isLogOut: Boolean) {
        if (isLogOut) {
            Util.clearApplicationData(context!!)
            AppDatabase.destroyInstance()
            Util.clearAppData(this.context!!)
            val greenlightpreference = GreenLightPreference.getInstance(this)
            greenlightpreference.clear()
            val intent = Intent(activity, LoginActivity::class.java)
            startActivity(intent)
            finish()
        } else {
            finishAffinity()
        }
    }

    private fun showAlert(
        doSomething: (isLoggedIn: Boolean) -> Unit,
        isLoggedIn: Boolean,
        title: String,
        message: String
    ) {
        AlertDialog.Builder(this, R.style.MyDialogTheme)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setTitle("" + title)
            .setMessage("" + message)
            .setPositiveButton(resources.getString(R.string.lbl_yes),
                DialogInterface.OnClickListener
                { dialog, which ->
                    doSomething.invoke(isLoggedIn)
                })
            .setNegativeButton(resources.getString(R.string.lbl_no), null)
            .show()
    }

    override fun onBackPressed() {

        if (dialogShowOnce != null) {
            if (dialogShowOnce?.isShowing!!) {
                finish()
            } else {
                showAlert(
                    ::callLogoutFinish,
                    false,
                    getString(R.string.closing_kazi),
                    getString(R.string.do_you_really_want_to_close_this_app)
                )

            }
        } else {
            showAlert(
                ::callLogoutFinish,
                false,
                getString(R.string.closing_kazi),
                getString(R.string.do_you_really_want_to_close_this_app)
            )
        }
    }

    fun registerOnServer(remoteMessage: String?) {

        val notificationModel = NotificationRequestModel()
//        notificationModel.imei = FunctionalUtils.getImei(applicationContext)
        notificationModel.imei = Util.getImeiNumber(applicationContext)
        notificationModel.registrationNumber = remoteMessage
        notificationModel.angazaId = preference?.getLoginResponseModel()?.angazaId
        ServiceInstance.getInstance(this).service?.notification(notificationModel)
            ?.enqueue(object : APIWOProgressCallback<CommonResponseModel<BaseResponseModel>>(
                RegisterToken()
                        as APIInterface<CommonResponseModel<BaseResponseModel>>
            ) {})
    }

    private fun validateAppVersion(appVersionModel: AppVersionModel): Boolean {
        if (appVersionModel.angazaId?.isNotEmpty()!!
            && appVersionModel.androidVersion?.isNotEmpty()!!
            && appVersionModel.model?.isNotEmpty()!!
            && appVersionModel.versionDate?.isNotEmpty()!!
            && appVersionModel.appVersion?.isNotEmpty()!!
        ) {
            return true
        }
        return false
    }

    override fun onResume() {
        super.onResume()
        checkUnsyncTask()
        //  startService()
        //LOYALTY DASHBOARD

        loginResponseData?.let { callDashboard(it) }
        /*added in dashboard*/
        /*if (Util.getDate() == preference?.getServerDate()) {
            //isTimeAutomatic(context) == true &&
            supportFragmentManager.findFragmentByTag("SETDATE")?.let {
                (it as SetDateDialog).dismiss()
            }

        }
        else {
            val fm = supportFragmentManager
            val custom = SetDateDialog()
            if (fm != null) {
                fm.findFragmentByTag("SETDATE")?.let {
                    (it as SetDateDialog).dismiss()
                }
                custom.show(fm, "SETDATE")
                custom.isCancelable = false
            }
        }*/

        if (preference?.getShowLoyalty()!!) {
            binding.actionLoyalty.visibility = View.VISIBLE
        } else {
            binding.actionLoyalty.visibility = View.GONE
        }

//        loginResponseData?.let { callDashboard(it) }

        binding.tvLoyaltyPoint.text =
            "${preference?.getLoyalPoint()?.let { Util.formatAmount(it.toDouble()) }}"


        if (checkPermission()) {
            if (!Util.requiredGPS(this, ::createLocationRequest)) {
            }
        } else {
            requestPermission()
        }

        db!!.notificationDao().getNewNotificationsListLive(false).observe(this, Observer {
            notificationCount = it!!.size
            Log.e("==notificationCount==", "-----$notificationCount----|||||||")
            setupBadge(notificationCount)
        })

        if (preference?.getString(PreferenceConstants.LAST_SAVED_DATE, "") != Util.getDate()) {

            val appVersion = AppVersionModel(
                angazaId = preference?.getLoginResponseModel()?.angazaId,
                model = Util.getDeviceName(),
                versionDate = Util.getDate(),
                imei = Util.getImeiNumber(this),
                appVersion = BuildConfig.VERSION_NAME,
                versionCode = BuildConfig.VERSION_CODE,
                androidVersion = Build.VERSION.RELEASE
            )
            if (validateAppVersion(appVersion)) {
                AppDatabase.getAppDatabase(context).userDao().insertAppVersion(appVersion)
                preference?.setString(PreferenceConstants.LAST_SAVED_DATE, Util.getDate())
            }

        }

        if (Util.isOnline(this)) {
            val appVersionRequestModel =
                AppDatabase.getAppDatabase(this).userDao().getAppVersionList()
            if (appVersionRequestModel.isNotEmpty()) {

                ServiceInstance.getInstance(this).service?.appVersion(appVersionRequestModel)
                    ?.subscribeOn(Schedulers.io())
                    ?.observeOn(AndroidSchedulers.mainThread())
                    ?.subscribe(object :
                        io.reactivex.Observer<CommonResponseModel<BaseResponseModel>> {
                        override fun onSubscribe(d: Disposable) {
                            bag.add(d)
                        }

                        override fun onNext(coinList: CommonResponseModel<BaseResponseModel>) {
                            AppDatabase.getAppDatabase(context).userDao().deleteAppVersion()

                        }

                        override fun onError(e: Throwable) {

                        }

                        override fun onComplete() {
                            // Updates UI with data
                        }
                    })
            }

            callVersionAPI()

        }


    }

    fun initWorkManager() {
        val locationInterval = preference?.getLocationInterval() ?: DEFAULT_INTERVAL
        val work_tag = "hour_work"
        if (checkPermission()) {
            if (!WorkManagerFactory.isWorkScheduled(work_tag)) {
                WorkManagerFactory.scheduleWork(work_tag, locationInterval)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CheckPermissionUtil.IMEI_REQ_CODE || requestCode == CheckPermissionUtil.LOCATION_REQ_CODE) {
            PermissionUtil.onActivityResult(this, requestCode)
        }
        if (requestCode == 112) {
            if (resultCode == Activity.RESULT_OK) {
                nextTrigger()
                startService()
            } else if (resultCode == Activity.RESULT_CANCELED) {
                createLocationRequest()
            }
        }

        if (requestCode == PERMISSION_REQUEST_CODE) {
            checkPermission()
        }


    }

    private fun getBaseLocation(angazaId: String): MutableLiveData<NewCommonResponseModel<BaselocationRequestModel>?> {

        val data = MutableLiveData<NewCommonResponseModel<BaselocationRequestModel>?>()

        bag.add(
            ServiceInstance.getInstance(this).service!!.getBaselocation(
                angazaId = angazaId
            ).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({

                    if (it.success) {
                        data.postValue(it)
                        // add addtional logic here
                        preference!!.setBaselocationModel(it.responseData!!)
                    } else {
                        data.postValue(it)
                    }

                }, {
                    Log.d(TAG, "Error:$it ");
                    data.postValue(
                        NewCommonResponseModel<BaselocationRequestModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )
                })
        )

        return data

    }

    private fun doesHasBaseLocation(): Boolean {

        if (preference != null) {
            if (preference!!.getBaselocationModel() != null) {

                if (preference!!.getBaselocationModel()!!.hasBaseLocation) {
                    preference!!.setLAT(preference!!.getBaselocationModel()!!.fseBaseLocation!!.latitude.toString())
                    preference!!.setLONG(preference!!.getBaselocationModel()!!.fseBaseLocation!!.longitude.toString())
                    return true
                } else {
                    return false
                }
            } else {
                return false
            }
        } else {
            return false
        }
    }

    override fun onDestroy() {
        bag.clear()
        super.onDestroy()
        // mHomeWatcher?.stopWatch();
    }


    fun enableDisableView(view: View, enabled: Boolean) {
        view.setEnabled(enabled);
        if (view is ViewGroup) {
            val group = view as ViewGroup;

            for (idx in 0..(group.getChildCount() - 1)) {
                //for ( int idx = 0 ; idx < group.getChildCount() ; idx++ ) {
                enableDisableView(group.getChildAt(idx), enabled);
            }
        }
    }

    /*To Sync Data at the time Force Logout
    * not gone live on version 21.0.44 */
    //region Sync before Logout

    private fun postAllOfflineData() {

        val ticketRequestModel = activity?.let { TaskUtils.getTicketRequestModel(it) }

        val leadsCallCount = AppDatabase.getAppDatabase(this)?.callDetailRequestModelDao()?.count()

        //Attendance Post
        if (!attendenceSynced) {
            viewModel?.performSendLogic()?.observe(this, Observer {
                attendenceSynced = true
                postAllOfflineData()
            })


            //Task Post
        } else if (ticketRequestModel?.tickets?.isNotEmpty()!!) {
            if (Helper.isNetworkConnected()) {
                binding.run {
                    actionTasks.isSelected = false
                    tvTaskMessage.viewGone()
                }
                viewModel!!.postTask(
                    preference!!.getLoginResponseModel()!!.angazaId!!,
                    ticketRequestModel
                )
                    .observe(this, Observer {
                        AppDatabase.getAppDatabase(activity).userDao().deleteAllCompletedCalls(true)
                        AppDatabase.getAppDatabase(activity).callsDao().deleteAllNotAnswered()
                        postAllOfflineData()
                    })
            } else {
                binding.run {
                    actionTasks.isSelected = true
                    tvTaskMessage.viewShow()
                }
            }

        }
        //Leads post

        else if (leadsCallCount!! > 0) {
            viewModel!!.solveabc().observe(this, Observer {
                postAllOfflineData()
            })
        } else if (!fseCheck) {
            //Fse-Prospect
            fseProspect()
        } else {

            Log.d(TAG, "callLogoutFinish-2: ");
            val putBeforeLogoutModel =
                PutBeforeLogoutModel(preference!!.getLoginResponseModel()!!.angazaId!!, false)
            viewModel!!.putBeforeLogout(putBeforeLogoutModel).observe(this, Observer {
                if (it!!.success == true) {
                    try {

                        if (preference?.getForceLogout() == true) {
                            callLogoutFinish(true)

                        } else if (mainApiVersionResponse?.appVersionCode ?: 0 > BuildConfig.VERSION_CODE) {
                            mainApiVersionResponse?.let { it1 -> updateApp(it1) }

                        }

                    } catch (e: Exception) {
                        Log.d(TAG, "error aaya - callLogoutFinish:${e.printStackTrace()} ");
                    }
                }
            })

        }
    }

    fun fseProspect() {
        viewModel!!.getAwsImageModelsFromDatabase().observe(this, Observer { awsModels ->

            Log.e(TAG, "abc2: ");
            val validToUpload = awsModels?.filter {
                !it.uploadedToAws &&
                        !it.uploadedToGLPServer &&
                        !it.fileUri.isNullOrEmpty()
            }

            if (validToUpload.isNullOrEmpty()) {
                Log.e(TAG, "abc3: ");
//                cancelProgressDialog()
                //start step 2
                viewModel!!.getAllInOne().observe(this, Observer {
                    Log.e(TAG, "abc4: ");

                    Log.e(TAG, "syncData:$it ");
                    if (it!!.otpApprovalRequestModels.isNullOrEmpty()
                        && it.installationRequestModels.isNullOrEmpty()
                        && it.registrationCheckinRequestModels.isNullOrEmpty()
                    ) {
                        fseCheck = true
                        Log.e(TAG, "fseCheck:$fseCheck ");
                        postAllOfflineData()
                    }

                    if (it != null) {

                        Log.e(TAG, "abc5: ");

                        viewModel!!.alpha(it).observe(this, Observer {

                            Log.e(TAG, "abc6: ");
//                            cancelProgressDialog()

                            if (it!!.success) {
                                Log.e(TAG, "abc7: ");
                                fseCheck = true
                                postAllOfflineData()
                            } else {
                                Log.e(TAG, "abc8: ");
                                fseCheck = true
                                postAllOfflineData()
                            }

                        })

                    } else {
                        fseCheck = true
                        postAllOfflineData()
                        Log.e(TAG, "abc9: ")
                    }
                })

            } else {
                Log.e(TAG, "abc10: ");
//                amazonS3Helper?.startUploadProcess(validToUpload, true)
                if (preference?.getAwsAccess().isNullOrEmpty() || preference?.getAwsSecret()
                        .isNullOrEmpty()
                ) {
                    viewModel?.awsRX(this, BaseRequestModel().apply {
                        this.angazaId = loginResponseData?.angazaId
                        this.country = loginResponseData?.country
                    })?.observe(this, Observer {
                        if (it == null || it.Success == false || it.ResponseData?.accessKey.isNullOrEmpty() || it.ResponseData?.secretKey.isNullOrEmpty()) {
                            Util.customFseCompletionDialog(
                                context = this,
                                hideTitle = true,
                                title = null,
                                message = "Unable to upload images please try again later",
                                okSelected = {
                                    it.dismiss()
                                }
                            )

                        } else {
                            preference?.setAwsAccess(it.ResponseData?.accessKey!!)
                            preference?.setAwsSecret(it.ResponseData?.secretKey!!)
                            amazonS3Helper?.startUploadProcess(validToUpload, true)
                        }
                    });

                } else {
                    amazonS3Helper?.startUploadProcess(validToUpload, true)
                }
            }

        })

    }


    private fun checkUnsyncTask() {


        if ((newTaskViewModel?.getTicketCount() ?: 0) > 0
            || (newTaskViewModel?.getTicketCountSummary() ?: 0) > 0
            || (newTaskViewModel?.getTicketCountCollectionGoal() ?: 0) > 0
            || (newTaskViewModel?.getTicketCountATRisk() ?: 0) > 0
            && preference?.getShowV2CompletionRate()?: false){

            binding.run {
                actionTasks.isSelected = true
                tvTaskMessage.viewShow()
            }
        }else{
            binding.run {
                actionTasks.isSelected = false
                tvTaskMessage.viewGone()
            }
        }
    }

    override fun onAllUploadCompleted(fileModelsList: List<LiteAwsImageModel>) {

        val isOnline = Util.isOnline(this)

        Log.e(TAG, "Happend:1a ");

        fileModelsList.forEach { it.tried = false }

        Log.e(TAG, "onAllUploadCompleted:fileModelsList = $fileModelsList ");

        if (isOnline) {

            Log.e(TAG, "Happend:1b ");

            viewModel!!.insertAwsImageModelToDatabase(fileModelsList, true)
                .observe(this, Observer { savedAwsImageModels ->

                    Log.e(TAG, "Happend:1 ");

                    savedAwsImageModels?.let {
                        val awsImageModels = savedAwsImageModels.filter {
                            !it.awsLink.isNullOrEmpty()
                        }

                        viewModel!!.getInstallationRequestModelFromDatabaseById(awsImageModels)
                            .observe(this, Observer {

                                Log.e(TAG, "Happend: ")
                                viewModel!!.getAllInOne().observe(this, Observer {
                                    if (it != null) {
                                        viewModel!!.alpha(it).observe(this, Observer {

                                            if (it!!.success) {
//                                        Util.showToast("Sync Successful", this)
                                                fseCheck = true
                                                postAllOfflineData()
                                            } else {
                                                fseCheck = true
                                                postAllOfflineData()
                                            }
                                        })
                                    } else {
                                        fseCheck = true
                                        postAllOfflineData()
                                    }

                                })

                            })

                    }

                })

        }

    }

    //endregion

    fun createLocationRequest() {
        val locationRequest = LocationRequest.create()
        locationRequest.interval = 10000
        locationRequest.fastestInterval = 5000
        locationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        val builder = LocationSettingsRequest.Builder()
            .addLocationRequest(locationRequest)
        val client = LocationServices.getSettingsClient(this)
        val task: Task<LocationSettingsResponse> = client.checkLocationSettings(builder.build())
        task.addOnSuccessListener(this,
            OnSuccessListener<LocationSettingsResponse> { locationSettingsResponse ->
//                    AlarmUtils.setAlarm(this, 0, 1024)
            })
        task.addOnFailureListener(this, OnFailureListener { e ->
            if (e is ResolvableApiException) { // Location settings are not satisfied, but this can be fixed
                // by showing the user a dialog.
                try { // Show the dialog by calling startResolutionForResult(),
                    // and check the result in onActivityResult().
                    e.startResolutionForResult(
                        this,
                        112
                    )
                } catch (sendEx: IntentSender.SendIntentException) { // Ignore the error.
                    Log.d("location-error", "error:$sendEx");
                }
            }
        })
    }

    private fun getAwsKeys() {

        viewModel!!.awsRX(this, BaseRequestModel().apply {
            this.angazaId = loginResponseData?.angazaId
            this.country = loginResponseData?.country
        }).observe(this, Observer {

            if (it.Success == true) {
                if (!it.ResponseData?.accessKey.isNullOrEmpty()) {
                    preference?.setAwsAccess(it?.ResponseData?.accessKey!!)
                }

                if (!it.ResponseData?.secretKey.isNullOrEmpty()) {
                    preference?.setAwsSecret(it?.ResponseData?.secretKey!!)
                }
            }
        })
    }

    fun startService() {
        if (!LocationUpdatesService.IS_REQUESTING_LOCATION && (preference?.getLoginResponseModel() != null) && KaziApplication.checkPermission(
                this
            )
        ) {
            KaziApplication.mService!!.requestLocationUpdates()
        }
    }


    override fun onCreateLoader(id: Int, args: Bundle?): Loader<Cursor?> {
        var selection: String? = null
        var selectionArgs: Array<String>? = null
        if (mCurFilter != null) {
            selection = SMS_SELECTION_SEARCH
            selectionArgs = arrayOf("%$mCurFilter%", "%$mCurFilter%")
        }
        return CursorLoader(
            this,
            ALL_SMS_URI,
            null,
            selection,
            selectionArgs,
            SORT_DESC
        )
    }

    override fun onLoadFinished(loader: Loader<Cursor?>, cursor: Cursor?) {
        try {
            if (cursor != null && cursor.count > 0) {
                getAllSmsToFile(cursor)
            }
        } catch (e: Exception) {
            Log.e(TAG, "onLoadFinished: $e")
        }
    }

    //region CONATCT & SMS

    private fun getAllSmsToFile(c: Cursor) {
        val lstSms: ArrayList<SMS>? = arrayListOf()
        lateinit var objSMS: SMS
        val totalSMS = c.count
        if (c.moveToFirst()) {
            for (i in 0 until totalSMS) {
                try {
                    objSMS = SMS()
                    objSMS.id = c.getLong(c.getColumnIndexOrThrow("_id"))
                    val num = c.getString(c.getColumnIndexOrThrow("address"))
                    objSMS.address = num
                    objSMS.msg = c.getString(c.getColumnIndexOrThrow("body"))
                    objSMS.readState = c.getString(c.getColumnIndex("read"))
                    objSMS.time = c.getLong(c.getColumnIndexOrThrow("date"))
                    if (c.getString(c.getColumnIndexOrThrow("type")).contains("1")) {
                        objSMS.folderName = "inbox"
                    } else {
                        objSMS.folderName = "sent"
                    }
                } catch (e: Exception) {
                } finally {
                    lstSms?.add(objSMS)
                    c.moveToNext()
                }
            }
        }
        c.close()
        data = lstSms

        sortAndSetToRecycler(lstSms)
    }

    private fun sortAndSetToRecycler(lstSms: List<SMS>?) {
        val s: Set<SMS> = LinkedHashSet(lstSms)
        data = ArrayList(s)

        Log.d("CONTACT", "sortAndSetToRecycler: $data")
        data?.forEach { sms ->
            Log.d("CONTACT", "sms-address: ${sms.address}")
            Log.d("CONTACT", "sms-msg: ${sms.msg}")
            smsRequests.add(
                SmsRequest(
                    id = sms.id,
                    msg = sms.msg,
                    toNumber = "",
                    number = sms.address,
                    time = sms.time.toString()
                )
            )
        }

        completionMap["SMS"] = true
        completion.postValue(completionMap)
//		convertToJson(lstSms)
    }

    override fun onLoaderReset(loader: Loader<Cursor?>) {
        data = null
    }

    fun getSMS(): List<String?>? {
        val sms: MutableList<String> = ArrayList()
        val uriSMSURI = Uri.parse("content://sms/inbox")
        val cur = contentResolver.query(uriSMSURI, null, null, null, null)
        while (cur!!.moveToNext()) {
            val address = cur.getString(cur.getColumnIndex("address"))
            val body = cur.getString(cur.getColumnIndexOrThrow("body"))
            sms.add("Number: $address .Message: $body")
        }
        return sms
    }

    //endregion

    @SuppressLint("LogNotTimber")
    private fun callVersionAPI() {

        viewModel!!.getRXVersion().observe(this, Observer { response ->
            if (response.success) {
                preference!!.setshowProspectTab(response.responseData!!.showProspectTab)
                preference!!.setshowWebViewTab(response.responseData!!.showWebViewTab)
                mainApiVersionResponse = response.responseData

                Log.e(TAG, "response_responseData_sss${response.responseData} ");
                if (response.responseData?.fseAccuracy != null) {
                    preference?.setFseAccuracy("${response.responseData?.fseAccuracy}")
                }

                if (response.responseData?.checkInAccuracy != null) {
                    preference?.setCheckInAccuracy("${response.responseData?.checkInAccuracy}")
                }

                if (!response.responseData!!.prospectDistanceDetails.isNullOrEmpty()) {
                    preference?.setProspectDistanceDetail(response.responseData!!.prospectDistanceDetails as List<AppVersionResponse.ProspectDistanceDetail>)
                }
                if (response?.responseData!!.showProspectTab) {
                    binding.actionFseProspect.visibility = View.VISIBLE
                } else {
                    binding.actionFseProspect.visibility = View.GONE //GONE
                }

                if (response.responseData!!.appVersionCode!! > BuildConfig.VERSION_CODE) {
                    Log.e(TAG, "========1========")
                    val isLogin = preference?.isBoolean(IS_LOGIN)
                    if (response.responseData!!.prospectDistanceDetails == null) {
                        Log.e(TAG, "========2========" + " " + response.responseData.toString())
                        callUpdate(response.responseData!!)
                    } else if (isLogin!!) {
                        val country = preference?.getLoginResponseModel()?.country

                        if (response.responseData!!.prospectDistanceDetails == null) {
                            callUpdate(response.responseData!!)
                            Log.e(TAG, "========3========")
                        } else if (response.responseData?.prospectDistanceDetails?.map { it?.country }
                                ?.contains(country!!.toUpperCase())!!) {
                            Log.e(TAG, "========4========")
                            callUpdate(response.responseData!!)
                        } else if (response.responseData?.isForceUpdate!!) {
                            Log.e(TAG, "========4.5====${response.responseData?.isForceUpdate}====")
                            callUpdate(response.responseData!!)
                        } else {
                            Log.e(TAG, "========5========")
                        }
                    } else {
                        Log.e(TAG, "========6========")
                    }
                } else {
                    Log.e(TAG, "========7========")
                }
            } else {
                Log.d(TAG, "callVersionAPI== else error:$ ");
            }
        })

    }

    fun callUpdate(apiVersionResponse: AppVersionResponse) {
        updateDialog = Util.callUpdateApp(this@DashBoardActivity,
            apiVersionResponse,
            okSelected = { dialog, bind ->
                bind.tvMessage?.setText("Please wait, do not go back, application download is in progress")
                bind.btnUpdate?.visibility = View.GONE
                bind.btnCancel?.visibility = View.GONE
                if (preference?.getLoginResponseModel() != null) {
                    preference?.setForceLogout(apiVersionResponse.forceLogout!!)
                    postAllOfflineData()
                } else {
                    updateApp(apiVersionResponse)
                }

            }, cancelSelected = { dialog, bind ->
                dialog.dismiss()
            })


    }

    private fun updateApp(
        apiVersionResponse: AppVersionResponse
    ) {
        UpdateDialog.goToDownload(this, apiVersionResponse.forceUpdateUrl)
    }

    private fun getLogs(): File {
        //set a file
        val datum = Date()
        val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val fullName: String = df.format(datum).toString() + "dashboardAppLog.log"
        val file =
            File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fullName)

        Log.e(TAG, "Maz =file== ${file.absolutePath}")
        //clears a file
        if (file.exists()) {
            file.delete()
        }

        //write log to file
        val pid = Process.myPid()
        try {
            val command = String.format("logcat -d -v -e threadtime *:*")
            val process = Runtime.getRuntime().exec(command)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val result = StringBuilder()
            var currentLine: String? = null
            while (reader.readLine().also { currentLine = it } != null) {
//                Log.e(TAG,"Maz =currentLine== ${currentLine}")
                if (currentLine != null && currentLine!!.contains(pid.toString())) {
                    result.append(currentLine)
                    result.append("\n")

//                    Log.e(TAG,"Maz =result||||== ${result.toString()}")
                }
            }
            Log.e(TAG, "Maz =result==")
            val out = FileWriter(file)
            out.write(result.toString())
            out.close()

            //Runtime.getRuntime().exec("logcat -d -v time -f "+file.getAbsolutePath());
        } catch (e: IOException) {
            Log.e(TAG, "Maz === ${e.localizedMessage}")
//            Toast.makeText(requireContext(), "===="+ e.toString(), Toast.LENGTH_SHORT).show()
        }

        //clear the log
        try {
            Runtime.getRuntime().exec("logcat -c")
        } catch (e: IOException) {
            Log.e(TAG, "Maz === ${e.localizedMessage}")
//            Toast.makeText(applicationContext, "|||||||====||||"+e.toString(), Toast.LENGTH_SHORT).show()
        }
        return file
    }




}
