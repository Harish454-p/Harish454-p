package com.greenlightplanet.kazi.loyalty.converter.passbook

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.loyalty.model.passbook.Entries

class EntriesConverter {

    @TypeConverter
    fun fromEntriesList(list: List<Entries>?): String? {
        if (list == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<Entries>>() {

        }.type
        return gson.toJson(list, type)
    }

    @TypeConverter
    fun toEntriesList(string: String?): List<Entries>? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<Entries>>() {

        }.type
        return gson.fromJson(string, type)
    }

}


