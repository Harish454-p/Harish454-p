package com.greenlightplanet.kazi.agentReferral.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.agentReferral.model.referralStatusDetail.ReferralDetail
import io.reactivex.Single

@Dao
interface ReferralStatusDetailDao {
    @Query("SELECT * FROM ReferralDetail")
    fun getAgentReferral() : Single<List<ReferralDetail>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAgentReferral(referralDetail: ReferralDetail)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAllAgentReferral(referral : List<ReferralDetail>)

    @Query("DELETE FROM ReferralDetail")
    fun deleteAllAgentReferral() : Int

    @Query("SELECT * FROM ReferralDetail WHERE statusId = :statusId")
    fun getAllSelectedChild(statusId : Int) : Single<List<ReferralDetail>>
}