package com.greenlightplanet.kazi.liteFseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import com.greenlightplanet.kazi.liteFseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.liteFseProspective.model.*
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteInstallationRepo
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.networking.CommonResponseModel

import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel

class ClickMultiViewModel(application: Application) : AndroidViewModel(application) {

    val installationRepo = LiteInstallationRepo.getInstance(application)

    //region start installationRepo
    fun compressImageForAws(context: Context, files: List<ImageUploadUtil.ImageModel>, showProgress: () -> Unit = {}): MutableLiveData<List<LiteAwsImageModel>?> {
        showProgress()
        return installationRepo.compressImageForAws(context, files)
    }

    fun performInstallation(context: Context, fseProspectResponseModel: LiteFseProspectResponseModel?, isOnline: Boolean, prospectId: String, angazaId: String, accountNumber: String, installationAttempted: Int, fileModel: List<LiteAwsImageModel>, /*location: Location,*/ imageName: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return installationRepo.performInstallation(context, fseProspectResponseModel, isOnline, prospectId, angazaId, accountNumber, installationAttempted, fileModel/*, location*/)
    }

    fun performInstallation2(context: Context, fseProspectResponseModel: LiteFseProspectResponseModel?, isOnline: Boolean, prospectId: String, fileModel: List<LiteAwsImageModel>, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return installationRepo.performInstallation2(context,fseProspectResponseModel,isOnline, prospectId,fileModel)
    }

    fun insertAwsImageModelToDatabase(inputFiles: List<LiteAwsImageModel>, isUploadedToAws: Boolean): MutableLiveData<List<LiteAwsImageModel>?> {
        return installationRepo.insertAwsImageModelToDatabase(inputFiles, isUploadedToAws)
    }


    //
    fun updateFseProspect(fseProspectResponseModel: LiteFseProspectResponseModel): MutableLiveData<LiteFseProspectResponseModel> {
        return installationRepo.updateFseProspect(fseProspectResponseModel)
    }

    fun getFseProspectiveFromServerInstallation(angazaId: String, prospectId: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>? {
        showProgress()
        return installationRepo.getFseProspectiveFromServer(angazaId, prospectId)
    }

    fun awsRX(context: Context, requestModel: BaseRequestModel): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
        return installationRepo.awsRX(context, requestModel)
    }

    fun getFseProsResponseModelFromProspectID(prospectId: String): MutableLiveData<LiteFseProspectResponseModel> {
        return installationRepo.getFseProsResponseModelFromProspectID(prospectId)
    }
    //endregion installationRepo


    override fun onCleared() {
        super.onCleared()
//        installationRepo.destroy()
    }

}
