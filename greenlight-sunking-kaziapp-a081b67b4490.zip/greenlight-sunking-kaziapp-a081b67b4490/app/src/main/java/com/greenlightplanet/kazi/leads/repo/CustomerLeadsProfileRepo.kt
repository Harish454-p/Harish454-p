package com.greenlightplanet.kazi.leads.repo

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.disposables.CompositeDisposable

class CustomerLeadsProfileRepo(val context: Context) {

    companion object : SingletonHolderUtil<CustomerLeadsProfileRepo, Context>(::CustomerLeadsProfileRepo) {
        public const val TAG = "CustomerLeadsProfileR"

    }


    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    var gson: Gson? = null


    init {
        try {

            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context)
            gson = Gson()

        } catch (e: Exception) {
            Log.d(TAG, "Init:Error ");
        }
    }


    fun destroy() {

        Log.d(TAG, "Repo : destroy");
        bag.clear()
    }

}