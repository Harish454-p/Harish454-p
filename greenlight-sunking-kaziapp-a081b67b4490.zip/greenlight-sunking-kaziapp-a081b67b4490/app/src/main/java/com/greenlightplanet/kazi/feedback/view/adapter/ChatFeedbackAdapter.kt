package com.greenlightplanet.kazi.feedback.view.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.ItemChatAgentFeedbackBinding
import com.greenlightplanet.kazi.databinding.ItemChatUserFeedbackBinding
import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackConstants
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.feedback.repo.model.response.ChatData
import com.greenlightplanet.kazi.feedback.repo.model.response.TicketResponseData
import timber.log.Timber
import java.lang.ref.WeakReference

class ChatFeedbackAdapter(): RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var dataList = mutableListOf<ChatData>()
    lateinit var listener: WeakReference<ChatFeedbackAdapterClickListener>
    val TAG = "ChatFeedbackAdapter"
    var isClosed = false
    var isPending = false


    fun setRvData(list: List<ChatData>, isStatusClosed: Boolean = false, isStatusPending: Boolean = false) {
        clearRvData()
        isClosed = isStatusClosed
        isPending = isStatusPending
        Log.d(TAG,"$TAG: AdapterList -> $list")
        dataList.addAll(list)
        notifyDataSetChanged()

    }

    fun clearRvData() {
        dataList.clear()
        isClosed = false
        isPending = false
        Log.d(TAG,"$TAG: AdapterList Cleared ")
        notifyDataSetChanged()

    }

    fun addRvData(chatData: ChatData) {
        Timber.d("$TAG  : New Chat Data ->  $chatData")
        val size = dataList.size
        dataList.add(chatData)
        notifyItemInserted(size)
    }


    fun attachListener(clickListener: WeakReference<ChatFeedbackAdapterClickListener>) {
        listener = clickListener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
      val  bindingUser = ItemChatUserFeedbackBinding.inflate(LayoutInflater.from(parent.context), parent, false)
      val  bindingAgent = ItemChatAgentFeedbackBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    return   if(viewType == 1) ViewHolderUser(bindingUser) else ViewHolderAgent(bindingAgent)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when(holder){
            is ViewHolderUser -> holder.bind(dataList.get(position))
            is ViewHolderAgent -> holder.bind(dataList.get(position))
        }
    }

    override fun getItemViewType(position: Int): Int {
       return if(dataList.get(position).senderType.equals("EO")) 1 else 2


    }

       inner  class ViewHolderUser(private val vBinding: ItemChatUserFeedbackBinding): RecyclerView.ViewHolder(vBinding.root) {
        fun bind(holdingData: ChatData) {
            with(vBinding) {
                tvUser.text = FeedbackConstants.fullName
                tvUserMessage.text = holdingData.message
                tvTime.text = Helper.convertUTCTimeWithFormatToRequired(holdingData.timestamp, FeedbackConstants.utcDateFormat)
                Timber.d("$TAG || Chat DateTime EO: API: ${holdingData.timestamp} || Local: ${Helper.convertUTCTimeWithFormatToRequired(holdingData.timestamp, FeedbackConstants.utcDateFormat)}")
            }
        }
    }
    inner class ViewHolderAgent(private val vBinding: ItemChatAgentFeedbackBinding): RecyclerView.ViewHolder(vBinding.root) {
        fun bind(holdingData: ChatData) {
            with(vBinding) {
                tvAgent.text = "CC Support"
                tvAgentMessage.text = holdingData.message
                tvTime.text = Helper.convertUTCTimeWithFormatToRequired(holdingData.timestamp, FeedbackConstants.utcDateFormat)
                Timber.d("$TAG || Chat DateTime CC: API: ${holdingData.timestamp} || Local: ${Helper.convertUTCTimeWithFormatToRequired(holdingData.timestamp, FeedbackConstants.utcDateFormat)}")
            }

        }
    }

    override fun getItemCount(): Int = dataList.size

}

interface ChatFeedbackAdapterClickListener{
    fun onTicketItemClickedFilter(data: TicketResponseData)
}