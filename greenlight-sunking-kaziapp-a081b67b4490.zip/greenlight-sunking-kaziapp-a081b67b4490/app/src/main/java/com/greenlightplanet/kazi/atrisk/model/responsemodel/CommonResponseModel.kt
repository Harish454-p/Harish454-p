package com.greenlightplanet.kazi.atrisk.model.responsemodel

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class CommonResponseModel<T : Parcelable>(
    @SerializedName("Error")
    var error: Error? = null,

    @SerializedName("ResponseStatus")
    var responseStatus: Int? = null,

    @SerializedName("ResponseData")
    var ResponseData: T? = null,

    @SerializedName("Success")
    var success: Boolean = false
) : Parcelable

@Parcelize
data class OnlyResponseModel(
    @SerializedName("Error")
    var error: Error?,

    @SerializedName("ResponseStatus")
    var responseStatus: Int?,

    @SerializedName("ResponseData")
    var ResponseData: String?,

    @SerializedName("Success")
    var success: Boolean?
) : Parcelable

@Parcelize
data class OnlyTBResponseModel(
    @SerializedName("ResponseStatus")
    var responseStatus: Int?,

    @SerializedName("Success")
    var success: Boolean?
) : Parcelable

@Parcelize
data class OnlyKaziPrizeResponseModel(
    @SerializedName("Error")
    var error: Error?,

    @SerializedName("ResponseStatus")
    var responseStatus: Int?,

//    @SerializedName("ResponseData")
//    var ResponseData: ResponseData?,

    @SerializedName("Success")
    var success: Boolean?,

    @SerializedName("message")
    var message: Boolean?
) : Parcelable

@Parcelize
public data class Error(
    @SerializedName("ErrorCause")
    var errorCause: String? = null,
    @SerializedName("ErrorMessage")
    var errorMessage: String? = null,
    @SerializedName("ErrorTrace")
    var errorTrace: String? = null,
    @SerializedName("MessageToUser")
    var messageToUser: String? = null
) : Parcelable
