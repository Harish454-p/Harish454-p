package com.greenlightplanet.kazi.collectiongoal.extra

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.annotation.Keep
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.databinding.DialogNewChoosePhonenoBinding
import com.greenlightplanet.kazi.databinding.DialogTaskBinding
import com.greenlightplanet.kazi.leads.extras.LEAD_INTENT
import com.greenlightplanet.kazi.leads.view.adapter.ChoosePhoneNoAdapter
import com.greenlightplanet.kazi.newtasks.extras.SendingCallStatus
import com.greenlightplanet.kazi.newtasks.model.FeedbackIntentModel
import com.greenlightplanet.kazi.newtasks.view.fragment.CalenderDialogFragment
import com.greenlightplanet.kazi.summary.model.SummaryCallDetailRequestModel
import com.greenlightplanet.kazi.task.TaskUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import ru.cleverpumpkin.calendar.CalendarDate
import java.text.SimpleDateFormat
import java.util.*


@Keep
class CollectionGoalCallDialog(
    val activity: BaseActivity,
    val sendingCallStatus: SendingCallStatus
) : LifecycleObserver {

    val TAG = "CGCallDialog"
    private lateinit var itemBinding: DialogNewChoosePhonenoBinding
    var callIntentDialogCallback: CallIntentDialogCallback? = null

    var phoneNumberDialog: Dialog? = null
    var datePicker: DatePickerDialog? = null
    var intentDialog: Dialog? = null
    var summaryCallDetailRequestModel: SummaryCallDetailRequestModel? = null
    var adapterPosition: Int? = null

    //new task
    //
    var dialogMainModel: FeedbackIntentModel? = null
    var intentMainList: MutableList<FeedbackIntentModel.Intents> = mutableListOf()
    val intentStringList: MutableList<String> = mutableListOf()

    //
    val custIntentId: MutableList<Int> = mutableListOf()
    val customerFeedbackList: MutableList<String> = mutableListOf()
    val custFeedbackId: MutableList<Int> = mutableListOf()

    //    --
    var intentsorted: FeedbackIntentModel.Intents? = null
    val NewintentList: MutableList<FeedbackIntentModel.Intents> = mutableListOf()
    val NewcustomerFeedbackList: MutableList<FeedbackIntentModel.Intents.Feedback> = mutableListOf()
    var preference: GreenLightPreference? = GreenLightPreference.getInstance(activity)

    fun newShowPhoneNumberDialog(
        cAccount: MakeCallNewModel.ColGoalAccount,
        list: List<String?>,
        feedbackIntent: List<FeedbackIntentModel.Intents>?,
        showWarning: Boolean = false
    ) {

        summaryCallDetailRequestModel =
            SummaryCallDetailRequestModel(accountNumber = cAccount.accountNumber?.toInt() ?: 0)
        summaryCallDetailRequestModel.apply {
            this?.imei = Util.getImeiNumber(activity)
//            this?.attempt = /*cAccount.taskAttempt!!.plus(1) ?:*/ 1
            val mm = cAccount.attempt ?: 0
            this?.attempt = mm.plus(1)
        }

        phoneNumberDialog = Dialog(activity, R.style.Theme_Dialog)
        phoneNumberDialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        phoneNumberDialog?.setCanceledOnTouchOutside(true)
        itemBinding = DialogNewChoosePhonenoBinding.inflate(LayoutInflater.from(activity))
        phoneNumberDialog?.setContentView(itemBinding.root)
        phoneNumberDialog?.setCancelable(false)
        itemBinding.imCancel.setOnClickListener {
            phoneNumberDialog!!.dismiss()
        }

        if (cAccount.lastCallDate.isNullOrEmpty()) {
            itemBinding.tvLastCalled.visibility = View.GONE
        } else {
            itemBinding.tvLastCalled.visibility = View.VISIBLE
            itemBinding.tvLastCalled.text =
                "Last call date : ${Util.getDDMMYYYYFormate(cAccount.lastCallDate!!)}"
        }

        itemBinding.tvInfo.text = preference!!.getReimbursementMessage()
        itemBinding.tvCallMessage.text = cAccount.successfulCallMessage ?: ""
        if (showWarning) {
            itemBinding.ivInfo.visibility = View.VISIBLE
            itemBinding.tvInfo.visibility = View.VISIBLE
        } else {
            itemBinding.ivInfo.visibility = View.GONE
            itemBinding.tvInfo.visibility = View.GONE
        }

        val listAdapter = ChoosePhoneNoAdapter(activity, list.filterNotNull())
        listAdapter.choosePhoneNoAdapterCallback =
            object : ChoosePhoneNoAdapter.ChoosePhoneNoAdapterCallback {
                @SuppressLint("MissingPermission")
                override fun numberSelected(position: Int, number: String) {
                    phoneNumberDialog?.dismiss()

                    summaryCallDetailRequestModel.apply {
                        this?.contactedNumber = number
                    }

                    val callCustomer = Intent(Intent.ACTION_CALL)
                    callCustomer.data = Uri.parse("tel:$number")
                    activity.startActivity(callCustomer)
                    sendingCallStatus.setOnCall(true)
                    feedbackIntent?.let {
                        feedbackIntentDialog(activity, it)
                    }
                }
            }

        itemBinding.listview.layoutManager = LinearLayoutManager(activity)
        itemBinding?.listview?.adapter = listAdapter
        listAdapter.notifyDataSetChanged()

        phoneNumberDialog?.show()

    }


    @Keep
    fun newShowNewDatePicker(context: Context, followUpDayLimit: Int?) {

        if (isAbleToCall()) {
            val followDateLimit = if (followUpDayLimit!! == 0) {
                14
            } else {
                followUpDayLimit
            }
            activity.updateLangContext(activity, isEnglish = true)
            val calenderFragment = CalenderDialogFragment()
            calenderFragment.followUpDayLimit = followDateLimit
            calenderFragment.calenderDialogFragmentCallback =
                object : CalenderDialogFragment.CalenderDialogFragmentCallback {
                    override fun onCancel() {
                        activity.updateLangContext(activity, isEnglish = false)
//				Log.d($TAG, "onCancel: ")
                    }

                    override fun onSelected(calendarDate: CalendarDate) {
                        activity.updateLangContext(activity, isEnglish = false)
                        Log.d("$TAG == >", "onSelected:$calendarDate ")


                        val newVisitDateFormat = SimpleDateFormat("yyyy-MM-dd")
                        val newVisitDate = newVisitDateFormat.format(calendarDate.timeInMillis)

                        Log.d("$TAG == >", "onSelected:=> newVisitDate = $newVisitDate ")
                        summaryCallDetailRequestModel.apply {
                            this?.newVisitDate = newVisitDate
                        }

                        //todo add new logic here
                        //newSpinnerIntentDialog(context, list)

                        callIntentDialogCallback?.dialogCompleted(
                            summaryCallDetailRequestModel!!
                        )
                    }
                }
            val fragActivity = activity as FragmentActivity
            if (calenderFragment is CalenderDialogFragment) {
                calenderFragment.show(fragActivity.supportFragmentManager, null)
            } else {
                fragActivity.supportFragmentManager.beginTransaction()
                    .replace(android.R.id.content, calenderFragment)
                    .addToBackStack(null)
                    .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE).commit()
            }
        }
    }

    @Keep
    fun feedbackIntentDialog(context: Context, intentList: List<FeedbackIntentModel.Intents>?) {
        var selectedItem = ""

        var itemBinding: DialogTaskBinding? = null
        intentDialog = Dialog(context, R.style.Theme_Dialog)
        intentDialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        intentDialog?.setCanceledOnTouchOutside(false)
        itemBinding = DialogTaskBinding.inflate(LayoutInflater.from(context))
        intentDialog?.setContentView(itemBinding.root)
        intentDialog?.setCancelable(false)
//        dialogMainModel = FeedbackIntentModel(1, intentList!!)
        intentMainList.clear()
        intentMainList = intentList!!.toMutableList()
        intentStringList.clear()
        custIntentId.clear()
        NewintentList.clear()
        if (!intentMainList.isNullOrEmpty()) {
            intentMainList.let {
                it.map { intentStringList.add(it.intent) }
                it.map { custIntentId.add(it.intentId) }
                it.map { NewintentList.add(it) }
            }
            intentStringList.add(0, context.getString(R.string.select_customer_feedback))
            custIntentId.add(0, 0)

        } else {
            val defaultFeedback = activity.resources?.getStringArray(R.array.customer_fb1)
            intentStringList.addAll(defaultFeedback!!.toMutableList())
            val array1 = arrayOf(0, 1, 2, 3)
            custIntentId.addAll(array1.toMutableList())
        }


        val spinnerArrayAdapter = ArrayAdapter(
            context, R.layout.spinner_item,
            intentStringList
        )
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        itemBinding.spinCustomerIntent.adapter = spinnerArrayAdapter


        itemBinding.spinCustomerIntent.onItemSelectedListener = object : OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {
                val selectedItem = parent.getItemAtPosition(position).toString()
                if (selectedItem != context.getString(R.string.select_customer_feedback)) { // do your stuff
                    when (custIntentId.get(position)) {
                        0 -> {
                            itemBinding.spnrFeedback?.visibility = View.GONE
                            itemBinding.etFeedback?.visibility = View.GONE
                            itemBinding.etFeedback?.text?.clear()
                            summaryCallDetailRequestModel.apply {
                                this?.intentId = custIntentId.get(position)
                            }
                        }
                        1 -> {
                            itemBinding.spnrFeedback?.visibility = View.GONE
                            itemBinding.etFeedback?.visibility = View.GONE
                            itemBinding.etFeedback?.text?.clear()

                            summaryCallDetailRequestModel.apply {
                                this?.intentId = custIntentId.get(position)
                            }
//                                taskList?.get(position).customerIntent = custIntentId.get(pos).toString()
                        }
                        else -> {
                            itemBinding.spnrFeedback.visibility = View.VISIBLE
                            itemBinding.spnrFeedback?.setSelection(0)
                            setCustomerFeedbackList(
                                context,
                                itemBinding.spnrFeedback,
                                custIntentId.get(position),
                                itemBinding
                            )
                            itemBinding.etFeedback?.visibility = View.GONE
                            itemBinding.etFeedback?.text?.clear()
                            summaryCallDetailRequestModel.apply {
                                this?.intentId = custIntentId.get(position)
                            }
//                                taskList?.get(position)!!.customerIntent = custIntentId.get(pos).toString()
                        }
                    }

                } else {
                    summaryCallDetailRequestModel?.intentId = null
                }
            } // to close the onItemSelected

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        itemBinding.spnrFeedback.onItemSelectedListener = object : OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {
                selectedItem = parent.getItemAtPosition(position).toString()

                summaryCallDetailRequestModel!!.feedbackId = custFeedbackId.get(position)
                summaryCallDetailRequestModel!!.feedbackCode = customerFeedbackList.get(position)

                if (customerFeedbackList.get(position).equals(context.getString(R.string.others), true)
                    ||customerFeedbackList.get(position).equals("Others", true)) {
                    itemBinding!!.etFeedback?.visibility = View.VISIBLE
                } else {
                    itemBinding!!.etFeedback?.visibility = View.GONE
                }
            } // to close the onItemSelected

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        itemBinding.btnSubmit.setOnClickListener {
            if (!sendingCallStatus.isOnCall()) {
                if (summaryCallDetailRequestModel!!.intentId != null) {
                    /*new added {summaryCallDetailRequestModel!!.intentId == LEAD_INTENT.DID_NOT_ANSWER} */
                    if (summaryCallDetailRequestModel!!.feedbackId != 0 || summaryCallDetailRequestModel!!.intentId == LEAD_INTENT.DID_NOT_ANSWER) {

                        val otherReason = itemBinding?.etFeedback?.text.toString()

                        if (summaryCallDetailRequestModel!!.intentId != LEAD_INTENT.OTHER
                            || !otherReason.isBlank()
                            || summaryCallDetailRequestModel!!.feedbackId != null
                        ) {
                            Log.e(
                                "Mazhar===otherReason::", "ifffff == ${otherReason}"
                            )
                            if ((selectedItem.equals(context.getString(R.string.others), false)
                                        ||selectedItem.equals("Others", false)) && otherReason.isEmpty()) {
                                Util.showToast("Please add your reason", context)
                            } else {

                                summaryCallDetailRequestModel.apply {
                                    this?.otherReason = otherReason
                                }

                                intentDialog?.dismiss()

                                if (summaryCallDetailRequestModel!!.intentId == LEAD_INTENT.DID_NOT_ANSWER) {

                                    var date: Date? = null
                                    date = Util.getCurrentDate()

                                    if (date == null) {
                                        date = Calendar.getInstance().time
                                    }

                                    summaryCallDetailRequestModel!!.callDuration = 0
                                    summaryCallDetailRequestModel!!.calledTime =
                                        TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!)
                                    callIntentDialogCallback?.dialogCompleted(
                                        summaryCallDetailRequestModel!!
                                    )
                                } else if (summaryCallDetailRequestModel!!.intentId == LEAD_INTENT.CANCLE) {
                                    if (isAbleToCall()) {
                                        callIntentDialogCallback?.dialogCompleted(
                                            summaryCallDetailRequestModel!!
                                        )
                                    }

                                } else {
                                    newShowNewDatePicker(
                                        activity,
                                        preference!!.getCalendarDisableDays()
                                    )
                                }
                            }

                        } else {
                            Util.showToast(
                                context.getString(R.string.please_add_your_reason),
                                context)
                        }

                    } else {
                        Util.showToast(context.getString(R.string.please_select_feedback), context)
                    }

                } else {
                    Util.showToast(context.getString(R.string.please_select_feedback), context)
                }
            } else {
                Util.showToast(context.getString(R.string.proceed_once_call_ended), context)
            }


        }

        intentDialog?.show()
    }

    fun setCustomerFeedbackList(
        context: Context,
        spinner: Spinner,
        intentID: Int,
        itemBinding: DialogTaskBinding
    ) {

//        if (intentMainList != null) {
        if (!intentMainList.isNullOrEmpty()) {
            intentsorted = NewintentList.find { it.intentId == intentID }
            Log.e("::::::intentsorted == ", "${intentsorted}")
            customerFeedbackList.clear()
            custFeedbackId.clear()
            NewcustomerFeedbackList.clear()
            for (dbd in intentsorted!!.feedbacks) {
                NewcustomerFeedbackList.add(
                    FeedbackIntentModel.Intents.Feedback(
                        dbd.feedback,
                        dbd.feedbackId,
                        dbd.intentId
                    )
                )
                val str = dbd.feedback
                customerFeedbackList.add(str)
                val strId = dbd.feedbackId
                custFeedbackId.add(strId)
            }
            custFeedbackId.add(0, 0)
            customerFeedbackList.add(0, context.getString(R.string.select_customer_feedback))
            Log.e("customfedbackList === ", customerFeedbackList.toString())
            Log.e("custFeedbackId === ", custFeedbackId.toString())

            if (NewcustomerFeedbackList.isNullOrEmpty()) {
                itemBinding!!.spnrFeedback.visibility = View.GONE
                itemBinding!!.spnrFeedback?.setSelection(0)
            }

        } else {

            if (intentID == 2) {
                val customerFeedbackWithPay =
                    activity.resources?.getStringArray(R.array.customer_fb_wt_pay)
                val NOcustIntentId: IntArray = intArrayOf(0, 1, 2, 3, 4, 5, 6, 999)
                custFeedbackId.clear()
                custFeedbackId.addAll(NOcustIntentId.toMutableList())
                customerFeedbackList.clear()
                customerFeedbackList.addAll(customerFeedbackWithPay!!)
            } else if (intentID == 3) {
                val customerFeedbackNotPay =
                    activity.resources?.getStringArray(R.array.customer_fb_nt_pay)
                custFeedbackId.clear()
                val NOcustIntentId: IntArray = intArrayOf(0, 7, 8, 9, 10, 11, 12, 9999)
                custFeedbackId.addAll(NOcustIntentId.toMutableList())
                customerFeedbackList.clear()
                customerFeedbackList.addAll(customerFeedbackNotPay!!)
            }

        }

        setAdapter(spinner, customerFeedbackList)

    }

    fun setAdapter(spinner: Spinner?, spinnerArray: List<String>?) {
        if (activity != null) {
            if (spinnerArray != null) {
                val spinnerArrayAdapter = ArrayAdapter(
                    activity, R.layout.spinner_item,
                    spinnerArray
                )
                spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_filter_text)
                spinner?.adapter = spinnerArrayAdapter
            }
        }
    }

    //new added
    private fun isAbleToCall(): Boolean {

        val callLogModel = Util.checkCallLog(
            phoneNumber = summaryCallDetailRequestModel?.contactedNumber!!,
            activity = activity
        )

        if (callLogModel.time.isNullOrBlank()) {
            Util.showToast("Unable to make a call", activity)
            return false
        } else {

            callLogModel.apply {
                this.time = convertCallLogTimestamp(this.time!!)
            }

            summaryCallDetailRequestModel.apply {
                this?.callDuration = callLogModel.lastCallTime ?: 0
                this?.calledTime = callLogModel.time!!
            }

            return true
        }
    }

    interface CallIntentDialogCallback {
        fun dialogCompleted(summaryCallDetailRequestModel: SummaryCallDetailRequestModel)
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun onDestroy() {

        phoneNumberDialog?.let {
            dismissDialog(it)
        }

        datePicker?.let {
            dismissDialog(it)
        }

        intentDialog?.let {
            dismissDialog(it)
        }
    }

    private fun dismissDialog(dialog: Dialog) {
        if (dialog.isShowing) {
            dialog.dismiss()
        }
    }


    private fun convertCallLogTimestamp(value: String): String {

        val oldFormat = SimpleDateFormat("yyyy:MM:dd h:mm:ss a")
        val date = oldFormat.parse(value)
        val newFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        newFormat.timeZone = TimeZone.getTimeZone("UTC")

        return newFormat.format(date)
    }

}
