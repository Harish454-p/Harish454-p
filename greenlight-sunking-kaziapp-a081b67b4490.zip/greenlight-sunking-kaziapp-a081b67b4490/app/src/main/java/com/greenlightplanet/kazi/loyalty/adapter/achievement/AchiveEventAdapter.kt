package com.greenlightplanet.kazi.loyalty.adapter.achievement

import android.content.Context
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYou
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYouListener
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ItemLoadingBinding
import com.greenlightplanet.kazi.databinding.ItemPostBinding
import com.greenlightplanet.kazi.loyalty.model.achievements.Achieved
import com.greenlightplanet.kazi.utils.Util


/**
 * Created by Rahul on 06/04/21.
 */


class AchiveEventAdapter internal constructor(var context: Context, var mAchieved: MutableList<Achieved>) : RecyclerView.Adapter<BaseViewHolder>() {
    private val VIEW_TYPE_LOADING = 0
    private val VIEW_TYPE_NORMAL = 1
    private var isLoaderVisible = false

    var onAchievedClickItem: OnAchievedClickItem? = null


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder {
        return when (viewType) {
            VIEW_TYPE_NORMAL -> ViewHolder(
                    ItemPostBinding.inflate(LayoutInflater.from(parent.context), parent, false), mAchieved, context, onAchievedClickItem)
            VIEW_TYPE_LOADING -> ProgressHolder(
                    ItemLoadingBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            else -> null!!
        }
    }

    override fun onBindViewHolder(holder: BaseViewHolder, position: Int) {
        holder.onBind(position)
    }

    override fun getItemViewType(position: Int): Int {
        return if (isLoaderVisible) {
            if (position == mAchieved.size - 1) VIEW_TYPE_LOADING else VIEW_TYPE_NORMAL
        } else {
            VIEW_TYPE_NORMAL
        }
    }

    override fun getItemCount(): Int {
        return mAchieved.size
    }

    fun addItems(achieved: MutableList<Achieved>) {


        mAchieved.removeAll(achieved)
        mAchieved.addAll(achieved)
        notifyDataSetChanged()
    }

    fun addLoading() {
        isLoaderVisible = true
        mAchieved.add(Achieved(0, 0, 0, "", "", "", 0, "", 0, "", 0L))
        notifyItemInserted(mAchieved.size - 1)
    }

    fun removeLoading() {
        isLoaderVisible = false
        val position = mAchieved.size - 1
        val item: Achieved? = getItem(position)

        if (item?.event_id == 0) {
            mAchieved.removeAt(position)
            notifyItemRemoved(position)
        }
    }


    fun clear() {
        mAchieved.clear()
        notifyDataSetChanged()
    }

    fun getItem(position: Int): Achieved? {
        return mAchieved[position]
    }

    class ViewHolder internal constructor(private val itemBinding:  ItemPostBinding, private val mAchieved: MutableList<Achieved>?, val context: Context, var onAchievedClickItem: OnAchievedClickItem?) : BaseViewHolder(itemBinding.root) {

        override fun clear() {}
        override fun onBind(position: Int) {
            super.onBind(position)
            val item: Achieved? = mAchieved?.distinct()?.get(position)


            itemBinding.imageBackgroundId.background = context.resources.getDrawable(R.drawable.light_yellow_circle)

            if (item?.count?:0 > 1){
                itemBinding.linearCount.visibility=View.VISIBLE
                itemBinding.tvItemCountId.text = item?.count?.let { Util.formatAmount(it.toDouble()) }
               // itemView.tvItemCountId.text = item?.count.toString()
            }else{
                itemBinding.linearCount.visibility=View.GONE
            }



            if (item?.icon_url?.contains(".svg") == true) {
                GlideToVectorYou
                        .init()
                        .with(context)
                        .withListener(object : GlideToVectorYouListener {
                            override fun onLoadFailed() {

                            }

                            override fun onResourceReady() {
                            }
                        })
                        .load(Uri.parse(item?.icon_url), itemBinding.imgIconId)
            } else {
                Log.e("resultDataIcon", " NO")


            }


            itemBinding.tvNameId.text = item?.event_name

            itemView.setOnClickListener {
                item.let { it1 -> it1?.let { it2 -> onAchievedClickItem?.onAchievedTab(it2) } }
            }
        }

    }

    class ProgressHolder internal constructor(itemView:  ItemLoadingBinding) : BaseViewHolder(itemView.root) {
        override fun clear() {}

    }

    interface OnAchievedClickItem {

        fun onAchievedTab(storeItem: Achieved)


    }
}