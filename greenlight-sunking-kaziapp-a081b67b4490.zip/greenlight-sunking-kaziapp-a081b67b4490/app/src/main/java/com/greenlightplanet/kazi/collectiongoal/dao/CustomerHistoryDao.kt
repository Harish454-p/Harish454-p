package com.greenlightplanet.kazi.collectiongoal.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistoryModel
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistoryModel
import io.reactivex.Single

@Dao
interface CustomerHistoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertCallHistory(callHistoryModel: CallHistoryModel): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertPaymentHistory(paymentHistoryModel: PaymentHistoryModel): Long

    @Query("SELECT * FROM CallHistoryModel where accountNumber = :accountNumber")
    fun getAllCallingHistory1(accountNumber :Int?): Single<CallHistoryModel>

    @Query("SELECT * FROM PaymentHistoryModel where accountNumber = :accountNumber")
    fun getAllPaymentHistory1(accountNumber: Int?): Single<PaymentHistoryModel>

    @Query("DELETE FROM CallHistoryModel where accountNumber = :accountNumber")
    fun deleteCustomerHistoryAll(accountNumber: Int?): Int

    @Query("DELETE FROM PaymentHistoryModel where accountNumber = :accountNumber")
    fun deletePaymentHistoryAll(accountNumber: Int?): Int

}