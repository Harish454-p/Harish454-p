package com.greenlightplanet.kazi.feedback.feedback_utils

import android.annotation.SuppressLint
import android.app.Activity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import android.content.Context
import android.util.Log
import com.amazonaws.auth.AWSCredentialsProvider
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.mobile.auth.core.IdentityHandler
import com.amazonaws.mobile.auth.core.IdentityManager
import com.amazonaws.mobile.client.AWSMobileClient
import com.amazonaws.mobile.config.AWSConfiguration
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener
import com.amazonaws.mobileconnectors.s3.transferutility.TransferNetworkLossHandler
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility
import com.amazonaws.services.s3.AmazonS3Client
import com.greenlightplanet.kazi.liteFseProspective.model.LiteAwsImageModel
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import timber.log.Timber
import java.io.File

class AmazonS3Helper(val activity: Activity) : LifecycleObserver {


    private var awsCredentialsProvider: AWSCredentialsProvider? = null
    private var awsConfiguration: AWSConfiguration? = null
    private var awsMobileClient: AWSMobileClient? = null
    private var identityManager: IdentityManager? = null
    private var basicAWSCredentials: BasicAWSCredentials? = null
    private var amazonS3Client: AmazonS3Client? = null
    private var transferUtility: TransferUtility? = null
    private var transferNetworkLossHandler: TransferNetworkLossHandler? = null
    private var fileModelsList = mutableListOf<LiteAwsImageModel>()
    private var imageDataList = mutableListOf<String>()
    var amazonS3HelperCallback: AmazonS3HelperCallback? = null
    var isForService = false
    var isReplacement = false
    var isVisits = false
    var preference: GreenLightPreference = GreenLightPreference.getInstance(activity)

    //companion object : SingletonHolderUtil<AmazonS3Helper, Activity>(::AmazonS3Helper) {
    companion object {
        const val TAG = "AmazonS3Helper"
        const val TAG_UPLOAD = "AmazonS3Upload"

        const val AMAZON_S3_KEY = "feedback/"

        const val AMAZON_S3_BASE =
            "https://s3.eu-west-2.amazonaws.com/kazi-userfiles-mobilehub-391300116/"
    }

    private val KEY = preference.getAwsAccess()
    private val SECRET = preference.getAwsSecret()

    @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
    fun initializer() {

        Log.d(TAG, "Initializing AWSMobileClient")


        AWSMobileClient.getInstance().initialize(activity) {
            // Obtain the reference to the AWSCredentialsProvider and AWSConfiguration objects
            awsMobileClient = AWSMobileClient.getInstance()
            awsCredentialsProvider = awsMobileClient?.credentialsProvider
            awsConfiguration = awsMobileClient?.configuration

            buildTransferUtility(activity.applicationContext)

            // Use IdentityManager#getUserID to fetch the identity id.
            IdentityManager.getDefaultIdentityManager().getUserID(object : IdentityHandler {
                override fun onIdentityId(identityId: String) {


                    Log.d(TAG, "Successfully retrieved identity")
                    identityManager = IdentityManager.getDefaultIdentityManager()
                    val cachedIdentityId = identityManager?.cachedUserID

                }

                override fun handleError(exception: Exception) {

                    Log.d(TAG, "Error in retrieving the identity:$exception")

                }
            })
        }.execute()

    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun destroy() {
        awsMobileClient = null
        awsCredentialsProvider = null
        awsConfiguration = null
        basicAWSCredentials = null
        amazonS3Client = null
        transferNetworkLossHandler = null
        transferUtility = null
        identityManager = null
    }


    private fun buildTransferUtility(context: Context) {

        basicAWSCredentials = BasicAWSCredentials(KEY, SECRET);
        amazonS3Client = AmazonS3Client(basicAWSCredentials);
        transferNetworkLossHandler = TransferNetworkLossHandler.getInstance(context);

        transferUtility = TransferUtility.builder()
            .context(context)
            .awsConfiguration(AWSMobileClient.getInstance().getConfiguration())
            .s3Client(amazonS3Client)
            .build()

    }

    suspend fun uploadImage(fileModels: ImageUploadUtil.ImageModel) {
        imageDataList.clear()

            val rndNumber = (0..10000000).random()
        val ext = ".jpg"
            var photoUrl = "${"${fileModels.imageName.replace(" ", "_")}" + "_" + "$rndNumber"}$ext"

            val transferObserver = transferUtility?.upload(AMAZON_S3_KEY + photoUrl, fileModels.file)
            transferObserver?.setTransferListener(object : TransferListener {

                @SuppressLint("LogNotTimber")
                override fun onProgressChanged(id: Int, bytesCurrent: Long, bytesTotal: Long) {

                    Log.d(
                        TAG_UPLOAD,
                        "onProgressChanged---> bytesCurrent:$bytesCurrent == bytesTotal$bytesTotal"
                    )
                }

                override fun onStateChanged(id: Int, state: TransferState?) {

                    Log.d(TAG_UPLOAD, "onStateChanged--->")


                    //49122906
                    if (TransferState.COMPLETED == state) {

                        Log.d(TAG_UPLOAD, "onStateChanged--|${System.currentTimeMillis()}|-> COMPLETED")

                        //hideProgress()
                        // Handle a completed download.

                        var awsLink = AMAZON_S3_BASE + AMAZON_S3_KEY + "" + photoUrl
                        imageDataList.add(awsLink)
                        Timber.d("$TAG_UPLOAD: Uploaded Image Link: $awsLink")
                        amazonS3HelperCallback?.onAllUploadCompleted(imageDataList, awsLink)
//                    internalCallback(awsLink, fileModels)

                        return
                    }

                    if (TransferState.FAILED == state) {
                        Log.d(TAG_UPLOAD, "onStateChanged---> FAILED")

                        //hideProgress()
                        //getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

//                    internalCallback(null, fileModels)
                        return
                    }


                    if (TransferState.CANCELED == state) {
                        Log.d(TAG_UPLOAD, "onStateChanged---> CANCELED")

                        //hideProgress()

//                    internalCallback(null, fileModels)
                        return
                    }

                }

                override fun onError(id: Int, ex: Exception?) {
                    Log.d(TAG_UPLOAD, "onError---> ex:${ex?.localizedMessage}")
                    ex?.printStackTrace()

//                internalCallback(null, fileModels)
                    return

                }

            })




    }

    public fun startUploadProcess(
        fileModels: List<LiteAwsImageModel>,
        isForService: Boolean,
        isReplacement: Boolean = false,
        isVisits: Boolean = false
    ) {
        this.isForService = isForService
        this.isReplacement = isReplacement
        this.isVisits = isVisits

        fileModelsList.clear()
        fileModelsList.addAll(fileModels)
//        uploadAll(fileModels)
    }

//    private fun uploadAll(fileModels: List<LiteAwsImageModel>) {
//        //start progress
//        uploadImage(fileModels.first())
//    }


    interface AmazonS3HelperCallback {

        fun onAllUploadCompleted(imageList: List<String>, url: String)
    }


    public data class FileModel(
        var tried: Boolean = false,
        var fileName: String,
        var file: File,
        var awsLink: String?
    )


}
