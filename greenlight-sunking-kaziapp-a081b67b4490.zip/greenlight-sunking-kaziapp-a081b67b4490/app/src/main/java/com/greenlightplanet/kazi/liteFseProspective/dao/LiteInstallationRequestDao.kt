package com.greenlightplanet.kazi.liteFseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.liteFseProspective.model.LiteInstallationRequestModel
import io.reactivex.Single

@Dao
interface LiteInstallationRequestDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(liteInstallationRequestModel: List<LiteInstallationRequestModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(liteInstallationRequestModel: LiteInstallationRequestModel): Long

    @Delete
    fun delete(liteInstallationRequestModel: LiteInstallationRequestModel): Int

    @Query("DELETE FROM LiteInstallationRequest")
    fun deleteAll(): Int

    @Query("SELECT * FROM LiteInstallationRequest")
    fun getAll(): Single<List<LiteInstallationRequestModel>>

    @Query("SELECT * FROM LiteInstallationRequest LIMIT 1")
    fun get(): Single<LiteInstallationRequestModel>

    @Query("SELECT COUNT(*) from LiteInstallationRequest")
    fun count(): Single<Int>

    @Query("SELECT * FROM LiteInstallationRequest WHERE prospectId=:prospectId LIMIT 1")
    fun getByProspectId(prospectId: String): Single<LiteInstallationRequestModel>?

    @Query("SELECT * FROM LiteInstallationRequest WHERE prospectID IN (:prospectId)")
    fun getAllByProspectId(prospectId: List<String>): Single<List<LiteInstallationRequestModel>?>

}
