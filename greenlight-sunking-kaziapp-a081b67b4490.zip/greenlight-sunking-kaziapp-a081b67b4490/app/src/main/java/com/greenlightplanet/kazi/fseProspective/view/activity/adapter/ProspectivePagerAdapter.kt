package com.greenlightplanet.kazi.fseProspective.view.activity.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager.widget.PagerAdapter
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.fseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseModel
import com.greenlightplanet.kazi.fseProspective.view.activity.ProspectiveActivity
import com.greenlightplanet.kazi.fseProspective.view.fragment.AllFragment
import com.greenlightplanet.kazi.fseProspective.view.fragment.InstallationFragment
import com.greenlightplanet.kazi.fseProspective.view.fragment.RegistrationFragment
import com.greenlightplanet.kazi.fseProspective.view.fragment.VerificationFragment

class ProspectivePagerAdapter(val activity : ProspectiveActivity, fm: FragmentManager, var list: List<FseProspectResponseModel>, val allowedDistance: Int) : FragmentStatePagerAdapter(fm) {


    var installationFragment: InstallationFragment? = null
    var registrationFragment: RegistrationFragment? = null
    var verificationFragment: VerificationFragment? = null
    var allFragment: AllFragment? = null

    override fun getCount(): Int {
        return 4
    }

    override fun getItem(position: Int): Fragment {
        val fragment: Fragment? = null

        when (position) {
            0 -> {
                allFragment = AllFragment.newInstance(/*list*/allowedDistance)
                return allFragment as Fragment
            }
            1 -> {
                verificationFragment = VerificationFragment.newInstance(
//                        list.filter { it.ticketType == FseProspectiveConstant.ProspectiveType.VERIFICATION }
                        allowedDistance)
                return verificationFragment as Fragment
            }
            2 -> {
                registrationFragment = RegistrationFragment.newInstance(
//                        list.filter { it.ticketType == FseProspectiveConstant.ProspectiveType.REGISTRATION }
                        allowedDistance)
                return registrationFragment as Fragment
            }
            3 -> {
                installationFragment = InstallationFragment.newInstance(
//                        list.filter { it.ticketType == FseProspectiveConstant.ProspectiveType.INSTALLATION }
                        allowedDistance)
                return installationFragment as Fragment
            }
            else ->
                return fragment!!
        }
    }


    override fun getItemPosition(`object`: Any): Int {
        return PagerAdapter.POSITION_NONE
    }

    override fun getPageTitle(position: Int): CharSequence {
        var title: String? = null
        when (position) {
            0 -> {
                title = activity.getString(R.string.all)
                return title
            }
            1 -> {
                title = activity.getString(R.string.verification)
                return title
            }
            2 -> {
                title = activity.getString(R.string.registration)
                return title
            }
            3 -> {
                title = activity.getString(R.string.installation)
                return title
            }
            else ->
                return title!!
        }
    }


}
