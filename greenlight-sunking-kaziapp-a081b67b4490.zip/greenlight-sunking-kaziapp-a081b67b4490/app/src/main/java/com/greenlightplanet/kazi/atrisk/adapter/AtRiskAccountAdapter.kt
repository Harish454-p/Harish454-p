package com.greenlightplanet.kazi.atrisk.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.atrisk.model.AtRiskAccountModel
import com.greenlightplanet.kazi.databinding.RecyclerItemAtRiskAccountBinding
import com.greenlightplanet.kazi.newtasks.extras.AdapterUtils
import com.greenlightplanet.kazi.summary.model.CollectionRateAccount
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.Util.Companion.getCorrectDecimal
import org.jetbrains.annotations.NotNull


class AtRiskAccountAdapter(list: MutableList<AtRiskAccountModel.CollectionAccount>, con: Context) :
    RecyclerView.Adapter<AtRiskAccountAdapter.RecyclerViewHolder>() {
    var atRisklist: MutableList<AtRiskAccountModel.CollectionAccount> = mutableListOf()
    var context: Context
    var hashmap: HashMap<Int?, Int?> = HashMap<Int?, Int?>()

    init {
        atRisklist = list
        context = con
    }

    var atRiskAccountAdapterCallback: AtRiskAccountAdapterCallback? = null

    inner class RecyclerViewHolder(private val itemBinding: RecyclerItemAtRiskAccountBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {

        fun bind(pos: Int, dataModel: AtRiskAccountModel.CollectionAccount, itemView: View) {

            itemBinding.tvPendingAmount.text =
                getCorrectDecimal(dataModel.pendingPayment?.toDouble())
            itemBinding.tvPendingAmountPerm.text =
                getCorrectDecimal(dataModel.pendingToExitRiskPermanent?.toDouble())
            itemBinding.tvAccount.text = dataModel.accountNumber.toString()



            Util.addUnderline(textView = itemBinding.tvCustomer, context = context, view = itemView)
            itemBinding.tvCustomer.text = HtmlCompat.fromHtml(
                "<u>${dataModel.customerName}</u>",
                HtmlCompat.FROM_HTML_MODE_LEGACY
            );

            if (dataModel.eligibleForReimbursement == true) {
                itemBinding.imgCall.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_call_black_24dp
                    )
                )
            } else {
                itemBinding.imgCall.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_empty_phone
                    )
                )
            }
            itemBinding.tvCustomer.setOnClickListener(null)
            if (hashmap.containsValue(dataModel.accountNumber)) {
                itemBinding.llType.visibility = View.VISIBLE
            } else {
                itemBinding.llType.visibility = View.GONE
            }

            itemBinding.tvCustomer.setOnClickListener {
                atRiskAccountAdapterCallback?.onCustomerSelected(dataModel)
            }
            itemBinding.imgCall.setOnClickListener {
                if (AdapterUtils.checkCallLogPermission(context)) {
                    atRiskAccountAdapterCallback?.makeCall(pos, account = dataModel)
                } else {
                    atRiskAccountAdapterCallback?.requestCallLogPermission(pos, account = dataModel)
                }
            }


        }
    }

    override fun onBindViewHolder(holder: RecyclerViewHolder, p1: Int) {
        val dataModel = atRisklist[holder.adapterPosition]
        holder.bind(p1, dataModel, holder.itemView)
    }

    override fun onCreateViewHolder(@NotNull parent: ViewGroup, p1: Int): RecyclerViewHolder {


        val itemBinding = RecyclerItemAtRiskAccountBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return RecyclerViewHolder(itemBinding)

    }

    override fun getItemCount(): Int {
        return atRisklist.size
    }

    interface AtRiskAccountAdapterCallback {
        fun onCustomerSelected(account: AtRiskAccountModel.CollectionAccount)
        fun makeCall(position: Int, account: AtRiskAccountModel.CollectionAccount)
        fun requestCallLogPermission(position: Int, account: AtRiskAccountModel.CollectionAccount)
    }

}
