package com.greenlightplanet.kazi.collectiongoal.view.fragment

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.KaziApplication
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.collectiongoal.adapter.CallHistoryAdapterRecycler
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistory
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistoryModel
import com.greenlightplanet.kazi.collectiongoal.view.activity.CustomerHistoryActivity
import com.greenlightplanet.kazi.collectiongoal.viewmodel.CustomerHistoryViewModel
import com.greenlightplanet.kazi.databinding.FragmentCallingHistoryBinding
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.newtasks.model.FeedbackIntentModel
import com.greenlightplanet.kazi.utils.BaseFragment
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util


class CallingHistoryFragment : BaseFragment() {

    private var _binding: FragmentCallingHistoryBinding? = null
    private val binding get() = _binding!!
    val ARG_PARAM1 = "list"
    val ARG_PARAM2 = "AccountNumber"
    val ARG_PARAM3 = "pageNumber"
    private var list: MutableList<CallHistory>? = null
    private var activityInstance: CustomerHistoryActivity? = null
    private val viewModel: CustomerHistoryViewModel by viewModels()
    private var adapterList: MutableList<CallHistory> = mutableListOf()
    private var adapter: CallHistoryAdapterRecycler? = null
    private var accountNumber: Int? = null
    var nextPageCalling: Int? = null
    var feedbackIntentModel: FeedbackIntentModel? = null
    var previousListSize = 0

    companion object {
        const val TAG = "CallingHistoryFragment"

        @JvmStatic
        fun newInstance(list: List<CallHistory>?, accountNumberString: Int?, nextPage: Int) =
            CallingHistoryFragment().apply {
                arguments = Bundle().apply {
                    putParcelableArrayList(ARG_PARAM1, ArrayList(list!!))
                    putInt(ARG_PARAM2, accountNumberString!!)
                    putInt(ARG_PARAM3, nextPage)
                    arguments?.clear()
                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        adapterList.clear()
        arguments?.let {
            list = it.getParcelableArrayList<CallHistory>(ARG_PARAM1)
            accountNumber = it.getInt(ARG_PARAM2)
            nextPageCalling = it.getInt(ARG_PARAM3)
            arguments?.clear()
        }

    }

    @SuppressLint("LongLogTag")
    val observer = Observer<NewCommonResponseModel<CallHistoryModel>> {

        cancelProgressDialog()
        if (viewLifecycleOwner.lifecycle.currentState== Lifecycle.State.RESUMED) {
            cancelProgressDialog()

            if (!it!!.success) {
                binding.tvNoData.visibility = View.VISIBLE
                binding.divider.visibility = View.VISIBLE
                binding.viewMore.visibility = View.GONE
                //Util.showToast(requireActivity(),it.error?.messageToUser.toString())
            }
            else {
                Log.d("PageNumberCallingHistoryFrag",it.responseData?.next.toString())
                val callDetailsList = it.responseData!!.callHistory
                if (callDetailsList.isEmpty()) {
                    binding.viewMore.visibility = View.GONE
                    binding.tvNoData.visibility = View.GONE
                    binding.divider.visibility = View.GONE
                }
                if (it.responseData?.next==null || it.responseData?.next==0){
                    binding.viewMore.visibility = View.GONE
                }else {
                    nextPageCalling = it.responseData?.next!!.toInt()
                }
                if (adapterList.isNullOrEmpty() && !callDetailsList.isNullOrEmpty()) {
                    if (callDetailsList.size > 0) {
                        setAdapter(callDetailsList.toMutableList())
                    }
                } else {

                    if (!it.responseData?.callHistory.isNullOrEmpty()) {
                        val nextPage: Int = 0
                        val data = MutableLiveData<NewCommonResponseModel<CallHistoryModel>>()
                        val list = it.responseData?.callHistory?.toMutableList()
                        list?.addAll(adapterList)
                        it.responseData?.callHistory = emptyList()
                        it.responseData?.callHistory = list!!

                        viewModel.insertCallHistoryTargetResponseToDb(it,data,accountNumber)
                        Log.d("CheckDataListNew", " ${it.responseData!!.callHistory.size} $it")
                    }

                    previousListSize = adapterList.size
                    Log.d("CheckingListShiv", " ${adapterList.size}")
                    setAdapter(callDetailsList.toMutableList())
                    binding.recyclerViewCallHis.scrollToPosition(previousListSize-1)


                }
                setViewMoreVisibility(callDetailsList.isEmpty())
            }


        }

    }

    @SuppressLint("LongLogTag")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        // Inflate the layout for this fragment
        _binding = FragmentCallingHistoryBinding.inflate(inflater, container, false)
        activityInstance = (activity as CustomerHistoryActivity?)!!

        KaziApplication.preference = GreenLightPreference.getInstance(activityInstance!!)

        Log.d("CallingHistoryFragmentList", "success: ${list}")

        Initialize()

        Log.d("PageNumberCallingHistory1",nextPageCalling.toString())

        if (nextPageCalling==0){
            binding.viewMore.visibility = View.GONE
        }

        binding.viewMore.setOnClickListener {

            Log.d("callingViewMore","OnClicked:" + "true")

            when(Util.isOnline(requireActivity())){

                true -> {

                    if (nextPageCalling!=null && nextPageCalling!=0){
                        showProgressDialog(requireActivity())
                        viewModel.getCallingHistoryData1(accountNumber, nextPageCalling!!)
                    }
                }

                false -> {
                    Util.customFseCompletionDialog(
                        context = requireActivity(),
                        hideTitle = true,
                        message = "Please check internet connection",
                        okSelected = {
                            it.dismiss()
                        },
                        title = null
                    )
                }
            }


        }

        if (!viewModel.callDetailsData?.hasActiveObservers()!!) {
            viewModel.callDetailsData?.observe(requireActivity(),observer)
        }

        return binding.root;
    }

    @SuppressLint("LongLogTag")
    private fun Initialize() {


        if (!list.isNullOrEmpty()) {
            viewModel.getTaskIntentFromDb().observe(requireActivity(), Observer {
                Log.e("FeedBackIntentDataCheck","${it.responseData}")
                if (it!!.success) {
                    feedbackIntentModel = it.responseData
                    Log.e("FeedBackIntentDataCheck1","${it.responseData}")
                    initRecyclerView(list)
                } else {
                    Util.showToast(requireActivity(),"No feedback data available")
                }

            })

        } else {
            binding.viewMore.visibility = View.GONE
            binding.tvNoData.visibility = View.VISIBLE
            binding.divider.visibility = View.VISIBLE
        }
    }

    @SuppressLint("LongLogTag", "NotifyDataSetChanged")
    private fun setAdapter(mutableList: MutableList<CallHistory>?) {

        Log.d("PreviousListCallingHistory", "success: ${adapterList.size}")
        Log.d("NewListCallingHistory", "success: ${mutableList?.size}")

        if (mutableList.isNullOrEmpty()) {
            binding.tvNoData.visibility = View.VISIBLE
            binding.divider.visibility = View.VISIBLE
            binding.viewMore.visibility = View.GONE
        }
        else {
            binding.tvNoData.visibility = View.GONE
            binding.divider.visibility = View.GONE
            //adapterList.clear()
            if (!mutableList.isNullOrEmpty()) {
                adapterList.addAll(mutableList)
                Log.d("CallingAdapterListSize", "adapter : $adapterList")
                Log.d("CallingAdapterFeedbackList", "adapter : $feedbackIntentModel")
                adapter = CallHistoryAdapterRecycler(requireActivity(), adapterList,feedbackIntentModel)
                binding.recyclerViewCallHis.adapter = adapter
                visibilityHandler(true, false, false)
            }
            adapter?.notifyDataSetChanged()
        }
    }

    private fun setViewMoreVisibility(hideViewMore: Boolean = false) {
        if (adapterList.isEmpty() || adapterList.size == 0) {
            binding.tvNoData.visibility = View.VISIBLE
            binding.divider.visibility = View.VISIBLE
            binding.viewMore.visibility = View.GONE
        } else {
            Log.d(TAG, "setViewMoreVisibitlity:adapterList.size => ${adapterList.size}")

            binding.tvNoData.visibility = View.GONE
            binding.divider.visibility = View.GONE
        }

        if (hideViewMore) {
            binding.viewMore.visibility = View.GONE
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun initRecyclerView(list: MutableList<CallHistory>?) {

        val layoutManager = LinearLayoutManager(requireActivity())
        binding.recyclerViewCallHis.layoutManager = layoutManager
        binding.recyclerViewCallHis.addItemDecoration(
            DividerItemDecoration(
                requireContext(),
                DividerItemDecoration.VERTICAL
            ).apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    this.setDrawable(
                        resources.getDrawable(
                            R.drawable.line_divider,
                            requireContext().theme
                        )
                    )
                } else {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider))
                }
            })
        setAdapter(list)
    }

    @JvmOverloads
    private fun visibilityHandler(showRecyclerView: Boolean = false,
                                  showNoData: Boolean = false,
                                  showSearchNoData: Boolean = false,
    ) {

        if (showRecyclerView) {
            binding.recyclerViewCallHis.visibility = View.VISIBLE
        } else {
            binding.recyclerViewCallHis.visibility = View.GONE
        }

        if (showNoData) {
            binding.tvNoData.visibility = View.VISIBLE
            binding.divider.visibility = View.VISIBLE
        } else {
            binding.tvNoData.visibility = View.GONE
            binding.divider.visibility = View.GONE
        }
    }



}