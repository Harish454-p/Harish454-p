package com.greenlightplanet.kazi.attendance.extra

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.attendance.model.AttendanceResponseModel

import io.reactivex.Single

@Dao
interface AttendanceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAttendance(users: List<AttendanceResponseModel.Checkin>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertSingleAttendance(users: AttendanceResponseModel.Checkin)

    @Query("SELECT * FROM checkins")
    fun getAttendanceSS():Single<List<AttendanceResponseModel.Checkin>>

    @Query("SELECT * FROM checkins WHERE date BETWEEN :fromDate AND :toDate")
    fun getAttendance(fromDate: Long,toDate: Long):Single<List<AttendanceResponseModel.Checkin>>

    @Query("SELECT * FROM checkins WHERE date BETWEEN :fromDate AND :toDate")
    fun getAttend(fromDate: Long,toDate: Long):List<AttendanceResponseModel.Checkin>

    @Query("SELECT * FROM  checkins WHERE date BETWEEN :fromDate AND :toDate GROUP BY date HAVING COUNT(*) > 0")
    fun getAttendanceCount(fromDate: Long,toDate: Long):List<AttendanceResponseModel.Checkin>

    @Query("SELECT * FROM checkins WHERE is_online_added=:isOnlineAdded")
//    fun getOfflineAttendance(isOnlineAdded:Boolean):Single<List<AttendanceResponseModel.Checkin>>
    fun getOfflineAttendance(isOnlineAdded:Boolean):List<AttendanceResponseModel.Checkin>

    @Query("SELECT * FROM checkins WHERE is_online_added=:isOnlineAdded")
    fun getRXOfflineAttendance(isOnlineAdded:Boolean):Single<List<AttendanceResponseModel.Checkin>>

    @Query("UPDATE checkins SET is_online_added =:makeTrue WHERE is_online_added =:isOnlineAdded")
    fun updateOfflineList(isOnlineAdded: Boolean,makeTrue:Boolean)

    @Query("DELETE FROM checkins")
    fun deleteAll(): Int


}
