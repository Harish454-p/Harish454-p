package com.greenlightplanet.kazi.location.extras

import android.content.Context
import android.content.pm.PackageManager

class PermissionUtils {

	companion object {
		public const val TAG = "PermissionUtils"


		fun checkLocationPermission(context: Context): Boolean {
			// Check for ACCESS_FINE_LOCATION Permission
			return context.checkCallingOrSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
		}

		fun checkImeiPermission(context: Context): Boolean {
			// Check for READ_PHONE_STATE Permission
			return context.checkCallingOrSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
		}


		fun checkCallPermission(context: Context): Boolean {
			// Check for READ_PHONE_STATE Permission
			return (context.checkCallingOrSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED && context.checkCallingOrSelfPermission(android.Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED)
		}
	}

}
