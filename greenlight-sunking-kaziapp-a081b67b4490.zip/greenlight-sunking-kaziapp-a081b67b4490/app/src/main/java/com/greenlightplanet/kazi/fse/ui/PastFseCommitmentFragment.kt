package com.greenlightplanet.kazi.fse.ui


import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.LinearLayoutManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentFseCommitmentBinding
import com.greenlightplanet.kazi.databinding.FragmentPastFseCommitmentBinding
import com.greenlightplanet.kazi.fse.extras.custom.CustomProgress
import com.greenlightplanet.kazi.fse.extras.util.DateConversionUtil.Companion.getCurrentDate
import com.greenlightplanet.kazi.fse.extras.util.DateConversionUtil.Companion.getTimeAsPerPosition
import com.greenlightplanet.kazi.fse.model.FseHistory
import com.greenlightplanet.kazi.fse.model.FseHistoryResponse
import com.greenlightplanet.kazi.fse.ui.adapter.PastFseCommitmentAdapter
import com.greenlightplanet.kazi.fse.viewmodel.PastFseCommitmentViewModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.github.luizgrp.sectionedrecyclerviewadapter.SectionedRecyclerViewAdapter


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 *
 */
class PastFseCommitmentFragment : Fragment() {

private  lateinit var _binding:FragmentPastFseCommitmentBinding

    private val binding get() = _binding


    companion object {
        public const val TAG = "PastFseCommitmentFrag"

    }


    private lateinit var progressBar: CustomProgress
    var preference: GreenLightPreference? = null

    lateinit var viewModel: PastFseCommitmentViewModel
    var adapterData: MutableMap<PastFseCommitmentViewModel.PastHeaderHistory, List<FseHistory>> = mutableMapOf()
    var adapterList: MutableList<FseHistory>? = null
    var sectionAdapter: SectionedRecyclerViewAdapter? = null
    var baseActivity: BaseActivity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        baseActivity = activity as BaseActivity
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment

        _binding = FragmentPastFseCommitmentBinding.inflate(inflater, container, false)


        progressBar = CustomProgress.getInstance(requireContext())
        preference = GreenLightPreference.getInstance(requireContext())


        viewModel = ViewModelProviders.of(this).get(PastFseCommitmentViewModel::class.java)
        return binding.root

       // return view
    }

    override fun onResume() {
        super.onResume()
        // working, but now no use of it
        /*viewModel.getFseHistroyCommitment(progressBar, context!!, getCurrentDate(), getCurrentDate()).observe(this, Observer {


            progressBar.cancelProgressDialog()
            adapterList = it?.toMutableList()!!

            val convertedMap = viewModel.convertListToMap(adapterData, adapterList!!)

            //todo remove in production
            Log.d(TAG, "adapterList:$adapterList ");
            Log.d(TAG, "convertedMap:$convertedMap ");

            setAdapter(convertedMap)

        })*/

        activity?.findViewById<AppCompatTextView>(R.id.toolbar_title)?.setText("Past Visits")

        binding.spnrCommitment.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) =
                    if (position == 1) {
                        //get fse by today's date
                        getFseByDate(getTimeAsPerPosition(position), getTimeAsPerPosition(position))
                    } else {
                        //get fse based on selected date
                        getFseByDate(getTimeAsPerPosition(position), getCurrentDate())
                    }
        }
    }


    /*fun setAdapter(mutableMap: MutableMap<PastHeaderHistory, List<FseHistory>>) {


        //todo remove in production used for logging
        for ((key, value) in mutableMap) {

            Log.d(TAG, "mutableMap: key  = $key   || value = $value");

        }

        val reverse = mutableMap.toSortedMap(reverseOrder())

        //todo remove in production used for logging
        for ((key, value) in reverse) {

            Log.d(TAG, "reverse: key  = $key   || value = $value");

        }

        if (sectionAdapter == null) {
            sectionAdapter = SectionedRecyclerViewAdapter()


            for (entry in reverse) {
                val section = PastFseCommitmentAdapter(context!!, entry.key, entry.value)
                //callback for adapter
                //section.setMySectionSampleCallback(this)
                sectionAdapter!!.addSection(section)

            }

            recyclerView.layoutManager = LinearLayoutManager(context)


            //setting edit-text textwatcher
            if (recyclerView?.adapter == null) {
                et_search.addTextChangedListener(textWatcher)
            }

            recyclerView.adapter = sectionAdapter


        } else {

            sectionAdapter!!.removeAllSections()

            for (entry in reverse) {
                val section = PastFseCommitmentAdapter(context!!, entry.key, entry.value)
                //callback for adapter
                //section.setMySectionSampleCallback(this)
                sectionAdapter!!.addSection(section)
            }
        }
        sectionAdapter?.notifyDataSetChanged()
    }*/


    fun setAdapter(mutableMap: MutableMap<PastFseCommitmentViewModel.PastHeaderHistory, List<FseHistory>>?) {

        if (mutableMap.isNullOrEmpty()) {
            binding.tvNoData.visibility = View.VISIBLE
            binding.recyclerView.visibility = View.INVISIBLE
        } else {


            binding.tvNoData.visibility = View.GONE
           binding.recyclerView.visibility = View.VISIBLE

            //val reverse = mutableMap.toSortedMap(reverseOrder())
            val reverse = viewModel.getReverseOfMutableMap(mutableMap)

            if (sectionAdapter == null) {
                sectionAdapter = SectionedRecyclerViewAdapter()


                for (entry in reverse) {
                    val section = PastFseCommitmentAdapter(requireContext(), entry.key, entry.value)
                    //callback for adapter
                    //section.setMySectionSampleCallback(this)
                    sectionAdapter!!.addSection(section)
                }

               binding.recyclerView.layoutManager = LinearLayoutManager(context)


                //setting edit-text textwatcher
                if (binding.recyclerView?.adapter == null) {
                    binding.etSearch.addTextChangedListener(textWatcher)
                }

                binding.recyclerView.adapter = sectionAdapter


            } else {

                sectionAdapter!!.removeAllSections()

                for (entry in reverse) {
                    val section = PastFseCommitmentAdapter(requireContext(), entry.key, entry.value)
                    //callback for adapter
                    //section.setMySectionSampleCallback(this)
                    sectionAdapter!!.addSection(section)
                }
            }
            sectionAdapter?.notifyDataSetChanged()


        }


    }


    fun getFseByDate(fromDate: String, toDate: String) {

        //todo old
        /*viewModel.getFseHistroyCommitment(context!!, fromDate, toDate, preference?.getLoginResponseModel()?.angazaId!!) {
            baseActivity?.showProgressDialog(context)
        }.observe(this, Observer {
            //viewModel.getFseHistroyCommitment( progressBar, context!!, fromDate, toDate,preference?.getLoginResponseModel()?.angazaId!!).observe(this, Observer {

            //progressBar.cancelProgressDialog()
            baseActivity?.cancelProgressDialog()
            adapterList = it?.toMutableList()!!
            val convertedMap = viewModel.convertListToMap(adapterData, adapterList!!)

            //todo remove in production
            Log.d(TAG, "adapterList:$adapterList ");
            Log.d(TAG, "convertedMap:$convertedMap ");

            setAdapter(convertedMap)

        })*/


        viewModel.getNewFseHistroyCommitment(requireContext(), fromDate, toDate, preference?.getLoginResponseModel()?.angazaId!!) {
            baseActivity?.showProgressDialog(context)
        }.observe(this, Observer {
            //viewModel.getFseHistroyCommitment( progressBar, context!!, fromDate, toDate,preference?.getLoginResponseModel()?.angazaId!!).observe(this, Observer {

            //progressBar.cancelProgressDialog()


            it?.let {

                sampleMethod(it)

            } ?: run {
                baseActivity?.cancelProgressDialog()

                viewModel.getNewFseHistroyCommitment(requireContext(), fromDate, toDate, preference?.getLoginResponseModel()?.angazaId!!,forceOffline = true) {
                    baseActivity?.showProgressDialog(context)
                }.observe(this, Observer {
                    baseActivity?.cancelProgressDialog()

                    it?.let {
                        sampleMethod(it)
                    }

                })
            }


        })
    }

    fun sampleMethod(it: FseHistoryResponse.ResponseData) {

        baseActivity?.cancelProgressDialog()


        it?.let {
            binding.llMatric1Value.text = "${it?.hitRate}%" //"${getPer(it?.hitRate!!, it?.totalCustomersCommitment!!)}%"
           binding.llMatric2Value.text = "${it?.todaysVisit} / ${it?.targetVisit}"
        }

        var convertedMap: MutableMap<PastFseCommitmentViewModel.PastHeaderHistory, List<FseHistory>>? = null

        it?.let {
            it.fseHistory?.let {

                //todo imporove this
                //adapterList.addAll(it.filterNotNull())
                adapterList = it.filterNotNull().toMutableList()

                convertedMap = viewModel.convertListToMap(adapterData, adapterList!!)
            }
        }


        //todo remove in production
        Log.d(TAG, "adapterList:$adapterList ");
        Log.d(TAG, "convertedMap:$convertedMap ");

        setAdapter(convertedMap)

    }

    private var textWatcher = object : TextWatcher {

        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
        override fun afterTextChanged(s: Editable) {

            val filterList = viewModel.searchLogic(s.toString(), adapterList!!)

            val mutablePostList: MutableLiveData<List<FseHistory>> = MutableLiveData()

            mutablePostList.value = filterList

            mutablePostList.observe(
                    this@PastFseCommitmentFragment, Observer {


                it?.let {


                    Log.d(TAG, "search:$it ");
                    //setAdapter(viewModel.convertListToMap(adapterData, it.toMutableList()))
                    setAdapter(viewModel.convertListToMapForSearch(adapterData, it.toMutableList(), adapterList!!))

                }

            }
            )
        }

    }


    fun getPer(got: Int, total: Int): Double {

        var result: Double = 0.0
        try {
            result = (got / total).toDouble()
        } catch (e: Exception) {
            return 0.0
        }
        return result * 100


    }


    override fun onDestroy() {
        progressBar.cancelProgressDialog()
        progressBar.destroy()
        super.onDestroy()
    }

}
