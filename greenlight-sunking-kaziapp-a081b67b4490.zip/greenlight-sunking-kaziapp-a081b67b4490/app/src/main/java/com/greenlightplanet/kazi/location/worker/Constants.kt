package com.greenlightplanet.kazi.location.worker

const val PENDING_REQUEST_ID = 9823

const val DEFAULT_INTERVAL = 30L

const val TASK_ALARM = "ALARM"

const val TASK_WM = "WORK_MANAGER"

const val TASK_TAG = "TASK_TAG"

const val CAN_CALL_WM_DURATION = 2100000 // 35 minutes x 60000
