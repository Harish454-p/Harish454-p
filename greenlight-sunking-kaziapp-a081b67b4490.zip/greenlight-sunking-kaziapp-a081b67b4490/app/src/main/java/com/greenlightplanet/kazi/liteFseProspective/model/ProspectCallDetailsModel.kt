package com.greenlightplanet.kazi.liteFseProspective.model

import android.os.Parcelable
import androidx.room.*
import kotlinx.android.parcel.Parcelize
import com.google.gson.annotations.SerializedName
import com.greenlightplanet.kazi.utils.Util

@Parcelize
data class ProspectCallDetailsModel(
        @ColumnInfo(name = "prospectCallDetails")
        @SerializedName("prospectCallDetails")
        var prospectCallDetails: List<ProspectCallDetail>
) : Parcelable

@Parcelize
@Entity(tableName = "ProspectCallDetail",primaryKeys = ["prospectId","callingTime"])
data class ProspectCallDetail(
//        @PrimaryKey
        @ColumnInfo(name = "prospectId")
        @SerializedName("prospectId")
        var prospectId: String, // PP000001
        @ColumnInfo(name = "callAttempt")
        @SerializedName("callAttempt")
        var callAttempt: Int,
        @ColumnInfo(name = "callingTime")
        @SerializedName("callingTime")
        var callingTime: String,
        @ColumnInfo(name = "dispositionCode")
        @SerializedName("dispositionCode")
        var dispositionCode: String,
        @ColumnInfo(name = "phoneNumber")
        @SerializedName("phoneNumber")
        var phoneNumber: String
) : Parcelable {
    val callingTimeLong: Long?
        get() {
            return if (this.callingTime == null) {
                null
            } else {
                Util.fseUtcToDate(this.callingTime!!).time
            }
        }
}