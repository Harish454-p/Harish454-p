package com.greenlightplanet.kazi.collectiongoal.model.paymenthistory

import android.os.Parcelable
import androidx.annotation.Keep
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

@Keep
@Parcelize
@Entity(tableName = "PaymentHistoryModel")
data class PaymentHistoryModel(

    @ColumnInfo(name = "accountNumber")
    @PrimaryKey(autoGenerate = false)
    var accountNumber:Int,

    @ColumnInfo(name ="next", defaultValue = "")
    var next: Int?,

    @ColumnInfo(name ="pageNo")
    val pageNo: Int?,

    @ColumnInfo(name = "paymentHistory")
    var paymentHistory: List<PaymentHistory>? = listOf()
) : Parcelable