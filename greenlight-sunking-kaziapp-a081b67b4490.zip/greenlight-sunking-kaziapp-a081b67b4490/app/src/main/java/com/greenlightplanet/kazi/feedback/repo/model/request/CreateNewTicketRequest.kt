package com.greenlightplanet.kazi.feedback.repo.model.request

import androidx.annotation.Keep

@Keep
data class CreateNewTicketRequest(
    var accountNumber: String = "",
    var angazaId: String = "",
    var attachments: MutableList<String> = mutableListOf<String>(),
    var category: String = "",
    var message: String = "",
    var subcategory: String = ""
) {
    var isAccountNoMandatory = false
    var isAccountInUiFound = false
    var isAccountFilled = false
    var isMessageInUiFound = false
    var isMessageFilled = false
}