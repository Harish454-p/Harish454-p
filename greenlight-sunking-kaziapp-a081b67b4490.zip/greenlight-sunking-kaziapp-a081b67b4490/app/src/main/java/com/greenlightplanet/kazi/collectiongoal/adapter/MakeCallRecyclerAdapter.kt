package com.greenlightplanet.kazi.collectiongoal.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.text.SpannableString
import android.text.style.UnderlineSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.collectiongoal.view.activity.CustomerProfileActivity
import com.greenlightplanet.kazi.databinding.MakeCallItemLayoutBinding
import com.greenlightplanet.kazi.newtasks.extras.AdapterUtils
import com.greenlightplanet.kazi.utils.Util
import kotlin.math.roundToInt

class MakeCallRecyclerAdapter constructor(
    private val context: Context,
    private var values: List<MakeCallNewModel.ColGoalAccount>
) :
    RecyclerView.Adapter<MakeCallRecyclerAdapter.ViewHolder>() {

    var makeCallAdapterCallback: MakeCallAdapterCallback? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MakeCallRecyclerAdapter.ViewHolder {
        val itemBinding = MakeCallItemLayoutBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: MakeCallRecyclerAdapter.ViewHolder, position: Int) {
        val task = values[position]
        if (position + 1 == values.size) {
            holder.itemBinding.llpastWeekIncentiveItem.setBackgroundResource(R.drawable.square_border_with_bottom)
        } else {
            holder.itemBinding.llpastWeekIncentiveItem.setBackgroundResource(R.drawable.square_border_without_bottom)
        }
        holder.bind(task, holder.itemView)
    }

    override fun getItemCount(): Int {
//        Log.d("MakeCallItemCount", values.size.toString())
        return values.size
    }

    inner class ViewHolder(val itemBinding: MakeCallItemLayoutBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {

        @SuppressLint("SetTextI18n", "LogNotTimber")
        fun bind(task: MakeCallNewModel.ColGoalAccount, itemView: View) {

            itemBinding.llmakeCallBottom.visibility = View.GONE

            itemBinding.tvCustomerName.text = task.customerName
            val paid_amount = task.collectedAmount.let { it?.roundToInt() }.toString()
                .let { Util.checkBlank(it, context = context) }
            val target_amount = task.expectedAmount.let { it?.roundToInt() }.toString()
                .let { Util.checkBlank(it, context = context) }

//            Log.d("CheckingAmountOnly", "CustomerName ${task.customerName} " +
//                    "\n ExpectedAmount $target_amount " +
//                    "\n CollectedAmount $paid_amount " +
//                    "\n FinalAmount ${task.expectedAmount?.roundToInt()
//                        ?.minus(task.collectedAmount?.roundToInt()!!)}")

            if (task.isAchieved) {
                val aa = task.expectedAmount.let { it?.roundToInt() }
                val bb = task.collectedAmount.let { it?.roundToInt() }
                val mm = bb
                val mSpannableString = SpannableString(mm.toString()
                    .let { Util.checkBlank(it, context = context) })
//            val mSpannableString =  SpannableString(task.balanceAmount.let { it?.roundToInt() }.toString()
//                .let { Util.checkBlank(it, context = context) })
                mSpannableString.setSpan(UnderlineSpan(), 0, mSpannableString.length, 0)
                itemBinding.tvAmountRequired.text = mSpannableString
            }
            else {
                val aa = task.expectedAmount.let { it?.roundToInt() }
                val bb = task.collectedAmount.let { it?.roundToInt() }
                val mm = aa!! - bb!!
                val mSpannableString = SpannableString(mm.toString()
                    .let { Util.checkBlank(it, context = context) })
//            val mSpannableString =  SpannableString(task.balanceAmount.let { it?.roundToInt() }.toString()
//                .let { Util.checkBlank(it, context = context) })
                mSpannableString.setSpan(UnderlineSpan(), 0, mSpannableString.length, 0)
                itemBinding.tvAmountRequired.text = mSpannableString
            }

            /*todo expectedAmount - collectedAmount = tvAmountRequired*/
            itemBinding.tvAmountRequired.setTextColor(Color.parseColor("#428b28"))
            itemBinding.tvCustomerName.setTextColor(Color.parseColor("#428b28"))


//            var paid_amount = task.totalPaid.let { it?.roundToInt() }.toString()
//                .let { Util.checkBlank(it, context = context) }
//            val target_amount = task.unlockPrice.let { it?.roundToInt() }.toString()
//                .let { Util.checkBlank(it, context = context) }


            itemBinding.tvPaidTarget.text = "$paid_amount/$target_amount"

            if (task.isTask!!) {
                itemBinding.IVBcall.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_call_black_24dp
                    )
                )
            } else {
                itemBinding.IVBcall.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_empty_phone
                    )
                )
            }

            itemBinding.IVBcall.setOnClickListener {
                if (AdapterUtils.checkCallLogPermission(context)) {
                    makeCallAdapterCallback?.makeCall(account = task)
                } else {
                    makeCallAdapterCallback?.requestCallLogPermission(account = task)
                }
            }

            if (task.status == "DISABLED") {
                itemBinding.tvCustomerName.setTextColor(Color.parseColor("#FF0000"))
            } else {
                itemBinding.tvCustomerName.setTextColor(Color.parseColor("#000000"))
            }

            itemBinding.tvAmountRequired.setOnClickListener {

                if (itemBinding.llmakeCallBottom.visibility != View.VISIBLE) {

                    itemBinding.llmakeCallBottom.visibility = View.VISIBLE
                } else {
                    itemBinding.llmakeCallBottom.visibility = View.GONE
                }
            }

            itemBinding.tvCustomerName.setOnClickListener {
                makeCallAdapterCallback?.gotoNewTaskProfile(position, account = task)
            }
        }
    }

    interface MakeCallAdapterCallback {

        fun gotoNewTaskProfile(position: Int, account: MakeCallNewModel.ColGoalAccount)
        //fun gotoNewTaskFeedback(position: Int, account: MakeCallNewModel.ColGoalAccount)
        fun makeCall(account: MakeCallNewModel.ColGoalAccount)
        fun requestCallLogPermission(account: MakeCallNewModel.ColGoalAccount)

    }
}