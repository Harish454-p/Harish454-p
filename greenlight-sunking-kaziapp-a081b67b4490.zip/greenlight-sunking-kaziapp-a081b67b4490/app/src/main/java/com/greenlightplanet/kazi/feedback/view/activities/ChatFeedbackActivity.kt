package com.greenlightplanet.kazi.feedback.view.activities

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.databinding.ActivityChatFeedbackBinding
import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackConstants
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.feedback.repo.model.request.SendRequest
import com.greenlightplanet.kazi.feedback.repo.model.response.ChatData
import com.greenlightplanet.kazi.feedback.repo.model.response.MessageData
import com.greenlightplanet.kazi.feedback.repo.model.response.TicketResponseData
import com.greenlightplanet.kazi.feedback.repo.socket.SocketHelper
import com.greenlightplanet.kazi.feedback.view.adapter.ChatFeedbackAdapter
import com.greenlightplanet.kazi.feedback.view.adapter.ChatFeedbackAdapterClickListener
import com.greenlightplanet.kazi.feedback.viewmodel.ChatFeedbackViewModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.NetworkResult
import com.greenlightplanet.kazi.utils.Util
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import timber.log.Timber
import java.lang.ref.WeakReference

@AndroidEntryPoint
class ChatFeedbackActivity : BaseActivity(), ChatFeedbackAdapterClickListener,
    SocketHelper.NewMessageListener {
    private lateinit var binding: ActivityChatFeedbackBinding
    private val viewModel by viewModels<ChatFeedbackViewModel>()
    private var adapter = ChatFeedbackAdapter()
    private lateinit var socketHelper: SocketHelper
    private var isSocketInit = false
    private var isSocketConnected = false
    private var isConvoFirst = false
    private var isFirstConnect = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatFeedbackBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initToolbar()
        socketHelper = SocketHelper(WeakReference(this))
        initIntentData(intent)
        initializeChatRv()
        setupListener()
        observer()
        with(viewModel) {
            if (isClosed) {
                invokeConversationData(viewModel.ticketId)
                binding.footerParent.visibility = View.GONE
            }
            if (isPending) {
                socketSetup()
                isFirstConnect = true
                invokeConversationData(viewModel.ticketId)
                binding.footerParent.visibility = View.VISIBLE
            }
        }

    }

    private fun initToolbar() {
        setSupportActionBar(binding.toolbar)
        Util.setToolbar(this, binding.toolbar)
    }

    private fun socketSetup() {
        socketHelper.makeConnection()
        Timber.d("Stomp Activity: First time || makeConnection Called")
        socketHelper.observers(viewModel.ticketId)
        isSocketInit = true
    }

    private fun observer() {
        with(viewModel) {
            /** Chat History API Observer */
            chatResponseLiveData.observe(this@ChatFeedbackActivity) { result ->
                when (result) {
                    is NetworkResult.Success -> {
                        dialog?.dismiss()
                        Timber.d("Observer Conversation: Success: Response: ${result.data}")
                        if (!result.data.isNullOrEmpty()) {
                            adapter.setRvData(result.data)
                            binding.recyclerView.scrollToPosition(adapter.dataList.size - 1)
                        } else {
                            Timber.d("Observer Conversation: Chat Data not found")
                        }
                    }
                    is NetworkResult.Error -> {
                        dialog?.dismiss()
                        Timber.d("Observer Conversation: Error: ${result.message}")
                    }
                    is NetworkResult.Loading -> {
                        if (isConvoFirst) {
                            showProgressDialog(this@ChatFeedbackActivity)
                            isConvoFirst = false
                        }


                    }
                    is NetworkResult.DbSuccess -> {

                    }
                    else->{}
                }
            }

            /** New Message Send Observer */
            sendMessageLiveData.observe(this@ChatFeedbackActivity) { result ->
                when (result) {
                    is NetworkResult.Success -> {
                        Timber.d("Observer Send Message: Success: Response: ${result.data}")
                        result.data?.let {
                            if (it) {
                                Timber.d("Observer Send Message: Message sent successfully")
                            }
                        }

                    }
                    is NetworkResult.Error -> {
                        result.data?.let {
                            if (!it) {
                                Toast.makeText(
                                    this@ChatFeedbackActivity,
                                    "Message not sent",
                                    Toast.LENGTH_SHORT
                                ).show()
                                Timber.d("Observer Send Message: Message not Sent: Server Message : ${result.message}")
                            }
                        }
                    }
                    is NetworkResult.Exception -> {
//                        Toast.makeText(this@ChatFeedbackActivity, "Message not sent", Toast.LENGTH_SHORT).show()
                        Timber.d("Observer Send Message Exception: Message not Sent")
                    }
                    is NetworkResult.Loading -> {

                    }
                    is NetworkResult.DbSuccess -> {

                    }
                }
            }
        }
    }

    private fun setupListener() {
        binding.ivSend.setOnClickListener {
            cookMessageAndSend()
        }
    }

    /** Creates New Message Request Body before sending */
    private fun cookMessageAndSend() {
        binding.etMessage.text?.let { message ->
            if (Helper.isNetworkConnected()) {
                val currentDate =
                    Helper.getCurrentUTCDateInRequiredFormat(FeedbackConstants.utcDateFormat)
                if (message.trim().isNotEmpty()) {
                    val sendRequest = SendRequest(
                        angazaId = FeedbackConstants.angazaId,
                        attachment = emptyList<String>(),
                        message = message.trim().toString(),
                        requesterType = "EO",
                        status = "open",
                        ticketId = viewModel.ticketId,
                        updatedBy = FeedbackConstants.angazaId
                    )

                    Timber.d("Stomp Activity: Date while sending message: $currentDate")
                    val chatData = ChatData(
                        ticketId = viewModel.ticketId,
                        sender = FeedbackConstants.angazaId,
                        senderType = "EO",
                        message = message.trim().toString(),
                        timestamp = currentDate
                    )
                    viewModel.currentChatData = chatData
                    adapter.addRvData(chatData)
                    binding.recyclerView.scrollToPosition(adapter.dataList.size - 1)
//                    socketHelper.sendMessage(messageData)
                    Timber.d("Stomp Activity: Message to Send: $sendRequest")
                    lifecycleScope.launch(Dispatchers.IO) {
                        viewModel.invokeSendMessageData(
                            FeedbackConstants.country,
                            sendRequest = sendRequest
                        )
                    }
                    binding.etMessage.setText("")
                }
            } else {
                Toast.makeText(
                    this@ChatFeedbackActivity,
                    "No internet. Please turn on internet to continue",
                    Toast.LENGTH_SHORT
                ).show()
            }

        }
    }
    /** Receives necessary intent data from Closed/Pending Screens */
    private fun initIntentData(intent: Intent) {
        with(viewModel) {
            val status = intent.getBooleanExtra(FeedbackConstants.CLOSED_CHAT_INTENT, false)
            viewModel.ticketId = intent.getStringExtra(FeedbackConstants.TICKETID_CHAT_INTENT) ?: ""
            viewModel.status = intent.getStringExtra(FeedbackConstants.STATUS_CHAT_INTENT) ?: ""
            if (status) isClosed = true
            else isPending = true
        }

    }

    /** Chat Rv Adapter Setup*/
    private fun initializeChatRv() {
        val layoutFilterManager = LinearLayoutManager(this@ChatFeedbackActivity)
        binding.recyclerView.layoutManager = layoutFilterManager
        binding.recyclerView.adapter = adapter
        adapter.attachListener(WeakReference(this))
    }

    override fun onTicketItemClickedFilter(data: TicketResponseData) {

    }

    /** Callback for getting new message received from Socket*/
    override fun onNewMessageReceived(chatData: ChatData) {
        Timber.d("Stomp Activity: Message Received: Data: $chatData")
        adapter.dataList.apply {
            if (this.isNotEmpty()) {
                if (last().timestamp != chatData.timestamp) {
                    Timber.d("Stomp Activity: Message Received: Inside ValidationData: ${this.last().timestamp} != ${chatData.timestamp}")
                    adapter.addRvData(chatData)
                    binding.recyclerView.scrollToPosition(adapter.dataList.size - 1)
                }
            }
        }
    }


    // Socket Callback Region Start
    override fun onSocketConnected() {
        Timber.d("Stomp Activity: Connected")
        isSocketConnected = true
        dialog?.dismiss()
    }

    override fun onSocketError() {
        Timber.d("Stomp Activity: Error")
        dialog?.dismiss()
    }

    override fun onSocketClosed() {
        Timber.d("Stomp Activity: Closed")
        dialog?.dismiss()
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            lifecycleScope.launch(Dispatchers.IO) {
                viewModel.invokeConversationData(viewModel.ticketId)
            }
            Timber.d("Stomp Activity: Initiating re-connect")
            isSocketConnected = false
            socketHelper.compositeDisposable.dispose()
            socketHelper.makeConnection()
            socketHelper.observers(viewModel.ticketId)
            Timber.d("Stomp Activity: onSocketClosed || makeConnection Called")
        }
    }
    // Socket Callback Region End..............



    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        if (viewModel.isPending) socketHelper.disconnect()
        super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        dialog?.dismiss()
        if (viewModel.isPending) socketHelper.disconnect()
    }

    override fun onResume() {
        super.onResume()
        /** Reconnects to Socket connection if the connection is lost at the time*/
        if (Helper.isNetworkConnected()) {
            if (viewModel.isPending) {
                if (!isFirstConnect) {
                    if (!socketHelper.mStompClient.isConnected) {
                        socketHelper.compositeDisposable.dispose()
                        socketHelper.makeConnection()
                        socketHelper.observers(viewModel.ticketId)
                        Timber.d("Stomp Activity: onResume || makeConnection Called")
                    }
                } else {
                    isFirstConnect = false
                }
            }
        }
    }


}
