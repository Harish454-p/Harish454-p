package com.greenlightplanet.kazi.agentReferral.model.agentreferral


import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import kotlinx.parcelize.Parcelize

@Entity(tableName = "AgentReferralModel")
@Parcelize
data class AgentReferralModel(

    @PrimaryKey(autoGenerate = true)
    val id : Int,

    @SerializedName("length")
    var length: Int?,
    @SerializedName("pagination")
    var pagination: Pagination?,
    @SerializedName("referred_agents_metrics")
    var referredAgentsMetrics: ReferredAgentsMetrics?,
    @SerializedName("successfully_referred_agents")
    var successfullyReferredAgents: List<SuccessfullyReferredAgent>?
) : Parcelable {

    class AgentReferralTypeConverter {

        @TypeConverter
        fun paginationToStr(value : Pagination) : String {
            return Gson().toJson(value)
        }

        @TypeConverter
        fun strToPagination(value : String?) : Pagination {
            return when(value) {
                null, "" -> Pagination(
                    page = null,
                    pageSize = null,
                    endOfStream = true
                )
                else -> Gson().fromJson<Pagination>(value, object : TypeToken<Pagination>() {}.type)
            }
        }

        @TypeConverter
        fun referredMetricToStr(value : ReferredAgentsMetrics) : String {
            return Gson().toJson(value)
        }

        @TypeConverter
        fun strToReferredMetric(value : String?) : ReferredAgentsMetrics {
            return when(value) {
                null, "" -> ReferredAgentsMetrics(
                    successfullyReferredAgentsCount = null,
                    totalReferralIncentiveLastMonth = null,
                    totalReferredAgentsCount = null,
                    totalSalesByReferredAgentsLastMonth = null
                )
                else -> Gson().fromJson<ReferredAgentsMetrics>(value, object : TypeToken<ReferredAgentsMetrics>(){}.type)
            }
        }

        @TypeConverter
        fun successfulReferredToStr(value : List<SuccessfullyReferredAgent>) : String {
            return Gson().toJson(value)
        }

        @TypeConverter
        fun strToSuccessFulReferred(value : String?) : List<SuccessfullyReferredAgent> {
            return when(value) {
                null, "" -> ArrayList<SuccessfullyReferredAgent>()
                else -> Gson().fromJson<List<SuccessfullyReferredAgent>>(value, object : TypeToken<List<SuccessfullyReferredAgent>>(){}.type)
            }
        }
    }
}