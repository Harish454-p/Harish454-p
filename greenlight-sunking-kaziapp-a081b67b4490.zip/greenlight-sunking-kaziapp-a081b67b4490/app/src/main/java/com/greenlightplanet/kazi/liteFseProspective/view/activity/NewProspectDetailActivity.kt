package com.greenlightplanet.kazi.liteFseProspective.view.activity

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.view.Window
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityNewProspectDetailBinding
import com.greenlightplanet.kazi.liteFseProspective.extras.AmazonS3Helper
import com.greenlightplanet.kazi.liteFseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.liteFseProspective.extras.FseProspectiveConstant.ProspectStatus
import com.greenlightplanet.kazi.liteFseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.liteFseProspective.model.*
import com.greenlightplanet.kazi.liteFseProspective.view.activity.adapter.ProspectCallDetailsDialogAdapter
import com.greenlightplanet.kazi.liteFseProspective.view.activity.adapter.ProspectProgressAdapter
import com.greenlightplanet.kazi.liteFseProspective.viewmodel.ProspectDetailViewModel
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.Constants
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import com.jama.carouselview.CarouselScrollListener
import com.jama.carouselview.enums.IndicatorAnimationType
import com.jama.carouselview.enums.OffsetType

import io.reactivex.disposables.CompositeDisposable
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class NewProspectDetailActivity : BaseActivity(),
    ProspectProgressAdapter.ProspectProgressAdapterCallback,
    AmazonS3Helper.AmazonS3HelperCallback {

    companion object {
        val TAG = "NewProspectDetailAct"
    }

    private lateinit var binding: ActivityNewProspectDetailBinding
    var fseProspectResponseModel: LiteFseProspectResponseModel? = null
    var loginResponseData: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    lateinit var viewModel: ProspectDetailViewModel
    var mHomeWatcher: HomeWatcher? = null
    var adapter: ProspectProgressAdapter? = null
    var adapterList: MutableList<LiteFseProspectResponseModel.StatusUpdateObjects> = mutableListOf()
    var circularProgressDrawable: CircularProgressDrawable? = null
    var installationRequestModel: LiteInstallationRequestModel? = null

    private val bag: CompositeDisposable = CompositeDisposable()
    var imageList: MutableList<String> = mutableListOf()
    var productNameList: MutableList<String> = mutableListOf()
    var amazonS3Helper: AmazonS3Helper? = AmazonS3Helper(this)
    var prospectCallList: MutableList<ProspectCallDetail> = mutableListOf()
    //  private var mLastClickTime: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewProspectDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        Util.setToolbar(this, toolbar)
        amazonS3Helper?.initializer()
        amazonS3Helper?.amazonS3HelperCallback = this
        circularProgressDrawable = CircularProgressDrawable(this)
        viewModel = ViewModelProviders.of(this).get(ProspectDetailViewModel::class.java)
        preference = GreenLightPreference.getInstance(this)
        loginResponseData = preference?.getLoginResponseModel()
        binding.progressRecyclerView.layoutManager = LinearLayoutManager(this)
        showProgressDialog(this)
        if (intent.hasExtra("data")) {
            var aa = intent.getStringExtra("data")
            viewModel!!.getSingleProspect("$aa").observe(this, Observer {
                fseProspectResponseModel = it.responseData
                fseProspectResponseModel?.let {
                    initialize(it)
                    cancelProgressDialog()
                    refreshCall(fseProspectResponseModel!!)
                }
            })
            /*fseProspectResponseModel = intent.getParcelableExtra("data")
            fseProspectResponseModel?.let {
                initialize(it)
//                Log.e(TAG, "initialize = = ===${fseProspectResponseModel!!.statusUpdateTime}")
            }*/
        }


//        callProspectCallApi()
//        cancelProgressDialog()
//        refreshCall(fseProspectResponseModel!!)
        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }

    private fun refreshCall(fse: LiteFseProspectResponseModel) {
        val refreshObserver = Observer<NewCommonResponseModel<ProspectCallDetailsModel>> { result ->
            Log.d(TAG, "refreshObserver:$result ");
            result?.let {
                cancelProgressDialog()
                if (it.success) {
                    prospectCallList.clear()
                    prospectCallList.addAll(it.responseData!!.prospectCallDetails)
                }
            }
        }
        getCall(fse, refreshObserver)
    }

    private fun getCall(
        fse: LiteFseProspectResponseModel,
        observer: Observer<NewCommonResponseModel<ProspectCallDetailsModel>>
    ) {
        viewModel!!.getProspectCallDetails(this, fse!!.prospectId)
            .observe(this, observer)
    }

    fun initialize(fseProspectResponseModel: LiteFseProspectResponseModel) {

//        if (intent.hasExtra("data")) {
//            fseProspectResponseModel = intent.getParcelableExtra("data")
        fseProspectResponseModel?.let {
            setUI(it)
            Log.e(TAG, "initialize = = ===${fseProspectResponseModel!!.statusUpdateTime}")
        }
//        }
        fseProspectResponseModel?.let {
            generalClickHandler(it.ticketType, it)
        }
        binding.tvAppBottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        binding.tvLastSavedDetails.text = "${getString(R.string.last_saved_key)} ${preference?.getFseProspectLastSynced()}"
    }

    private fun setUI(fseProspectResponseModel: LiteFseProspectResponseModel) {
        binding.tvCustomerName.text = fseProspectResponseModel.name ?: ""
        binding.tvCustomerAddress.text = fseProspectResponseModel.customerAddress
        binding.tvPhoneNumber.text = fseProspectResponseModel.customerPhoneNumber
        binding.tvProspectID.text = fseProspectResponseModel.prospectId ?: ""
        binding.tvAccountNumberID.text = fseProspectResponseModel.accountNumber ?: ""

        if (fseProspectResponseModel.status == ProspectStatus.THREE_WAY_CALL || fseProspectResponseModel.status == ProspectStatus.PROSPECT) {
            binding.llAccountNumberID.visibility = View.GONE
            binding.llProspectID.visibility = View.VISIBLE
        } else {
            binding.llAccountNumberID.visibility = View.VISIBLE
            binding.llProspectID.visibility = View.GONE
        }

        binding.tvStep1.setOnClickListener {
            if (!fseProspectResponseModel.sampleImages.isNullOrEmpty()) {
                val intent = Intent(this, ClickMultiImageActivity::class.java)
                intent.putExtra("prospectId", fseProspectResponseModel!!.prospectId)
                startActivityForResult(intent, Constants.CLICK_REQUEST_CODE)
            } else {
                Util.showToast(this, "No data available")
            }
        }

        if (fseProspectResponseModel.status != ProspectStatus.PROSPECT
            || fseProspectResponseModel.status == ProspectStatus.THREE_WAY_CALL
        ) {
            val createdList: MutableList<LiteFseProspectResponseModel.InstallationPictures> =
                mutableListOf()
            if (fseProspectResponseModel.installationPictures.isNullOrEmpty()) {
                fseProspectResponseModel.sampleImages!!.forEach {
                    createdList.add(
                        LiteFseProspectResponseModel.InstallationPictures(
                            name = it.name,
                            sampleimage = it.url,
                            phoneUrl = "",
                            isRejected = false,
                            isNewImage = false,
                            attempt = 0,
                            url = ""
                        )
                    )
                }
                fseProspectResponseModel.installationPictures = createdList
            }
//        runOnUiThread {
            // Here, use glide or do your things on UiThread
            loadImageForOffline(fseProspectResponseModel.installationPictures!!)
            alphaMethodInstallation(fseProspectResponseModel)
        } else {

            fseProspectResponseModel.statusUpdateObjects.let {
                setAdapter(fseProspectResponseModel, it!!.toMutableList())
            }
            adapter!!.notifyDataSetChanged()
        }

    }

    fun setAdapter(
        fse: LiteFseProspectResponseModel,
        mutableList: MutableList<LiteFseProspectResponseModel.StatusUpdateObjects>
    ) {

        Log.e(TAG, "fse == ${fse.status}")
        if (!fse.isInstallationChanged) {
            mutableList.forEach { data ->
                if (data.status!!.equals(fse.status, true)) {
                    data.customApproved = fse.approved
                    Log.e(TAG, "data.status == ${data.status} ===== $data.customApproved")
                } else {
                    data.customApproved = true
                }
            }
        }
        val filterList = mutableList.filter { it.visibility!! }
        Log.e(TAG, "filterList == $filterList")

        val sortedList = sortListHandler(fse, mutableList, filterList)
        Log.e(TAG, "sortedList == $sortedList")
        adapterList.clear()
        adapterList.addAll(sortedList)

        if (adapter == null) {
            adapter = ProspectProgressAdapter(this, adapterList, fseProspectResponseModel!!)
            adapter?.prospectProgressAdapterCallbackCallback = this
            binding.progressRecyclerView.adapter = adapter
        }
        adapter?.notifyDataSetChanged()

    }

    private fun sortListHandler(
        fse: LiteFseProspectResponseModel,
        mainList: List<LiteFseProspectResponseModel.StatusUpdateObjects>,
        sortedList: List<LiteFseProspectResponseModel.StatusUpdateObjects>
    )
            : List<LiteFseProspectResponseModel.StatusUpdateObjects> {
        var revisedStatus: List<LiteFseProspectResponseModel.StatusUpdateObjects> = listOf()

        when (fse.status) {
            ProspectStatus.INSTALLATION_PENDING -> {
                mainList.forEach { m ->
                    sortedList.map { s ->
                        if (m.status == ProspectStatus.INSTALLATION_PENDING && s.status == ProspectStatus.INSTALLATION_PENDING) {
                            s.statusTime = ""
                            s.customApproved = fse.approved
                        }
                    }
                }
            }
            ProspectStatus.INSTALLED -> {
                mainList.forEach { m ->
                    sortedList.map { s ->
                        if (m.status == ProspectStatus.INSTALLED && s.status == ProspectStatus.INSTALLATION_VERIFIED) {
//                            s.statusTime = m.statusTime
                            s.customApproved = fse.approved
                        }
                    }
                }
                mainList.forEach { m ->
                    sortedList.map { s ->
                        if (m.status == ProspectStatus.INSTALLED && s.status == ProspectStatus.INSTALLATION_PENDING) {
                            s.statusTime = m.statusTime
                            s.customApproved = fse.approved
                        }
                    }
                }

            }
            ProspectStatus.INSTALLATION_VERIFIED -> {
                mainList.forEach { m ->
                    sortedList.map { s ->
                        if (m.status == ProspectStatus.INSTALLATION_VERIFIED && s.status == ProspectStatus.INSTALLATION_VERIFIED) {
                            s.statusTime = m.statusTime
                            s.customApproved = fse.approved
                        }
                    }
                }
            }
            ProspectStatus.INSTALLATION_REATTEMPT -> {
                mainList.forEach { m ->
                    sortedList.map { s ->
                        if (m.status == ProspectStatus.INSTALLATION_REATTEMPT && s.status == ProspectStatus.INSTALLATION_VERIFIED) {
                            s.statusTime = m.statusTime
                            s.customApproved = fse.approved
                        }
                    }
                }
            }
            else -> {
//                sortedList.forEach { s ->
//                    s.customApproved = fse.approved
//                }
            }
        }
        revisedStatus = sortedList
        return revisedStatus
    }


    override fun onErrorClick(position: Int, value: LiteFseProspectResponseModel) {
        errorMessage(fseProspectResponseModel!!)
    }

    private fun errorMessage(fseProspectResponseModel: LiteFseProspectResponseModel) {
        if (fseProspectResponseModel.status == ProspectStatus.INSTALLATION_REATTEMPT) {
            Util.customDialog(
                context = this,
                message = fseProspectResponseModel.message,
                positiveText = "Proceed",
                negetiveText = "Cancel",
                poitiveSelected = {
                    //add logic
                    updateFseProspect(fseProspectResponseModel, 1)
                    it.dismiss()
                },
                negetiveSelected = {
                    it.dismiss()
                }
            )
        } else {
            Util.customFseCompletionDialog(
                context = this,
                hideTitle = true,
                title = null,
                message = fseProspectResponseModel.message,
                okSelected = {
                    it.dismiss()
                }
            )
        }
    }

    private fun updateFseProspect(
        fseProspectResponseModel: LiteFseProspectResponseModel,
        reattemptedStage: Int
    ) {
        when (reattemptedStage) {
            1 -> {
                fseProspectResponseModel.reattemptedStage = 1
                fseProspectResponseModel.statusUpdateTime?.installed = ""
                fseProspectResponseModel.statusUpdateTime?.installationVerified = ""
                fseProspectResponseModel.statusUpdateObjects!!.forEach {
                    if (it.status == ProspectStatus.INSTALLATION_VERIFIED
                        || it.status == ProspectStatus.INSTALLED
                        || it.status == ProspectStatus.INSTALLATION_REATTEMPT
                    ) {
                        it.statusTime = ""
                        it.customApproved = true
                    }
                }
                fseProspectResponseModel.status = ProspectStatus.INSTALLATION_PENDING
                fseProspectResponseModel.approved = true
                fseProspectResponseModel.isInstallationChanged = true

                this.fseProspectResponseModel = fseProspectResponseModel
            }
        }
        viewModel.updateFseProspect(fseProspectResponseModel).observe(this, Observer {
            initialize(it)
            binding.tvStep1.visibility = View.VISIBLE
//            imageView.setImageResource(0)
//            mainCarouselLayout.visibility = View.GONE
            binding.ivLeft.visibility = View.GONE
            binding.ivRight.visibility = View.GONE
            binding.carouselView.visibility = View.GONE
        })
    }


    //region carousel
    private fun setCarousel(imagesCList: List<String>, productName: List<String>) {
        circularProgressDrawable?.strokeWidth = 5f
        circularProgressDrawable?.centerRadius = 30f
        circularProgressDrawable?.start()
        var currentItem = 0
        var pos = 0
        try {

            if (imagesCList.isNotEmpty()) {
                if (imagesCList.size > 1) {
                    binding.ivRight.visibility = View.VISIBLE
                    binding.ivLeft.visibility = View.VISIBLE
                } else {
                    binding.ivRight.visibility = View.GONE
                    binding.ivLeft.visibility = View.GONE
                }
            } else {
                binding.ivRight.visibility = View.GONE
                binding.ivLeft.visibility = View.GONE
            }

            if (!imagesCList.isNullOrEmpty()) {
                binding.carouselView?.apply {

                    Log.d(TAG, "setCarousel: imagesCList : $imagesCList")
                    size = imagesCList.size
                    resource = R.layout.carousel_item
                    autoPlay = true
                    indicatorAnimationType = IndicatorAnimationType.THIN_WORM
                    carouselOffset = OffsetType.CENTER

                    carouselViewListener = null
                    setCarouselViewListener { view, position ->
                        // Example here is setting up a full image carousel
                        val imView = view.findViewById<ImageView>(R.id.imageCView)
                        val tvProductName = view.findViewById<TextView>(R.id.tvProductName)
                        tvProductName.text = productName.get(position).replace("_", " ")
                            .capitalize()/*?.toLowerCase()*/
                        Glide.with(context)
                            .load(imagesCList.get(position))
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .apply(
                                RequestOptions()
                                    .centerCrop()
                                    .placeholder(circularProgressDrawable)
                                    .error(R.mipmap.ic_launcher_round)
                            ).into(imView)

                        imView.setOnClickListener {
                            ImageUploadUtil.ImageEnlargeDialog(
                                this@NewProspectDetailActivity,
                                imagesCList.get(position)
                            )
                        }

                    }
                    currentItem = this.currentItem

                    setCarouselScrollListener(object : CarouselScrollListener {
                        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                        }

                        override fun onScrollStateChanged(
                            recyclerView: RecyclerView,
                            newState: Int,
                            position: Int
                        ) {
                            pos = position
//                            Log.e(TAG, "Position === $position ==currentItem==${currentItem}")
                        }
                    })
                    // After you finish setting up, show the CarouselView
                    if (!binding.carouselView.isShown) {
                        show()
                    }
                }
                binding.ivLeft.setOnClickListener {
                    binding.carouselView.currentItem =
                        changeLeftCarouselView(imagesCList, pos, currentItem)
                }

                binding.ivRight.setOnClickListener {
                    binding.carouselView.currentItem =
                        changeRightCarouselView(imagesCList, pos, currentItem)
                }
                binding.carouselView.visibility = View.VISIBLE
            } else {
                binding.carouselView.visibility = View.GONE
            }

        } catch (e: Exception) {
            e.printStackTrace()
            Log.d(TAG, "RAJIV - 1: ${e.localizedMessage}")
        }
    }

    fun changeRightCarouselView(imagesList: List<String>, position: Int, currentItem: Int): Int {
        return if (position != imagesList.size && position != currentItem) {
            position + 1
        } else {
            position + 1
        }
    }

    fun changeLeftCarouselView(imagesList: List<String>, position: Int, currentItem: Int): Int {
        return if (position != imagesList.size && position != currentItem) {
            position - 1
        } else {
            position - 1
        }
    }
    //endregion

    private fun alphaMethodInstallation(fseProspectResponseModel: LiteFseProspectResponseModel) {
        viewModel.getCombineRequestModelInstallation(fseProspectResponseModel.prospectId)
            .observe(this, Observer {
                Log.d(TAG, "combineRequest:$it ")
                it?.fseProspectResponseModel?.let {
                    this.fseProspectResponseModel = it
//                setUI(it)
                    setAdapter(it, it.statusUpdateObjects!!.toMutableList())
                } ?: run {
                    setAdapter(
                        fseProspectResponseModel,
                        fseProspectResponseModel.statusUpdateObjects!!.toMutableList()
                    )
                }
                if (it?.installationRequestModels == null) {
                    //do your logic
                    //change to green
                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                    binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                    fseProspectResponseModel.statusUpdateObjects!!.forEach {
                        if (it.status == ProspectStatus.INSTALLED) {
                            if (!it.statusTime.isNullOrEmpty()) {
                                Log.d(TAG, "Tempo:1 ")
                                handleButtonVisibility(this.fseProspectResponseModel)
                            }
                        }
                    }
                    if (fseProspectResponseModel.status == ProspectStatus.INSTALLATION_PENDING) {
//                        if (!it.statusTime.isNullOrEmpty()) {
                        Log.d(TAG, "Tempo:2 ")
                        binding.tvStep1.visibility = View.VISIBLE
//                        }
                    }
                } else {
                    installationRequestModel = it.installationRequestModels!!
                    Log.d(
                        TAG,
                        "Tempo:2 : fseProspectResponseModel.reattemptedStag = ${fseProspectResponseModel.reattemptedStage}"
                    )
                    if (this.fseProspectResponseModel!!.reattemptedStage != 1) {
                        /*Check Here */
                        handleButtonVisibility(this.fseProspectResponseModel)
                    }
                    if (this.fseProspectResponseModel!!.isChanged) {
                        //change to green to red
                        val backgroundDrawable =
                            ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                        DrawableCompat.setTint(backgroundDrawable!!, Color.RED)
                        binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                    } else {
                        val backgroundDrawable =
                            ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                        DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                        binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                    }
                }
//            it?.fseError?.let {
//                if (this.fseProspectResponseModel!!.errorOccurred && (it.errorType == FseProspectiveConstant.ProspectiveType.INSTALLATION)) {
//                    llError.visibility = View.VISIBLE
//                    tvErrorMessage.text = it.messageToUser
//                }
//            }
            })
    }

    private fun handleButtonVisibility(fseProspectResponseModel: LiteFseProspectResponseModel?) {
        Log.d(
            TAG,
            "handleButtonVisibility: fseProspectResponseModel!!.installationPictures => ${fseProspectResponseModel!!.installationPictures}"
        )
        try {
            binding.tvStep1.visibility = View.GONE
            imageList.clear()
            productNameList.clear()
            fseProspectResponseModel!!.installationPictures!!.forEach {
                if (it.phoneUrl.isNullOrEmpty()) {
                    imageList.add(it.url!!)
                } else {
                    imageList.add(it.phoneUrl!!)
                }
                productNameList.add(it.name ?: "NA")

            }
            Log.d(TAG, "handleButtonVisibility: imageList : $imageList")
            setCarousel(imageList, productNameList)
            binding.carouselView.visibility = View.VISIBLE
        } catch (e: Exception) {
            e.printStackTrace()
            Log.d(TAG, "RAJIV - 2: ${e.localizedMessage}")
        }

    }

    private fun loadImageForOffline(installPics: List<LiteFseProspectResponseModel.InstallationPictures>) {
        if (Util.isOnline(this)) {
            for (ins in installPics) {
                if (!ins.sampleimage.isNullOrBlank()) {
                    GlobalScope.launch { // launch a new coroutine in background and continue
                        try {
                            Glide.with(this@NewProspectDetailActivity)
                                .downloadOnly()
                                .diskCacheStrategy(DiskCacheStrategy.DATA) // Cache resource before it's decoded
                                .load(ins.sampleimage)
                                .submit(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL)
                                .get() // Called on background thread
                        } catch (e: Exception) {
                            Log.d(TAG, "RAJIV - 3: ${e.localizedMessage}")
                            e.printStackTrace()
                        }
                    }

                    Log.e(TAG, "====done====${ins.sampleimage}")
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Constants.CLICK_REQUEST_CODE) {
            var bundle = Bundle()
            bundle = data!!.extras!!
            fseProspectResponseModel = bundle.getParcelable("fseProspectResponseModel")!!
            Log.e(TAG, "onActivityResult = = ===${fseProspectResponseModel!!.statusUpdateTime}")
            if (Util.isOnline(this)) {
                refreshInstallation()
            } else {
                alphaMethodInstallation(fseProspectResponseModel!!)
            }
        }

//        if (resultCode == 1100) {
//            var bundle = Bundle()
//            bundle = data!!.extras!!
//            fseProspectResponseModel = bundle.getParcelable("fseProspectResponseModel")!!
//            initialize(fseProspectResponseModel!!)
//        }


    }

    private fun refreshInstallation() {
        viewModel.getFseProspectiveFromServerInstallation(
            loginResponseData!!.angazaId!!,
            fseProspectResponseModel!!.prospectId,
            showProgress = {
                showProgressDialog(this)
            })?.observe(this, Observer {
            if (it != null) {
                if ((it.success) && (it.responseData != null)) {
                    adapterList.clear()
                    setUI(it.responseData!!)
                    binding.tvLastSavedDetails.text =
                        "${getString(R.string.last_saved_key)} ${preference?.getFseProspectLastSynced()}"
                } else {
                    alphaMethodInstallation(fseProspectResponseModel!!)
//                    updateSharedPref(false)

                }
            } else {
                alphaMethodInstallation(fseProspectResponseModel!!)
//                updateSharedPref(false)

            }
            cancelProgressDialog()
        })
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item?.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private fun generalClickHandler(
        type: String?,
        fseProspectResponseModel: LiteFseProspectResponseModel
    ) {
        binding.ivSync.setOnClickListener {
//            callProspectCallApi()

            Log.e("ghghghghghg", " yesss")
            // mis-clicking prevention, using threshold of 1000 ms
            /*    if (SystemClock.elapsedRealtime() - mLastClickTime < 10000){
                    return@setOnClickListener;
                }
                mLastClickTime = SystemClock.elapsedRealtime();*/

            refreshCall(fseProspectResponseModel!!)
            when (type) {
                FseProspectiveConstant.ProspectiveType.INSTALLATION -> {
                    installationSync()
                }
                else -> {
//                    Util.customFseCompletionDialog(
//                            context = this,
//                            hideTitle = true,
//                            title = null,
//                            message = "You have nothing to sync.",
//                            okSelected = {
//                                it.dismiss()
//                            }
//                    )
                    refreshInstallation()
                }
            }
        }

        binding.btnMap.setOnClickListener {
            val intent = Intent(this, MapsCheckActivity::class.java)
            intent.putExtra("LAT", fseProspectResponseModel.latitude)
            intent.putExtra("LONG", fseProspectResponseModel.longitude)
            intent.putExtra("NAME", fseProspectResponseModel.name)
            startActivity(intent)
        }

        binding.ivCallDetails.setOnClickListener {
            if (!prospectCallList.isNullOrEmpty()) {
                Log.e(TAG, "if ===== prospectCallList ==== $prospectCallList")
                customDialogProspectDetails(this, prospectCallList)
            } else {
                showProgressDialog(this)
                /*viewModel.getProspectCallDetails(this, fseProspectResponseModel!!.prospectId)
                        .observe(this, Observer {
                            cancelProgressDialog()
                            if (it.success) {
                                Log.e(TAG, "==${it.success}=== prospectCallList ==== $prospectCallList")

                                if (!it.responseData!!.prospectCallDetails.isNullOrEmpty()) {
                                    prospectCallList.clear()
                                    prospectCallList.addAll(it.responseData!!.prospectCallDetails)
                                    Log.e(TAG, "==call dialog=== it.responseData!!.prospectCallDetails ==== $it.responseData!!.prospectCallDetails")
                                    customDialogProspectDetails(this, it.responseData!!.prospectCallDetails)
                                } else {
                                    Log.e(TAG, "=::else::=${it.success}=== prospectCallList ==== $prospectCallList")
                                    Util.customFseCompletionDialog(
                                            context = this,
                                            hideTitle = true,
                                            title = null,
                                            message = "No data available",
                                            okSelected = {
                                                it.dismiss()
                                            }
                                    )
                                }
                            } else {
                                Log.e(TAG, "else =:::1111111=${it.success}=== prospectCallList ==== $prospectCallList")
                                Util.customFseCompletionDialog(
                                        context = this,
                                        hideTitle = true,
                                        title = null,
                                        message = "No data available",
                                        okSelected = {
                                            it.dismiss()
                                        }
                                )
                            }
                        })*/
                val Observer =
                    Observer<NewCommonResponseModel<ProspectCallDetailsModel>> { result ->
                        Log.d(TAG, "refreshObserver:$result ");
                        result?.let {
                            cancelProgressDialog()

                            if (it.success) {
                                Log.e(
                                    TAG,
                                    "==${it.success}=== prospectCallList ==== $prospectCallList"
                                )

                                if (!it.responseData!!.prospectCallDetails.isNullOrEmpty()) {
                                    prospectCallList.clear()
                                    prospectCallList.addAll(it.responseData!!.prospectCallDetails)
                                    Log.e(
                                        TAG,
                                        "==call dialog=== it.responseData!!.prospectCallDetails ==== $it.responseData!!.prospectCallDetails"
                                    )
                                    customDialogProspectDetails(
                                        this,
                                        it.responseData!!.prospectCallDetails
                                    )
                                } else {
                                    Log.e(
                                        TAG,
                                        "=::else::=${it.success}=== prospectCallList ==== $prospectCallList"
                                    )
                                    Util.customFseCompletionDialog(
                                        context = this,
                                        hideTitle = true,
                                        title = null,
                                        message = "No data available",
                                        okSelected = {
                                            it.dismiss()
                                        }
                                    )
                                }
                            } else {
                                Log.e(
                                    TAG,
                                    "else =:::1111111=${it.success}=== prospectCallList ==== $prospectCallList"
                                )
                                Util.customFseCompletionDialog(
                                    context = this,
                                    hideTitle = true,
                                    title = null,
                                    message = "No data available",
                                    okSelected = {
                                        it.dismiss()
                                    }
                                )
                            }
                        }
                    }
                getCall(fseProspectResponseModel, Observer)
            }

        }
    }

    private fun installationSync() {
        if (Util.isOnline(this)) {
            if ((installationRequestModel != null) && fseProspectResponseModel!!.isChanged) {
                //you have data to sync
                viewModel.getAllAwsImageModelByProspectId(fseProspectResponseModel!!.prospectId)
                    .observe(this, Observer { awsModels ->

                        Log.e(TAG, "abc2: $awsModels")
                        val validToUpload = awsModels?.filter {
                            !it.uploadedToAws &&
                                    !it.uploadedToGLPServer &&
                                    !it.fileUri.isNullOrEmpty()
                        }
                        if (!validToUpload.isNullOrEmpty()) {
                            showProgressDialog(this)
                            awsImageUploadHandler(validToUpload, true)
                        } else {
                            viewModel.sendInstallationRequestToServerForce(
                                installationRequestModel!!,
                                validToUpload!!,
                                showProgress = {
                                    showProgressDialog(this)
                                }).observe(this, Observer {
//                                    cancelProgressDialog()
                                refreshInstallation()
                            })
                        }
                    })
            } else {
                refreshInstallation()
            }
        } else {
            //Util.showToast("No Internet", this)
            Util.customFseRationaleDialog(this, "",
                hideNegative = true,
                titleSpanned = null,
                hideTitle = true,
                message = "Please check internet connection",
                positveSelected = {
                    it.dismiss()
                },
                negativeSeleted = {
                    it.dismiss()
                }
            )
        }
    }

    private fun awsImageUploadHandler(fileModels: List<LiteAwsImageModel>, isForService: Boolean) {
        if (preference?.getAwsAccess().isNullOrEmpty() || preference?.getAwsSecret()
                .isNullOrEmpty()
        ) {
            viewModel.awsRX(this, BaseRequestModel().apply {
                this.angazaId = loginResponseData?.angazaId
                this.country = loginResponseData?.country
            }).observe(this, Observer {


                if (it == null || it.Success == false || it.ResponseData?.accessKey.isNullOrEmpty() || it.ResponseData?.secretKey.isNullOrEmpty()) {
                    Util.customFseCompletionDialog(
                        context = this,
                        hideTitle = true,
                        title = null,
                        message = "Unable to upload images please try again later",
                        okSelected = {
                            it.dismiss()
                        }
                    )
                } else {
                    preference?.setAwsAccess(it.ResponseData?.accessKey!!)
                    preference?.setAwsSecret(it.ResponseData?.secretKey!!)
                    amazonS3Helper?.startUploadProcess(fileModels, isForService)
                }
            })
        } else {
            amazonS3Helper?.startUploadProcess(fileModels, isForService)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        amazonS3Helper?.amazonS3HelperCallback = null
        amazonS3Helper = null
        bag.clear()
        mHomeWatcher?.stopWatch()
    }

    override fun onAllUploadCompleted(fileModelsList: List<LiteAwsImageModel>) {
        cancelProgressDialog()
        //send Data to server
        fileModelsList.forEach { it.tried = false }
        Log.d(TAG, "onAllUploadCompleted:fileModelsList2 = $fileModelsList ")
        val isOnline = Util.isOnline(this)
        //
        fseProspectResponseModel!!.installationPictures!!.map { data ->
            fileModelsList.find { it.imageName == data.name }?.let {
                data.url = it.awsLink
            }
        }
        //
        viewModel.insertAwsImageModelToDatabase(fileModelsList, true).observe(this, Observer {

            Log.d(
                TAG,
                "fseProspectResponseModel!!.installationAttempted:${fseProspectResponseModel!!.installationAttempted} "
            )
            viewModel.performInstallation2(
                context = this,
                isOnline = isOnline,
                fseProspectResponseModel = fseProspectResponseModel,
                prospectId = fseProspectResponseModel!!.prospectId,
                fileModel = fileModelsList,
                //location = currentLocation!!,
                showProgress = {
                    if (!isProgressShowing()) {
                        showProgressDialog(this)
                    }
                }
            ).observe(this, Observer {
                alphaMethodInstallation(fseProspectResponseModel!!)
                cancelProgressDialog()
                Log.d(TAG, ":step2$it")

                if (Util.isOnline(this)) {
                    refreshInstallation()
                }
            })

        })

    }

    private fun customDialogProspectDetails(
        context: Activity,
        callDetails: List<ProspectCallDetail>
    ): Dialog {

        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_prospect_call_details)
        var width = 0
        var height = 0

        dialog.setCancelable(true)
        val size = Point()
        val w = context.windowManager
        w.defaultDisplay.getSize(size)
        width = size.x - 40
        height = size.y
        dialog.setCancelable(true)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT)
        val recyclerIn = dialog.findViewById<RecyclerView>(R.id.recyclerIn)
        val btnClose = dialog.findViewById<ImageButton>(R.id.btnClose)

        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        var adapter: ProspectCallDetailsDialogAdapter? = null
        val layoutManager = LinearLayoutManager(context)
        recyclerIn.layoutManager = layoutManager
        val sortedList = callDetails.sortedByDescending { it.callingTimeLong }
        adapter = ProspectCallDetailsDialogAdapter(context, sortedList)
        recyclerIn.adapter = adapter

        dialog?.show()

        return dialog
    }


}