package com.greenlightplanet.kazi.fse.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.greenlightplanet.kazi.fse.model.FseHistory
import com.greenlightplanet.kazi.fse.model.FseHistoryResponse
import com.greenlightplanet.kazi.fse.repo.PastFseCommitmentRepo
import java.text.DateFormat
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*


class PastFseCommitmentViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "PastFseCommitmentViewMo"

    }

    val repo = PastFseCommitmentRepo.getInstance(application)

    //old
    /*
    fun getFseHistroyCommitment(context: Context, fromDate: String, toDate: String, angazaId: String, showProgress: () -> Unit = {}): MutableLiveData<List<FseHistory>?> {

        //progress?.showProgressDialog()
        showProgress()

        if (com.greenlightplanet.kazi.utils.Util.isOnline(context)) {
            //if (com.greenlightplanet.kazi.utils.Util.isInternetAvailable() && com.greenlightplanet.kazi.utils.Util.isOnline(context)) {
            return repo.getFseByDateFromServer(angazaId, fromDate, toDate)
        } else {
            return repo.getFseByDateFromDatabase(fromDate, toDate)
        }

    }*/


    fun getNewFseHistroyCommitment(context: Context, fromDate: String, toDate: String, angazaId: String, forceOffline: Boolean = false, showProgress: () -> Unit = {}): MutableLiveData<FseHistoryResponse.ResponseData> {

        //progress?.showProgressDialog()
        showProgress()

        if (forceOffline) {
            return repo.getNewFseByDateFromDatabase(fromDate, toDate)
        } else if (com.greenlightplanet.kazi.utils.Util.isOnline(context)) {
            //if (com.greenlightplanet.kazi.utils.Util.isInternetAvailable() && com.greenlightplanet.kazi.utils.Util.isOnline(context)) {
            return repo.getNewFseByDateFromServer(angazaId, fromDate, toDate)
        } else {
            return repo.getNewFseByDateFromDatabase(fromDate, toDate)
        }

    }


    //working
    /*fun getFseByDate(progress: CustomProgress?, fromDate: Long, toDate: Long): MutableLiveData<List<FseHistory>?> {

        progress?.showProgressDialog()

        return repo.getFseByDate(fromDate, toDate)

    }*/

    fun searchLogic(searchKeyword: String, adapterList: MutableList<FseHistory>): List<FseHistory> {

        return adapterList?.filter {
            val name = "${it?.customerName}"
            name.contains(
                    searchKeyword,
                    true
            )
        }!!
    }


    fun convertListToMap(adapterData: MutableMap<PastHeaderHistory, List<FseHistory>>, list: MutableList<FseHistory>): MutableMap<PastHeaderHistory, List<FseHistory>> {

        adapterData.clear()

        val listOfdistincDate = list.distinctBy { it.paymentDate }.map { it.paymentDateFormatted }

        sortByDate(listOfdistincDate)

        for (date in listOfdistincDate) {
            val listOfSameDate = list.filter { it.paymentDateFormatted == date }

            //todo remove in production
            Log.d(TAG, ":date = $date || listOfSameDate = $listOfSameDate ");

            val enableCount = listOfSameDate.filter { it.isPaid }.size


            adapterData.put(PastHeaderHistory(date!!, enableCount, listOfSameDate.size), listOfSameDate)
        }

        return adapterData
    }


    fun convertListToMapForSearch(adapterData: MutableMap<PastHeaderHistory, List<FseHistory>>, queryList: MutableList<FseHistory>, accutalList: MutableList<FseHistory>): MutableMap<PastHeaderHistory, List<FseHistory>> {

        adapterData.clear()

        val listOfdistincDate = queryList.distinctBy { it.paymentDate }.map { it.paymentDateFormatted }

        sortByDate(listOfdistincDate)

        for (date in listOfdistincDate) {
            val listOfSameDate = queryList.filter { it.paymentDateFormatted == date }

            val anotherListOfSameDate = accutalList.filter { it.paymentDateFormatted == date }

            //todo remove in production
            Log.d(TAG, ":date = $date || listOfSameDate = $listOfSameDate ");

            val enableCount = anotherListOfSameDate.filter { it.isPaid }.size
            //val enableCount = listOfSameDate.filter { it.isPaid }.size


            /*
            val listOfSameDate = queryList.filter { it.paymentDateFormatted == date }

            //todo remove in production
            Log.d(TAG, ":date = $date || listOfSameDate = $listOfSameDate ");

            val enableCount = accutalList.filter{ it.paymentDateFormatted == date }.filter { it.isPaid }.size
            //val enableCount = listOfSameDate.filter { it.isPaid }.size
*/

            adapterData.put(PastHeaderHistory(date!!, enableCount, anotherListOfSameDate.size), listOfSameDate)
        }

        return adapterData
    }


    fun getReverseOfMutableMap(mutableMap: MutableMap<PastHeaderHistory, List<FseHistory>>): SortedMap<PastHeaderHistory, List<FseHistory>> {

        //todo remove in production used for logging
        for ((key, value) in mutableMap) {

            Log.d(TAG, "mutableMap: key  = $key   || value = $value");

        }

        val reverse = mutableMap.toSortedMap(reverseOrder())

        //todo remove in production used for logging
        for ((key, value) in reverse) {

            Log.d(TAG, "reverse: key  = $key   || value = $value");

        }

        return reverse

    }


    data class PastHeaderHistory(
            var date: String, // 1996-09-21
            private var _completed: Int = 0,
            private var _total: Int = 0

    ) : Comparable<PastHeaderHistory> {


        val value: String
            get() {
                return "$_completed/$_total"
            }

        override fun compareTo(other: PastHeaderHistory): Int {
            return if (this.date == other.date && this.value == other.value) 0
            else -1

        }

    }

    fun sortByDate(list: List<String?>) {

        Log.d(TAG, "UNSORTED : $list ");

        Collections.sort(list, object : Comparator<String?> {
            internal var f: DateFormat = SimpleDateFormat("yyyy-MM-dd")
            override fun compare(o1: String?, o2: String?): Int {
                try {
                    return f.parse(o1).compareTo(f.parse(o2))
                } catch (e: ParseException) {
                    throw IllegalArgumentException(e)
                }

            }
        })

        Log.d(TAG, "SORTED : $list ");

    }


    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }

}
