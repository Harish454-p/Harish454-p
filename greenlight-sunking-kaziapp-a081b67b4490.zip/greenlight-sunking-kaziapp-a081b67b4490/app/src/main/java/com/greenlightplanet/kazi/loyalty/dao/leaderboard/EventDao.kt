package com.greenlightplanet.kazi.loyalty.dao.leaderboard

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.incentive.model.StarClubResponseModel
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryResponseData
import com.greenlightplanet.kazi.loyalty.model.achievements.Achieved
import com.greenlightplanet.kazi.loyalty.model.leaderboard.events.AllEvents
import com.greenlightplanet.kazi.loyalty.model.passbook.Entries
import com.greenlightplanet.kazi.loyalty.model.passbook.PassbookResponse
import com.greenlightplanet.kazi.loyalty.model.profile.ProfileResponse
import com.greenlightplanet.kazi.task.model.dialogIntent.FeedbackModel
import com.greenlightplanet.kazi.task.model.dialogIntent.NotAnsweredModel
import com.greenlightplanet.kazi.task.model.response.CallDetail
import com.greenlightplanet.kazi.task.model.response.TaskMddel
import com.greenlightplanet.kazi.task.model.response.firstCall

import io.reactivex.Single

@Dao
interface EventDao {

    @Query("SELECT * FROM EventList")
      fun getAllEvents(): Single<List<AllEvents>>

/*    @Query("SELECT * FROM Entries WHERE page=:page ")
    fun getAllEntriesResponseById(page:Int): Single<List<Entries>>*/



    @Insert(onConflict = OnConflictStrategy.REPLACE)
      fun insertAll(achieved: List<AllEvents>?)

    @Query("DELETE FROM EventList")
    fun deleteAll(): Int

    @Query("SELECT count(*) FROM EventList")
    fun getEventCount(): Single<Int>



}
