package com.greenlightplanet.kazi.collectiongoal.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.Keep
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistory
import com.greenlightplanet.kazi.databinding.NewCallHistoryDetailsBinding
import com.greenlightplanet.kazi.utils.Util

@Keep
class PaymentHistoryAdapterRecycler constructor(private val context: Context,
                                                private var values: List<PaymentHistory>) :

    RecyclerView.Adapter<PaymentHistoryAdapterRecycler.ViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): PaymentHistoryAdapterRecycler.ViewHolder {

        val itemBinding = NewCallHistoryDetailsBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(itemBinding)

    }

    override fun onBindViewHolder(holder: PaymentHistoryAdapterRecycler.ViewHolder, position: Int) {
        val task = values[position]
        holder.bind(task, holder.itemView)
    }

    @SuppressLint("LongLogTag")
    override fun getItemCount(): Int {
        Log.d("PaymentHistoryRecyclerAdapterListSize",values.size.toString())
        return values.size
    }

    inner class ViewHolder(val itemBinding: NewCallHistoryDetailsBinding)
        : RecyclerView.ViewHolder(itemBinding.root) {

        @SuppressLint("SetTextI18n")
        fun bind(task: PaymentHistory, itemView: View) {

            if (task.paymentDate.isNullOrBlank()) {
                itemBinding.tvCallDate.text = "NA"
            }
            else {
                itemBinding.tvCallDate.text = Util.convertUTCtoLocatTimeYYYYYMMDD(task.paymentDate)
            }

            itemBinding.tvCallDuration.text = task.amount.toString()
                .let{Util.checkBlank(it, context = context) }

            itemBinding.IvOption.visibility = View.GONE
        }
    }

}