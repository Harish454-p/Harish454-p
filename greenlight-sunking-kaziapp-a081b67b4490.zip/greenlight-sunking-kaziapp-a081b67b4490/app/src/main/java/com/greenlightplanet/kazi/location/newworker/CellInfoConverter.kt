package com.greenlightplanet.kazi.location.newworker

import android.telephony.CellInfo
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class CellInfoConverter {
	@TypeConverter
	fun fromCellInfoToString(cellInfo: CellInfo?): String? {
		if (cellInfo == null) {
			return null
		}
		val gson = Gson()
		val type = object : TypeToken<CellInfo>() {}.type
		return gson.toJson(cellInfo, type)
	}

	@TypeConverter
	fun fromStringToCellInfo(string: String?): CellInfo? {
		if (string == null) {
			return null
		}
		val gson = Gson()
		val type = object : TypeToken<CellInfo>() {
		}.type
		return gson.fromJson(string, type)
	}
}
