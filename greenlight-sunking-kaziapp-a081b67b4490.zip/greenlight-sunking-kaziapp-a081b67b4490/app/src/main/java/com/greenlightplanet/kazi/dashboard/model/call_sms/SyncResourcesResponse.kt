package com.greenlightplanet.kazi.dashboard.model.call_sms


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


@Parcelize
data class SyncResourcesResponse(
		@SerializedName("contacts")
		var contacts: List<ContactRequest>? // 1
) : Parcelable
