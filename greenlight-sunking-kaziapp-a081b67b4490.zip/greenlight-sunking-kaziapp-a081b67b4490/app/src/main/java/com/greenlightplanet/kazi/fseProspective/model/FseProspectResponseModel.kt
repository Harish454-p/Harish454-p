package com.greenlightplanet.kazi.fseProspective.model

import androidx.room.*
import android.os.Parcelable
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.utils.Util
import kotlinx.android.parcel.Parcelize


@Parcelize
//@Entity(tableName = "%s")
data class FseProspectResponseData(
    @ColumnInfo(name = "prospects")
    @SerializedName("prospects")
    var prospects: List<FseProspectResponseModel>?,

    @ColumnInfo(name = "allowedDistance")
    @SerializedName("allowedDistance")
    var allowedDistance: Int = 0 // PP000001


) : Parcelable

@Parcelize
@Entity(tableName = "FseProspectResponseModel")
data class FseProspectResponseModel(

    //new added
    @ColumnInfo(name = "prospectAllowedDistance")
    @SerializedName("prospectAllowedDistance")
    var prospectAllowedDistance: Int = 0, // PP000001

    ////
    @ColumnInfo(name = "approved")//todo check
    @SerializedName("approved")//todo check
    var approved: Boolean, // true//todo check

    @ColumnInfo(name = "message")
    @SerializedName("message")
    var message: String, // PP000001

    @ColumnInfo(name = "prospectUpdatedAt")
    @SerializedName("prospectUpdatedAt")
    var prospectUpdatedAt: String?, // 2019-12-24 16:56:25

    @ColumnInfo(name = "installationPicture")
    @SerializedName("installationPicture")
    var installationPicture: String, // https://s3.eu-west-2.amazonaws.com/kazi-userfiles-mobilehub-391300116/fse_prospective/Kazi_15652687652245845347389375337762.jpg

    @TypeConverters(InstallationPicturesConverter::class)
    @ColumnInfo(name = "installationPictures")
    @SerializedName("installationPictures")
    var installationPictures: List<InstallationPictures>?,

    @ColumnInfo(name = "accountNumber")
    @SerializedName("accountNumber")
    var accountNumber: String, // 20980801

    @ColumnInfo(name = "customerPhoneNumber")
    @SerializedName("customerPhoneNumber")
    var customerPhoneNumber: String, // +2348036632039

    @ColumnInfo(name = "area")
    @SerializedName("area")
    var area: String, // area

    @ColumnInfo(name = "unsuccessfulOtpAttempts")
    @SerializedName("unsuccessfulOtpAttempts")
    var unsuccessfulOtpAttempts: Int = 0, // 3


    @ColumnInfo(name = "reattemptedStage")
    @SerializedName("reattemptedStage")
    var reattemptedStage: Int = 0, // 0,1,2,3

    @ColumnInfo(name = "installationAttempted")
    @SerializedName("attempt")
    var installationAttempted: Int = 0, // 3

    @TypeConverters(SampleImagesConverter::class)
    @ColumnInfo(name = "sampleImages")
    @SerializedName("sampleImages")
    var sampleImages: List<FseProspectResponseModel.SampleImages>?,
    @ColumnInfo(name = "isChanged")
    @SerializedName("isChanged")
    var isChanged: Boolean = false, // false

    @ColumnInfo(name = "errorOccurred")
    var errorOccurred: Boolean = false, // false

    @PrimaryKey
    @ColumnInfo(name = "prospectId")
    @SerializedName("prospectId")
    var prospectId: String, // PP000001
    @ColumnInfo(name = "customerAddress")
    @SerializedName("customerAddress")
    var customerAddress: String? = "", // Addres1
    @ColumnInfo(name = "name")
    @SerializedName("name")
    var name: String?, // Richard 4
    @ColumnInfo(name = "otp")
    @SerializedName("otp")
    var otp: String?, // 4444
    @ColumnInfo(name = "productName")
    @SerializedName("productName")
    var productName: String?, // Sun King Home 120
    @ColumnInfo(name = "status")
    @SerializedName("status")
    var status: String?, // Pending Installation
    @ColumnInfo(name = "statusUpdateTime")
    @SerializedName("statusUpdateTime")
    var statusUpdateTime: StatusUpdateTime?,

    @ColumnInfo(name = "latitude")
    @SerializedName("latitude")
    var latitude: Double?,

    @ColumnInfo(name = "longitude")
    @SerializedName("longitude")
    var longitude: Double?,

    @ColumnInfo(name = "ticketType")
    @SerializedName("ticketType")
    var ticketType: String?, // INSTALLATION

    @ColumnInfo(name = "isInstallationChanged")
    @SerializedName("isInstallationChanged")
    var isInstallationChanged: Boolean = false, //

    @ColumnInfo(name = "prospectLocation")
    @SerializedName("prospectLocation")
    var prospectLocation: ProspectLocation?

) : Parcelable {

    val prospectUpdatedAtLong: Long?
        get() {
            return if (this.prospectUpdatedAt == null) {
                null
            } else {
                Util.fseUtcToDate(this.prospectUpdatedAt!!).time
            }
        }

    @Parcelize
    data class SampleImages(
        @ColumnInfo(name = "name")
        @SerializedName("name")
        var name: String?, //
        // @ColumnInfo(name = "label")
        //@SerializedName("label")
        //var label: String?, //
        @ColumnInfo(name = "url")
        @SerializedName("url")
        var url: String? // https://s3.eu-west-2.amazonaws.com/kazi-userfiles-mobilehub-391300116/fse_prospective/1_PP3440060
    ) : Parcelable
    
    @Parcelize
    data class ProspectLocation(
        @ColumnInfo(name = "latitude")
        var latitude: Double?,
        @ColumnInfo(name = "longitude")
        var longitude: Double?,
        @ColumnInfo(name = "accuracy")
        var accuracy: Float?
    ) : Parcelable

    @Parcelize
    data class InstallationPictures(
        @ColumnInfo(name = "name")
        @SerializedName("name")
        var name: String?, //
        //new added in model not from Api
        @ColumnInfo(name = "sampleimage")
        @SerializedName("sampleimage")
        var sampleimage: String? = "", // https://s3.eu-west-2.amazonaws.com/kazi-userfiles-mobilehub-391300116/fse_prospective/1_PP3440060
        @ColumnInfo(name = "phoneUrl")
        @SerializedName("phoneUrl")
        var phoneUrl: String? = "", // Url were offline image saved
        //end
        //new added for Reattempt of Multiple
        @ColumnInfo(name = "isRejected")
        @SerializedName("isRejected")
        var isRejected: Boolean = false, // false
        @ColumnInfo(name = "attempt")
        @SerializedName("attempt")
        var attempt: Int = 0,
        @ColumnInfo(name = "isNewImage")
        var isNewImage: Boolean = false, // false
        @ColumnInfo(name = "isReattemptClick")
        var isReattemptClick: Boolean = false, // false
        //end
        @ColumnInfo(name = "url")
        @SerializedName("url")
        var url: String? // https://s3.eu-west-2.amazonaws.com/kazi-userfiles-mobilehub-391300116/fse_prospective/1_PP3440060

    ) : Parcelable


    @Parcelize
    @Entity(tableName = "StatusUpdateTime")
    @TypeConverters(StatusUpdateTimeConverter::class)
    data class StatusUpdateTime(
        @ColumnInfo(name = "checkedIn")
        @SerializedName("checkedIn")
        var checkedIn: String?, // 2019-12-24 16:56:25
        @ColumnInfo(name = "installationPending")
        @SerializedName("installationPending")
        var installationPending: String?, // 2019-12-24 18:35:28
        @ColumnInfo(name = "installed")//todo check
        @SerializedName("installed")//todo check
        var installed: String?,//todo check
        @ColumnInfo(name = "otpApproved")//todo check
        @SerializedName("otpApproved")//todo check
        var otpApproved: String?, // 2019-12-24 16:35:28//todo check
        @ColumnInfo(name = "preApprovedProspect")
        @SerializedName("preApprovedProspect")
        var preApprovedProspect: String?, // 2019-12-24 16:37:28
        @ColumnInfo(name = "prospect")
        @SerializedName("prospect")
        var prospect: String?, // 2019-12-24 16:30:23
        @ColumnInfo(name = "threeWayCallVerification")
        @SerializedName("threeWayCallVerification")
        var threeWayCallVerification: String?, // 2019-12-24 16:30:23

        @ColumnInfo(name = "installationVerified")//todo check
        @SerializedName("installationVerified")//todo check
        var installationVerified: String?//todo check
    ) : Parcelable
}

class InstallationPicturesConverter {

    @TypeConverter
    fun fromInstallationPictures(installationPictures: List<FseProspectResponseModel.InstallationPictures>?): String? {
        if (installationPictures == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<FseProspectResponseModel.InstallationPictures>>() {

        }.type
        return gson.toJson(installationPictures, type)
    }

    @TypeConverter
    fun toInstallationPicturesList(listString: String?): List<FseProspectResponseModel.InstallationPictures>? {
        if (listString == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<FseProspectResponseModel.InstallationPictures>>() {

        }.type
        return gson.fromJson(listString, type)
    }

}


class StatusUpdateTimeConverter {

    @TypeConverter
    fun fromStatusUpdateTime(statusUpdateTime: FseProspectResponseModel.StatusUpdateTime?): String? {
        if (statusUpdateTime == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<FseProspectResponseModel.StatusUpdateTime>() {

        }.type
        return gson.toJson(statusUpdateTime, type)
    }

    @TypeConverter
    fun toStatusUpdateTime(string: String?): FseProspectResponseModel.StatusUpdateTime? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<FseProspectResponseModel.StatusUpdateTime>() {

        }.type
        return gson.fromJson(string, type)
    }

}

class SampleImagesConverter {

    @TypeConverter
    fun fromSampleImages(installationPictures: List<FseProspectResponseModel.SampleImages>?): String? {
        if (installationPictures == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<FseProspectResponseModel.SampleImages>>() {

        }.type
        return gson.toJson(installationPictures, type)
    }

    @TypeConverter
    fun toSampleImagesList(listString: String?): List<FseProspectResponseModel.SampleImages>? {
        if (listString == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<FseProspectResponseModel.SampleImages>>() {

        }.type
        return gson.fromJson(listString, type)
    }

}

class ProspectLocationConverter {

    @TypeConverter
    fun fromProspectLocation(statusUpdateTime: FseProspectResponseModel.ProspectLocation?): String? {
        if (statusUpdateTime == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<FseProspectResponseModel.ProspectLocation>() {

        }.type
        return gson.toJson(statusUpdateTime, type)
    }

    @TypeConverter
    fun toProspectLocation(string: String?): FseProspectResponseModel.ProspectLocation? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<FseProspectResponseModel.ProspectLocation>() {

        }.type
        return gson.fromJson(string, type)
    }

}
