package com.greenlightplanet.kazi.liteFseProspective.view.activity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.DrawableCompat
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import androidx.appcompat.content.res.AppCompatResources
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Button
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.android.gms.location.LocationRequest
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityClickMutliImageBinding
import com.greenlightplanet.kazi.databinding.ActivityInstallationBinding
import com.greenlightplanet.kazi.liteFseProspective.extras.AmazonS3Helper
import com.greenlightplanet.kazi.liteFseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.liteFseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.liteFseProspective.model.LiteAwsImageModel
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import com.greenlightplanet.kazi.liteFseProspective.model.LiteInstallationRequestModel
import com.greenlightplanet.kazi.liteFseProspective.viewmodel.InstallationViewModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import pl.charmas.android.reactivelocation2.ReactiveLocationProvider
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit


class InstallationActivity : BaseActivity(), AmazonS3Helper.AmazonS3HelperCallback {
private lateinit var binding: ActivityInstallationBinding
    var fseProspectResponseModel: LiteFseProspectResponseModel? = null
    lateinit var viewModel: InstallationViewModel
    var amazonS3Helper: AmazonS3Helper? = AmazonS3Helper(this)
    var loginResponseData: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    var installationRequestModel: LiteInstallationRequestModel? = null
    var circularProgressDrawable: CircularProgressDrawable? = null
    private val bag: CompositeDisposable = CompositeDisposable()
    var currentLocation: Location? = null
	var mHomeWatcher: HomeWatcher? = null

    companion object {
        public const val TAG = "InstallationActivity"
    }

    private val REQUEST_CAMERA: Int = 1;
    private val PERMISSION_REQUEST_CODE: Int = 101
    private var outputImgUri: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
      //  setContentView(R.layout.activity_installation)
        binding = ActivityInstallationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        Util.setToolbar(this, toolbar)
        preference = GreenLightPreference.getInstance(this)
        viewModel = ViewModelProviders.of(this).get(InstallationViewModel::class.java)
        loginResponseData = preference?.getLoginResponseModel()
        circularProgressDrawable = CircularProgressDrawable(this)

        initializeExtras()
        initialize()
        clickHandler()

		mHomeWatcher = HomeWatcher(this)
		mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
			override fun onHomePressed() {
				finish()
			}
		})
		mHomeWatcher!!.startWatch()
    }

    private fun clickHandler() {
        binding.tvStep1.setOnClickListener() {

            if (checkPersmission()) {
                if (!Util.enableGPSIfPossible(RegistrationActivity@ this)) {
                    takePicture()
                }
            } else {
                requestPermission()
            }
        }

        binding.ivSync.setOnClickListener {

            if (Util.isOnline(this@InstallationActivity)) {
                if ((installationRequestModel != null) && fseProspectResponseModel!!.isChanged) {
                    //you have data to sync


                    viewModel.getAllAwsImageModelByProspectId(fseProspectResponseModel!!.prospectId).observe(this, Observer {

                        /*if (it != null) {
                            if (installationRequestModel!!.installationPictures()) {
                                showProgressDialog(this)
                                amazonS3Helper?.startUploadProcess(mutableListOf(it), true)
                            } else {
                                viewModel.sendInstallationRequestToServerForce(installationRequestModel!!, it, showProgress = {
                                    showProgressDialog(this)
                                }).observe(this, Observer {
                                    viewModel.getFseProspectiveFromServer(loginResponseData!!.angazaId!!, fseProspectResponseModel!!.prospectId)?.observe(this, Observer {

                                        if (it != null) {
                                            if ((it.success) && (it.responseData != null)) {

                                                setValue(it.responseData!!)
                                            }else{
                                                alphaMethod(fseProspectResponseModel!!)
                                            }
                                        }else{
                                            alphaMethod(fseProspectResponseModel!!)
                                        }

                                        cancelProgressDialog()

                                    })
                                })
                            }

                        }*/
                    })


                } else {

                    viewModel.getFseProspectiveFromServer(loginResponseData!!.angazaId!!, fseProspectResponseModel!!.prospectId, showProgress = {
                        showProgressDialog(this)
                    })?.observe(this, Observer {
                        if (it != null) {
                            if ((it.success) && (it.responseData != null)) {

                                setValue(it.responseData!!)
                            }else{
                                alphaMethod(fseProspectResponseModel!!)
                            }
                        }else{
                            alphaMethod(fseProspectResponseModel!!)
                        }

                        cancelProgressDialog()
                    })

                }
            } else {
                //Util.showToast("No Internet", this)
                Util.customFseRationaleDialog(this, "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = "Please check internet connection",
                        positveSelected = {
                            it.dismiss()
                        },
                        negativeSeleted = {
                            it.dismiss()
                        }
                )
            }
        }

        binding.imageView.setOnClickListener {
            Util.CustomLeaderImageDialog(this, binding.imageView.drawable)
        }
        //CustomLeaderImageDialog
    }

    @SuppressLint("NewApi")
    fun takePicture() {

        Util.CustomInstallationDialog(context = this,
                onDialogShow = {
                    dialog, image ,gotItBtn->
                  //  val okbutton = dialog.findViewById<Button>(R.id.btnGotIT)
                    gotItBtn.isEnabled = false

                    val unwrappedDrawable = AppCompatResources.getDrawable(this, R.drawable.button_background);
                    val wrappedDrawable = DrawableCompat.wrap(unwrappedDrawable!!);
                    DrawableCompat.setTint(wrappedDrawable, Color.GRAY);
                    gotItBtn.background = wrappedDrawable

                    fetchAccuray()
                    bag.add(

                            Completable.timer(3000, TimeUnit.MILLISECONDS)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe({
                                        gotItBtn.isEnabled = true

                                        val unwrappedDrawable = AppCompatResources.getDrawable(this, R.drawable.button_background);
                                        val wrappedDrawable = DrawableCompat.wrap(unwrappedDrawable!!);
                                        DrawableCompat.setTint(wrappedDrawable, Color.BLACK);
                                        gotItBtn.background = wrappedDrawable

                                    }, {
                                        Log.d(TAG, "error:${it.localizedMessage} ");
                                    })
                    )
                },
                onCancel = {
                    bag.clear()
                    dialog?.dismiss()
                },
                imgGotSample = {
                    bag.clear()
                    val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    val fileaa: File = createFile()
                    //Log.d(TAG, "fileaa.absolutePath:${fileaa.absolutePath} ");
                    //Log.d(TAG, "fileaa.exists():${fileaa.exists()} ");
                    outputImgUri = fileaa.absolutePath

                    val Prouri: Uri = FileProvider.getUriForFile(
                            this,
                            "com.greenlightplanet.kazi.update.FileImageProvider", fileaa
                    )
                    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Prouri)
                    startActivityForResult(cameraIntent, REQUEST_CAMERA)
                    it.dismiss()
                })
    }

    @Throws(IOException::class)
    fun createFile(): File {
        // Create an image file name
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
                "Kazi_${System.currentTimeMillis()}", /* prefix */
                ".jpg", /* suffix */
                storageDir /* directory */
        ).apply {
            // Save a file: path for use with ACTION_VIEW intents
            outputImgUri = absolutePath
        }

    }

    private fun checkPersmission(): Boolean {
        return (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION),
                PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                        && grantResults[1] == PackageManager.PERMISSION_GRANTED
                        && grantResults[2] == PackageManager.PERMISSION_GRANTED) {
                    if (!Util.enableGPSIfPossible(RegistrationActivity@ this)) {
                        takePicture()
                    }
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQUEST_CAMERA) {
            if (resultCode == Activity.RESULT_OK) {
                //data?.let {
                onImageCaptured()
                //}
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    fun onImageCaptured() {

        outputImgUri?.let {

            val pictureBitmap = BitmapFactory.decodeFile(outputImgUri)
            binding.imageView.setImageBitmap(pictureBitmap)
            binding. grpStep1.visibility = View.VISIBLE
            binding.imageView.visibility = View.VISIBLE

            Log.d(TAG, "outputImgUri-test:$outputImgUri");

            //if (true) {
            if (currentLocation == null || preference?.getFseAccuracy().isNullOrEmpty()) {
                Log.d(TAG, "AccuracyDialog-1 = currentLocation:$currentLocation|preference?.getFseAccuracy():${preference?.getFseAccuracy()}")
                showLowAccuracyDialog()
            } else {
                if (currentLocation!!.accuracy > preference?.getFseAccuracy()?.toFloat() ?: 200F) {
                    Log.d(TAG, "AccuracyDialog-2 = currentLocation:$currentLocation|preference?.getFseAccuracy():${preference?.getFseAccuracy()}")
                    showLowAccuracyDialog()
                } else {
                    Log.d(TAG, "AccuracyDialog-3 = currentLocation:$currentLocation|preference?.getFseAccuracy():${preference?.getFseAccuracy()}")
                    showRationaleDialog(outputImgUri!!, fseProspectResponseModel!!)
                }
            }
        }
    }

    fun showRationaleDialog(imagePath: String, fseProspectResponseModel: LiteFseProspectResponseModel) {

        val title = "Image Captured Successfully. You Image accuracy is high."
        val spannable = SpannableString(title)
        spannable.setSpan(
                StyleSpan(Typeface.BOLD),
                0, title.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

        Util.customFseRationaleDialog(
                context = this@InstallationActivity,
                titleSpanned = spannable,
                //title = "Image Captured Successfully. You Image accuracy is high.",
                message = "Are you sure you want to complete installation for this customer?",
                setCanceledOnTouchOutside = false,
                positveSelected = {
                    it.dismiss()
                    //upload image
                    processImageCompression(this@InstallationActivity, imagePath, fseProspectResponseModel.prospectId)
                },
                negativeSeleted = {
                    it.dismiss()
                    Log.d(TAG, "Accuracy: ${if (currentLocation != null) currentLocation!!.accuracy.toString() else "NA"} ");
                    binding.grpStep1.visibility = View.GONE
                    binding. imageView.visibility = View.GONE
                },
                title = null
        )
    }

    fun showLowAccuracyDialog() {
        Log.d(TAG, "ACCURRACY - showLowAccuracyDialog :${currentLocation?.accuracy} ");
        //show accuracy here inside dialog
        fetchAccuray()

        val title = "Your Image accuracy is Low"
        val spannable = SpannableString(title)
        spannable.setSpan(
                StyleSpan(Typeface.BOLD),
                0, title.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

        Util.customFseCompletionDialog(
                context = this@InstallationActivity,
                hideTitle = false,
                message = "Please click the image again for better results.",
                titleSpanned = spannable,
                okSelected = {
                    it.dismiss()
                    //upload image
                    bag.clear()
                },
                title = null
        )
    }

    fun processImageCompression(context: Context, imagePath: String, prospectId: String) {

        val imageModels = mutableListOf<ImageUploadUtil.ImageModel>()
        val file = File(imagePath)

        imageModels.add(ImageUploadUtil.ImageModel(file = file, prospectId = prospectId))

        viewModel.compressImageForAws(context = context, files = imageModels, showProgress = {
            showProgressDialog(context)
        }).observe(this, Observer { awsImageModels ->

            val isOnline = Util.isOnline(context)
            if (awsImageModels != null) {

                var installAttempted = 0
                installAttempted = fseProspectResponseModel!!.installationAttempted + 1

                val awsImageModel = awsImageModels.first()
                awsImageModel.installationAttempted = installAttempted
                fseProspectResponseModel!!.installationAttempted = installAttempted
//                viewModel.performInstallation(
//                        context = context,
//                        isOnline = false,
//                        prospectId = fseProspectResponseModel!!.prospectId,
//                        fileModel = awsImageModel,
//                        angazaId = loginResponseData?.angazaId!!,
//                        accountNumber = fseProspectResponseModel!!.accountNumber,
//                        installationAttempted = installAttempted,
//                        location = currentLocation!!,
//                        date = ""//mazhar
//                ).observe(this, Observer {
//
//                    Log.d(TAG, "instaT1:$it ");
//                    it?.let {
//                        if (!isOnline) {
//                            cancelProgressDialog()
//                            alphaMethod(fseProspectResponseModel!!)
//                        } else {
//                            amazonS3Helper?.startUploadProcess(awsImageModels, false)
//                        }
//                    } ?: kotlin.run {
//                        cancelProgressDialog()
//                        alphaMethod(fseProspectResponseModel!!)
//                    }
//
//                    Log.d(TAG, "Offline:$it ");
//
//                })

            } else {
                cancelProgressDialog()
            }

        })

    }

    override fun onAllUploadCompleted(fileModelsList: List<LiteAwsImageModel>) {
        //override fun onAllUploadCompleted(fileModelsList: List<AmazonS3Helper.FileModel>) {
        cancelProgressDialog()
        //send Data to server
        fileModelsList.forEach { it.tried = false }
        Log.d(TAG, "onAllUploadCompleted:fileModelsList2 = $fileModelsList ");
        val isOnline = Util.isOnline(this)

//        viewModel.insertAwsImageModelToDatabase(fileModelsList, true).observe(this, Observer {
//
//            Log.d(TAG, "fseProspectResponseModel!!.installationAttempted:${fseProspectResponseModel!!.installationAttempted} ")
//            viewModel.performInstallation2(
//                    context = this,
//                    isOnline = isOnline,
//                    prospectId = fseProspectResponseModel!!.prospectId,
//                    angazaId = loginResponseData!!.angazaId!!,
//                    fileModel = fileModelsList.first(),
//                    accountNumber = fseProspectResponseModel!!.accountNumber,
//                    installationAttempted = fseProspectResponseModel!!.installationAttempted,
//                    //location = currentLocation!!,
//                    showProgress = {
//                        if (!isProgressShowing()) {
//                            showProgressDialog(this)
//                        }
//                    }
//            ).observe(this, Observer {
//                alphaMethod(fseProspectResponseModel!!)
//                cancelProgressDialog()
//                Log.d(TAG, ":step2$it");
//            })
//        })

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item?.itemId) {
            android.R.id.home -> {

                onBackPressed()

                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    fun initializeExtras() {

        if (intent.hasExtra("data")) {

            fseProspectResponseModel = intent.getParcelableExtra("data")

        }
    }

    fun initialize() {

        amazonS3Helper?.initializer()
        amazonS3Helper?.amazonS3HelperCallback = this

        fseProspectResponseModel?.let {
            setValue(it)
        }


    }

    private fun setValue(fseProspectResponseModel: LiteFseProspectResponseModel) {

        circularProgressDrawable?.strokeWidth = 5f
        circularProgressDrawable?.centerRadius = 30f
        circularProgressDrawable?.start()

        binding.tvCustomerName.text = fseProspectResponseModel.name
        binding.tvCustomerAddress.text = fseProspectResponseModel.customerAddress//not available
        binding.tvAccountNo.text = fseProspectResponseModel.accountNumber
        binding. tvPhoneNumber.text = fseProspectResponseModel.customerPhoneNumber
        alphaMethod(fseProspectResponseModel)

    }

    fun alphaMethod(fseProspectResponseModel: LiteFseProspectResponseModel) {

        viewModel.getCombineRequestModel(fseProspectResponseModel.prospectId).observe(this, Observer {

            Log.d(TAG, "combineRequest:$it ")

            it?.fseProspectResponseModel?.let {
                this.fseProspectResponseModel = it
                setProspectProgress(it.statusUpdateTime)
            } ?: run {
                setProspectProgress(fseProspectResponseModel.statusUpdateTime)
            }

            if (it?.installationRequestModels == null) {
                //do your logic
                //change to green
                val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                binding. ivSyncColor.setImageDrawable(backgroundDrawable)

                if (!this.fseProspectResponseModel!!.statusUpdateTime!!.installed.isNullOrEmpty()) {
                    Log.d(TAG, "Tempo:1 ");
                    handleButtonVisibility(this.fseProspectResponseModel!!.installationPicture, null)
                }
            } else {

                installationRequestModel = it.installationRequestModels!!

                Log.d(TAG, "Tempo:2 : fseProspectResponseModel.reattemptedStag = ${fseProspectResponseModel.reattemptedStage}");
                if (this.fseProspectResponseModel!!.reattemptedStage != 1) {
//                    handleButtonVisibility(installationRequestModel?.installationPictures, installationRequestModel?.pictureUri)
                }

                if (this.fseProspectResponseModel!!.isChanged) {

                    //change to green to red
                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.RED)
                    binding.ivSyncColor.setImageDrawable(backgroundDrawable)

                } else {

                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                    binding.ivSyncColor.setImageDrawable(backgroundDrawable)

                }
            }

            it?.fseError?.let {

                if (this.fseProspectResponseModel!!.errorOccurred && (it.errorType == FseProspectiveConstant.ProspectiveType.INSTALLATION)) {
                    binding.llError.visibility = View.VISIBLE
                    binding.tvErrorMessage.text = it.messageToUser
                }
            }


        })
    }

    fun handleButtonVisibility(urlOfImage: String?, uriPathOfImage: String?) {

        binding.tvStep1.visibility = View.GONE

        if (!urlOfImage.isNullOrBlank()) {


            Glide.with(this)
                    .load(urlOfImage)
                    .apply(RequestOptions()
                            .centerCrop()
                            .placeholder(circularProgressDrawable)
                            .error(R.mipmap.ic_launcher_round)).into(binding.imageView);


        } else {

            Glide.with(this)
                    .load(uriPathOfImage)
                    .apply(RequestOptions()
                            .centerCrop()
                            .placeholder(circularProgressDrawable)
                            .error(R.mipmap.ic_launcher_round)).into(binding.imageView);

        }

        binding.grpStep1.visibility = View.VISIBLE
        binding.imageView.visibility = View.VISIBLE
    }

    private fun setProspectProgress(statusUpdateTime: LiteFseProspectResponseModel.StatusUpdateTime?) {
        if (!statusUpdateTime?.prospect.isNullOrEmpty()) {
//            tv_ProspectDate.text = statusUpdateTime?.prospect
            binding. tvProspectDate.text = Util.fseUiDateFormatter(statusUpdateTime?.prospect!!)
            binding.imgProspect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
        } else {
            binding.tvProspectDate.text = ""
            binding.imgProspect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
        }

        if (!statusUpdateTime?.otpApproved.isNullOrEmpty()) {
            binding.tvOTPDate.text = statusUpdateTime?.otpApproved
            if (!statusUpdateTime?.otpApproved.isNullOrEmpty()) {
//            tv_OTPDate.text = statusUpdateTime?.otpApproval
                binding.tvOTPDate.text = Util.fseUiDateFormatter(statusUpdateTime?.otpApproved!!)
                binding.imgOtp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
            } else {
                binding.tvOTPDate.text = ""
                binding.imgOtp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }

            if (!statusUpdateTime?.preApprovedProspect.isNullOrEmpty()) {
                binding.tvPreApprovedDate.text = Util.fseUiDateFormatter(statusUpdateTime?.preApprovedProspect!!)
                //img_PreApproved
                binding.imgPreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                binding.tvPreApprovedDate.text = ""
                binding.imgPreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
            }

            if (!statusUpdateTime?.checkedIn.isNullOrEmpty()) {
                binding.tvCheckedInDate.text = Util.fseUiDateFormatter(statusUpdateTime?.checkedIn!!)
                //img_CheckedIn
                binding.imgCheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                binding.tvCheckedInDate.text = ""
                binding.imgCheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
            }

            if (!statusUpdateTime?.installed.isNullOrEmpty()) {
                binding.tvInstallPendDate.text = Util.fseUiDateFormatter(statusUpdateTime?.installed!!)
//            tv_InstallPendDate.text = statusUpdateTime?.installationPending
                //img_istallationP


                if (!fseProspectResponseModel!!.approved) {

                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.INSTALLED) {

                        binding.imgIstallationP.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_cancel))
                        binding.tvStep1.visibility = View.GONE
                        binding.imgIstallationP.setOnClickListener {
                            errorMessage(fseProspectResponseModel!!)
                        }
                    } else {
                        binding.imgIstallationP.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                    }
                } else {
                    binding.imgIstallationP.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                }

            } else {
                binding.tvInstallPendDate.text = ""
                binding.imgIstallationP.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
            }

            if (!statusUpdateTime?.installationVerified.isNullOrEmpty()) {
//            tv_InstallCompleteDate.text = statusUpdateTime?.installed
                binding.tvInstallCompleteDate.text = Util.fseUiDateFormatter(statusUpdateTime?.installationVerified!!)
                //img_InstallComplete

                if (!fseProspectResponseModel!!.approved) {

                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED || fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {

                        binding.imgInstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_cancel))
                        binding.tvStep1.visibility = View.GONE
                        binding.imgInstallComplete.setOnClickListener {
                            errorMessage(fseProspectResponseModel!!)
                        }
                    } else {
                        binding.imgInstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                    }
                } else {
                    binding.imgInstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                }

            } else {
                binding.tvInstallCompleteDate.text = ""
                binding.imgInstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
            }

            if (!statusUpdateTime?.threeWayCallVerification.isNullOrEmpty()) {
                binding.tvCCverif.text = Util.fseUiDateFormatter(statusUpdateTime?.threeWayCallVerification!!)
                binding.imgCCVerif.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                binding.tvCCverif.text = ""
                binding.imgCCVerif.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }
        }
    }

    private fun errorMessage(fseProspectResponseModel: LiteFseProspectResponseModel) {

        if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {

            Util.customDialog(
                    context = this,
                    message = fseProspectResponseModel.message,
                    positiveText = "Proceed",
                    negetiveText = "Cancel",
                    poitiveSelected = {
                        //add logic
                        updateFseProspect(fseProspectResponseModel, 1)
                        it.dismiss()
                    },
                    negetiveSelected = {
                        it.dismiss()
                    }
            )

        } else {
            Util.customFseCompletionDialog(
                    context = this,
                    hideTitle = true,
                    title = null,
                    message = fseProspectResponseModel.message,
                    okSelected = {
                        it.dismiss()
                    }
            )

        }
    }

    private fun updateFseProspect(fseProspectResponseModel: LiteFseProspectResponseModel, reattemptedStage: Int) {

        when (reattemptedStage) {
            1 -> {
                fseProspectResponseModel.reattemptedStage = 1
                fseProspectResponseModel.statusUpdateTime?.installed = ""
                fseProspectResponseModel.statusUpdateTime?.installationVerified = ""
                fseProspectResponseModel.status = FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                this.fseProspectResponseModel = fseProspectResponseModel
                binding.imgInstallComplete.setOnClickListener(null)
            }
        }

        viewModel.updateFseProspect(fseProspectResponseModel).observe(this, Observer {
            initialize()
            binding.tvStep1.visibility = View.VISIBLE
            binding.grpStep1.visibility = View.GONE
            binding.imageView.setImageResource(0);
            binding.imageView.visibility = View.GONE
        })

    }

    fun getCurrentLoc(): MutableLiveData<Location> {

        val data = MutableLiveData<Location>()

        bag.add(
                newGetCurrentLocation(this)!!.subscribe({
                    data.postValue(it)
                }, {
                    data.postValue(null)
                })
        )
        return data
    }

    fun fetchAccuray() {
        getCurrentLoc().observe(this, Observer {
            it?.let {
                currentLocation = it
                Log.d(TAG, "ACCURRACY :${currentLocation?.accuracy} ");
                Log.e("|| == ", "${it.latitude},${it.longitude}")
            }
        })
    }

    @SuppressLint("MissingPermission")
    fun newGetCurrentLocation(context: Context): Observable<Location>? {
        val request = LocationRequest.create() //standard GMS LocationRequest
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setNumUpdates(50).setInterval(20)

        val locationProvider = ReactiveLocationProvider(context)
        return locationProvider.getUpdatedLocation(request)

    }

    override fun onDestroy() {
        super.onDestroy()
        //AmazonS3Helper.destroy()
        amazonS3Helper?.amazonS3HelperCallback = null
        amazonS3Helper = null

        bag.clear()
		mHomeWatcher?.stopWatch();

	}


}
