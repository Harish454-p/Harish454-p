package com.greenlightplanet.kazi.leads.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData

import com.greenlightplanet.kazi.leads.extras.LEAD_STATUS
import com.greenlightplanet.kazi.leads.model.CallDetailRequestModel
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead
import com.greenlightplanet.kazi.leads.model.LeadsIntent
import com.greenlightplanet.kazi.leads.model.LeadsResponseModel
import com.greenlightplanet.kazi.leads.repo.CustomerLeadsRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable

class CustomerLeadsViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "CustomerLeadsViewModel"
    }

    val repo = CustomerLeadsRepo.getInstance(application)


    fun getCustomerLeadsFromServer(isOnline: Boolean = false, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<LeadsResponseModel>> {
        showProgress()
        return if (isOnline) {
            repo.getCustomerLeadsFromServer()
        } else {
            repo.getCustomerLeadsFromDb()
        }
    }

    fun getLeadsIntentFromDb(showProgress: () -> Unit = {}): MutableLiveData<List<LeadsIntent>> {
        showProgress()
        return repo.getLeadsIntentFromDb()
    }

    fun getPendingTabList(list: List<LeadsCrossSalesLead>, search: Boolean = false, searchQuery: String = ""): List<LeadsCrossSalesLead> {

        return if (search) {
            list.filter { (it.status == LEAD_STATUS.PENDING || it.status == LEAD_STATUS.REASSIGNED) && it.customerName!!.contains(searchQuery, true) }
        } else {
            list.filter { (it.status == LEAD_STATUS.PENDING || it.status == LEAD_STATUS.REASSIGNED) }
        }

    }


    fun getCalledTabList(list: List<LeadsCrossSalesLead>, search: Boolean = false, searchQuery: String = ""): List<LeadsCrossSalesLead> {

        return if (search) {
            list.filter { (it.status == LEAD_STATUS.CALLED) && it.customerName!!.contains(searchQuery, true) }
        } else {
            list.filter { (it.status == LEAD_STATUS.CALLED) }
        }
    }


    fun getPendingTabProductList(list: List<LeadsCrossSalesLead>, search: Boolean = false, searchQuery: String = "", productName: String): List<LeadsCrossSalesLead> {

        return if (search) {
            list.filter { (it.status == LEAD_STATUS.PENDING || it.status == LEAD_STATUS.REASSIGNED) && it.customerName!!.contains(searchQuery, true) && it.interestedIn.equals(productName, true) }
        } else {
            list.filter { (it.status == LEAD_STATUS.PENDING || it.status == LEAD_STATUS.REASSIGNED) && it.interestedIn.equals(productName, true) }
        }

    }


    fun getCalledTabProductList(list: List<LeadsCrossSalesLead>, search: Boolean = false, searchQuery: String = "", productName: String): List<LeadsCrossSalesLead> {

        return if (search) {
            list.filter { (it.status == LEAD_STATUS.CALLED) && it.customerName!!.contains(searchQuery, true) && it.interestedIn.equals(productName, true) }
        } else {
            list.filter { (it.status == LEAD_STATUS.CALLED) && it.interestedIn.equals(productName, true)}
        }
    }

    fun getPendingTabProductListSource(list: List<LeadsCrossSalesLead>, search: Boolean = false, searchQuery: String = "", source: String): List<LeadsCrossSalesLead> {

        return if (search) {
            list.filter { (it.status == LEAD_STATUS.PENDING || it.status == LEAD_STATUS.REASSIGNED) && it.customerName!!.contains(searchQuery, true) && it.source.equals(source, true) }
        } else {
            list.filter { (it.status == LEAD_STATUS.PENDING || it.status == LEAD_STATUS.REASSIGNED) && it.source.equals(source, true) }
        }

    }


    fun getCalledTabProductListSource(list: List<LeadsCrossSalesLead>, search: Boolean = false, searchQuery: String = "", source: String): List<LeadsCrossSalesLead> {

        return if (search) {
            list.filter { (it.status == LEAD_STATUS.CALLED) && it.customerName!!.contains(searchQuery, true) && it.source.equals(source, true) }
        } else {
            list.filter { (it.status == LEAD_STATUS.CALLED) && it.source.equals(source, true)}
        }
    }



    fun getPendingFilteredList(list: List<LeadsCrossSalesLead>, productName: String): List<LeadsCrossSalesLead> {
        return list.filter { (it.status == LEAD_STATUS.PENDING || it.status == LEAD_STATUS.REASSIGNED) && it.interestedIn.equals(productName, true) }
    }

    fun getCalledTabFilteredList(list: List<LeadsCrossSalesLead>, productName: String): List<LeadsCrossSalesLead> {
        return list.filter { (it.status == LEAD_STATUS.CALLED) && it.interestedIn.equals(productName, true) }
    }

    fun getPendingFilteredListSource(list: List<LeadsCrossSalesLead>, source: String): List<LeadsCrossSalesLead> {
        return list.filter { (it.status == LEAD_STATUS.PENDING || it.status == LEAD_STATUS.REASSIGNED) && it.source.equals(source, true) }
    }

    fun getCalledTabFilteredListSource(list: List<LeadsCrossSalesLead>, source: String): List<LeadsCrossSalesLead> {
        return list.filter { (it.status == LEAD_STATUS.CALLED) && it.source.equals(source, true) }
    }

    fun insertCallDetailRequestToDb(callDetailRequestModel: CallDetailRequestModel, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        showProgress()
        return repo.insertCallDetailRequestToDb(callDetailRequestModel)
    }

    fun solveCallDetailRequest(callDetailRequestModel: CallDetailRequestModel, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        showProgress()
        return repo.solveCallDetailRequest(callDetailRequestModel)
    }

    fun solveabc(showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        showProgress()
        return repo.solveabc()
    }

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }

}