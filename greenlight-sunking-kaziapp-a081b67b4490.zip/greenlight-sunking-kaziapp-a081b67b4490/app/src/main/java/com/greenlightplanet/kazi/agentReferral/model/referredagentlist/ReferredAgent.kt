package com.greenlightplanet.kazi.agentReferral.model.referredagentlist


import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "ReferredAgent")
data class ReferredAgent(
    @PrimaryKey(autoGenerate = true)
    val id : Int?,
    @ColumnInfo(name = "child_phone_number")
    @SerializedName("child_phone_number")
    var childPhoneNumber: String?,
    @ColumnInfo(name = "current_stage")
    @SerializedName("current_stage")
    var currentStage: String?,
    @ColumnInfo(name = "referred_date")
    @SerializedName("referred_date")
    var referredDate: String?,
    @ColumnInfo(name = "referred_date_timestamp")
    @SerializedName("referred_date_timestamp")
    var referredDateTimestamp: String?,
    @ColumnInfo(name = "status")
    @SerializedName("status")
    var status: String?
) : Parcelable