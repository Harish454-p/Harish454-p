package com.greenlightplanet.kazi.fseProspective.model


data class SyncCombineModel(
        var otpApprovalRequestModels: List<OtpApprovalRequestModel>? = null,
        var registrationCheckinRequestModels: List<RegistrationCheckinRequestModel>? = null,
        var installationRequestModels: List<InstallationRequestModel>? = null
)