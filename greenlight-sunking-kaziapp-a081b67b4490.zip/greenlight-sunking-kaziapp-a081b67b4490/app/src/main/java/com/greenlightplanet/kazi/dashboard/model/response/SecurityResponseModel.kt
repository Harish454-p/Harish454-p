package com.greenlightplanet.kazi.dashboard.model.response



import android.os.Parcelable
import androidx.room.*
import kotlinx.android.parcel.Parcelize
import com.google.gson.annotations.SerializedName

@Parcelize
@Entity(tableName = "%s")
data class SecurityResponseModel(
    @ColumnInfo(name = "securityKey")
    @SerializedName("securityKey")
    var securityKey: String
):Parcelable