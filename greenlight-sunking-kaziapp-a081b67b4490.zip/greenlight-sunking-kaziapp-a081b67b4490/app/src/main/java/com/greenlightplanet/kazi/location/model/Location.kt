package com.greenlightplanet.kazi.location.model


import com.google.gson.annotations.SerializedName

data class Location(
    @SerializedName("lat")
    var lat: Double?, // 19.2920217
    @SerializedName("lng")
    var lng: Double? // 72.87165139999999
)
