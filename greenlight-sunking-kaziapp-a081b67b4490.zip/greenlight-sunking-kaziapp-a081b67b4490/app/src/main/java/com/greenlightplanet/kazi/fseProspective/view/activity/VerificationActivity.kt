package com.greenlightplanet.kazi.fseProspective.view.activity

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.fseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseModel
import com.greenlightplanet.kazi.fseProspective.model.OtpApprovalRequestModel
import com.greenlightplanet.kazi.fseProspective.viewmodel.VerificationViewModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener



class VerificationActivity : BaseActivity() {

    var fseProspectResponseModel: FseProspectResponseModel? = null
    var loginResponseData: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    lateinit var viewModel: VerificationViewModel
    var otpApprovalRequestModel: OtpApprovalRequestModel? = null
	var mHomeWatcher: HomeWatcher? = null


	companion object {

        val TAG = "VerificationActivity"
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verification)
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        Util.setToolbar(this, toolbar)
        preference = GreenLightPreference.getInstance(this)
        loginResponseData = preference?.getLoginResponseModel()
        viewModel = ViewModelProviders.of(this).get(VerificationViewModel::class.java)

//        initializeExtras()
//        initialize()
//        clickHandler()


        Log.d(TAG, "Country: ${preference!!.getLoginResponseModel()!!.country}")

		mHomeWatcher = HomeWatcher(this)
		mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
			override fun onHomePressed() {
				finish()
			}
		})
		mHomeWatcher!!.startWatch()
    }
/*
    private fun clickHandler() {
        SubmitOk.setOnClickListener {
            Log.d(TAG, "Otp-Entered: ${otpView?.text.toString()}")
            if (otpView.text.isNullOrBlank()) {
                Toast.makeText(this, "Please enter OTP", Toast.LENGTH_SHORT).show()
            } else {
                validate(this@VerificationActivity, otpView?.text.toString())
            }

        }

        ivSync.setOnClickListener {

            if (Util.isOnline(this@VerificationActivity)) {
                if ((otpApprovalRequestModel != null) && fseProspectResponseModel!!.isChanged) {
                    //you have data to sync
                    viewModel.sendOtpApprovalToServerForceUpload((!otpApprovalRequestModel!!.otpVerificationTime.isNullOrBlank()), otpApprovalRequestModel!!,
                            showProgress = {
                                showProgressDialog(this)
                            }).observe(this, Observer {

                        viewModel.getFseProspectiveFromServer(loginResponseData!!.angazaId!!, fseProspectResponseModel!!.prospectId)?.observe(this, Observer {
                            if (it != null) {
                                if ((it.success) && (it.responseData != null)) {

                                    setValue(it.responseData!!)
                                }else{
                                    alphaMethod(fseProspectResponseModel!!)
                                }
                            }else{
                                alphaMethod(fseProspectResponseModel!!)
                            }

                            cancelProgressDialog()
                        })

                    })
                } else {
                    //you don't have data to sync
//                    Util.showToast("Sync not required", this)
                    viewModel.getFseProspectiveFromServer(loginResponseData!!.angazaId!!, fseProspectResponseModel!!.prospectId,showProgress = {
                        showProgressDialog(this)
                    })?.observe(this, Observer {
                        if (it != null) {
                            if ((it.success) && (it.responseData != null)) {

                                setValue(it.responseData!!)
                            }else{
                                alphaMethod(fseProspectResponseModel!!)
                            }
                        }else{
                            alphaMethod(fseProspectResponseModel!!)
                        }

                        cancelProgressDialog()
                    })
                }
            } else {
//                Util.showToast("No Internet", this)
                Util.customFseRationaleDialog(this, "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = "Please check internet connection",
                        positveSelected = {
                            it.dismiss()
                        },
                        negativeSeleted = {
                            it.dismiss()
                        }
                )
            }

        }

    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item?.itemId) {
            android.R.id.home -> {

                onBackPressed()

                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }


    fun initializeExtras() {

        if (intent.hasExtra("data")) {

            fseProspectResponseModel = intent.getParcelableExtra("data")

        }

    }

    fun initialize() {
        fseProspectResponseModel?.let {
            setValue(it)
        }
    }

    private fun setValue(fseProspectResponseModel: FseProspectResponseModel) {

        tv_CustomerName.text = fseProspectResponseModel.name
        tv_CustomerAddress.text = fseProspectResponseModel.customerAddress
        tv_PhoneNumber.text = fseProspectResponseModel.customerPhoneNumber
        tv_ProspectID.text = fseProspectResponseModel.prospectId
        //tv_AccountNo.text = fseProspectResponseModel.accuntNumber//not available
        //tv_TicketGenerationDate.text = fseProspectResponseModel.statusUpdateTime //no idea what value to set
        //tv_TypeOfTicket.text = fseProspectResponseModel.name // customer address not available


        Log.d(TAG, "statusUpdateTime: ${fseProspectResponseModel.statusUpdateTime}");


        alphaMethod(fseProspectResponseModel)

        if (!(fseProspectResponseModel.statusUpdateTime?.otpApproved.isNullOrBlank())) {
            otpView.visibility = View.GONE
            SubmitOk.visibility = View.GONE
        }

        setProspectProgress(fseProspectResponseModel.statusUpdateTime)

    }


    fun alphaMethod(fseProspectResponseModel: FseProspectResponseModel) {

        viewModel.getCombineRequestModel(fseProspectResponseModel.prospectId).observe(this, Observer {

            it?.fseProspectResponseModel?.let {
                this.fseProspectResponseModel = it

                Log.d(TAG, "it-isChanged:${it} ");

            }

            if ((it?.otpApprovalRequestModel == null) && !(this.fseProspectResponseModel!!.isChanged)) {

                val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                ivSyncColor.setImageDrawable(backgroundDrawable)

            } else {
                otpApprovalRequestModel = it?.otpApprovalRequestModel

                if (this.fseProspectResponseModel!!.isChanged) {
                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.RED)
                    ivSyncColor.setImageDrawable(backgroundDrawable)
                } else {

                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                    ivSyncColor.setImageDrawable(backgroundDrawable)


                }

                if (!it?.otpApprovalRequestModel?.otpVerificationTime.isNullOrEmpty()) {

                    img_Otp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                    tv_OTPDate.text = Util.fseUiDateFormatter(it!!.otpApprovalRequestModel?.otpVerificationTime!!)

                    otpView.visibility = View.GONE
                    SubmitOk.visibility = View.GONE

                }
            }


            it?.fseError?.let {

                if (this.fseProspectResponseModel!!.errorOccurred && (it.errorType == FseProspectiveConstant.ProspectiveType.VERIFICATION)) {
                    llError.visibility = View.VISIBLE
                    tvErrorMessage.text = it.messageToUser
                }
            }


        })
    }

    private fun setProspectProgress(statusUpdateTime: FseProspectResponseModel.StatusUpdateTime?) {

        if (!statusUpdateTime?.prospect.isNullOrEmpty()) {
            tv_ProspectDate.text = Util.fseUiDateFormatter(statusUpdateTime!!.prospect!!)
            //tv_ProspectDate.text = statusUpdateTime?.prospect

            //img_Prospect
            //img_Prospect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            if (!fseProspectResponseModel!!.approved) {

                if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.PROSPECT) {

                    img_Prospect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_cancel))
                    otpView.visibility = View.GONE
                    SubmitOk.visibility = View.GONE

                    img_Prospect.setOnClickListener {
                        errorMessage(fseProspectResponseModel!!)
                    }

                } else {
                    img_Prospect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                }
            } else {
                img_Prospect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
            }


        } else {
            tv_ProspectDate.text = ""
            img_Prospect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
        }


        if (!statusUpdateTime?.otpApproved.isNullOrEmpty()) {
//            tv_OTPDate.text = statusUpdateTime?.otpApproval
            tv_OTPDate.text = Util.fseUiDateFormatter(statusUpdateTime!!.otpApproved!!)
            if (!statusUpdateTime.otpApproved.isNullOrEmpty()) {
                tv_OTPDate.text = Util.fseUiDateFormatter(statusUpdateTime!!.otpApproved!!)
                //img_Otp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

                if (!fseProspectResponseModel!!.approved) {

                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.OTP_APPROVED) {

                        img_Otp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_cancel))
                        otpView.visibility = View.GONE
                        SubmitOk.visibility = View.GONE

                        img_Otp.setOnClickListener {
                            errorMessage(fseProspectResponseModel!!)
                        }

                    } else {
                        img_Otp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                    }
                } else {
                    img_Otp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                }

            } else {
                tv_OTPDate.text = ""
                img_Otp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
            }

            if (!statusUpdateTime?.preApprovedProspect.isNullOrEmpty()) {
//            tv_PreApprovedDate.text = statusUpdateTime?.preApprovedProspect
                tv_PreApprovedDate.text = Util.fseUiDateFormatter(statusUpdateTime!!.preApprovedProspect!!)
                //img_PreApproved
                img_PreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                tv_PreApprovedDate.text = ""
                img_PreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }


            if (!statusUpdateTime?.checkedIn.isNullOrEmpty()) {
//            tv_CheckedInDate.text = statusUpdateTime?.checkedIn
                tv_CheckedInDate.text = Util.fseUiDateFormatter(statusUpdateTime?.checkedIn!!)
                //img_CheckedIn
                img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                tv_CheckedInDate.text = ""
                img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }


            if (!statusUpdateTime?.installed.isNullOrEmpty()) {
//            tv_InstallPendDate.text = statusUpdateTime?.installationPending
                tv_InstallPendDate.text = Util.fseUiDateFormatter(statusUpdateTime?.installed!!)
                //img_istallationP
                img_istallationP.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                tv_InstallPendDate.text = ""
                img_istallationP.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }

            if (!statusUpdateTime?.installationVerified.isNullOrEmpty()) {
//            tv_InstallCompleteDate.text = statusUpdateTime?.installed
                tv_InstallCompleteDate.text = Util.fseUiDateFormatter(statusUpdateTime?.installationVerified!!)
                //img_InstallComplete
                img_InstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                tv_InstallCompleteDate.text = ""
                img_InstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }


            if (!statusUpdateTime?.threeWayCallVerification.isNullOrEmpty()) {
                tv_CCverif.text = Util.fseUiDateFormatter(statusUpdateTime?.threeWayCallVerification!!)
                //img_InstallComplete
                img_CCVerif.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                tv_CCverif.text = ""
                img_CCVerif.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }
        }

    }

    fun validate(context: Context, enteredOtp: String) {

        val isValid = isValidOtp(enteredOtp)
        val isOnline = Util.isOnline(context)
        viewModel.processOtp(
                context = context,
                isOnline = isOnline,
                isValid = isValid,
                prospectID = fseProspectResponseModel?.prospectId!!,
                angazaId = loginResponseData?.angazaId!!,
                unsuccessfulAttempt = fseProspectResponseModel?.unsuccessfulOtpAttempts!!,
                country = preference!!.getLoginResponseModel()!!.country!!,
                showProgress = {
                    showProgressDialog(context)
                }
        )?.observe(this, Observer {
            cancelProgressDialog()

            //Util.showToast("Completed Otp", this)

            //if (isOnline && isValid) {
            if (it!!.success) {
                if (isValid) {//going to change in feature

                    Util.customFseCompletionDialog(
                            context = context,
                            title = "OTP Verified",
                            message = "Please proceed to Check-In after 5 minutes.",
                            okSelected = {
                                it.dismiss()
                                //backpress //add your addditional logic here
                                this@VerificationActivity.onBackPressed()
                            })

                }
            } else {
                Util.showToast("Unknown error occurred", this)
            }


            alphaMethod(fseProspectResponseModel!!)

            //do further process after integrating with live/dev api

        })

        if (isValid.not()) {
            Util.customFseCompletionDialog(
                    context = this,
                    hideTitle = true,
                    title = null,
                    message = "Invalid OTP",
                    okSelected = {

                        it.dismiss()
                        otpView.text?.clear()


                    }
            )
        }
    }


    private fun errorMessage(fseProspectResponseModel: FseProspectResponseModel) {
        Util.customFseCompletionDialog(
                context = this,
                hideTitle = true,
                title = null,
                message = fseProspectResponseModel.message,
                okSelected = {

                    it.dismiss()

                }
        )
    }

    private fun isValidOtp(enteredOtp: String): Boolean {
        return enteredOtp == fseProspectResponseModel?.otp!!
    }


	override fun onDestroy() {
		super.onDestroy()
		mHomeWatcher?.stopWatch();

	}*/

}
