package com.greenlightplanet.kazi.leads.view.fragment

import android.app.Dialog
import android.content.DialogInterface
import android.content.res.Resources
import android.os.Build
import android.os.Bundle
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.BottomsheetSearchBinding
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead
import com.greenlightplanet.kazi.leads.view.adapter.CustomerLeadsAdapter


private const val ARG_PARAM1 = "list"


class LeadsButtomSheetSearch : BottomSheetDialogFragment(), CustomerLeadsAdapter.CustomerLeadsAdapterCallback {

	//private  var _binding:BottomsheetSearchBinding ? = null
	//private  val binding get() = _binding!!

	companion object {
		public const val TAG = "LeadsButtomSheetSearch"


		@JvmStatic
		fun newInstance(list: List<LeadsCrossSalesLead>?) =
			LeadsButtomSheetSearch().apply {
				arguments = Bundle().apply {
					putParcelableArrayList(ARG_PARAM1, ArrayList(list!!))
				}

				Log.d(TAG, "list-newInstance:$list ");

			}
	}

	var leadsButtomSheetSearchCallback: LeadsButtomSheetSearchCallback? = null

	private var list: MutableList<LeadsCrossSalesLead> = mutableListOf()
	private var adapterList: MutableList<LeadsCrossSalesLead> = mutableListOf()
	private var adapter: CustomerLeadsAdapter? = null

	private var mBehavior: BottomSheetBehavior<*>? = null
private var  editSearch:EditText ?= null
private var  recycle:RecyclerView ?= null
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)

		arguments?.let {
			list.clear()
			it.getParcelableArrayList<LeadsCrossSalesLead>(ARG_PARAM1)?.let { it1 -> list.addAll(it1) }
		}

		Log.d(TAG, "list-onCreate:$list ");
	}

	override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
		val dialog = super.onCreateDialog(savedInstanceState) as BottomSheetDialog
		//_binding = BottomsheetSearchBinding.inflate(LayoutInflater.from(requireContext()))
		val view = View.inflate(context, R.layout.bottomsheet_search, null)

		val linearLayout: LinearLayout = view.findViewById(R.id.root)
		editSearch = view.findViewById(R.id.editTextSearch)
		recycle = view.findViewById(R.id.recyclerView)
		val params = linearLayout.layoutParams as LinearLayout.LayoutParams
		params.height = getScreenHeight()
		linearLayout.layoutParams = params
		dialog.setContentView(view)
		init(view)
		mBehavior = BottomSheetBehavior.from(view.parent as View)
		return dialog
	}

	fun init(view: View) {
		initRecyclerView(view, list)
		editSearch?.addTextChangedListener(object : TextWatcher {
			override fun afterTextChanged(s: Editable?) {
				s?.let {
					if (s.isEmpty() || s.isBlank()) {
						setAdapter(view, list)
					} else {
						val text = s.toString()

						val result = list?.filter { it.customerName!!.contains(text, true) }
						//Log.d(TAG, "result:$result ");
						setAdapter(view, result)
					}

				}

			}

			override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
				s?.let {
					val text = s.toString()
					Log.d(TAG, "text1:$text ");
				}
			}

			override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
				s?.let {
					val text = s.toString()
					Log.d(TAG, "text1:$text ");
				}
			}
		})

		view.findViewById<ImageView>(R.id.btnCancel).setOnClickListener {
			dismiss()
		}
	}

	override fun onStart() {
		super.onStart()
		mBehavior!!.state = BottomSheetBehavior.STATE_EXPANDED

	}

	private fun getScreenHeight(): Int {
		return Resources.getSystem().getDisplayMetrics().heightPixels
	}


	private fun initRecyclerView(view: View, list: List<LeadsCrossSalesLead>?) {
		val layoutManager = LinearLayoutManager(activity)
		recycle?.layoutManager = layoutManager
		recycle?.addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL).apply {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
				this.setDrawable(resources.getDrawable(R.drawable.line_divider, requireContext().theme))
			} else {
				this.setDrawable(resources.getDrawable(R.drawable.line_divider))
			}
		})

		//visibilityHandler(false, true, false)
		setAdapter(view, list)
	}


	fun setAdapter(view: View, mutableList: List<LeadsCrossSalesLead>?) {
		Log.e(TAG, "mutableList : $mutableList")
		adapterList.clear()
		if (!mutableList.isNullOrEmpty()) {

			//visibilityHandler(true, false, false)


			adapterList.addAll(mutableList)
			if (adapter == null) {
				Log.d(TAG, "adapter : $adapterList")
				adapter = CustomerLeadsAdapter(requireActivity(), adapterList,true)
				adapter?.customerLeadsAdapterCallback = this
				recycle?.adapter = adapter
			}
		}
		adapter?.notifyDataSetChanged()
	}

	override fun onDetach() {
		adapter = null
		super.onDetach()

	}

	override fun gotoCustomerLeadsProfile(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead) {
		dismiss();
		leadsButtomSheetSearchCallback?.gotoCustomerLeadsProfile(position, leadsCrossSalesLead)
	}

	override fun gotoCustomerLeadsFeedback(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead) {
		dismiss();
		leadsButtomSheetSearchCallback?.gotoCustomerLeadsFeedback(position, leadsCrossSalesLead)
	}

	override fun makeCall(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead) {
		dismiss();
		leadsButtomSheetSearchCallback?.makeCall(position, leadsCrossSalesLead)
	}

	override fun requestCallLogPermission(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead) {
		dismiss();
		leadsButtomSheetSearchCallback?.requestCallLogPermission(position, leadsCrossSalesLead)
	}

	interface LeadsButtomSheetSearchCallback {

		fun gotoCustomerLeadsProfile(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead)
		fun gotoCustomerLeadsFeedback(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead)
		fun makeCall(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead)
		fun requestCallLogPermission(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead)

	}

}
