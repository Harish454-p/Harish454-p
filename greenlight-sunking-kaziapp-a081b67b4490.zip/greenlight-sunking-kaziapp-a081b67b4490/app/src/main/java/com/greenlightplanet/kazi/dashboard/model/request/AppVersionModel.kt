package com.greenlightplanet.kazi.dashboard.model.request

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import android.os.Parcelable
import androidx.annotation.NonNull
import com.greenlightplanet.kazi.task.model.response.DateConverter
import kotlinx.android.parcel.Parcelize
import java.util.*


@Entity(tableName = "app_version")
@Parcelize
data class AppVersionModel(

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var _ID: Long? = null,

    @ColumnInfo(name = "angaza_id")
    var angazaId: String?,

    @ColumnInfo(name = "app_version")
    var appVersion: String?,

    @ColumnInfo(name = "imei")
    var imei: String?,

    @ColumnInfo(name = "versionCode")
    var versionCode: Int?,

    @ColumnInfo(name = "model")
    var model: String?,

    @ColumnInfo(name = "android_version")
    var androidVersion: String?,

    @ColumnInfo(name = "version_date")
    var versionDate: String?
) : Parcelable
