package com.greenlightplanet.kazi.collectiongoal.view.fragment

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.collectiongoal.adapter.MakeCallRecyclerAdapter
import com.greenlightplanet.kazi.collectiongoal.extra.CollectionGoalCallDialog
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.collectiongoal.view.activity.CustomerProfileActivity
import com.greenlightplanet.kazi.collectiongoal.view.activity.MakeCallActivity
import com.greenlightplanet.kazi.collectiongoal.viewmodel.MakeCallViewModel
import com.greenlightplanet.kazi.databinding.FragmentMakeCallBinding
import com.greenlightplanet.kazi.leads.extras.LEAD_INTENT
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.newtasks.extras.AdapterUtils
import com.greenlightplanet.kazi.newtasks.extras.PermissionHelper
import com.greenlightplanet.kazi.newtasks.extras.SendingCallStatus
import com.greenlightplanet.kazi.newtasks.model.CommonTaskModel
import com.greenlightplanet.kazi.newtasks.model.FeedbackIntentModel
import com.greenlightplanet.kazi.newtasks.model.TaskResponseModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.summary.model.SummaryCallDetailRequestModel
import com.greenlightplanet.kazi.utils.BaseFragment
import com.greenlightplanet.kazi.utils.Constants
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import timber.log.Timber


class CompletedFragment : BaseFragment(), MakeCallRecyclerAdapter.MakeCallAdapterCallback,
    CollectionGoalCallDialog.CallIntentDialogCallback, SendingCallStatus {

    private var _binding: FragmentMakeCallBinding? = null
    private val binding get() = _binding!!
    val ARG_PARAM1 = "list"
    val ARG_PARAM2 = "type"
    val ARG_PARAM3 = "model"

    private var type: String? = null

    //private var type: Boolean = false
    private var list: MutableList<MakeCallNewModel.ColGoalAccount>? = null
    private var activityInstance: MakeCallActivity? = null

    var makeCallNewModel: MakeCallNewModel? = null

    private val viewModel: MakeCallViewModel by activityViewModels()

    private var adapterList: MutableList<MakeCallNewModel.ColGoalAccount> = mutableListOf()
    private var adapter: MakeCallRecyclerAdapter? = null

    //region mazroid
    var permissionHelper: PermissionHelper? = null
    private var collectionGoalCallDialog: CollectionGoalCallDialog? = null
    private var taskFeedback: List<FeedbackIntentModel.Intents>? = null
    var preference: GreenLightPreference? = null
    private var callReceiver: BroadcastReceiver? = null

    var taskResponseModel: TaskResponseModel? = null

    var sortType = 1
    var sortAttribute = 0
    //endregion
    companion object {
        const val TAG = "CompletedFragment"

        @JvmStatic
        fun newInstance(
            list: List<MakeCallNewModel.ColGoalAccount>?,
            makeCallNewModel: MakeCallNewModel,
            type: String
        ) =
            CompletedFragment().apply {
                arguments = Bundle().apply {
                    putParcelableArrayList(ARG_PARAM1, ArrayList(list!!))
                    putString(ARG_PARAM2, type)
                    putParcelable(ARG_PARAM3, makeCallNewModel)
                    arguments?.clear()
                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            list = it.getParcelableArrayList<MakeCallNewModel.ColGoalAccount>(ARG_PARAM1)
            type = it.getString(ARG_PARAM2)
            makeCallNewModel = it.getParcelable(ARG_PARAM3)
            arguments?.clear()
        }
    }

    val observer1 = Observer<MutableList<MakeCallNewModel.ColGoalAccount>> {

        if (this.lifecycle.currentState == Lifecycle.State.RESUMED) {

            cancelProgressDialog()

            if (it.isNullOrEmpty()) {
                visibilityHandler(false, true, false)
            } else {
                Log.d("CheckTypeFragment1", type.toString())
                Log.d("CheckingSizeMakeFrag1", "${it.size}")

                val CommonList = mutableListOf<MakeCallNewModel.ColGoalAccount>()

                CommonList.addAll(it)

                val priorityList = CommonList.sortedWith(compareBy { it.priority })
                setAdapter(priorityList.toMutableList())
            }

        }

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (!viewModel.completedListDataSend.hasActiveObservers()) {
            viewModel.completedListDataSend.observe(this.viewLifecycleOwner, observer1)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        _binding = FragmentMakeCallBinding.inflate(inflater, container, false)
        activityInstance = (activity as MakeCallActivity?)!!
        preference = GreenLightPreference.getInstance(activityInstance!!)
        permissionHelper = PermissionHelper(activityInstance!!)
        collectionGoalCallDialog = CollectionGoalCallDialog(activityInstance!!,this)
        collectionGoalCallDialog!!.callIntentDialogCallback = this
        viewModel!!.getTaskIntentFromDb().observe(activityInstance!!, Observer {
            taskFeedback = it?.responseData?.intents
            viewModel.getNewTaskFromDb().observe(viewLifecycleOwner, Observer {
                Log.e("$TAG == ", "getNewTaskFromDb ${it!!.success}")
                taskResponseModel = it.responseData
            })
        })

        binding.amountHeader.text = "Amount Collected"
        initRecyclerView(list)
        setUpReceiver()
        val data: LastSaved? = OfferUtils.loadSummaryFromPref(activityInstance!!)
        activityInstance!!.binding.tvTaskLastSaved.text = data?.makeCallSaved

        onClickSorting()
        Log.d("CheckTypeFrag", type.toString())

        savedInstanceState?.clear()

        return binding.root
    }

    private fun onClickSorting() {

        binding.customerNameHeader.setOnClickListener { byCustomerName(adapterList) }
        binding.amountHeader.setOnClickListener { byAmount(adapterList) }
    }

    private fun sortData(
        adapterList: MutableList<MakeCallNewModel.ColGoalAccount>,
        sortAttribute: Int,
        sortType: Int,
    ) {

        val newList = viewModel.applySortCustomerName(sortAttribute,adapterList,sortType)
        setAdapter(newList.toMutableList())
    }


    private fun byCustomerName(adapterList: MutableList<MakeCallNewModel.ColGoalAccount>) {

        sortAttribute = 1
        refreshSortBackground()
        if (adapterList.size > 0) {
            if (sortType == 1) {
                sortType = 0
            } else {
                sortType = 1
            }
            sortData(adapterList, sortAttribute,sortType)
            binding.customerNameHeader.setBackgroundColor(Color.GRAY)
        }

    }

    private fun byAmount(adapterList: MutableList<MakeCallNewModel.ColGoalAccount>) {

        sortAttribute = 2
        refreshSortBackground()
        if (adapterList.size > 0) {
            if (sortType == 1) {
                sortType = 0
            } else {
                sortType = 1
            }
            sortData(adapterList, sortAttribute,sortType)
            binding.amountHeader.setBackgroundColor(Color.GRAY)
        }

    }

    private fun refreshSortBackground() {
        binding.customerNameHeader.setBackgroundColor(Color.BLACK)
        binding.amountHeader.setBackgroundColor(Color.BLACK)
    }

    private fun initRecyclerView(list: MutableList<MakeCallNewModel.ColGoalAccount>?) {

        val layoutManager = LinearLayoutManager(requireActivity())
        binding.recyclerView.layoutManager = layoutManager
        binding.recyclerView.addItemDecoration(
            DividerItemDecoration(
                requireContext(),
                DividerItemDecoration.VERTICAL
            ).apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    this.setDrawable(
                        resources.getDrawable(
                            R.drawable.line_divider,
                            requireContext().theme
                        )
                    )
                } else {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider))
                }
            })

        val priorityList = list?.sortedWith(compareBy { it.priority })
        setAdapter(priorityList?.toMutableList())
//        visibilityHandler(false, true, false)
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun setAdapter(mutableList: MutableList<MakeCallNewModel.ColGoalAccount>?) {

        adapterList.clear()
        if (!mutableList.isNullOrEmpty()) {
            adapterList.addAll(mutableList)
            if (adapter == null) {
                Log.d(TAG, "adapter : $adapterList")
                adapter = MakeCallRecyclerAdapter(requireActivity(), adapterList)
                adapter?.makeCallAdapterCallback = this
                binding.recyclerView.adapter = adapter
            }
            visibilityHandler(true, false, false)
        }
        adapter?.notifyDataSetChanged()
    }


    private fun visibilityHandler(
        showRecyclerView: Boolean = false,
        showNoData: Boolean = false,
        showSearchNoData: Boolean = false
    ) {

        if (showRecyclerView) {
            binding.recyclerView.visibility = View.VISIBLE
        } else {
            binding.recyclerView.visibility = View.GONE
        }

        if (showNoData) {
            binding.tvNoData.visibility = View.VISIBLE
        } else {
            binding.tvNoData.visibility = View.GONE
        }

        if (showSearchNoData) {
            binding.tvSearchedData.visibility = View.VISIBLE
        } else {
            binding.tvSearchedData.visibility = View.GONE
        }
    }

    override fun gotoNewTaskProfile(position: Int, account: MakeCallNewModel.ColGoalAccount) {

        val intent = Intent(requireContext(), CustomerProfileActivity::class.java)
        intent.putExtra("makeCallCustomerData", account)
        requireContext().startActivity(intent)
    }

    override fun makeCall(account: MakeCallNewModel.ColGoalAccount) {
        val list: MutableList<String> = mutableListOf()
        list.clear()
        account.alternateContact1?.let {
            list.add(0, it)
        }
        account.alternateContact2?.let {
            list.add(0, it)
        }
        account.alternateContact3?.let {
            list.add(0, it)
        }
        account.alternateContact4?.let {
            list.add(0, it)
        }
        account.alternateContact5?.let {
            list.add(0, it)
        }
        account.secondaryPhoneNumber?.let {
            list.add(0, it)
        }
        account.ownerPhoneNumber?.let {
            list.add(0, it)
        }


        collectionGoalCallDialog?.newShowPhoneNumberDialog(
            account,
            list.filterNot { it.isNullOrBlank() || it.equals("NA") || it.equals("NULL") },
            taskFeedback,
            !account.isTask!!
        )
    }

    override fun requestCallLogPermission(account: MakeCallNewModel.ColGoalAccount) {
        permissionHelper?.onPermissionGranted = { makeCall(account) }
        permissionHelper?.onPermissionRejected = {
            Util.customFseCompletionDialog(
                context = activityInstance!!,
                hideTitle = true,
                message = getString(R.string.please_allow_call),
                okSelected = {
                    it.dismiss()
                },
                title = null
            )
        }
        permissionHelper?.performPermissionCheck(activityInstance!!)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        permissionHelper?.onRequestPermissionsResult(requestCode, permissions, grantResults)
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun dialogCompleted(summaryCallDetailRequestModel: SummaryCallDetailRequestModel) {
        if (summaryCallDetailRequestModel.callDuration < preference!!.getMinimumCallDuration()!!
            && summaryCallDetailRequestModel.intentId != LEAD_INTENT.DID_NOT_ANSWER
        ) {

            AdapterUtils.taskDurationDialog(
                context = activityInstance!!,
                message = "${getString(R.string.duration)} " + summaryCallDetailRequestModel.callDuration.toString() + "${
                    getString(
                        R.string.sec_time
                    )
                } " + AdapterUtils.durationFormat(
                    summaryCallDetailRequestModel.calledTime
                )!!,//"2021-06-03 07:00:00"
                dialogButton = {
                    it.dismiss()
                },
                title = getString(R.string.calls_duration_low)
            )


        } else {
            Log.e("MAzhar ==>", "Completed ==> ${summaryCallDetailRequestModel}")
            performTask(summaryCallDetailRequestModel)

        }
    }

    private fun performTask(summaryCallDetailRequestModel: SummaryCallDetailRequestModel) {
        summaryCallDetailRequestModel.module = Constants.COLLECTION_GOAL_FLAG
        val observer = Observer<NewCommonResponseModel<NewEmptyParcelable>> {
            Log.e("TAG = performTask = ::", "dialogCompleted: $it ")
            cancelProgressDialog()
            if (summaryCallDetailRequestModel.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
                Util.customFseCompletionDialog(
                    context = activityInstance!!,
                    hideTitle = true,
                    message = getString(R.string.congrats_call_made),
                    okSelected = {
                        it.dismiss()
//                        callSummary()
                    },
                    title = null
                )
            }

        }

        val list: MutableList<CommonTaskModel> = mutableListOf()
        list.clear()
        list.addAll(taskResponseModel!!.called!!)
        list.addAll(taskResponseModel!!.firstCall!!)

        val aa = list.find { it.accountNumber == summaryCallDetailRequestModel.accountNumber }
        val isPresent = aa != null
        Log.e("Maz =$isPresent= ", "${aa}")


        if (Util.isOnline(activityInstance!!)) {
            viewModel.solveTaskCallDetailRequest(summaryCallDetailRequestModel, isPresent) {
                showProgressDialog(activityInstance!!)
            }.observe(this, observer)
        } else {
            viewModel.insertCallDetailRequestToDb(summaryCallDetailRequestModel, isPresent) {
                showProgressDialog(activityInstance!!)
            }.observe(this, observer)
        }
    }

    //region for call status
    private fun setUpReceiver() {
        val intentFilter = IntentFilter()

        callReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {

                try {
                    val state = intent?.getStringExtra(TelephonyManager.EXTRA_STATE);
                    if (state.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                        Timber.d("BROADCAST==: CALL STATE: RINGING")
                    }
                    if (state.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                        Timber.d("BROADCAST==: CALL STATE: Connected")
                    }
                    if (state.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                        // CALL ENDED
                        Timber.d("BROADCAST==: CALL STATE: Disconnected")
                        if (preference?.getIsOnCall()!!) {
                            preference?.setIsOnCall(false)
//                            viewModel.currentTask?.let {
//                                navigateToDynamicFeedbackActivity(task = it)
//                            }
                            isOnCall()

                        }
                    }
                } catch (e1: Exception) {
                    Timber.d("BROADCAST==: CALL STATE: EXCEPTION : $e1")
                    e1.printStackTrace();
                }
            }
        }

        intentFilter.addAction("android.intent.action.PHONE_STATE")
        requireActivity().registerReceiver(callReceiver, intentFilter)

    }
    override fun setOnCall(isOnCall: Boolean) {
        preference?.setIsOnCall(isOnCall)!!
    }

    override fun isOnCall(): Boolean {
        return preference?.getIsOnCall()!!
    }

    //endregion

}
