package com.greenlightplanet.kazi.dashboard.dao

import androidx.room.*
import com.greenlightplanet.kazi.dashboard.model.CountryResponseModel
import io.reactivex.Single
import kotlinx.coroutines.flow.Flow


@Dao
interface CountryDaos {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(location: CountryResponseModel): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(locations: List<CountryResponseModel>): List<Long>

//    @Query("SELECT * FROM location WHERE id = :id")
//    fun selectById(id: Long): Flowable<Location>


    @Query("SELECT * FROM countryProfiles")
    fun selectToAll(): Single<List<CountryResponseModel>>

    @Update
    fun update(location: CountryResponseModel): Int

    @Query("DELETE FROM countryProfiles WHERE id= :id")
    fun deleteById(id: Long): Int

    @Query("DELETE FROM countryProfiles")
    suspend fun deleteAll(): Int
}