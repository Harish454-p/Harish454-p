package com.greenlightplanet.kazi.agentReferral.model.referralStatusDetail


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ReferralStatusDetailModel(
    @SerializedName("referral_details")
    var referralDetails: List<ReferralDetail>?,
) : Parcelable