package com.greenlightplanet.kazi.loyalty.adapter.leaderboard

import android.content.Context
import android.util.Log
import android.view.ViewGroup
import androidx.paging.PagedListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.loyalty.model.leaderboard.User_rank
import com.greenlightplanet.kazi.loyalty.pagging.State


class LeaderBoardAdapter(private val type:String,private val retry: () -> Unit)
    : PagedListAdapter<User_rank, RecyclerView.ViewHolder>(NewsDiffCallback) {


    private val DATA_VIEW_TYPE = 1
    private val FOOTER_VIEW_TYPE = 2
    var listener: onClickItem? = null

    private var state = State.LOADING

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == DATA_VIEW_TYPE) LeaderBoardViewHolder.create(parent) else LeaderBoardFooterViewHolder.create(retry, parent)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        try {
            if (getItemViewType(position) == DATA_VIEW_TYPE)
                getItem(position)?.let { (holder as LeaderBoardViewHolder).bind(it,position,type) }
            else (holder as LeaderBoardFooterViewHolder).bind(state)
        } catch (e: Exception) {
            Log.e("LeaderBoardAdapter", "onBindViewHolder: ${e.localizedMessage}" )
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if (position < super.getItemCount()) DATA_VIEW_TYPE else FOOTER_VIEW_TYPE
    }

    companion object {
        val NewsDiffCallback = object : DiffUtil.ItemCallback<User_rank>() {
            override fun areItemsTheSame(oldItem: User_rank, newItem: User_rank): Boolean {
                return oldItem.rank == newItem.rank
            }

            override fun areContentsTheSame(oldItem: User_rank, newItem: User_rank): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun getItemCount(): Int {
        return super.getItemCount() + if (hasFooter()) 1 else 0
    }

    private fun hasFooter(): Boolean {
        return super.getItemCount() != 0 && (state == State.LOADING || state == State.ERROR || state == State.OFFLINE)
    }

    fun setState(state: State) {
        this.state = state
        notifyItemChanged(super.getItemCount())
    }

    interface onClickItem {

        fun onTab(User_rank: User_rank)


    }
}