package com.greenlightplanet.kazi.leads.dao

import androidx.room.*
import com.greenlightplanet.kazi.leads.model.LeadsIntent
import io.reactivex.Single

@Dao
interface LeadsIntentDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(LeadsIntent: List<LeadsIntent>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(LeadsIntent: LeadsIntent): Long

    @Delete
    fun delete(LeadsIntent: LeadsIntent): Int

    @Query("DELETE FROM LeadsIntent")
    fun deleteAll(): Int

    @Query("SELECT * FROM LeadsIntent")
    fun getAll(): Single<List<LeadsIntent>>

    @Query("SELECT * FROM LeadsIntent LIMIT 1")
    fun get(): Single<LeadsIntent>

    @Query("SELECT * FROM LeadsIntent WHERE intent_id=:intentId LIMIT 1")
    fun getByLeadsIntentById(intentId: Int): Single<LeadsIntent>

    @Query("SELECT COUNT(*) from LeadsIntent")
    fun count(): Single<Int>

}
