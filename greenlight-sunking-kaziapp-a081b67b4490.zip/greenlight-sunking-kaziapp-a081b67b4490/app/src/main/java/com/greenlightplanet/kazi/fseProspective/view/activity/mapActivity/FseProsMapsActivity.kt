package com.greenlightplanet.kazi.fseProspective.view.activity.mapActivity

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.annotation.SuppressLint
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.location.Location
import android.os.Build
import android.os.Bundle
import android.os.Handler
import androidx.core.content.ContextCompat
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.view.ViewAnimationUtils
import android.view.animation.AccelerateDecelerateInterpolator
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivityFseProsMapsBinding
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import pl.charmas.android.reactivelocation2.ReactiveLocationProvider


class FseProsMapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private var circle: Circle? = null
    private var LAT: Double? = null
    private var LONG: Double? = null
    var preference: GreenLightPreference? = null
    private val bag: CompositeDisposable = CompositeDisposable()
    var CurrentLoc: LatLng? = null
    var mCurrLocationMarker: Marker? = null
    var markerAdded = false
    var radius: Int = 0
    var mHomeWatcher: HomeWatcher? = null
    private lateinit var binding: ActivityFseProsMapsBinding

    companion object {
        val TAG = "FseProsMapsActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_fse_pros_maps)
        binding = ActivityFseProsMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        preference = GreenLightPreference.getInstance(this)

        if (intent.hasExtra("radius")) {
            radius = intent.getIntExtra("radius", 0)
        }


        //radius = Util.getProspectDistance(this,preference?.getLoginResponseModel()?.country!!)?.mapCircleRadius?.toDouble()!!

        Log.d(TAG, "radius-radius:${radius} ");

        LAT = preference!!.getLAT()!!.toDouble()
        LONG = preference!!.getLONG()!!.toDouble()

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @SuppressLint("RestrictedApi")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        getCurrentLoc().observe(this, Observer {
            it?.let {
                Log.e("|| == ", "${it.latitude},${it.longitude}")
                setCurreMarker(it.latitude, it.longitude)
            }
        })


        // Add a marker in Sydney and move the camera
        val sydney = LatLng(LAT!!, LONG!!)
        mMap.addMarker(
            MarkerOptions().position(sydney).title("Your Base Location")
                .icon(bitmapDescriptorFromVector(this, R.drawable.ic_base_home_24dp))
        )
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 11.0f))

        drawCircle(LAT!!, LONG!!, radius * 1000)


        //SATATLITE VIEW


        // Initialise the map variable

        // When map is initially loaded, determine which map type option to 'select'
        when {
            mMap.mapType == GoogleMap.MAP_TYPE_SATELLITE -> {
                binding.mapTypeSatelliteBackground.visibility = View.VISIBLE
                binding.mapTypeSatelliteText.setTextColor(Color.BLUE)
            }
            mMap.mapType == GoogleMap.MAP_TYPE_TERRAIN -> {
                binding.mapTypeTerrainBackground.visibility = View.VISIBLE
                binding.mapTypeTerrainText.setTextColor(Color.BLUE)
            }
            else -> {
                binding.mapTypeDefaultBackground.visibility = View.VISIBLE
                binding.mapTypeDefaultText.setTextColor(Color.BLUE)
            }
        }

        // Set click listener on FAB to open the map type selection view
        binding.mapTypeFAB.setOnClickListener {

            // Start animator to reveal the selection view, starting from the FAB itself
            val anim = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                ViewAnimationUtils.createCircularReveal(
                    binding.mapTypeSelection,
                    binding.mapTypeSelection.width - (binding.mapTypeFAB.width / 2),
                    binding.mapTypeFAB.height / 2,
                    binding.mapTypeFAB.width / 2f,
                    binding.mapTypeSelection.width.toFloat()
                )
            } else {
                TODO("VERSION.SDK_INT < LOLLIPOP")
            }

            anim.duration = 200
            anim.interpolator = AccelerateDecelerateInterpolator()

            anim.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationStart(animation: Animator) {
                    super.onAnimationEnd(animation)
                    binding.mapTypeSelection.visibility = View.VISIBLE
                }
            })

            anim.start()
            binding.mapTypeFAB.visibility = View.INVISIBLE

        }

        // Set click listener on the map to close the map type selection view
        mMap.setOnMapClickListener {

            // Conduct the animation if the FAB is invisible (window open)
            if (binding.mapTypeFAB.visibility == View.INVISIBLE) {

                // Start animator close and finish at the FAB position
                val anim = ViewAnimationUtils.createCircularReveal(
                    binding.mapTypeSelection,
                    binding.mapTypeSelection.width - (binding.mapTypeFAB.width / 2),
                    binding.mapTypeFAB.height / 2,
                    binding.mapTypeSelection.width.toFloat(),
                    binding.mapTypeFAB.width / 2f
                )
                anim.duration = 200
                anim.interpolator = AccelerateDecelerateInterpolator()

                anim.addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        super.onAnimationEnd(animation)
                        binding.mapTypeSelection.visibility = View.INVISIBLE
                    }
                })

                // Set a delay to reveal the FAB. Looks better than revealing at end of animation
                Handler().postDelayed({
                    kotlin.run {
                        binding.mapTypeFAB.visibility = View.VISIBLE
                    }
                }, 100)
                anim.start()
            }
        }

        // Handle selection of the Default map type
        binding.mapTypeDefault.setOnClickListener {
            binding.mapTypeDefaultBackground.visibility = View.VISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.INVISIBLE
            binding.mapTypeTerrainBackground.visibility = View.INVISIBLE
            binding.mapTypeDefaultText.setTextColor(Color.BLUE)
            binding.mapTypeSatelliteText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeTerrainText.setTextColor(Color.parseColor("#808080"))
            mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
        }

        // Handle selection of the Satellite map type
        binding.mapTypeSatellite.setOnClickListener {
            binding.mapTypeDefaultBackground.visibility = View.INVISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.VISIBLE
            binding.mapTypeTerrainBackground.visibility = View.INVISIBLE
            binding.mapTypeDefaultText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeSatelliteText.setTextColor(Color.BLUE)
            binding.mapTypeTerrainText.setTextColor(Color.parseColor("#808080"))
            mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
        }

        // Handle selection of the terrain map type
        binding.mapTypeTerrain.setOnClickListener {
            binding.mapTypeDefaultBackground.visibility = View.INVISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.INVISIBLE
            binding.mapTypeTerrainBackground.visibility = View.VISIBLE
            binding.mapTypeDefaultText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeSatelliteText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeTerrainText.setTextColor(Color.BLUE)
            mMap.mapType = GoogleMap.MAP_TYPE_TERRAIN
        }


    }


    fun setCurreMarker(Lat: Double, Longg: Double) {
        CurrentLoc = LatLng(Lat, Longg)


        val markerOptions = MarkerOptions()
        markerOptions.position(CurrentLoc!!)
        markerOptions.title("Current Position")
//        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN))
        markerOptions.icon(bitmapDescriptorFromVector(this, R.drawable.ic_current_location_24dp))


        if (!markerAdded) {
            mCurrLocationMarker = mMap.addMarker(markerOptions)
            markerAdded = true
            mMap.moveCamera(CameraUpdateFactory.newLatLng(CurrentLoc))
            mMap.animateCamera(CameraUpdateFactory.zoomTo(11f))
        }

    }

    fun getCurrentLoc(): MutableLiveData<Location> {

        val data = MutableLiveData<Location>()

        bag.add(
            newGetCurrentLocation(this)!!.subscribe({
                data.postValue(it)

            }, {
                data.postValue(null)
            })
        )
        return data
    }

    @SuppressLint("MissingPermission")
    fun newGetCurrentLocation(context: Context): Observable<Location>? {
        val request = LocationRequest.create() //standard GMS LocationRequest
            .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            .setNumUpdates(50).setInterval(20)

        val locationProvider = ReactiveLocationProvider(context)
        return locationProvider.getUpdatedLocation(request)

    }

    private fun drawCircle(latitude: Double, longitude: Double, radius: Int) {
        val circleOptions = CircleOptions()
            .center(LatLng(latitude, longitude))
            .radius(radius.toDouble())
            .strokeWidth(2.0f)
            .strokeColor(ContextCompat.getColor(this, R.color.colorPrimaryDark))
            .fillColor(ContextCompat.getColor(this, R.color.colorMapShadow))
        circle?.remove() // Remove old circle.
        circle = mMap.addCircle(circleOptions) // Draw new circle.
    }

    private fun bitmapDescriptorFromVector(context: Context, vectorResId: Int): BitmapDescriptor {
        val vectorDrawable = ContextCompat.getDrawable(context, vectorResId)
        vectorDrawable!!.setBounds(
            0,
            0,
            vectorDrawable.intrinsicWidth,
            vectorDrawable.intrinsicHeight
        )
        val bitmap =
            Bitmap.createBitmap(
                vectorDrawable.intrinsicWidth,
                vectorDrawable.intrinsicHeight,
                Bitmap.Config.ARGB_8888
            )
        val canvas = Canvas(bitmap)
        vectorDrawable.draw(canvas)
        return BitmapDescriptorFactory.fromBitmap(bitmap)

    }

    override fun onDestroy() {
        super.onDestroy()
        bag.clear()
        mHomeWatcher?.stopWatch();
    }

}
