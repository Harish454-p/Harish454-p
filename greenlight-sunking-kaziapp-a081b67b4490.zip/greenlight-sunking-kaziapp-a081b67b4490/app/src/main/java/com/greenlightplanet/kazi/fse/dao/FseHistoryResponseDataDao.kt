package com.greenlightplanet.kazi.fse.dao

import androidx.room.*
import com.greenlightplanet.kazi.fse.model.FseHistoryResponse
import io.reactivex.Single

@Dao
interface FseHistoryResponseDataDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(FseHistoryResponseData: List<FseHistoryResponse.ResponseData?>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(FseHistoryResponseData: FseHistoryResponse.ResponseData): Long

    @Delete
    fun delete(Fse: FseHistoryResponse.ResponseData): Int

    @Query("DELETE FROM FseHistoryResponseData")
    fun deleteAll(): Int

    @Query("SELECT * FROM FseHistoryResponseData")
    fun getAll(): Single<List<FseHistoryResponse.ResponseData>>


    @Query("SELECT * FROM FseHistoryResponseData LIMIT 1")
    fun get(): Single<FseHistoryResponse.ResponseData>


    /*@Query("SELECT * FROM fse WHERE accountNumber=:accountNumber LIMIT 1")
    fun getNameById(accountNumber: String): Single<FseHistoryResponse.ResponseData>*/

    @Query("SELECT COUNT(*) from FseHistoryResponseData")
    fun count(): Single<Int>

}


