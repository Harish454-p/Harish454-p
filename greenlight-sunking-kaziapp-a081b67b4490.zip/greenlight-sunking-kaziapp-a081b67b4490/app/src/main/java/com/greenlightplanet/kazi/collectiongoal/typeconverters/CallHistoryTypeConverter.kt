package com.greenlightplanet.kazi.collectiongoal.typeconverters

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistory


class CallHistoryTypeConverter {

    @TypeConverter
    fun fromCollection(crlist: List<CallHistory>?): String? {
        if (crlist == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<CallHistory>>() {

        }.type
        return gson.toJson(crlist, type)
    }

    @TypeConverter
    fun toCollectionList(clList: String?): List<CallHistory>? {
        if (clList == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<CallHistory>>() {

        }.type
        return gson.fromJson(clList, type)
    }
}