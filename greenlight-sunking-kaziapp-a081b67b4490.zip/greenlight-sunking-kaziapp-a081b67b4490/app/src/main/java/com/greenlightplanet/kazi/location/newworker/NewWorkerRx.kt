package com.greenlightplanet.kazi.location.newworker

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.RxWorker
import androidx.work.WorkerParameters
import com.greenlightplanet.kazi.location.dao.LocationRequestDao
import com.greenlightplanet.kazi.KaziApplication
import com.greenlightplanet.kazi.location.worker.WorkManagerFactory
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.Single

class NewWorkerRx(private val context: Context, workerParams: WorkerParameters) :
	RxWorker(context, workerParams) {

	private var mContext: Context? = null

	var preference: GreenLightPreference? = null
	private var localDb: AppDatabase? = null
	private lateinit var dao: LocationRequestDao

	lateinit var projectXLogic: ProjectXLogic

	companion object {
		public const val TAG = "NewWorkerRx"
	}

	override fun createWork(): Single<Result> {
		Log.d(TAG, "createWork: ");

		initialize(context)



		return if (preference?.getLoginResponseModel() != null) {
//			if (true) {
			if (preference?.getLastCalledNewWorker()!! <= 0 || (System.currentTimeMillis() - preference?.getLastCalledNewWorker()!!.toLong()) >= WORKER_MINI_DIFF.DIFF_MILLI) {
				projectXLogic.performRxWM(mContext!!, preference?.getLoginResponseModel()?.angazaId!!)
					.onErrorResumeNext {
						it.printStackTrace()
						nextTrigger(mContext!!)
						Single.just(Result.success())
					}
					.map {
						nextTrigger(mContext!!)
						Result.success()
					}

			} else {
				nextTrigger(mContext!!)
				Single.just(Result.success())
			}
//			projectXLogic.performRx(mContext!!, preference?.getLoginResponseModel()?.angazaId!!)
//				.map {
//					Result.success()
//				}
		} else {
			nextTrigger(mContext!!)
			Single.just(Result.success())
		}.onErrorResumeNext {
			nextTrigger(mContext!!)
			Single.just(Result.success())
		}

	}


	fun initialize(context: Context) {

		mContext = context

		preference = GreenLightPreference.getInstance(mContext!!)
		localDb = AppDatabase.getAppDatabase(mContext!!)
		dao = localDb!!.locationRequestDao()
		preference?.setLastCalledWorker(System.currentTimeMillis())

		projectXLogic = ProjectXLogic(context, preference!!, dao)

	}


	fun nextTrigger(context: Context) {
		NewAlarmUtils.setNewAlarm(context, WORKER_INTERVAL.ALARM_INTERVAL)

		if (!NewAlarmUtils.repeatAlreadyExists(context)) {
			NewAlarmUtils.setRepeatAlarm(context)
		}

//		if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {

			WorkManagerFactory.makeWorkOneTime(WORKER_INTERVAL.WM_INTERVAL)

			if (!WorkManagerFactory.isWorkScheduled(WORKER_DEFAULT_CONST.WM_TAG)) {
				WorkManagerFactory.scheduleWork(WORKER_DEFAULT_CONST.WM_TAG, WORKER_INTERVAL.WM_INTERVAL)
			}
//		}

//		if(!NewFourgroundService.is_service_running){}
		val service = Intent(context, NewFourgroundService::class.java)
		service.action = KaziApplication.STARTFOREGROUND_ACTION
		context.startService(service)
	}

}
