package com.greenlightplanet.kazi.location.model.googlegeolocation


import com.google.gson.annotations.SerializedName

data class GoogleGeoLoationRequest(
	@SerializedName("carrier")
	var carrier: String?, // Vodafone
	@SerializedName("cellTowers")
	var cellTowers: List<CellTower>?,
	@SerializedName("considerIp")
	var considerIp: String?, // true
	@SerializedName("homeMobileCountryCode")
	var homeMobileCountryCode: Int?, // 310
	@SerializedName("homeMobileNetworkCode")
	var homeMobileNetworkCode: Int?, // 410
	@SerializedName("radioType")
	var radioType: String?, // gsm
	@SerializedName("wifiAccessPoints")
	var wifiAccessPoints: List<WifiAccessPoint>?
)
