package com.greenlightplanet.kazi.fseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.location.Location
import com.greenlightplanet.kazi.fseProspective.model.CombineRequestModel
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseData
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseModel
import com.greenlightplanet.kazi.fseProspective.model.RegistrationCheckinRequestModel
import com.greenlightplanet.kazi.fseProspective.repo.ProspectiveRepo
import com.greenlightplanet.kazi.fseProspective.repo.RegistrationRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable

class RegistrationViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "RegistrationViewModel"

    }

    val repo = RegistrationRepo.getInstance(application)
    private val repository = ProspectiveRepo(context = application.applicationContext)

    fun processCheckIn(context: Context, isOnline: Boolean, prospectID: String, angazaId: String, area: String,  prospectAllowedDistance: Int,showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

        showProgress()

        return repo.performCheckin(context, isOnline, prospectID, angazaId, area,prospectAllowedDistance)

    }


    fun processCheckIn2(context: Context, isOnline: Boolean, prospectID: String, angazaId: String, area: String, location: Location, prospectAllowedDistance: Int, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

        showProgress()

        return repo.performCheckin2(context, isOnline, prospectID, angazaId, area, location,prospectAllowedDistance)


    }

    fun getCombineRequestModel(prospectID: String): MutableLiveData<CombineRequestModel?> {
        return repo.getCombineRequestModel(prospectID)
    }

    fun sendRegistrationCheckinRequestToServerForceUpload(registrationCheckinRequestModel: RegistrationCheckinRequestModel, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return repo.sendRegistrationCheckinRequestToServerForceUpload(registrationCheckinRequestModel)
    }

    fun getFseProspectiveFromServer(angazaId: String, prospectId: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>? {
        showProgress()
        return repo.getFseProspectiveFromServer(angazaId, prospectId)
    }

    //region registration list...
    fun getFseProspectiveFromDatabase() : MutableLiveData<NewCommonResponseModel<FseProspectResponseData>> {
        return repository.getFseProspectiveFromDatabase()!!
    }
    //endregion

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
        repository.destroy()
    }

}
