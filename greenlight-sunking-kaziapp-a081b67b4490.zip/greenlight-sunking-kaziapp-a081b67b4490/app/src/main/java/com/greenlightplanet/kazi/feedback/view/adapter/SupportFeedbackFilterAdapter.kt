package com.greenlightplanet.kazi.feedback.view.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.ItemFeedbackSupportRvBinding
import com.greenlightplanet.kazi.feedback.repo.model.response.TicketResponseData
import timber.log.Timber
import java.lang.ref.WeakReference

class SupportFeedbackFilterAdapter(): RecyclerView.Adapter<SupportFeedbackFilterAdapter.ViewHolder>() {
    lateinit var binding: ItemFeedbackSupportRvBinding
    var dataList = mutableListOf<TicketResponseData>()
    lateinit var listener: WeakReference<SupportFeedbackFilterAdapterClickListener>
    val TAG = "SupportFilterAdapter"
    var isClosed = false
    var isPending = false


    fun setRvData(list: List<TicketResponseData>, isStatusClosed: Boolean = false, isStatusPending: Boolean = false) {
        clearRvData()
        val sortedList = mutableListOf<TicketResponseData>()
        sortedList.addAll(list)
        if (isStatusClosed) sortedList.sortByDescending {
            it.getClosedAtTimeStampLocal()
        }
        if (isStatusPending) sortedList.sortByDescending {
            it.getCreatedAtTimeStampLocal()
        }
        isClosed = isStatusClosed
        isPending = isStatusPending
        Log.d(TAG,"$TAG: AdapterList -> $list")
        dataList.addAll(sortedList)
        notifyDataSetChanged()

    }
    fun clearRvData() {
        dataList.clear()
        isClosed = false
        isPending = false
        Log.d(TAG,"$TAG: AdapterList Cleared ")
        notifyDataSetChanged()

    }


    fun attachListener(clickListener: WeakReference<SupportFeedbackFilterAdapterClickListener>) {
        listener = clickListener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        binding = ItemFeedbackSupportRvBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (dataList.isNotEmpty()) {
            dataList[position].let {
                holder.bind(it)
                Log.d(TAG ,"$TAG: onBind -> Position: $position | Item: $it")
            }
        }
    }


    inner class ViewHolder(private val vBinding: ItemFeedbackSupportRvBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(holdingData: TicketResponseData) {
            Timber.d("Paging : RvItem : $holdingData")
            if (isClosed) {
                vBinding.tvTicketIdValue.text = holdingData.ticketId
                vBinding.tvCloseDateValue.text = holdingData.getClosedAtUtcToLocal()
                vBinding.tvCategoryValue.text = holdingData.category?:""
                vBinding.tvSubCategoryValue.text = holdingData.subCategory?:""
                Timber.d("Paging : RvItem : ConvertedClosedDate ${holdingData.getClosedAtUtcToLocal()} || TS: ${holdingData.getCreatedAtTimeStampUtc()}")
            }
            if (isPending) {
                vBinding.tvTicketIdValue.text = holdingData.ticketId
                vBinding.tvCloseDateTitle.text = "Raised At"
                vBinding.tvCloseDateValue.text = holdingData.getCreatedAtUtcToLocal()
                vBinding.tvCategoryValue.text = holdingData.category?:""
                vBinding.tvSubCategoryValue.text = holdingData.subCategory?:""
                Timber.d("Paging : RvItem : ConvertedPendingDate ${holdingData.getCreatedAtUtcToLocal()} || TS: ${holdingData.getClosedAtTimeStampUtc()}")
            }

            vBinding.ivNext.setOnClickListener {
                listener.get()?.onTicketItemClickedFilter(holdingData)
            }

        }
    }

    override fun getItemCount(): Int = dataList.size


}

interface SupportFeedbackFilterAdapterClickListener{
    fun onTicketItemClickedFilter(data: TicketResponseData)
}