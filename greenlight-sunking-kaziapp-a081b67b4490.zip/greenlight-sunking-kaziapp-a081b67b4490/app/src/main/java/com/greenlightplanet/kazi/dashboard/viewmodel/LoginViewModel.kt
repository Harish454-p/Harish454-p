package com.greenlightplanet.kazi.dashboard.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.dashboard.model.CountryResponseModel
import com.greenlightplanet.kazi.dashboard.model.request.LoginRequestModel
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.dashboard.repo.LoginRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.task.model.dialogIntent.FeedbackModel


class LoginViewModel(application: Application) : AndroidViewModel(application) {

    val repo = LoginRepo.getInstance(application)

    fun getCountryList(context: Context): MutableLiveData<List<CountryResponseModel>> {
        return repo!!.getCountryList(context)
    }
   /* fun login(context: Context, loginRequestModel: LoginRequestModel): MutableLiveData<NewCommonResponseModel<LoginResponseModel>?> {
        return repo.login(context, loginRequestModel)
    }*/
}