package com.greenlightplanet.kazi.leads.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "LeadsResponseModel")
//@TypeConverters(CrossSalesLeadConverter::class, LeadsCallDetailConverter::class)
data class LeadsResponseModel(
        @PrimaryKey
        var id: Int = 1,
        //@ColumnInfo(name = "crossSalesLeads")
        @ColumnInfo(name = "pendingLeads")
        @SerializedName("pendingLeads")
        var pendingLeads: Int?, // 9

        @ColumnInfo(name = "leadVersion")
        @SerializedName("leadVersion")
        var leadVersion: Int? ,// 9,

        @ColumnInfo(name = "totalAssigned")
        @SerializedName("totalAssigned")
        var totalAssigned: Int? ,// 9,

        @ColumnInfo(name = "totalConverted")
        @SerializedName("totalConverted")
        var totalConverted: Int? ,// 9,

        @ColumnInfo(name = "leadFollowupLimit")
        @SerializedName("leadFollowupLimit")
        var leadFollowupLimit: String? ,// 7,


        @ColumnInfo(name = "daysPercentageLeadsConverted")
        @SerializedName("30daysPercentageLeadsConverted")
        var daysPercentageLeadsConverted: Double? // 9,

) : Parcelable {

    @SerializedName("crossSalesLeads")
    @Ignore
    var crossSalesLeads: List<LeadsCrossSalesLead>? = null

    override fun toString(): String {
        return "LeadsResponseModel(id=$id, pendingLeads=$pendingLeads, crossSalesLeads=$crossSalesLeads)"
    }


}

