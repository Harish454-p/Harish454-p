package com.greenlightplanet.kazi.agentReferral.repo

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.agentReferral.model.agentreferral.AgentReferralModel
import com.greenlightplanet.kazi.agentReferral.model.agentreferral.Pagination
import com.greenlightplanet.kazi.agentReferral.model.agentreferral.SuccessfullyReferredAgent
import com.greenlightplanet.kazi.agentReferral.model.referralStatus.ReferralStatusModel
import com.greenlightplanet.kazi.agentReferral.model.referralStatusDetail.ReferralDetail
import com.greenlightplanet.kazi.agentReferral.model.referralStatusDetail.ReferralStatusDetailModel
import com.greenlightplanet.kazi.agentReferral.model.referredagentlist.ReferredAgentModel
import com.greenlightplanet.kazi.agentReferral.model.submitAgent.NewAgentRequestModel
import com.greenlightplanet.kazi.agentReferral.model.submitAgent.NewAgentResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.Flowable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.lang.Exception

class AgentReferralRepo(val context: Context) {

    private var territory: String? = null
    private var country : String? = null
    private val TAG : String = "AgentReferralRepo"
    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    private var angazaId : String? = null
    private val module : String = "Kazi"

    init {
        try{
            preference = GreenLightPreference.getInstance(context)
            localDb = AppDatabase.getAppDatabase(context)
            GreenLightPreference.getInstance(context).getLoginResponseModel()?.let { loginResponseModel ->
                angazaId = loginResponseModel.angazaId
                territory = loginResponseModel.territory
                country = loginResponseModel.country
            }
//            territory = "KENYA::NA::NA::BOMET"
//            angazaId = "US1234567"
        } catch (e : Exception) {
            Log.e(TAG,"error in initiating $TAG class : ${e.localizedMessage}")
        }
    }



    fun agentReferralListFromServer(
        pageSize : Int?,
        page : Int?
    ) : MutableLiveData<NewCommonResponseModel<AgentReferralModel>> {
        val data : MutableLiveData<NewCommonResponseModel<AgentReferralModel>> = MutableLiveData()
        Log.e(TAG,"found angaza-------->>id as $angazaId")
        bag.add(
            ServiceInstance.getInstance(context).serviceAgentReferral?.getAgentReferrals(
                angaza_id = angazaId!!,
                page_size = pageSize,
                page = page,
                module = module,
                user_id = angazaId
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(
                    {success ->
                        preference?.setAgentReferralLastSync(Util.getCurrentLocalFormattedDateForSync())
                        Log.e(TAG,"get response from api as $success")
                        insertAgentReferral(data, success)
                    },
                    {error ->
                        data.postValue(NewCommonResponseModel<AgentReferralModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from server"
                            ),
                            success = false
                        ))
                        Log.e(TAG,"error as ${error.localizedMessage}")
                    }
                )
        )
        return data
    }

    private fun insertAgentReferral(
        data: MutableLiveData<NewCommonResponseModel<AgentReferralModel>>,
        response : AgentReferralModel?
    ) : Disposable {
        return Flowable.fromCallable {
            localDb?.agentReferralDao()?.deleteAllAgentReferral()
            localDb?.agentReferralDao()?.insertAgentReferral(response!!)
        }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe(
                {
                    Log.e(TAG,"data inserted successfully")
                    data.postValue(NewCommonResponseModel(
                        responseData = response!!,
                        success = true
                    ))
                },
                {error ->
                    Log.e(TAG,"error in inserting data")
                    data.postValue(NewCommonResponseModel<AgentReferralModel>(
                        error = NewCommonResponseModel.Error(
                            messageToUser = "Unable insert data from database : ${error.localizedMessage}"
                        ),
                        success = false
                    ))
                    Log.e(TAG,"error as ${error.localizedMessage}")

                }
            )
    }

    fun agentReferralListFromDb() : MutableLiveData<NewCommonResponseModel<AgentReferralModel>> {
        val data : MutableLiveData<NewCommonResponseModel<AgentReferralModel>> = MutableLiveData()
        localDb?.let { appDatabase ->
            bag.add(
                appDatabase.agentReferralDao().getAgentReferral()
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(
                        { success ->
                            Log.e(TAG,"found data from db as ${success.size}")
                            val refList : ArrayList<SuccessfullyReferredAgent> = ArrayList<SuccessfullyReferredAgent>()
                            success.forEach {
                                it.successfullyReferredAgents?.let { list ->
                                    refList.addAll(ArrayList(list))
                                }
                            }
                            data.postValue(
                                NewCommonResponseModel(
                                    responseData = AgentReferralModel(
                                        pagination = Pagination(
                                            pageSize = success[0].pagination!!.pageSize,
                                            page = success[0].pagination!!.page,
                                            endOfStream = true
                                        ),
                                        length = success[0].length,
                                        id = success[0].id,
                                        referredAgentsMetrics = success[0].referredAgentsMetrics,
                                        successfullyReferredAgents = refList
                                    ),
                                    success = true
                                )
                            )
                        },
                        { error ->
                            Log.e(TAG,"error in parsing data from database")
                            data.postValue(NewCommonResponseModel<AgentReferralModel>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from database : ${error.localizedMessage}"
                                ),
                                success = false
                            ))
                            Log.e(TAG,"error as ${error.localizedMessage}")
                        }
                    )
            )
        }
        return data
    }

    //region referred agent list
    fun getReferredAgentList(
        page : Int?,
        pageSize: Int?
    ) : MutableLiveData<NewCommonResponseModel<ReferredAgentModel>> {
        val data : MutableLiveData<NewCommonResponseModel<ReferredAgentModel>> = MutableLiveData()
        Log.e(TAG,"found angaza-------->>id as $angazaId")
        bag.add(
            ServiceInstance.getInstance(context).serviceAgentReferral?.getReferredAgentsList(
                angaza_id = angazaId!!,
                page = page,
                page_size = pageSize,
                user_id = angazaId,
                module = module
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(
                    { success ->
                        preference?.setReferredAgentLAstSync(Util.getCurrentLocalFormattedDateForSync())
                        Log.e(TAG,"receive response from api as $success")
                        insertAllList(data, success)
                    },
                    { error ->
                        data.postValue(NewCommonResponseModel<ReferredAgentModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from server"
                            ),
                            success = false
                        ))
                        Log.e(TAG,"error as ${error.localizedMessage}")
                    }
                )
        )
        return data
    }

    private fun insertAllList(
        data: MutableLiveData<NewCommonResponseModel<ReferredAgentModel>>,
        success: ReferredAgentModel?
    ) : Disposable {
        return Flowable.fromCallable {
            localDb?.referredAgentsDao()?.deleteAllAgentReferral()
            localDb?.referredAgentsDao()?.insertAllAgentReferral(referredAgents = success?.referredAgents!!)
        }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe(
                {
                    Log.e(TAG,"data inserted successfully")
                    data.postValue(NewCommonResponseModel(
                        responseData = success!!,
                        success = true
                    ))
                },
                { error ->
                    Log.e(TAG,"error in inserting data")
                    data.postValue(NewCommonResponseModel<ReferredAgentModel>(
                        error = NewCommonResponseModel.Error(
                            messageToUser = "Unable insert data from database : ${error.localizedMessage}"
                        ),
                        success = false
                    ))
                    Log.e(TAG,"error as ${error.localizedMessage}")
                }
            )
    }

    fun getReferredAgentListFromDB() : MutableLiveData<NewCommonResponseModel<ReferredAgentModel>> {
        val data : MutableLiveData<NewCommonResponseModel<ReferredAgentModel>> = MutableLiveData()
        localDb?.let { appDatabase ->
            bag.add(
                appDatabase.referredAgentsDao().getAgentReferral()
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(
                        { refList ->
                            when {
                                refList.isNotEmpty() -> {
                                    Log.e(TAG,"receive list as ${refList.size}")
                                    val referredAgentModel : ReferredAgentModel = ReferredAgentModel(
                                        length = refList.size,
                                        pagination = com.greenlightplanet.kazi.agentReferral.model.referredagentlist.Pagination(
                                            page = "0",
                                            pageSize = "20",
                                            endOfStream = true
                                        ),
                                        referredAgents = refList
                                    )

                                    data.postValue(
                                        NewCommonResponseModel(
                                            responseData = referredAgentModel,
                                            success = true
                                        )
                                    )
                                }
                                else -> {
                                    data.postValue(NewCommonResponseModel<ReferredAgentModel>(
                                        error = NewCommonResponseModel.Error(
                                            messageToUser = "No Data in Database"
                                        ),
                                        success = false
                                    ))
                                }
                            }
                        },
                        { error ->
                            Log.e(TAG,"error in parsing data from database")
                            data.postValue(NewCommonResponseModel<ReferredAgentModel>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from database : ${error.localizedMessage}"
                                ),
                                success = false
                            ))
                            Log.e(TAG,"error as ${error.localizedMessage}")
                        }
                    )
            )
        }
        return data
    }
    //endregion

    //region referral status...
    fun getReferralStatus(childPhone: String) : MutableLiveData<NewCommonResponseModel<ReferralStatusModel>> {
        val data : MutableLiveData<NewCommonResponseModel<ReferralStatusModel>> = MutableLiveData()
        bag.add(
            ServiceInstance.getInstance(context).serviceAgentReferral?.getReferralStatus(
                child_phone_number = childPhone,
                user_id = angazaId,
                module = module
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(
                    { response ->
                        preference?.setReferralStatusLastSync(Util.getCurrentLocalFormattedDateForSync())
                        Log.e(TAG,"receive new response as $response")
                        insertReferralStatus(data, response)
                    },
                    { error ->
                        Log.e(TAG,"error in getting data from api")
                        data.postValue(NewCommonResponseModel<ReferralStatusModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from api : ${error.localizedMessage}"
                            ),
                            success = false
                        ))
                        Log.e(TAG,"api error as ${error.localizedMessage}")
                    }
                )
        )
        return data
    }

    private fun insertReferralStatus(
        data: MutableLiveData<NewCommonResponseModel<ReferralStatusModel>>,
        response: ReferralStatusModel?
    ) : Disposable {
        return Flowable.fromCallable {
            localDb?.let { appDatabase ->
                appDatabase.referralStatusDao().deleteAllAgentReferral()
                appDatabase.referralStatusDao().insertAllAgentReferral(response?.referrals!!)
            }
        }.subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe(
                {
                    Log.e(TAG,"successful in inserting data")
                    data.postValue(
                      NewCommonResponseModel(
                          responseData = response!!,
                          success = true
                      )
                    )
                },
                { error ->
                    Log.e(TAG,"error in inserting data")
                    data.postValue(NewCommonResponseModel<ReferralStatusModel>(
                        error = NewCommonResponseModel.Error(
                            messageToUser = "Unable insert data from database : ${error.localizedMessage}"
                        ),
                        success = false
                    ))
                    Log.e(TAG,"database error as ${error.localizedMessage}")
                }
            )
    }

    fun getReferralStatusFromDB(childPhone: String) : MutableLiveData<NewCommonResponseModel<ReferralStatusModel>> {
        val data : MutableLiveData<NewCommonResponseModel<ReferralStatusModel>> = MutableLiveData()
        localDb?.let { appDatabase ->
            bag.add(
                appDatabase.referralStatusDao().getAllSelectedChild(childPhone = childPhone)
                    .observeOn(Schedulers.io())
                    .subscribeOn(Schedulers.io())
                    .subscribe(
                        { response ->
                            when {
                                response.isNotEmpty() -> {
                                    data.postValue(
                                        NewCommonResponseModel(
                                            responseData = ReferralStatusModel(
                                                referrals = response
                                            ),
                                            success = true
                                        )
                                    )
                                }
                                else -> {
                                    data.postValue(NewCommonResponseModel<ReferralStatusModel>(
                                        responseData = null,
                                        success = false
                                    ))
                                }
                            }
                        },
                        { error ->
                            Log.e(TAG,"error in getting data from database")
                            data.postValue(NewCommonResponseModel<ReferralStatusModel>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from database : ${error.localizedMessage}"
                                ),
                                success = false
                            ))
                            Log.e(TAG,"database error as ${error.localizedMessage}")
                        }
                    )
            )
        }
        return data
    }
    //endregion

    //region agent referral status details...
    fun getStatusDetails(
        statusId: Int,
        childPhone: String
    ): MutableLiveData<NewCommonResponseModel<ReferralStatusDetailModel>> {
        val data : MutableLiveData<NewCommonResponseModel<ReferralStatusDetailModel>> = MutableLiveData()
        bag.add(
            ServiceInstance.getInstance(context).serviceAgentReferral?.getReferralStatusDetails(
                statusId = statusId,
                user_id = angazaId,
                module = module
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(
                    { response ->
                        preference?.setReferralStatusDetailLastSync(Util.getCurrentLocalFormattedDateForSync())
                        Log.e(TAG,"receive new response as $response")
                        insertReferralStatusDetail(data, response, statusId, childPhone)

                    },
                    { error ->
                        Log.e(TAG,"error in getting data from api")
                        data.postValue(NewCommonResponseModel<ReferralStatusDetailModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from api : ${error.localizedMessage}"
                            ),
                            success = false
                        ))
                        Log.e(TAG,"api error as ${error.localizedMessage}")

                    }
                )
        )
        return data
    }

    private fun insertReferralStatusDetail(
        data: MutableLiveData<NewCommonResponseModel<ReferralStatusDetailModel>>,
        response: ReferralStatusDetailModel?,
        statusId: Int,
        childPhone: String
    ) : Disposable {
        val referralDetails : ArrayList<ReferralDetail> = ArrayList()
        return Flowable.fromCallable {
            referralDetails.clear()
            response?.referralDetails?.forEach { ref ->
                referralDetails.add(
                    ReferralDetail(
                        actTime = ref.actTime,
                        assessmentSmsBody = ref.assessmentSmsBody,
                        childPhone = childPhone,
                        createdAt = ref.createdAt,
                        stage = ref.stage,
                        status = ref.status,
                        reason = ref.reason,
                        statusId = statusId
                    )
                )
            }
            localDb?.referralStatusDetailDao()?.deleteAllAgentReferral()
            localDb?.referralStatusDetailDao()?.insertAllAgentReferral(referralDetails)
        }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe(
                {
                    Log.e(TAG,"successful in inserting data")
                    data.postValue(
                        NewCommonResponseModel(
                            responseData = ReferralStatusDetailModel(
                                referralDetails = referralDetails
                            ),
                            success = true
                        )
                    )
                },
                { error ->
                    Log.e(TAG,"error in inserting data")
                    data.postValue(NewCommonResponseModel<ReferralStatusDetailModel>(
                        error = NewCommonResponseModel.Error(
                            messageToUser = "Unable insert data from database : ${error.localizedMessage}"
                        ),
                        success = false
                    ))
                    Log.e(TAG,"database error as ${error.localizedMessage}")
                }
            )
    }

    fun getReferralStatusDetailsSelected(
        statusId: Int
    ) : MutableLiveData<NewCommonResponseModel<ReferralStatusDetailModel>> {
        val data : MutableLiveData<NewCommonResponseModel<ReferralStatusDetailModel>> = MutableLiveData()
        bag.add(
            localDb?.referralStatusDetailDao()?.getAllSelectedChild(
                statusId = statusId
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(
                    { response ->
                        when {
                            response.isNotEmpty() -> {
                                data.postValue(
                                    NewCommonResponseModel(
                                        responseData = ReferralStatusDetailModel(
                                            referralDetails = response
                                        ),
                                        success = true
                                    )
                                )
                            }
                            else -> {
                                data.postValue(
                                    NewCommonResponseModel(
                                        responseData = null,
                                        success = false
                                    )
                                )
                            }
                        }

                    },
                    { error ->
                        Log.e(TAG,"error in getting data from database")
                        data.postValue(NewCommonResponseModel<ReferralStatusDetailModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from database : ${error.localizedMessage}"
                            ),
                            success = false
                        ))
                        Log.e(TAG,"database error as ${error.localizedMessage}")
                    }
                )
        )
        return data
    }
    //endregion

    //region refer new agent...
    fun submitNewAgentRequest(
        phoneNumber: String?,
        name : String?,
        countryCode : String?
    ) : MutableLiveData<NewCommonResponseModel<NewAgentResponseModel>>{
        val childPhone = when {
            country.equals("Nigeria", true) -> "${countryCode}${phoneNumber}"
            else -> phoneNumber
        }
        Log.e(TAG,"final child info as $childPhone, $countryCode, $name")
        val newAgentRequestModel : NewAgentRequestModel = NewAgentRequestModel(
            parentAngazaId = angazaId,
            phoneNumber = childPhone,
            name = name,
            territory = territory
        )
        val data : MutableLiveData<NewCommonResponseModel<NewAgentResponseModel>> = MutableLiveData()
        bag.add(
            ServiceInstance.getInstance(context).servicePostAgentReferral?.submitNewAgentRequest(
                newAgentRequestModel = newAgentRequestModel,
                module = module,
                user_id = angazaId
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(
                    { response ->
                        preference?.setAgentReferralSubmitLastSync(Util.getCurrentLocalFormattedDateForSync())
                        Log.e(TAG,"receive new response as $response")
                        data.postValue(
                            NewCommonResponseModel(
                                responseData = response!!,
                                success = true
                            )
                        )
                    },
                    { error ->
                        Log.e(TAG,"error in getting data from api")
                        data.postValue(NewCommonResponseModel<NewAgentResponseModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from api : ${error.localizedMessage}"
                            ),
                            success = false
                        ))
                        Log.e(TAG,"api error as ${error.localizedMessage}")

                    }
                )
        )
        return data
    }
    //endregion
}