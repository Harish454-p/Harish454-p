package com.greenlightplanet.kazi.fseProspective.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.location.Location
import android.util.Log
import androidx.room.EmptyResultSetException
import com.google.gson.Gson
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.fseProspective.extras.ErrorUtils
import com.greenlightplanet.kazi.fseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.fseProspective.model.*
import com.greenlightplanet.kazi.location.extras.FunctionalUtils
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.util.*

class RegistrationRepo(val context: Context) {

    companion object :
            SingletonHolderUtil<RegistrationRepo, Context>(::RegistrationRepo) {
        public const val TAG = "RegistrationRepo"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    var gson: Gson? = null

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context!!)
//            country = preference?.getLoginResponseModel()?.country
            gson = Gson()

        } catch (e: Exception) {
            Log.d(TAG, ":Error ")
        }
    }

    private val territory: String? by lazy {
        preference?.getLoginResponseModel()?.territory
    }

    fun getCombineRequestModel(prospectId: String): MutableLiveData<CombineRequestModel?> {

        val data = MutableLiveData<CombineRequestModel?>()
        val combineModel = CombineRequestModel()

        try {
            bag.add(
                    localDb?.fseProspectResponseDao()?.getByProspectId(prospectId)!!
                            .flatMap {
                                combineModel.fseProspectResponseModel = it
                                localDb?.registrationCheckinRequestDao()?.getByProspectId(prospectId)
                            }
                            .flatMap {
                                combineModel.registrationCheckinRequestModel = it
                                localDb?.fseErrorDao()?.getByProspectId(prospectId)
                            }
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .doFinally { data.postValue(combineModel) }
                            .onErrorResumeNext {
                                if (it is EmptyResultSetException) Single.just(FseError(prospectId,it.localizedMessage,500,TAG,"No Data Available","No Data Available")) //<< an empty container is returned.
                                else Single.error(it)
                            }
                            .doOnError {
                                Log.d(TAG, "Error-1: ${it.localizedMessage}");
                                it.printStackTrace()
                            }
                            .subscribe({
                                combineModel.fseError = it
                            }, {
                                it.printStackTrace()
                                Log.d(TAG, "ERROR:${it.localizedMessage} ");
                            })


            )
        } catch (e: Exception) {
            Log.e("Errorrs","${e}")
        }
        return data
    }

    fun performCheckin2(context: Context, isOnline: Boolean, prospectId: String, angazaId: String, area: String, location: Location, prospectAllowedDistance: Int): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()


        val baseLocation = preference?.getBaselocationModel()?.fseBaseLocation

        val registrationCheckinRequestModel = RegistrationCheckinRequestModel(
                prospectId = prospectId,
                angazaId = angazaId,
                latitude = location.latitude.toString(),
                longitude = location.longitude.toString(),
                checkinTime = Util.fseDateToUtcFormatted(Date()),
                area = area,
                accuracy = location.accuracy.toString(),
                country = preference?.getLoginResponseModel()?.country?: ""
        )

        Log.d(TAG,
                """ baseLocation?.latitude!! :${baseLocation?.latitude!!}
                                baseLocation?.longitude!! :${baseLocation.longitude!!}
                                it.latitude :${location.latitude}
                                it.longitude :${location.longitude}
                                """.trimMargin()
        );

        Log.d(TAG, "distance:${Util.distance(baseLocation.latitude!!, location.latitude, baseLocation.longitude!!, location.longitude)} ");
        //val isNotValid = (Util.distance(baseLocation.latitude!!, location.latitude, baseLocation.longitude!!, location.longitude) > prospectDistance?.allowedDistance ?: 0)
        val isNotValid = (Util.distance(baseLocation.latitude!!, location.latitude, baseLocation.longitude!!, location.longitude) > prospectAllowedDistance ?: 0)

        insertRegistrationCheckinRequestToDatabase(isOnline, isNotValid, data, registrationCheckinRequestModel)
        return data
    }

    fun performCheckin(context: Context, isOnline: Boolean, prospectId: String, angazaId: String, area: String, prospectAllowedDistance: Int): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()

        bag.add(
                FunctionalUtils.newGetCurrentLocation(context)!!.subscribe({


                    val baseLocation = preference?.getBaselocationModel()?.fseBaseLocation

                    val registrationCheckinRequestModel = RegistrationCheckinRequestModel(
                            prospectId = prospectId,
                            angazaId = angazaId,
                            latitude = it.latitude.toString(),
                            longitude = it.longitude.toString(),
                            checkinTime = Util.fseDateToUtcFormatted(Date()),
                            area = area,
                            accuracy = "",
                            country = preference?.getLoginResponseModel()?.country?: ""
                    )

                    /*if (isOnline) {
                        sendRegistrationCheckinRequestToServer(data, registrationCheckinRequestModel)
                    } else {
                        insertRegistrationCheckinRequestToDatabase(data, registrationCheckinRequestModel)
                    }*/

                    //19.2821626,72.841517,13z //mira-road

                    Log.d(TAG,
                            """
                                baseLocation?.latitude!! :${baseLocation?.latitude!!}
                                baseLocation?.longitude!! :${baseLocation.longitude!!}
                                it.latitude :${it.latitude}
                                it.longitude :${it.longitude}

                            """.trimMargin()
                    );


                    //val prospectDistance = Util.getProspectDistance(context, country!!)

                    Log.d(TAG, "distance:${Util.distance(baseLocation.latitude!!, it.latitude, baseLocation.longitude!!, it.longitude)} ");
                    //val isNotValid = (Util.distance(baseLocation.latitude!!, it.latitude, baseLocation.longitude!!, it.longitude) > prospectDistance?.allowedDistance ?: 0)
                    val isNotValid = (Util.distance(baseLocation.latitude!!, it.latitude, baseLocation.longitude!!, it.longitude) > prospectAllowedDistance ?: 0)

                    insertRegistrationCheckinRequestToDatabase(isOnline, isNotValid, data, registrationCheckinRequestModel)

                }, {

                    Log.d(TAG, "Error:$it ");
                    it.printStackTrace()
                    data.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable to send data to server")
                            , success = false
                    ))
                })
        )
        return data
    }

    fun sendRegistrationCheckinRequestToServerForceUpload(registrationCheckinRequestModel: RegistrationCheckinRequestModel): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()
        var response: NewCommonResponseModel<NewEmptyParcelable>? = null

        bag.add(
                ServiceInstance.getInstance(context).service?.postRegisterCheckin(
                        registrationCheckinRequestModel = registrationCheckinRequestModel)!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .flatMapCompletable {
                            response = it

                            if (it.success) {
                                performIsChanged(registrationCheckinRequestModel.prospectId, false, registrationCheckinRequestModel.checkinTime!!)
                            } else {
                                performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, isChanged = false, errorOccurred = true, errorModel = it.error)
                            }
                        }
                        /*.doOnError { t ->

                            Log.d(TAG, "API-Error3: ${t.localizedMessage}")

                            liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                    error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable to send data to server"
                                    ),
                                    success = false
                            ))
                        }*/
                        .subscribe({
                            data.postValue(response)
                        }, { t ->


                            /*val error = t as HttpException
                            val errorBody = error.response().errorBody()!!.string()

                            val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)

                            bag.add(

                                    performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, isChanged = false, errorOccurred = true, errorModel = errorModel?.error).subscribe()
                            )

                            data.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                    error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable to send data to server"
                                    ),
                                    success = false

                            ))*/

                            /*performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, isChanged = true, errorOccurred = true, errorModel = NewCommonResponseModel.Error(
                                    messageToUser = "Unable to send data to server"
                            )).subscribe()*/

                            /*Log.d(TAG, "API-Error:$errorBody")
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")*/


                            ErrorUtils.errorHandler(
                                    gson,
                                    t,
                                    TAG,
                                    "sendRegistrationCheckinRequestToServerForceUpload",
                                    "Unable to send data to server",
                                    data
                            )
                        })
        )

        return data
    }

    private fun sendRegistrationCheckinRequestToServer(liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>, registrationCheckinRequestModel: RegistrationCheckinRequestModel, isNotValid: Boolean) {

        bag.add(
                ServiceInstance.getInstance(context).service?.postRegisterCheckin(
                        registrationCheckinRequestModel = registrationCheckinRequestModel)!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .flatMapCompletable {

                            if (it.success) {
                                if (isNotValid) {
                                    liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                            success = false,
                                            error = NewCommonResponseModel.Error(
                                                    code = 1001,
                                                    messageToUser = "Your'e location is not valid"
                                            )
                                    ))
                                } else {
                                    liveData.postValue(it)
                                }
                                performIsChanged(registrationCheckinRequestModel.prospectId, false, registrationCheckinRequestModel.checkinTime!!, isNotValid)

                            } else {
                                if (isNotValid) {
                                    liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                            success = false,
                                            error = NewCommonResponseModel.Error(
                                                    code = 1001,
                                                    messageToUser = "Your'e location is not valid"
                                            )
                                    ))
                                } else {
                                    liveData.postValue(it)
                                }
                                performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, changeApproved = isNotValid, isChanged = false, errorOccurred = true, errorModel = it.error)
                            }

                        }
                        /*.doOnError { t ->

                            Log.d(TAG, "API-Error3: ${t.localizedMessage}")

                            liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                    error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable to send data to server"
                                    ),
                                    success = false
                            ))
                        }*/
                        .subscribe({}, {


                            /*//todo check the cause
                            Log.d(TAG, "cause:${t.cause} ");
                            val error = t as HttpException
                            val errorBody = error.response().errorBody()?.string()
                            val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)*/


                            val isApi = it is retrofit2.HttpException

                            var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                            if (isApi) {
                                val error = it as HttpException
                                val errorBody = error.response().errorBody()?.string()
                                errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)

                            } else {


                                errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                                        error = NewCommonResponseModel.Error(
                                                messageToUser = it.localizedMessage
                                        ),
                                        success = false

                                )

                            }


                            /*performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, isChanged = true, errorOccurred = true, errorModel = NewCommonResponseModel.Error(
                                    messageToUser = "Unable to send data to server"
                            )).subscribe()*/

                            bag.add(
                                    performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, isChanged = false, errorOccurred = true, errorModel = errorModel?.error).subscribe({
                                        Log.d(TAG, " on Success ===");
                                    },{
                                        Log.d(TAG, " Error:${it.printStackTrace()}");
                                    })
                            )


                            if (isNotValid) {
                                liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                        success = false,
                                        error = NewCommonResponseModel.Error(
                                                code = 1001,
                                                messageToUser = "Your'e location is not valid"
                                        )
                                ))
                            } else {
                                liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                        error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable to send data to server"
                                        ),
                                        success = false
                                ))
                            }




                        })
        )
    }

    fun getRegistrationCheckinRequestFromDB(prospectId: String): MutableLiveData<RegistrationCheckinRequestModel> {

        val data: MutableLiveData<RegistrationCheckinRequestModel> = MutableLiveData()

        bag.add(
                localDb!!.registrationCheckinRequestDao().getByProspectId(prospectId)!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({
                            data.postValue(it)
                        }, {
                            it.printStackTrace()
                            data.postValue(null)
                        })
        )
        return data

    }

    private fun insertRegistrationCheckinRequestToDatabase(isOnline: Boolean, isNotValid: Boolean, liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>, registrationCheckinRequestModel: RegistrationCheckinRequestModel) {


        localDb?.let {
            bag.add(

                    //appDatabase.registrationCheckinRequestDao().insert()
                    Completable.fromAction {
                        it.registrationCheckinRequestDao().insert(registrationCheckinRequestModel)
                    }
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.d(TAG, "isNotValid :$isNotValid");
                                Log.d(TAG, "checkinTime:${registrationCheckinRequestModel.checkinTime!!}");
                                performIsChanged(
                                        prospectId = registrationCheckinRequestModel.prospectId,
                                        isChanged = true,
                                        date = registrationCheckinRequestModel.checkinTime!!,
                                        changeApproved = isNotValid)
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({

                                            Log.d(TAG, "Insertion:Completed ")

                                            if (isOnline) {

                                                sendRegistrationCheckinRequestToServer(liveData, registrationCheckinRequestModel, isNotValid)

                                            } else {

                                                if (isNotValid) {
                                                    liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                                            success = false,
                                                            error = NewCommonResponseModel.Error(
                                                                    code = 1001,
                                                                    messageToUser = "Your'e location is not valid"
                                                            )
                                                    ))
                                                } else {
                                                    liveData.postValue(NewCommonResponseModel(
                                                            success = true
                                                    ))
                                                }

                                            }


                                        }, {

                                            if (isNotValid) {
                                                liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                                        success = false,
                                                        error = NewCommonResponseModel.Error(
                                                                code = 1001,
                                                                messageToUser = "Your'e location is not valid"
                                                        )
                                                ))
                                            } else {
                                                liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                                        error = NewCommonResponseModel.Error(
                                                                messageToUser = "Unable to send data to server"
                                                        ),
                                                        success = false
                                                ))
                                            }

                                            Log.d(TAG, "DB-Error: ${it.localizedMessage}")

                                        })
                            }, { t ->

                                if (isNotValid) {
                                    liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                            success = false,
                                            error = NewCommonResponseModel.Error(
                                                    code = 1001,
                                                    messageToUser = "Your'e location is not valid"
                                            )
                                    ))
                                } else {
                                    liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                            error = NewCommonResponseModel.Error(
                                                    messageToUser = "Unable to send data to server"
                                            ),
                                            success = false
                                    ))
                                }

                                Log.d(TAG, "DB-Error: ${t.localizedMessage}")


                            })

            )
        }

    }

    private fun performIsChanged(prospectId: String, isChanged: Boolean, date: String = "", changeApproved: Boolean = false, errorOccurred: Boolean = false, errorModel: NewCommonResponseModel.Error? = null): Completable {
        return localDb!!.fseProspectResponseDao().getByProspectId(prospectId)!!.flatMapCompletable {
            val value = it
            value.isChanged = isChanged
            value.errorOccurred = errorOccurred
            Log.d(TAG, "errorOccurred:$errorOccurred");


            value.statusUpdateTime?.checkedIn = date
            if (changeApproved) {
                value.approved = false
                value.message = "Your Check-In has failed the distance criteria check.\n" +
                        "This Prospect will now be re-assigned. Please contact the ABM"
                value.status = FseProspectiveConstant.ProspectStatus.CHECKED_IN
            } else {
                value.approved = true
                value.status = FseProspectiveConstant.ProspectStatus.CHECKED_IN
            }

            Log.d(TAG, "checkedIn:date = $date");

            val fseError = FseError(
                    prospectId = prospectId,
                    errorType = FseProspectiveConstant.ProspectiveType.REGISTRATION,
                    code = errorModel?.code,
                    errorClass = errorModel?.errorClass,
                    errorTrace = errorModel?.errorTrace,
                    messageToUser = errorModel?.messageToUser
            )


            /*Completable.fromAction {
                localDb!!.fseProspectResponseDao().insert(value)

            }.mergeWith {
                if (errorOccurred) {
                    Completable.fromAction {
                        localDb!!.fseErrorDao().insert(fseError)
                    }
                }
            }*/

            val list = mutableListOf<Completable>()

            list.add(
                    Completable.fromAction {
                        localDb!!.fseProspectResponseDao().insert(value)

                    }
            )
            if (errorOccurred) {
                list.add(
                        Completable.fromAction {
                            localDb!!.fseErrorDao().insert(fseError)
                        }
                )
            }

            /* if (!isChanged){
                 list.add(
                         Completable.fromAction {
                             localDb!!.fseErrorDao().deleteProspectById(prospectId)
                         }
                 )
             }*/

            Completable.merge(list)


            /*if (errorOccurred) {
                Completable.fromAction {
                    localDb!!.fseProspectResponseDao().insert(value)

                }.mergeWith {
                    localDb!!.fseErrorDao().insert(fseError)
                }
            } else {
                Completable.fromAction {
                    localDb!!.fseProspectResponseDao().insert(value)

                }
            }*/
        }
    }

    //new
    private fun syncServerRegistrationCheckinRequestModel(registrationCheckinRequestModel: RegistrationCheckinRequestModel): Single<NewCommonResponseModel<NewEmptyParcelable>> {

        return ServiceInstance.getInstance(context).service?.postRegisterCheckin(
                registrationCheckinRequestModel = registrationCheckinRequestModel)!!
                .subscribeOn(Schedulers.newThread())
                .flatMap {
                    Single.create<NewCommonResponseModel<NewEmptyParcelable>> { emitter ->


                        try {

                            /*val result = localDb!!.registrationCheckinRequestDao().insert(registrationCheckinRequestModel)
                            result.let {
                                emitter.onSuccess(it)
                            }*/

                            performIsChanged(registrationCheckinRequestModel.prospectId, false).subscribe({ emitter.onSuccess(it) }, { emitter.onError(it) })


                        } catch (e: Exception) {
                            emitter.onError(e)
                        }
                    }
                }
                .doOnSuccess {
                    Completable.fromAction {
                        // logic
                        Log.d(TAG, " inserting:${registrationCheckinRequestModel.prospectId}");
                        performIsChanged(registrationCheckinRequestModel.prospectId, false)
                    }.subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                        .subscribe({
                            Log.d(TAG, " on Success ===");
                        },{
                            Log.d(TAG, " Error:${it.printStackTrace()}");
                        })
                }
                .onErrorResumeNext { it ->


                    /*val error = it as HttpException
                    val errorBody = error.response().errorBody()?.string()
                    val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)*/

                    val isApi = it is retrofit2.HttpException

                    var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                    if (isApi) {
                        val error = it as HttpException
                        val errorBody = error.response().errorBody()?.string()
                        errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)

                    } else {


                        errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                                error = NewCommonResponseModel.Error(
                                        messageToUser = it.localizedMessage
                                ),
                                success = false

                        )

                    }


                    performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, isChanged = false, errorOccurred = true, errorModel = errorModel?.error)
                            .toSingleDefault(true)
                            .onErrorReturnItem(false)
                            .flatMap {
                                Single.just(NewCommonResponseModel<NewEmptyParcelable>())
                            }

                }


    }

    private fun syncLoopRegistrationCheckinRequestModel(registrationCheckinRequestModel: List<RegistrationCheckinRequestModel>): Single<List<RegistrationCheckinRequestModel>> {

        val requests = mutableListOf<Single<NewCommonResponseModel<NewEmptyParcelable>>>()

        registrationCheckinRequestModel.forEach {
            requests.add(syncServerRegistrationCheckinRequestModel(it))
        }

        return Single.zip(requests) {
            //val returnList = it.map { it as NewCommonResponseModel<NewEmptyParcelable> }

            //Log.d(TAG, "r-repo:${returnList} ");
            //returnList
            registrationCheckinRequestModel
        }
    }

    /*private fun syncAllInsertRegistrationCheckinRequestModel(allSingles: Single<List<RegistrationCheckinRequestModel>>): Single<List<RegistrationCheckinRequestModel>> {


        return allSingles.flatMap {
            insertAllRegistrationCheckinToDatabase(it)
        }

    }*/

    private fun insertAllRegistrationCheckinToDatabase(registrationCheckinRequestModel: List<RegistrationCheckinRequestModel>): Single<List<RegistrationCheckinRequestModel>> {

        return Single.create { emitter ->

            try {
                val result = localDb!!.registrationCheckinRequestDao().insertAll(registrationCheckinRequestModel)
                result.let {
                    emitter.onSuccess(registrationCheckinRequestModel)
                }

            } catch (e: Exception) {
                emitter.onError(e)
            }
        }
    }

    /*    private fun insertAllRegistrationCheckinToDatabase(registrationCheckinRequestModel: List<RegistrationCheckinRequestModel>, responseList: List<NewCommonResponseModel<NewEmptyParcelable>>): Single<List<RegistrationCheckinRequestModel>> {

        return Single.create { emitter ->


            try {
                val result = localDb!!.registrationCheckinRequestDao().insertAll(registrationCheckinRequestModel)
                result.let {
                    emitter.onSuccess(registrationCheckinRequestModel)
                }

            } catch (e: Exception) {
                emitter.onError(e)
            }
        }
    }*/

    fun processAll(otpApprovalRequestModels: List<RegistrationCheckinRequestModel>): Single<List<RegistrationCheckinRequestModel>> {
        return syncLoopRegistrationCheckinRequestModel(otpApprovalRequestModels).flatMap {
            insertAllRegistrationCheckinToDatabase(it)
        }
    }


    fun getFseProspectiveFromServer(angazaId: String, prospectId: String): MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>? {

        val data = MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>()

        var value: NewCommonResponseModel<FseProspectItemResponseModel>? = null

        bag.add(

                localDb!!.fseProspectResponseDao().getByProspectId(prospectId)!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .flatMapCompletable { prospectFromDatabase ->
                            // here delete all data from database
                            Completable.fromAction {
                                localDb!!.fseProspectResponseDao().delete(prospectFromDatabase)
                            }.doOnError {
                                Log.d(TAG, "Error-2: ${it.localizedMessage}");
                                data.postValue(NewCommonResponseModel<FseProspectResponseModel>(
                                        error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable get data from server"
                                        ),
                                        success = false
                                ))
                                it.printStackTrace()
                            }.doOnComplete {
                                //ServiceInstance.getInstance(context).service?.getFseProspectives()!!
                                ServiceInstance.getInstance(context).service?.getFseProspective(angazaId, prospectId,territory!!)!!
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        /*.doOnSuccess {

                                        }.doOnError {
                                            Log.d(TAG, "Error-1: ${it.localizedMessage}");
                                            NewCommonResponseModel<FseProspectResponseData>(
                                                    error = NewCommonResponseModel.Error(
                                                            messageToUser = "Unable get data from server"
                                                    ),
                                                    success = false
                                            )
                                            it.printStackTrace()
                                        }*/
                                        .subscribe({
                                            value = it!!

                                            val fromDatabase = prospectFromDatabase

                                            var fromServer = value!!.responseData!!.prospect!!

                                            //val uniqueInDb = mutableListOf<FseProspectResponseData>()

                                            /*fromDatabase.forEach { databaseItem ->

                                                if (fromServer.find { it.prospectId == databaseItem.prospectId } == null) {
                                                    fromDatabase.remove(databaseItem)
                                                }
                                            }*/

                                            //val combinedList = fromDatabase + fromServer

                                            //new Value Added in server response
                                            /*val distinctValueFromServer = combinedList.groupBy { it.prospectId }
                                                    .filter { it.value.size == 1 }
                                                    .flatMap { it.value }*/


                                            /*val notNewAddedServerValue = fromServer.toSet().minus(distinctValueFromServer.toSet()).toMutableList()
                                            val notNewAddedDatabaseValue = fromDatabase.toSet().minus(distinctValueFromServer.toSet()).toMutableList()*/

                                            var oldChangedData: FseProspectResponseModel? = null

                                            //notNewAddedServerValue.forEach { itemServer ->

                                            val sameDataInDatabase = fromDatabase

                                            fun statusUpdateTimeHandler(oldStatus: FseProspectResponseModel.StatusUpdateTime, newStatus: FseProspectResponseModel.StatusUpdateTime, oldFseProspectResponseModel: FseProspectResponseModel): FseProspectResponseModel.StatusUpdateTime {
                                                var revisedStatus = oldStatus

                                                if (!newStatus.prospect.isNullOrEmpty()) {
                                                    revisedStatus.prospect = newStatus.prospect
                                                }


                                                if (!newStatus.otpApproved.isNullOrEmpty()) {
                                                    revisedStatus.otpApproved = newStatus.otpApproved
                                                }


                                                if (!newStatus.preApprovedProspect.isNullOrEmpty()) {
                                                    revisedStatus.preApprovedProspect = newStatus.preApprovedProspect
                                                }

                                                if (!newStatus.checkedIn.isNullOrEmpty()) {
                                                    revisedStatus.checkedIn = newStatus.checkedIn
                                                }

                                                if (!newStatus.threeWayCallVerification.isNullOrEmpty()) {
                                                    revisedStatus.threeWayCallVerification = newStatus.threeWayCallVerification
                                                }

                                                if (!newStatus.installationPending.isNullOrEmpty()) {
                                                    revisedStatus.installationPending = newStatus.installationPending
                                                }


                                                if (oldFseProspectResponseModel.reattemptedStage != 1 || oldFseProspectResponseModel.reattemptedStage != 2) {
                                                    if (!newStatus.installed.isNullOrEmpty()) {
                                                        revisedStatus.installed = newStatus.installed
                                                    }

                                                    if (!newStatus.installationVerified.isNullOrEmpty()) {
                                                        revisedStatus.installationVerified = newStatus.installationVerified
                                                    }
                                                }

                                                return revisedStatus
                                            }

                                            fun statusHandler(oldStatus: String, newStatus: String): String {
                                                var revisedStatus = ""

                                                when (oldStatus) {
                                                    FseProspectiveConstant.ProspectStatus.PROSPECT -> {

                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.OTP_APPROVED) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.PROSPECT
                                                        }

                                                    }

                                                    FseProspectiveConstant.ProspectStatus.OTP_APPROVED -> {
                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT -> {
                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.CHECKED_IN) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.CHECKED_IN -> {

                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                        } else if (newStatus == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL -> {
                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING -> {
                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLED) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLED
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.INSTALLED -> {
                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                                        } else if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLED
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED -> {

                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                                        }
                                                    }

                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT -> {

                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                        }
                                                    }

                                                    else -> {
                                                        revisedStatus = FseProspectiveConstant.ProspectStatus.PROSPECT
                                                    }

                                                }

                                                return revisedStatus
                                            }

                                            sameDataInDatabase?.let {

                                                sameDataInDatabase.approved = fromServer.approved
                                                sameDataInDatabase.message = fromServer.message
                                                sameDataInDatabase.customerAddress = fromServer.customerAddress

                                                sameDataInDatabase.name = fromServer.name
                                                sameDataInDatabase.otp = fromServer.otp
                                                sameDataInDatabase.productName = fromServer.productName
                                                sameDataInDatabase.status = statusHandler(sameDataInDatabase.status!!, fromServer.status!!)
                                                sameDataInDatabase.statusUpdateTime = statusUpdateTimeHandler(sameDataInDatabase.statusUpdateTime!!, fromServer.statusUpdateTime!!, sameDataInDatabase)
                                                sameDataInDatabase.ticketType = fromServer.ticketType
                                                sameDataInDatabase.accountNumber = fromServer.accountNumber
                                                sameDataInDatabase.installationPicture = fromServer.installationPicture
                                                sameDataInDatabase.customerPhoneNumber = fromServer.customerPhoneNumber
                                                sameDataInDatabase.area = fromServer.area

                                                oldChangedData = sameDataInDatabase

                                            }
                                            //need to add some new attributes here
                                            //}


                                            val resultData = oldChangedData


                                            if (resultData != null) {

                                                //data.postValue(value)
                                                fromServer = resultData
                                                fseProspectiveFromServerLogic(data, NewCommonResponseModel(responseData = fromServer, success = true))
                                                //add to database

                                            } else {
                                                data.postValue(
                                                        NewCommonResponseModel<FseProspectResponseModel>(
                                                                error = NewCommonResponseModel.Error(
                                                                        messageToUser = "Unable get data from server"
                                                                ),
                                                                success = false
                                                        )
                                                )
                                            }
                                        }, {
                                            Log.d(TAG, "Error-1: ${it.localizedMessage}");

                                            data.postValue(NewCommonResponseModel<FseProspectResponseModel>(
                                                    error = NewCommonResponseModel.Error(
                                                            messageToUser = "Unable get data from server"
                                                    ),
                                                    success = false
                                            ))

                                            it.printStackTrace()
                                        })
                            }
                        }.doOnError {
                            Log.d(TAG, "Error-1: ${it.localizedMessage}");
                            data.postValue(NewCommonResponseModel<FseProspectResponseModel>(
                                    error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable get data from server"
                                    ),
                                    success = false
                            ))
                            it.printStackTrace()
                        }.subscribe({
                        Log.d(TAG, " on Success ===");
                    },{
                        Log.d(TAG, " Error:${it.printStackTrace()}");
                    })

        )

        return data
    }

    private fun fseProspectiveFromServerLogic(liveData: MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>, responseData: NewCommonResponseModel<FseProspectResponseModel>) {

        bag.add(
                Completable.fromAction {
                    localDb?.fseProspectResponseDao()?.insert(responseData.responseData!!)
                }
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({
                            Log.d(TAG, "Insertion:Completed ")
                            preference?.setFseProspectLastSynced(Util.getCurrentLocalFormattedDateForSync())
                            liveData.postValue(responseData)
                        }, { t ->
                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                        })
        )

    }

    fun destroy() {

        Log.d(TAG, "Repo : Distroyed");
        bag.clear()

    }

}
