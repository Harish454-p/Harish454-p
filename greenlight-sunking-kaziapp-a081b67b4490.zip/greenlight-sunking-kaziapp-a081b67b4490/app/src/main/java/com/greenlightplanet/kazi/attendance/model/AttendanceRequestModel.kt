package com.greenlightplanet.kazi.attendance.model

import androidx.room.*
import androidx.annotation.NonNull
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.task.model.response.DateConverter
import java.io.Serializable
import java.text.SimpleDateFormat
import java.util.*


@Entity(tableName = "attendance")
@TypeConverters(AttendanceConveter::class)
class AttendanceRequestModel : Serializable {
    var checkins: ArrayList<checkins>? = null
}


@Entity(tableName = "checkins")
@TypeConverters(AttendanceConveter::class)
class checkins : Serializable {


    @ColumnInfo(name = "latitude")
    @SerializedName("latitude")
    var latitude: String? = null

    @ColumnInfo(name = "longitude")
    @SerializedName("longitude")
    var longitude: String? = null


    @ColumnInfo(name = "is_online_added")
    @SerializedName("isOnlineAdded")
    var isOnlineAdded: Boolean? = true

    /*-----------*/

    @ColumnInfo(name = "accountNumber")
    @SerializedName("accountNumber")
    var accountNumber: String = ""


    @ColumnInfo(name = "checkinType")
    @SerializedName("checkinType")
    var checkinType: String? = null // GENERAL // CUSTOMER


    var customer_name: String? = null // User Name

    /*-----------*/


    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "time")
    @SerializedName("time")
    var time: String? = null

    @ColumnInfo(name = "date")
    @SerializedName("date")
    @TypeConverters(DateConverter::class)
    var date: Date? = time?.let { getFormattedDate(it) }

    fun getFormattedDate(time: String): Date {

        val sdf = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
        var date: Date? = sdf.parse(time)
        return date!!
    }

    override fun toString(): String {
        return "checkins(latitude=$latitude, longitude=$longitude, isOnlineAdded=$isOnlineAdded, accountNumber='$accountNumber', checkinType=$checkinType, customer_name=$customer_name, time=$time, date=$date)"
    }


}

class DateConverter {

    @TypeConverter
    fun toDate(dateLong: Long?): Date? {
        return if (dateLong == null) null else Date(dateLong)
    }

    @TypeConverter
    fun fromDate(date: Date?): Long? {
        return date?.time
    }
}

class AttendanceConveter {

    @TypeConverter
    fun fromTaskList(countryLang: ArrayList<checkins>?): String? {
        if (countryLang == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<checkins>>() {

        }.type
        return gson.toJson(countryLang, type)
    }

    @TypeConverter
    fun toTaskList(countryLangString: String?): ArrayList<checkins>? {
        if (countryLangString == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<checkins>>() {

        }.type
        return gson.fromJson(countryLangString, type)
    }

}





