package com.greenlightplanet.kazi.liteFseProspective.view.fragment


import android.Manifest
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.lifecycle.ViewModelProviders
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentAllBinding
import com.greenlightplanet.kazi.liteFseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import com.greenlightplanet.kazi.liteFseProspective.view.activity.NewProspectDetailActivity
import com.greenlightplanet.kazi.liteFseProspective.view.activity.adapter.VerificationAdapter
import com.greenlightplanet.kazi.liteFseProspective.view.activity.mapActivity.FseProsMapsActivity
import com.greenlightplanet.kazi.liteFseProspective.viewmodel.AllViewModel
import com.greenlightplanet.kazi.utils.BaseFragment


/**
 * A simple [Fragment] subclass.
 *
 */
class AllFragment : BaseFragment(), VerificationAdapter.VerificationAdapterCallback {


    private var _binding:FragmentAllBinding ? = null
    private  val binding get() = _binding!!

    val array = mutableListOf<String>()


    private var firstVisit = false
    lateinit var viewModel: AllViewModel

    override fun onTapped(position: Int, value: LiteFseProspectResponseModel) {

//		val intent: Intent = Intent(activity, ProspectDetailActivity::class.java)
        val intent = Intent(activity, NewProspectDetailActivity::class.java)
//        intent.putExtra("data", value)
        intent.putExtra("data", value.prospectId)
        startActivity(intent)
        binding. etsearch.text.clear()
    }


    companion object {

        const val TAG = "VerificationFragment"

        fun newInstance(
//            list: List<LiteFseProspectResponseModel>?,
            allowedDistance: Int
		): AllFragment {
            val myFragment = AllFragment()

            val args = Bundle()
//            args.putParcelableArrayList("list", ArrayList(list!!))
            args.putInt("allowedDistance", allowedDistance)
            myFragment.arguments = args

            return myFragment
        }
    }

    var verificationAdapter: VerificationAdapter? = null
    var adapterList: MutableList<LiteFseProspectResponseModel> = mutableListOf()

    private var list: MutableList<LiteFseProspectResponseModel>? = mutableListOf()
    private var allowedDistance: Int = 0
    var rootView: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        showProgressDialog(activity)
        arguments?.let {

//            if (it.containsKey("list")) {
//                list = it.getParcelableArrayList("list")
//            }

            if (it.containsKey("allowedDistance")) {
                allowedDistance = it.getInt("allowedDistance")
            }
        }

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
							  savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment

        _binding = FragmentAllBinding.inflate(inflater, container, false)
        viewModel = ViewModelProviders.of(requireActivity()).get(AllViewModel::class.java)
        val layoutManager = LinearLayoutManager(activity)
        binding!!.AllRecycler.layoutManager = layoutManager


        firstVisit = true
        binding.btnMap.bringToFront()
        viewModel.getFseProspectiveFromDatabase()!!.observe(viewLifecycleOwner, Observer {

            list = it.responseData!!.prospects!!.toMutableList()

            if (!list.isNullOrEmpty()) {
                binding.tvNoData.visibility = View.GONE
                binding.AllRecycler.visibility = View.VISIBLE
                setAdapter(list!!.toMutableList())
            } else {
                binding.tvNoData.visibility = View.VISIBLE
                binding.AllRecycler.visibility = View.GONE
            }


            val distinct = list?.distinctBy { it.status }
            array.add("ALL")
            distinct?.map { array.add(it.status?.replace("_", " ") ?: "") }
            setAdapter(binding.spinner!!, array.toTypedArray())
//            cancelProgressDialog()
        })



        clickHandler()
        watcher()

        binding.btnMap.setOnClickListener {
            if (checkPersmission()) {
                val intent = Intent(activity, FseProsMapsActivity::class.java)
                intent.putExtra("radius", allowedDistance)
                startActivity(intent)
            } else {
                requestPermission()
            }

        }



        return binding.root
    }

    override fun onResume() {
        if (firstVisit) {
            //view?.etsearch?.text?.clear()
            binding?.etsearch?.text?.clear()
            firstVisit = false
        }
        super.onResume()

    }

    fun setAdapter(spinner: Spinner, array: Array<String>) {
        val spinnerArrayAdapter = ArrayAdapter<String>(
				requireContext(), R.layout.spinner_item, array
		)
        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_filter_text)
        spinner.setAdapter(spinnerArrayAdapter)
    }

    private fun clickHandler() {

        binding!!.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {
                Log.d(TAG, "Nothing selected");

            }


            override fun onItemSelected(adapterView: AdapterView<*>?, view: View?,
										position: Int, id: Long) {
                filterLogic(position, array[position])
            }
        }
    }

    fun filterLogic(position: Int, selectedStatus: String) {
        Log.d(TAG, "filterLogic=> postion:$position || selectedStatus=> $selectedStatus ");
        val filteredList: List<LiteFseProspectResponseModel>? = when (selectedStatus) {
			"PROSPECT" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.PROSPECT }
			}
			"OTP APPROVED" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.OTP_APPROVED }
			}
			"PRE APPROVED PROSPECT" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT }
			}
			"CHECKED IN" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.CHECKED_IN }
			}
			"THREE WAY CALL" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL }
			}
			"INSTALLATION PENDING" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING }
			}
			"INSTALLED" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.INSTALLED }
			}
			"INSTALLATION VERIFIED" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED }
			}
			"INSTALLATION REATTEMPT" -> {
				list?.filter { it.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT }
			}
            else -> {
                list
            }
        }

        setAdapter(filteredList!!.toMutableList())
    }

    private val PERMISSION_REQUEST_CODE: Int = 101
    private fun checkPersmission(): Boolean {
        return (ContextCompat.checkSelfPermission(requireActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED)
    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(
				requireActivity(), arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
				PERMISSION_REQUEST_CODE
		)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
			PERMISSION_REQUEST_CODE -> {
				if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
					val intent = Intent(activity, FseProsMapsActivity::class.java)
					startActivity(intent)
				}

			}
        }
    }

    fun setAdapter(mutableList: MutableList<LiteFseProspectResponseModel>) {
        adapterList.clear()
        val sortedList = mutableList.sortedByDescending { it.prospectUpdatedAtLong }
        adapterList.addAll(sortedList)

        if (verificationAdapter == null) {
            Log.e("All=inadapter= ", "${adapterList.size}")
            verificationAdapter = VerificationAdapter(requireActivity(), adapterList)
            verificationAdapter?.verificationAdapterCallback = this
            binding.AllRecycler.adapter = verificationAdapter
        }
        verificationAdapter?.notifyDataSetChanged()

    }

    private var textWatcher = object : TextWatcher {

        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
        override fun afterTextChanged(s: Editable) {

            val searchEOList = list!!.filter {
                val name = "${it.name}"
                name.contains(
						s.toString(),
						true
				)
            }.toMutableList()

            val mutablePostList: MutableLiveData<List<LiteFseProspectResponseModel>> = MutableLiveData()

            mutablePostList.value = searchEOList

            mutablePostList.observe(activity!!, searchEOObserver)

        }

    }

    val searchEOObserver: Observer<List<LiteFseProspectResponseModel>> = Observer { data ->

        if (data != null) {

            val collectionEoResponse = data

            if (collectionEoResponse.isNullOrEmpty()) {
                binding.tvNoData.visibility = View.VISIBLE
                binding.AllRecycler.visibility = View.GONE
            } else {
                binding.tvNoData.visibility = View.GONE
                binding.AllRecycler.visibility = View.VISIBLE
            }

            collectionEoResponse.let {

                setAdapter(data.toMutableList())
                Log.e("MAzhar =data= ", data.toString())
                watcher()
            }
        } else {
            Log.e("MAzhar No data= ", "NNNOOO")
        }

    }

    private fun watcher() {
        binding!!.etsearch.removeTextChangedListener(textWatcher)
        binding!!.etsearch.addTextChangedListener(textWatcher)
    }


}
