package com.greenlightplanet.kazi.incentivenew.model.reffrel

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import com.greenlightplanet.kazi.incentivenew.model.reffrel.ReferredAgents
import kotlinx.android.parcel.Parcelize

/**
 * Created by Rahul on 09/12/20.
 */

@Parcelize
@Entity
data class AgentReffedResponseData (

        @PrimaryKey
        @ColumnInfo
        @SerializedName("referredAgents") val referredAgents : List<ReferredAgents>
):Parcelable