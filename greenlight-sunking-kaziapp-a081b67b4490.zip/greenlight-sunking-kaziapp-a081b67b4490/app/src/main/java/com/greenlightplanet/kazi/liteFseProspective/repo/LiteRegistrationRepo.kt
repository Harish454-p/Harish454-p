package com.greenlightplanet.kazi.liteFseProspective.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.location.Location
import android.util.Log
import com.google.gson.Gson
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.liteFseProspective.extras.ErrorUtils
import com.greenlightplanet.kazi.liteFseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.liteFseProspective.model.*
import com.greenlightplanet.kazi.location.extras.FunctionalUtils
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.util.*

class LiteRegistrationRepo(val context: Context) {

    companion object :
            SingletonHolderUtil<LiteRegistrationRepo, Context>(::LiteRegistrationRepo) {
        public const val TAG = "RegistrationRepo"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    var gson: Gson? = null
//    var country: String? = null

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context!!)
//            country = preference?.getLoginResponseModel()?.country
            gson = Gson()

        } catch (e: Exception) {
            Log.d(TAG, ":Error ")
        }
    }
    private val territory: String? by lazy {
        preference?.getLoginResponseModel()?.territory
    }

    fun getCombineRequestModel(prospectId: String): MutableLiveData<CombineRequestModel?> {

        val data = MutableLiveData<CombineRequestModel?>()
        val combineModel = CombineRequestModel()

        bag.add(
                localDb?.liteFseProspectResponseDao()?.getByProspectId(prospectId)!!
                        .flatMap {
                            combineModel.fseProspectResponseModel = it
                            localDb?.liteRegistrationCheckInRequestDao()?.getByProspectId(prospectId)
                        }
                        .flatMap {
                            combineModel.registrationCheckinRequestModel = it
                            localDb?.liteFseErrorDao()?.getByProspectId(prospectId)
                        }
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .doFinally { data.postValue(combineModel) }
                        .subscribe({
                            combineModel.fseError = it
                        }, {
                            it.printStackTrace()
                            Log.d(TAG, "ERROR:${it.localizedMessage} ");
                        })


        )
        return data
    }

    fun performCheckin2(context: Context, isOnline: Boolean, prospectId: String, angazaId: String, area: String, location: Location, prospectAllowedDistance: Int): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()

        //bag.add(

        /*FunctionalUtils.newGetCurrentLocation(context)!!.subscribe({

        }, {

            Log.d(TAG, "Error:$it ");
            it.printStackTrace()
            data.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                    error = NewCommonResponseModel.Error(
                            messageToUser = "Unable to send data to server")
                    , success = false
            ))
        })*/


        //)

        val baseLocation = preference?.getBaselocationModel()?.fseBaseLocation

        val registrationCheckinRequestModel = LiteRegistrationCheckinRequestModel(
                prospectId = prospectId,
                angazaId = angazaId,
                latitude = location.latitude.toString(),
                longitude = location.longitude.toString(),
                checkinTime = Util.fseDateToUtcFormatted(Date()),
                area = area,
                accuracy = location.accuracy.toString(),
                country = preference?.getLoginResponseModel()?.country?: ""
        )

        /*if (isOnline) {
            sendRegistrationCheckinRequestToServer(data, registrationCheckinRequestModel)
        } else {
            insertRegistrationCheckinRequestToDatabase(data, registrationCheckinRequestModel)
        }*/

        //19.2821626,72.841517,13z //mira-road

        Log.d(TAG,
                """ baseLocation?.latitude!! :${baseLocation?.latitude!!}
                                baseLocation?.longitude!! :${baseLocation.longitude!!}
                                it.latitude :${location.latitude}
                                it.longitude :${location.longitude}
                                """.trimMargin()
        );


//        val prospectDistance = Util.getProspectDistance(context, country!!)




        Log.d(TAG, "distance:${Util.distance(baseLocation.latitude!!, location.latitude, baseLocation.longitude!!, location.longitude)} ");
        //val isNotValid = (Util.distance(baseLocation.latitude!!, location.latitude, baseLocation.longitude!!, location.longitude) > prospectDistance?.allowedDistance ?: 0)
        val isNotValid = (Util.distance(baseLocation.latitude!!, location.latitude, baseLocation.longitude!!, location.longitude) > prospectAllowedDistance ?: 0)

        insertRegistrationCheckinRequestToDatabase(isOnline, isNotValid, data, registrationCheckinRequestModel)
        return data
    }

    fun performCheckin(context: Context, isOnline: Boolean, prospectId: String, angazaId: String, area: String, prospectAllowedDistance: Int): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()

        bag.add(
                FunctionalUtils.newGetCurrentLocation(context)!!.subscribe({


                    val baseLocation = preference?.getBaselocationModel()?.fseBaseLocation

                    val registrationCheckinRequestModel = LiteRegistrationCheckinRequestModel(
                            prospectId = prospectId,
                            angazaId = angazaId,
                            latitude = it.latitude.toString(),
                            longitude = it.longitude.toString(),
                            checkinTime = Util.fseDateToUtcFormatted(Date()),
                            area = area,
                            accuracy = "",
                            country = preference?.getLoginResponseModel()?.country?: ""
                    )

                    /*if (isOnline) {
                        sendRegistrationCheckinRequestToServer(data, registrationCheckinRequestModel)
                    } else {
                        insertRegistrationCheckinRequestToDatabase(data, registrationCheckinRequestModel)
                    }*/

                    //19.2821626,72.841517,13z //mira-road

                    Log.d(TAG,
                            """
                                baseLocation?.latitude!! :${baseLocation?.latitude!!}
                                baseLocation?.longitude!! :${baseLocation.longitude!!}
                                it.latitude :${it.latitude}
                                it.longitude :${it.longitude}

                            """.trimMargin()
                    );


                    //val prospectDistance = Util.getProspectDistance(context, country!!)

                    Log.d(TAG, "distance:${Util.distance(baseLocation.latitude!!, it.latitude, baseLocation.longitude!!, it.longitude)} ");
                    //val isNotValid = (Util.distance(baseLocation.latitude!!, it.latitude, baseLocation.longitude!!, it.longitude) > prospectDistance?.allowedDistance ?: 0)
                    val isNotValid = (Util.distance(baseLocation.latitude!!, it.latitude, baseLocation.longitude!!, it.longitude) > prospectAllowedDistance ?: 0)

                    insertRegistrationCheckinRequestToDatabase(isOnline, isNotValid, data, registrationCheckinRequestModel)

                }, {

                    Log.d(TAG, "Error:$it ");
                    it.printStackTrace()
                    data.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable to send data to server")
                            , success = false
                    ))
                })
        )
        return data
    }

    fun sendRegistrationCheckinRequestToServerForceUpload(registrationCheckinRequestModel: LiteRegistrationCheckinRequestModel): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()
        var response: NewCommonResponseModel<NewEmptyParcelable>? = null

        bag.add(
                ServiceInstance.getInstance(context).service?.postLiteRegisterCheckIn(
                        registrationCheckinRequestModel = registrationCheckinRequestModel)!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .flatMapCompletable {
                            response = it

                            if (it.success) {
                                performIsChanged(registrationCheckinRequestModel.prospectId, false, registrationCheckinRequestModel.checkinTime!!)
                            } else {
                                performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, isChanged = false, errorOccurred = true, errorModel = it.error)
                            }
                        }
                        /*.doOnError { t ->

                            Log.d(TAG, "API-Error3: ${t.localizedMessage}")

                            liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                    error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable to send data to server"
                                    ),
                                    success = false
                            ))
                        }*/
                        .subscribe({
                            data.postValue(response)
                        }, { t ->


                            /*val error = t as HttpException
                            val errorBody = error.response().errorBody()!!.string()

                            val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)

                            bag.add(

                                    performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, isChanged = false, errorOccurred = true, errorModel = errorModel?.error).subscribe()
                            )

                            data.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                    error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable to send data to server"
                                    ),
                                    success = false

                            ))*/

                            /*performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, isChanged = true, errorOccurred = true, errorModel = NewCommonResponseModel.Error(
                                    messageToUser = "Unable to send data to server"
                            )).subscribe()*/

                            /*Log.d(TAG, "API-Error:$errorBody")
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")*/


                            ErrorUtils.errorHandler(
                                    gson,
                                    t,
                                    TAG,
                                    "sendRegistrationCheckinRequestToServerForceUpload",
                                    "Unable to send data to server",
                                    data
                            )
                        })
        )

        return data
    }

    private fun sendRegistrationCheckinRequestToServer(liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>, registrationCheckinRequestModel: LiteRegistrationCheckinRequestModel, isNotValid: Boolean) {

        bag.add(
                ServiceInstance.getInstance(context).service?.postLiteRegisterCheckIn(
                        registrationCheckinRequestModel = registrationCheckinRequestModel)!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .flatMapCompletable {

                            if (it.success) {
                                if (isNotValid) {
                                    liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                            success = false,
                                            error = NewCommonResponseModel.Error(
                                                    code = 1001,
                                                    messageToUser = "Your'e location is not valid"
                                            )
                                    ))
                                } else {
                                    liveData.postValue(it)
                                }
                                performIsChanged(registrationCheckinRequestModel.prospectId, false, registrationCheckinRequestModel.checkinTime!!, isNotValid)

                            } else {
                                if (isNotValid) {
                                    liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                            success = false,
                                            error = NewCommonResponseModel.Error(
                                                    code = 1001,
                                                    messageToUser = "Your'e location is not valid"
                                            )
                                    ))
                                } else {
                                    liveData.postValue(it)
                                }
                                performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, changeApproved = isNotValid, isChanged = false, errorOccurred = true, errorModel = it.error)
                            }

                        }
                        /*.doOnError { t ->

                            Log.d(TAG, "API-Error3: ${t.localizedMessage}")

                            liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                    error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable to send data to server"
                                    ),
                                    success = false
                            ))
                        }*/
                        .subscribe({}, {


                            /*//todo check the cause
                            Log.d(TAG, "cause:${t.cause} ");
                            val error = t as HttpException
                            val errorBody = error.response().errorBody()?.string()
                            val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)*/


                            val isApi = it is retrofit2.HttpException

                            var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                            if (isApi) {
                                val error = it as HttpException
                                val errorBody = error.response().errorBody()?.string()
                                errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)

                            } else {


                                errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                                        error = NewCommonResponseModel.Error(
                                                messageToUser = it.localizedMessage
                                        ),
                                        success = false

                                )

                            }


                            bag.add(
                                    performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, isChanged = false, errorOccurred = true, errorModel = errorModel?.error).subscribe()
                            )


                            if (isNotValid) {
                                liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                        success = false,
                                        error = NewCommonResponseModel.Error(
                                                code = 1001,
                                                messageToUser = "Your'e location is not valid"
                                        )
                                ))
                            } else {
                                liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                        error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable to send data to server"
                                        ),
                                        success = false
                                ))
                            }




                        })
        )
    }

    fun getRegistrationCheckinRequestFromDB(prospectId: String): MutableLiveData<LiteRegistrationCheckinRequestModel> {

        val data: MutableLiveData<LiteRegistrationCheckinRequestModel> = MutableLiveData()

        bag.add(
                localDb!!.liteRegistrationCheckInRequestDao().getByProspectId(prospectId)!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({
                            data.postValue(it)
                        }, {
                            it.printStackTrace()
                            data.postValue(null)
                        })
        )
        return data

    }

    private fun insertRegistrationCheckinRequestToDatabase(isOnline: Boolean, isNotValid: Boolean, liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>, registrationCheckinRequestModel: LiteRegistrationCheckinRequestModel) {


        localDb?.let {
            bag.add(

                    //appDatabase.liteRegistrationCheckInRequestDao().insert()
                    Completable.fromAction {
                        it.liteRegistrationCheckInRequestDao().insert(registrationCheckinRequestModel)
                    }
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                Log.d(TAG, "isNotValid :$isNotValid");
                                Log.d(TAG, "checkinTime:${registrationCheckinRequestModel.checkinTime!!}");
                                performIsChanged(
                                        prospectId = registrationCheckinRequestModel.prospectId,
                                        isChanged = true,
                                        date = registrationCheckinRequestModel.checkinTime!!,
                                        changeApproved = isNotValid)
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({

                                            Log.d(TAG, "Insertion:Completed ")

                                            if (isOnline) {

                                                sendRegistrationCheckinRequestToServer(liveData, registrationCheckinRequestModel, isNotValid)

                                            } else {

                                                if (isNotValid) {
                                                    liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                                            success = false,
                                                            error = NewCommonResponseModel.Error(
                                                                    code = 1001,
                                                                    messageToUser = "Your'e location is not valid"
                                                            )
                                                    ))
                                                } else {
                                                    liveData.postValue(NewCommonResponseModel(
                                                            success = true
                                                    ))
                                                }

                                            }


                                        }, {

                                            if (isNotValid) {
                                                liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                                        success = false,
                                                        error = NewCommonResponseModel.Error(
                                                                code = 1001,
                                                                messageToUser = "Your'e location is not valid"
                                                        )
                                                ))
                                            } else {
                                                liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                                        error = NewCommonResponseModel.Error(
                                                                messageToUser = "Unable to send data to server"
                                                        ),
                                                        success = false
                                                ))
                                            }

                                            Log.d(TAG, "DB-Error: ${it.localizedMessage}")

                                        })
                            }, { t ->

                                if (isNotValid) {
                                    liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                            success = false,
                                            error = NewCommonResponseModel.Error(
                                                    code = 1001,
                                                    messageToUser = "Your'e location is not valid"
                                            )
                                    ))
                                } else {
                                    liveData.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                                            error = NewCommonResponseModel.Error(
                                                    messageToUser = "Unable to send data to server"
                                            ),
                                            success = false
                                    ))
                                }

                                Log.d(TAG, "DB-Error: ${t.localizedMessage}")


                            })

            )
        }

    }

    private fun performIsChanged(prospectId: String, isChanged: Boolean, date: String = "", changeApproved: Boolean = false, errorOccurred: Boolean = false, errorModel: NewCommonResponseModel.Error? = null): Completable {
        return localDb!!.liteFseProspectResponseDao().getByProspectId(prospectId)!!.flatMapCompletable {
            val value = it
            value.isChanged = isChanged
            value.errorOccurred = errorOccurred
            Log.d(TAG, "errorOccurred:$errorOccurred");


            value.statusUpdateTime?.checkedIn = date
            if (changeApproved) {
                value.approved = false
                value.message = "Your Check-In has failed the distance criteria check.\n" +
                        "This Prospect will now be re-assigned. Please contact the ABM"
                value.status = FseProspectiveConstant.ProspectStatus.CHECKED_IN
            } else {
                value.approved = true
                value.status = FseProspectiveConstant.ProspectStatus.CHECKED_IN
            }

            Log.d(TAG, "checkedIn:date = $date");

            val fseError = LiteFseError(
                    prospectId = prospectId,
                    errorType = FseProspectiveConstant.ProspectiveType.REGISTRATION,
                    code = errorModel?.code,
                    errorClass = errorModel?.errorClass,
                    errorTrace = errorModel?.errorTrace,
                    messageToUser = errorModel?.messageToUser
            )


            /*Completable.fromAction {
                localDb!!.liteFseProspectResponseDao().insert(value)

            }.mergeWith {
                if (errorOccurred) {
                    Completable.fromAction {
                        localDb!!.liteFseErrorDao().insert(fseError)
                    }
                }
            }*/

            val list = mutableListOf<Completable>()

            list.add(
                    Completable.fromAction {
                        localDb!!.liteFseProspectResponseDao().insert(value)

                    }
            )
            if (errorOccurred) {
                list.add(
                        Completable.fromAction {
                            localDb!!.liteFseErrorDao().insert(fseError)
                        }
                )
            }

            /* if (!isChanged){
                 list.add(
                         Completable.fromAction {
                             localDb!!.liteFseErrorDao().deleteProspectById(prospectId)
                         }
                 )
             }*/

            Completable.merge(list)


            /*if (errorOccurred) {
                Completable.fromAction {
                    localDb!!.liteFseProspectResponseDao().insert(value)

                }.mergeWith {
                    localDb!!.liteFseErrorDao().insert(fseError)
                }
            } else {
                Completable.fromAction {
                    localDb!!.liteFseProspectResponseDao().insert(value)

                }
            }*/
        }
    }

    //new
    private fun syncServerRegistrationCheckinRequestModel(registrationCheckinRequestModel: LiteRegistrationCheckinRequestModel): Single<NewCommonResponseModel<NewEmptyParcelable>> {

        return ServiceInstance.getInstance(context).service?.postLiteRegisterCheckIn(
                registrationCheckinRequestModel = registrationCheckinRequestModel)!!
                .subscribeOn(Schedulers.newThread())
                .flatMap {
                    Single.create<NewCommonResponseModel<NewEmptyParcelable>> { emitter ->


                        try {

                            /*val result = localDb!!.liteRegistrationCheckInRequestDao().insert(registrationCheckinRequestModel)
                            result.let {
                                emitter.onSuccess(it)
                            }*/

                            performIsChanged(registrationCheckinRequestModel.prospectId, false).subscribe({ emitter.onSuccess(it) }, { emitter.onError(it) })


                        } catch (e: Exception) {
                            emitter.onError(e)
                        }
                    }
                }
                .doOnSuccess {
                    Completable.fromAction {
                        // logic
                        Log.d(TAG, " inserting:${registrationCheckinRequestModel.prospectId}");
                        performIsChanged(registrationCheckinRequestModel.prospectId, false)
                    }.subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())

                            .subscribe()
                }
                .onErrorResumeNext { it ->


                    /*val error = it as HttpException
                    val errorBody = error.response().errorBody()?.string()
                    val errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)*/

                    val isApi = it is retrofit2.HttpException

                    var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                    if (isApi) {
                        val error = it as HttpException
                        val errorBody = error.response().errorBody()?.string()
                        errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(errorBody, NewCommonResponseModel::class.java)

                    } else {


                        errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                                error = NewCommonResponseModel.Error(
                                        messageToUser = it.localizedMessage
                                ),
                                success = false

                        )

                    }


                    performIsChanged(prospectId = registrationCheckinRequestModel.prospectId, isChanged = false, errorOccurred = true, errorModel = errorModel?.error)
                            .toSingleDefault(true)
                            .onErrorReturnItem(false)
                            .flatMap {
                                Single.just(NewCommonResponseModel<NewEmptyParcelable>())
                            }

                }


    }

    private fun syncLoopRegistrationCheckinRequestModel(registrationCheckinRequestModel: List<LiteRegistrationCheckinRequestModel>): Single<List<LiteRegistrationCheckinRequestModel>> {

        val requests = mutableListOf<Single<NewCommonResponseModel<NewEmptyParcelable>>>()

        registrationCheckinRequestModel.forEach {
            requests.add(syncServerRegistrationCheckinRequestModel(it))
        }

        return Single.zip(requests) {
            //val returnList = it.map { it as NewCommonResponseModel<NewEmptyParcelable> }

            //Log.d(TAG, "r-repo:${returnList} ");
            //returnList
            registrationCheckinRequestModel
        }
    }

    /*private fun syncAllInsertRegistrationCheckinRequestModel(allSingles: Single<List<RegistrationCheckinRequestModel>>): Single<List<RegistrationCheckinRequestModel>> {


        return allSingles.flatMap {
            insertAllRegistrationCheckinToDatabase(it)
        }

    }*/

    private fun insertAllRegistrationCheckinToDatabase(registrationCheckinRequestModel: List<LiteRegistrationCheckinRequestModel>): Single<List<LiteRegistrationCheckinRequestModel>> {

        return Single.create { emitter ->

            try {
                val result = localDb!!.liteRegistrationCheckInRequestDao().insertAll(registrationCheckinRequestModel)
                result.let {
                    emitter.onSuccess(registrationCheckinRequestModel)
                }

            } catch (e: Exception) {
                emitter.onError(e)
            }
        }
    }

    /*    private fun insertAllRegistrationCheckinToDatabase(registrationCheckinRequestModel: List<RegistrationCheckinRequestModel>, responseList: List<NewCommonResponseModel<NewEmptyParcelable>>): Single<List<RegistrationCheckinRequestModel>> {

        return Single.create { emitter ->


            try {
                val result = localDb!!.liteRegistrationCheckInRequestDao().insertAll(registrationCheckinRequestModel)
                result.let {
                    emitter.onSuccess(registrationCheckinRequestModel)
                }

            } catch (e: Exception) {
                emitter.onError(e)
            }
        }
    }*/

    fun processAll(otpApprovalRequestModels: List<LiteRegistrationCheckinRequestModel>): Single<List<LiteRegistrationCheckinRequestModel>> {
        return syncLoopRegistrationCheckinRequestModel(otpApprovalRequestModels).flatMap {
            insertAllRegistrationCheckinToDatabase(it)
        }
    }


    fun getFseProspectiveFromServer(angazaId: String, prospectId: String): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>? {

        val data = MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>()

        var value: NewCommonResponseModel<LiteFseProspectItemResponseModel>? = null

        bag.add(

                localDb!!.liteFseProspectResponseDao().getByProspectId(prospectId)!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .flatMapCompletable { prospectFromDatabase ->
                            // here delete all data from database
                            Completable.fromAction {
                                localDb!!.liteFseProspectResponseDao().delete(prospectFromDatabase)
                            }.doOnError {
                                Log.d(TAG, "Error-2: ${it.localizedMessage}");
                                data.postValue(NewCommonResponseModel<LiteFseProspectResponseModel>(
                                        error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable get data from server"
                                        ),
                                        success = false
                                ))
                                it.printStackTrace()
                            }.doOnComplete {
                                //ServiceInstance.getInstance(context).service?.getFseProspectives()!!
                                ServiceInstance.getInstance(context).service?.getLiteFseProspective(angazaId, prospectId,territory!!)!!
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe({
                                            value = it!!

                                            val fromDatabase = prospectFromDatabase

                                            var fromServer = value!!.responseData!!.prospect!!

                                            var oldChangedData: LiteFseProspectResponseModel? = null

                                            //notNewAddedServerValue.forEach { itemServer ->

                                            val sameDataInDatabase = fromDatabase

                                            fun statusUpdateTimeHandler(oldStatus: LiteFseProspectResponseModel.StatusUpdateTime, newStatus: LiteFseProspectResponseModel.StatusUpdateTime, oldFseProspectResponseModel: LiteFseProspectResponseModel): LiteFseProspectResponseModel.StatusUpdateTime {
                                                var revisedStatus = oldStatus

                                                if (!newStatus.prospect.isNullOrEmpty()) {
                                                    revisedStatus.prospect = newStatus.prospect
                                                }


                                                if (!newStatus.otpApproved.isNullOrEmpty()) {
                                                    revisedStatus.otpApproved = newStatus.otpApproved
                                                }


                                                if (!newStatus.preApprovedProspect.isNullOrEmpty()) {
                                                    revisedStatus.preApprovedProspect = newStatus.preApprovedProspect
                                                }

                                                if (!newStatus.checkedIn.isNullOrEmpty()) {
                                                    revisedStatus.checkedIn = newStatus.checkedIn
                                                }

                                                if (!newStatus.threeWayCallVerification.isNullOrEmpty()) {
                                                    revisedStatus.threeWayCallVerification = newStatus.threeWayCallVerification
                                                }

                                                if (!newStatus.installationPending.isNullOrEmpty()) {
                                                    revisedStatus.installationPending = newStatus.installationPending
                                                }


                                                if (oldFseProspectResponseModel.reattemptedStage != 1 || oldFseProspectResponseModel.reattemptedStage != 2) {
                                                    if (!newStatus.installed.isNullOrEmpty()) {
                                                        revisedStatus.installed = newStatus.installed
                                                    }

                                                    if (!newStatus.installationVerified.isNullOrEmpty()) {
                                                        revisedStatus.installationVerified = newStatus.installationVerified
                                                    }
                                                }

                                                return revisedStatus
                                            }

                                            fun statusHandler(oldStatus: String, newStatus: String): String {
                                                var revisedStatus = ""

                                                when (oldStatus) {
                                                    FseProspectiveConstant.ProspectStatus.PROSPECT -> {

                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.OTP_APPROVED) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.PROSPECT
                                                        }

                                                    }

                                                    FseProspectiveConstant.ProspectStatus.OTP_APPROVED -> {
                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT -> {
                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.CHECKED_IN) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.CHECKED_IN -> {

                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                        } else if (newStatus == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL -> {
                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING -> {
                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLED) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLED
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.INSTALLED -> {
                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                                        } else if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLED
                                                        }
                                                    }
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED -> {

                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                                        }
                                                    }

                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT -> {

                                                        if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                        } else {
                                                            revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                        }
                                                    }

                                                    else -> {
                                                        revisedStatus = FseProspectiveConstant.ProspectStatus.PROSPECT
                                                    }

                                                }

                                                return revisedStatus
                                            }

                                            sameDataInDatabase?.let {

                                                sameDataInDatabase.approved = fromServer.approved
                                                sameDataInDatabase.message = fromServer.message
                                                sameDataInDatabase.customerAddress = fromServer.customerAddress

                                                sameDataInDatabase.name = fromServer.name
                                                sameDataInDatabase.otp = fromServer.otp
                                                sameDataInDatabase.productName = fromServer.productName
                                                sameDataInDatabase.status = statusHandler(sameDataInDatabase.status!!, fromServer.status!!)
                                                sameDataInDatabase.statusUpdateTime = statusUpdateTimeHandler(sameDataInDatabase.statusUpdateTime!!, fromServer.statusUpdateTime!!, sameDataInDatabase)
                                                sameDataInDatabase.ticketType = fromServer.ticketType
                                                sameDataInDatabase.accountNumber = fromServer.accountNumber
                                                sameDataInDatabase.installationPicture = fromServer.installationPicture
                                                sameDataInDatabase.customerPhoneNumber = fromServer.customerPhoneNumber
                                                sameDataInDatabase.area = fromServer.area

                                                oldChangedData = sameDataInDatabase

                                            }


                                            val resultData = oldChangedData


                                            if (resultData != null) {

                                                //data.postValue(value)
                                                fromServer = resultData
                                                fseProspectiveFromServerLogic(data, NewCommonResponseModel(responseData = fromServer, success = true))
                                                //add to database

                                            } else {
                                                data.postValue(
                                                        NewCommonResponseModel<LiteFseProspectResponseModel>(
                                                                error = NewCommonResponseModel.Error(
                                                                        messageToUser = "Unable get data from server"
                                                                ),
                                                                success = false
                                                        )
                                                )
                                            }
                                        }, {
                                            Log.d(TAG, "Error-1: ${it.localizedMessage}");

                                            data.postValue(NewCommonResponseModel<LiteFseProspectResponseModel>(
                                                    error = NewCommonResponseModel.Error(
                                                            messageToUser = "Unable get data from server"
                                                    ),
                                                    success = false
                                            ))

                                            it.printStackTrace()
                                        })
                            }
                        }.doOnError {
                            Log.d(TAG, "Error-1: ${it.localizedMessage}");
                            data.postValue(NewCommonResponseModel<LiteFseProspectResponseModel>(
                                    error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable get data from server"
                                    ),
                                    success = false
                            ))
                            it.printStackTrace()
                        }.subscribe()

        )

        return data
    }

    private fun fseProspectiveFromServerLogic(liveData: MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>, responseData: NewCommonResponseModel<LiteFseProspectResponseModel>) {

        bag.add(
                Completable.fromAction {
                    localDb?.liteFseProspectResponseDao()?.insert(responseData.responseData!!)
                }
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({
                            Log.d(TAG, "Insertion:Completed ")
                            preference?.setFseProspectLastSynced(Util.getCurrentLocalFormattedDateForSync())
                            liveData.postValue(responseData)
                        }, { t ->
                            Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                        })
        )

    }

    fun destroy() {

        Log.d(TAG, "Repo : Distroyed");
        bag.clear()

    }

}
