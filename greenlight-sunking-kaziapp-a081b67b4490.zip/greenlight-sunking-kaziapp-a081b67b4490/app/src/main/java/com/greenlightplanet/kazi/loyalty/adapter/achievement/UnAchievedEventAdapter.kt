package com.greenlightplanet.kazi.loyalty.adapter.achievement

import android.content.Context
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYou
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYouListener
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ItemLoadingBinding
import com.greenlightplanet.kazi.databinding.ItemPostBinding
import com.greenlightplanet.kazi.loyalty.model.achievements.unachieved.UnAchievedEvents
import com.squareup.picasso.Picasso


/**
 * Created by Rahul on 06/04/21.
 */


class UnAchievedEventAdapter internal constructor(private var mUnAchieved: MutableList<UnAchievedEvents>, var context: Context) : RecyclerView.Adapter<BaseViewHolder>() {
    private val VIEW_TYPE_LOADING = 0
    private val VIEW_TYPE_NORMAL = 1
    private var isLoaderVisible = false

    lateinit var onUnAchievedClickItem: OnUnAchievedClickItem


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder {
        return when (viewType) {
            VIEW_TYPE_NORMAL -> ViewHolder(
                    ItemPostBinding.inflate(LayoutInflater.from(parent.context), parent, false), mUnAchieved, context, onUnAchievedClickItem)
            VIEW_TYPE_LOADING -> ProgressHolder(
                    ItemLoadingBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            else -> null!!
        }
    }

    override fun onBindViewHolder(holder: BaseViewHolder, position: Int) {
        holder.onBind(position)
    }

    override fun getItemViewType(position: Int): Int {
        return if (isLoaderVisible) {
            if (position == mUnAchieved.size - 1) VIEW_TYPE_LOADING else VIEW_TYPE_NORMAL
        } else {
            VIEW_TYPE_NORMAL
        }
    }

    override fun getItemCount(): Int {
        return mUnAchieved.size
    }

    fun addItems(unAchievedEvents: MutableList<UnAchievedEvents>) {
        mUnAchieved.removeAll(unAchievedEvents)
        mUnAchieved.addAll(unAchievedEvents)
        notifyDataSetChanged()
    }

    fun addLoading() {
        isLoaderVisible = true
        mUnAchieved.add(UnAchievedEvents(0, 0, "", 0, 0, "", "", "", false))
        notifyItemInserted(mUnAchieved.size - 1)
    }

    fun removeLoading() {
        isLoaderVisible = false
        val position = mUnAchieved.size - 1
        val item: UnAchievedEvents? = getItem(position)
        if (item?.type_id == 0) {
            mUnAchieved.removeAt(position)
            notifyItemRemoved(position)
        }
    }


    fun clear() {
        mUnAchieved.clear()
        notifyDataSetChanged()
    }

    fun getItem(position: Int): UnAchievedEvents {
        return mUnAchieved[position]
    }

    class ViewHolder internal constructor(private val itemBinding:  ItemPostBinding, val mUnAchieved: MutableList<UnAchievedEvents>?, val context: Context, val onUnAchievedClickItem: OnUnAchievedClickItem?) : BaseViewHolder(itemBinding.root) {

        override fun clear() {}
        override fun onBind(position: Int) {
            super.onBind(position)
            val item: UnAchievedEvents? = mUnAchieved?.distinct()?.get(position)
            itemBinding.imgLocakId.visibility = View.VISIBLE
            itemBinding.imageBackgroundId.background = context.resources.getDrawable(R.drawable.light_gray_circle)


            itemView.setOnClickListener { item?.let { it1 -> onUnAchievedClickItem?.onUnAchievedTab(it1) } }

            if (item?.icon_url?.contains(".svg") == true) {
                GlideToVectorYou
                        .init()
                        .with(context)
                        .withListener(object : GlideToVectorYouListener {
                            override fun onLoadFailed() {

                            }

                            override fun onResourceReady() {
                            }
                        })
                        .load(Uri.parse(item.icon_url), itemBinding.imgIconId);
            } else {

                try {
                    item?.icon_url?.let {
                        Picasso.get().load(it)
                                .into(itemBinding.imgIconId)
                    }
                } catch (e: Exception) {
                    Log.e("error","${e.localizedMessage}")
                }

            }

            itemBinding.tvNameId.text = item?.name
        }

    }

    class ProgressHolder internal constructor(itemBinding:  ItemLoadingBinding) : BaseViewHolder(itemBinding.root) {
        override fun clear() {}


    }


    interface OnUnAchievedClickItem {

        fun onUnAchievedTab(unAchievedEvents: UnAchievedEvents)


    }
}