package com.greenlightplanet.kazi.collectiongoal.view.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.annotation.Keep
import androidx.appcompat.app.AppCompatActivity
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityCustomerProfileBinding
import com.greenlightplanet.kazi.liteFseProspective.view.activity.MapsCheckActivity
import com.greenlightplanet.kazi.newtasks.extras.AdapterUtils
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util

@Keep
class CustomerProfileActivity : BaseActivity() {

    var makeCallNewModel:MakeCallNewModel.ColGoalAccount? = null
    private lateinit var binding: ActivityCustomerProfileBinding
    var preference: GreenLightPreference? = null
    var loginResponseModel: LoginResponseModel? = null
    var activity: AppCompatActivity? = null
    var isFromNotification = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomerProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)


        initialize()
        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        if (intent.hasExtra("fromNotification")) {
            isFromNotification = intent.getBooleanExtra("fromNotification", false)
        }
    }

    fun initialize() {
        activity = this
        Util.setToolbar(this, this.binding.toolbar)
        preference = GreenLightPreference.getInstance(this)
        loginResponseModel = preference?.getLoginResponseModel()

        makeCallNewModel = intent.extras!!.getParcelable("makeCallCustomerData")

        Log.d("CheckingModelData4",makeCallNewModel?.customerName.toString())

        setData(makeCallNewModel)

        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this)
        binding.tvTaskLastSaved.text = data?.makeCallSaved

        ClickListener()

    }

    private fun ClickListener() {

        binding.btPaymentHistory.setOnClickListener {

            val intent = Intent(this, CustomerHistoryActivity::class.java)
            intent.putExtra("accountNumber", makeCallNewModel?.accountNumber?.toInt())
            intent.putExtra("paymentHistory", true)
            startActivity(intent)
        }

        binding.btCallingHistory.setOnClickListener {

            val intent = Intent(this, CustomerHistoryActivity::class.java)
            intent.putExtra("accountNumber", makeCallNewModel?.accountNumber?.toInt())
            intent.putExtra("paymentHistory", false)
            startActivity(intent)
        }



        binding.imgLoc.setOnClickListener {

            if (binding.imgLoc.visibility!=View.INVISIBLE){
                val intent = Intent(this, MapsCheckActivity::class.java)
                intent.putExtra("LAT", makeCallNewModel?.latitude)
                intent.putExtra("LONG", makeCallNewModel?.longitude)
                intent.putExtra("NAME", makeCallNewModel?.customerName)
                startActivity(intent)
            }

        }

        binding.tvcustPhonenumber1.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL)
            intent.data = Uri.parse("tel:${makeCallNewModel?.ownerPhoneNumber}")
            startActivity(intent)

        }
        binding.tv2PhoneNumber.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL)
            intent.data = Uri.parse("tel:${makeCallNewModel?.secondaryPhoneNumber}")
            startActivity(intent)

        }
    }

    @SuppressLint("SetTextI18n")
    private fun setData(makeCallNewModel: MakeCallNewModel.ColGoalAccount?) {

        val symbol = preference?.getCountryResponseModel()?.countryCurrency ?: "NA"
        binding.tvcustAccountNumber.text = makeCallNewModel?.accountNumber.toString().let { Util.checkBlankNA(it,this) }
        binding.tvCustomerRegDate.text =  "${AdapterUtils.`yyyy-MM-dd_To_dd-MM-yyyy`(makeCallNewModel?.registrationDate)}"
        binding.tvcustName.text = makeCallNewModel?.customerName
        binding.tvcustAddress.text = makeCallNewModel?.address
        binding.tvcustPhonenumber1.text = makeCallNewModel?.ownerPhoneNumber
        binding.tvcustStatus.text = makeCallNewModel?.status
        binding.tvproductName.text = makeCallNewModel?.productName
        binding.tv2PhoneNumber.text = makeCallNewModel?.secondaryPhoneNumber

        //binding.tvcustTotalPaid.text = makeCallNewModel?.totalPaid.toString()


        binding.tvcustTotalPaid.text =  "${Util.formatAmount(makeCallNewModel?.totalPaid ?: 0.0)} $symbol"

        //binding.tvcustAmountRemaining.text = makeCallNewModel?.balanceAmount.toString()
        binding.tvcustAmountRemaining.text =  "${Util.formatAmount(makeCallNewModel?.balanceAmount ?: 0.0)} $symbol"

        //binding.tvcustUnlockprice.text = makeCallNewModel?.unlockPrice.toString()
        binding.tvcustUnlockprice.text = "${Util.formatAmount(makeCallNewModel?.unlockPrice ?: 0.0)} $symbol"


        /** New Changes */

//        if (makeCallNewModel?.latitude == 0.0 || makeCallNewModel?.longitude == 0.0) {
//            binding.imgLoc.visibility = View.INVISIBLE
//        } else {
//            binding.imgLoc.visibility = View.VISIBLE
//        }


        when(makeCallNewModel?.latitude){
            0.0 -> {
                binding.imgLoc.visibility = View.INVISIBLE
            }
            null -> {
                binding.imgLoc.visibility = View.INVISIBLE
            }

            else -> {
                when(makeCallNewModel.longitude){
                    0.0 -> {
                        binding.imgLoc.visibility = View.INVISIBLE
                    }
                    null -> {
                        binding.imgLoc.visibility = View.INVISIBLE
                    }

                    else -> {
                        binding.imgLoc.visibility = View.VISIBLE
                    }
                }
            }
        }


        when (makeCallNewModel?.daysDisabled) {
            null -> binding.llDaysDisabled.visibility = View.GONE
            else ->  binding.tvDaysDisabled.text = makeCallNewModel.daysDisabled.toString()
        }

        when (makeCallNewModel?.lastPaidDate) {
            null -> binding.llLastPaymentDate.visibility = View.GONE
            else -> binding.tvLastPaymentDate.text =
                "${AdapterUtils.`yyyy-MM-dd_To_dd-MM-yyyy`(makeCallNewModel.lastPaidDate)}"
        }

        when (makeCallNewModel?.weeklyPaymentRate) {
            null -> binding.llWeeklyPayment.visibility = View.GONE
            else -> binding.tvWeeklyPayment.text =
                "${Util.formatAmount(makeCallNewModel.weeklyPaymentRate ?: 0.0)} $symbol"
        }


        when (makeCallNewModel?.minimumPaymentAmount) {
            null -> binding.llMinimumPayment.visibility = View.GONE
            else -> binding.tvMinimumPayment.text =
                "${Util.formatAmount(makeCallNewModel.minimumPaymentAmount ?: 0.0)} $symbol"
        }



//        makeCallNewModel?.balanceAmount.let { it?.roundToInt() }.toString()
//            .let { Util.checkBlank(it, context = this) } +" "+symbol

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        finish()
        return true
    }

//    private val onBackPressedCallback: OnBackPressedCallback =
//        object : OnBackPressedCallback(true) {
//            override fun handleOnBackPressed() {
//                finish()
//            }
//        }

//    override fun onBackPressed() {
//        super.onBackPressed()
//        finish()
//    }
}