package com.greenlightplanet.kazi.liteFseProspective.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import com.google.gson.Gson
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.liteFseProspective.extras.ErrorUtils
import com.greenlightplanet.kazi.liteFseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.liteFseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.liteFseProspective.model.*
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.*

class LiteInstallationRepo(val context: Context) {

    companion object : SingletonHolderUtil<LiteInstallationRepo, Context>(::LiteInstallationRepo) {
        public const val TAG = "LiteInstallationRepo"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    var gson: Gson? = null

    //var country: String? = null
    private val territory: String? by lazy {
        preference?.getLoginResponseModel()?.territory
    }


    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context!!)
            //country = preference?.getLoginResponseModel()?.country
            gson = Gson()

        } catch (e: Exception) {
            Log.d(TAG, ":Error ");
        }
    }


    fun updateFseProspect(fseProspectResponseModel: LiteFseProspectResponseModel): MutableLiveData<LiteFseProspectResponseModel> {
        val data = MutableLiveData<LiteFseProspectResponseModel>()

        bag.add(
            Completable.fromAction {
                localDb?.liteFseProspectResponseDao()?.insert(fseProspectResponseModel)
            }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(fseProspectResponseModel)
                }, { data.postValue(null) })
        )


        return data
    }


    //This is called when activity is loaded and installation is perform
    fun getCombineRequestModel(prospectId: String): MutableLiveData<CombineRequestModel> {

        val data = MutableLiveData<CombineRequestModel>()
        val combineModel = CombineRequestModel()


        bag.add(
            localDb?.liteFseProspectResponseDao()?.getByProspectId(prospectId)!!
                .flatMap {
                    combineModel.fseProspectResponseModel = it
                    localDb?.liteInstallationRequestDao()?.getByProspectId(prospectId)
                }.flatMap {
                    combineModel.installationRequestModels = it
                    localDb?.liteFseErrorDao()?.getByProspectId(prospectId)!!
                }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .doFinally { data.postValue(combineModel) }
                .doOnError {
                    Log.d(TAG, "doOnERROR:${it.localizedMessage} ");

                }
                .subscribe({
                    combineModel.fseError = it
                }, {
//                    it.printStackTrace()
                    Log.d(TAG, "ERROR:${it.localizedMessage} ");
                })
        )
        return data
    }


    //Force Sync-Installation is perform for a particular prospect
    fun sendInstallationRequestToServerForce(
        installationRequestModel: LiteInstallationRequestModel,
        fileModel: List<LiteAwsImageModel>
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()
        bag.add(
            ServiceInstance.getInstance(context).service?.postLiteInstallation(
                prospectId = installationRequestModel.prospectId,
                installationRequestModel = installationRequestModel
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable {
                    if (it.success) {
                        data.postValue(it)
                        performIsChanged(
                            installationRequestModel.prospectId,
                            false,
                            installationRequestModel.installationCompletedTime!!
                        )
                            .mergeWith {
//                                            fileModel.uploadedToGLPServer = true
//                                            fileModel.savedInDatabase = true
                                fileModel.forEach {
                                    it.uploadedToGLPServer = true
                                    it.savedInDatabase = true
                                }
//                                            localDb?.liteAwsImageModelDao()?.insert(fileModel)
                                localDb?.liteAwsImageModelDao()?.insertAll(fileModel)

                            }
                    } else {
                        data.postValue(it)
                        performIsChanged(
                            prospectId = installationRequestModel.prospectId,
                            isChanged = false,
                            errorOccurred = true,
                            errorModel = it.error
                        )
                    }


                }.subscribe({}, { t ->

                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "sendInstallationRequestToServerForce",
                        "Unable to send data to server",
                        data
                    )

                })
        )
        return data
    }

    //Performing installation based on Online/Offline automatically
    fun performInstallation(
        context: Context,
        fseProspectResponseModel: LiteFseProspectResponseModel?,
        isOnline: Boolean,
        prospectId: String,
        angazaId: String,
        accountNumber: String,
        installationAttempted: Int,
        fileModel: List<LiteAwsImageModel>/*, location: Location*/
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()
        val imageList: MutableList<LiteInstallationRequestModel.ImagesList> = mutableListOf()
        imageList.clear()
        val fseLoc = fseProspectResponseModel!!.prospectLocation
        if (fseProspectResponseModel.isInstallationChanged!!) {
            for (fse in fseProspectResponseModel.installationPictures!!) {
                if (fse.isRejected!!) {
                    imageList.add(
                        LiteInstallationRequestModel.ImagesList(
                            installationPictures = fse.url,
                            latitude = fseLoc!!.latitude.toString(),
                            longitude = fseLoc.longitude.toString(),
                            accuracy = fseLoc.accuracy.toString(),
                            attempt = fse.attempt.plus(1),
                            imageName = fse.name
                        )
                    )
                } else {
                    imageList.add(
                        LiteInstallationRequestModel.ImagesList(
                            installationPictures = fse.url,
                            latitude = fseLoc!!.latitude.toString(),
                            longitude = fseLoc.longitude.toString(),
                            accuracy = fseLoc.accuracy.toString(),
                            attempt = fse.attempt,
                            imageName = fse.name
                        )
                    )
                }

            }
        } else {
            for (fse in fseProspectResponseModel.installationPictures!!) {
                if (fse.isRejected!!) {
                    imageList.add(
                        LiteInstallationRequestModel.ImagesList(
                            installationPictures = fse.url,
                            latitude = fseLoc!!.latitude.toString(),
                            longitude = fseLoc.longitude.toString(),
                            accuracy = fseLoc.accuracy.toString(),
                            attempt = fse.attempt.plus(1),
                            imageName = fse.name
                        )
                    )
                } else {
                    imageList.add(
                        LiteInstallationRequestModel.ImagesList(
                            installationPictures = fse.url,
                            latitude = fseLoc!!.latitude.toString(),
                            longitude = fseLoc.longitude.toString(),
                            accuracy = fseLoc.accuracy.toString(),
                            attempt = installationAttempted,
                            imageName = fse.name
                        )
                    )
                }

            }
        }


        val installationRequestModel = LiteInstallationRequestModel(
            images = imageList,
            prospectId = prospectId,
            angazaId = angazaId,
            installationCompletedTime = Util.fseDateToUtcFormatted(Date()),
            accountNumber = accountNumber,
            installationAttempted = installationAttempted,
            country = preference?.getLoginResponseModel()?.country ?: ""
        )

        //Insert Lat-long to Database first
        insertInstallationRequestToDatabase(isOnline, data, installationRequestModel, fileModel)

        return data
    }

    fun performInstallation2(
        context: Context,
        fseProspectResponseModel: LiteFseProspectResponseModel?,
        isOnline: Boolean,
        prospectId: String,
        fileModel: List<LiteAwsImageModel>
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()

        bag.add(
            localDb!!.liteInstallationRequestDao().getByProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .subscribeOn(Schedulers.io())
                .subscribe({
                    it.images!!.map { data ->
                        fileModel.find { it.imageName == data.imageName }?.let {
                            data.installationPictures = it.awsLink
                        }
                    }
                    Log.e(TAG, "installationRequestModel === $it")

                    Log.e(TAG, "fileModel === $fileModel")
                    insertInstallationRequestToDatabase(isOnline, data, it, fileModel)
                }, { t ->

                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "performInstallation2",
                        "Unable to send data to server",
                        data
                    )

                })
        )


        return data
    }


    private fun sendInstallationRequestToServer(
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        installationRequestModel: LiteInstallationRequestModel,
        fileModel: List<LiteAwsImageModel>
    ) {

        var response: NewCommonResponseModel<NewEmptyParcelable>? = null

        bag.add(
            ServiceInstance.getInstance(context).service?.postLiteInstallation(
                prospectId = installationRequestModel.prospectId,
                installationRequestModel = installationRequestModel
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "sendInstallationRequestToServer-subscribe:$response");
//                            liveData.postValue(response)

                    if (it.success) {

                        val list = mutableListOf<Completable>()
                        fileModel.forEach {
                            it.uploadedToGLPServer = true
                            it.savedInDatabase = true
                        }
                        list.add(
                            performIsChanged(
                                installationRequestModel.prospectId,
                                false,
                                installationRequestModel.installationCompletedTime!!
                            )
                        )
                        list.add(
                            Completable.fromAction {
//                                            localDb?.liteAwsImageModelDao()?.insert(fileModel)
                                localDb?.liteAwsImageModelDao()?.insertAll(fileModel)
                            }
                        )

                        bag.add(
                            Completable.merge(list).subscribe({
                                Log.d(TAG, "sendInstallationRequestToServer-subscribe1:$response");
                                liveData.postValue(response)
                                localDb?.let {
                                    it.liteInstallationRequestDao().delete(installationRequestModel)
                                }
                            }, {
                                /*Log.d(TAG, "sendInstallationRequestToServer-subscribe2:$response");
                                liveData.postValue(response)*/
                                Log.d(TAG, "API-Error3: ${it.localizedMessage}")
                            })
                        )

                    } else {
                        bag.add(
                            performIsChanged(
                                prospectId = installationRequestModel.prospectId,
                                isChanged = false,
                                errorOccurred = true,
                                errorModel = it.error
                            )
                                .observeOn(Schedulers.io())
                                .subscribeOn(Schedulers.io())
                                .subscribe({
                                    Log.d(
                                        TAG,
                                        "sendInstallationRequestToServer-subscribe3:$response"
                                    );
                                    liveData.postValue(response)
                                }, {
                                    //Log.d(TAG, "sendInstallationRequestToServer-subscribe4:$response");
                                    //liveData.postValue(response)
                                    Log.d(TAG, "API-Error4: ${it.localizedMessage}")

                                })
                        )

                    }
//                            liveData.postValue(it)

                }, { t ->


                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "sendInstallationRequestToServer",
                        "Unable to send data to server",
                        liveData
                    )


                })
        )
    }


    /*
    * After getting latlong first insert data to database
    *
    *
    * */
    private fun insertInstallationRequestToDatabase(
        isOnline: Boolean,
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        installationRequestModel: LiteInstallationRequestModel,
        fileModel: List<LiteAwsImageModel>
    ) {
        localDb?.let {
            bag.add(
                //Inserting Lat-Long to database
                Completable.fromAction {
                    it.liteInstallationRequestDao().insert(installationRequestModel)
                }
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        //after lat-long insertion in database
                        //Perform is Change
                        performIsChanged(
                            prospectId = installationRequestModel.prospectId,
                            isChanged = true,
                            installationAttempted = installationRequestModel.installationAttempted
                        )
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                //after performing change in fseprospectModel
                                //Inserting AwsImageModel to database
                                Completable.fromAction {
                                    fileModel.forEach {
                                        it.savedInDatabase = true
                                    }
                                    localDb?.liteAwsImageModelDao()?.insertAll(fileModel)

                                }.subscribeOn(Schedulers.io())
                                    .observeOn(Schedulers.io())
                                    .subscribe({
                                        //after inserting AwsImageModel to database
                                        if (isOnline) {
                                            //If online send the (already) saved Installation request to server
                                            sendInstallationRequestToServer(
                                                liveData,
                                                installationRequestModel,
                                                fileModel
                                            )
                                        } else {
                                            //If not online notify the view by live data
                                            //successfully inserted to database
                                            liveData.postValue(
                                                NewCommonResponseModel<NewEmptyParcelable>(
                                                    success = true
                                                )
                                            )
                                        }
                                    }, {
                                        //Error occured while save awsImageMolde to database
                                        liveData.postValue(
                                            NewCommonResponseModel<NewEmptyParcelable>(
                                                error = NewCommonResponseModel.Error(
                                                    messageToUser = "Unable to send data to server"
                                                ),
                                                success = false
                                            )
                                        )
                                    })

                            }, {
                                //Error occurred while performing change in fseprospectModel
                                Log.d(TAG, "DB-Error: ${it.localizedMessage}")
                                liveData.postValue(null)
                                liveData.postValue(
                                    NewCommonResponseModel<NewEmptyParcelable>(
                                        error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable to send data to server"
                                        ),
                                        success = false
                                    )
                                )

                            })

                    }, { t ->

                        ErrorUtils.errorHandler(
                            gson,
                            t,
                            TAG,
                            "insertInstallationRequestToDatabase",
                            "Unable to send data to server",
                            liveData
                        )
                    })

            )
        }

    }

    private fun performIsChanged(
        prospectId: String,
        isChanged: Boolean,
        date: String = "",
        installationAttempted: Int? = null,
        errorOccurred: Boolean = false,
        errorModel: NewCommonResponseModel.Error? = null
    ): Completable {

        return localDb!!.liteFseProspectResponseDao().getByProspectId(prospectId)!!
            .flatMapCompletable {
                Log.d(TAG, "alpha 1abcd: ");
                val value = it
                value.isChanged = isChanged
                value.errorOccurred = errorOccurred

                if (installationAttempted != null) {
                    value.installationAttempted = installationAttempted
                }

                if (isChanged) {
                    value.reattemptedStage = 2
                }

                val fseError = LiteFseError(
                    prospectId = prospectId,
                    errorType = FseProspectiveConstant.ProspectiveType.INSTALLATION,
                    code = errorModel?.code,
                    errorClass = errorModel?.errorClass,
                    errorTrace = errorModel?.errorTrace,
                    messageToUser = errorModel?.messageToUser
                )

                if (!isChanged && !errorOccurred && date.isNotEmpty()) {
                    value.statusUpdateTime?.installed = date
                    if (!value.statusUpdateObjects!!.isEmpty()) {
                        value.statusUpdateObjects!!.forEach {
                            if (value.status == FseProspectiveConstant.ProspectStatus.INSTALLED) {
                                it.statusTime = date
                            }
                        }
                    }
                    value.approved = true
                    value.status = FseProspectiveConstant.ProspectStatus.INSTALLED
                    value.reattemptedStage = 0
                }


                val list = mutableListOf<Completable>()

                list.add(
                    Completable.fromAction {
                        localDb!!.liteFseProspectResponseDao().insert(value)

                    }
                )
                if (errorOccurred) {
                    list.add(
                        Completable.fromAction {
                            localDb!!.liteFseErrorDao().insert(fseError)
                        }
                    )
                }
                Completable.merge(list)

            }
    }

    //AwsImageModel logics

    fun insertAwsImageModelToDatabase(
        inputFiles: List<LiteAwsImageModel>,
        isUploadedToAws: Boolean?
    ): MutableLiveData<List<LiteAwsImageModel>?> {
        val data = MutableLiveData<List<LiteAwsImageModel>?>()

        inputFiles.forEach { each ->
            each.savedInDatabase = true
            isUploadedToAws?.let {
                each.uploadedToAws = isUploadedToAws
            }

        }

        bag.add(
            Completable.fromAction {
                localDb?.liteAwsImageModelDao()?.insertAll(inputFiles)
            }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "alpha2: ");
                    data.postValue(inputFiles.toMutableList())
                }, {
                    data.postValue(null)
                    Log.d(TAG, "Error:${it.localizedMessage} ");
                    it.printStackTrace()
                })
        )

        return data

    }

    fun getInstallationRequestModelByProspectId(prospectId: String): MutableLiveData<LiteInstallationRequestModel> {

        val data = MutableLiveData<LiteInstallationRequestModel>()

        bag.add(
            localDb!!.liteInstallationRequestDao().getByProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(it)
                }, {
                    it.printStackTrace()
                    data.postValue(null)
                })
        )

        return data
    }

    fun getAllAwsImageModelByProspectId(prospectId: String): MutableLiveData<List<LiteAwsImageModel>> {

        val data = MutableLiveData<List<LiteAwsImageModel>>()

        bag.add(
//                localDb!!.liteAwsImageModelDao().getByProspectId(prospectId)!!
            localDb!!.liteAwsImageModelDao().getByALLProspectId(prospectId)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .doOnError { data.postValue(null) }
                .subscribe({
                    data.postValue(it)
                }, {
                    it.printStackTrace()
                    data.postValue(null)
                })
        )

        return data
    }
    ///new

    private fun syncServerInstallationRequestModel(installationRequestModel: LiteInstallationRequestModel): Single<NewCommonResponseModel<NewEmptyParcelable>> {


        return ServiceInstance.getInstance(context).service?.postLiteInstallation(
            prospectId = installationRequestModel.prospectId,
            installationRequestModel = installationRequestModel
        )!!
            .subscribeOn(Schedulers.newThread())
            .flatMap {
                Single.create<NewCommonResponseModel<NewEmptyParcelable>> { emitter ->


                    try {
                        if (it.success) {
                            performIsChanged(
                                installationRequestModel.prospectId,
                                false,
                                installationRequestModel.installationCompletedTime!!
                            ).subscribe({ emitter.onSuccess(it) }, { emitter.onError(it) })
                        } else {
                            performIsChanged(
                                prospectId = installationRequestModel.prospectId,
                                isChanged = false,
                                errorOccurred = true,
                                errorModel = it.error
                            ).subscribe({ emitter.onSuccess(it) }, { emitter.onError(it) })
                        }


                    } catch (e: Exception) {
                        emitter.onError(e)
                    }
                }

            }
            .doOnSuccess {
                Log.d(
                    TAG,
                    " inserting-syncServerInstallationRequestModel:${installationRequestModel.prospectId} "
                );
                Completable.fromAction {
                    // logic
                    if (it.success) {
                        performIsChanged(
                            installationRequestModel.prospectId,
                            false,
                            installationRequestModel.installationCompletedTime!!
                        )
                    } else {
                        performIsChanged(
                            prospectId = installationRequestModel.prospectId,
                            isChanged = false,
                            errorOccurred = true,
                            errorModel = it.error
                        )
                    }

                }.subscribe({
                    Log.d(TAG, " on Success ===");
                },{
                    Log.d(TAG, " Error:${it.printStackTrace()}");
                })

            }
            .onErrorResumeNext { it ->


                val isApi = it is retrofit2.HttpException

                var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                if (isApi) {
                    val error = it as HttpException
                    val errorBody = error.response().errorBody()?.string()
                    errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(
                        errorBody,
                        NewCommonResponseModel::class.java
                    )

                } else {


                    errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                        error = NewCommonResponseModel.Error(
                            messageToUser = it.localizedMessage
                        ),
                        success = false
                    )

                }

                Log.d(
                    TAG,
                    " inserting-syncServerInstallationRequestModel-Error:${installationRequestModel.prospectId} "
                );

                performIsChanged(
                    prospectId = installationRequestModel.prospectId,
                    isChanged = false,
                    errorOccurred = true,
                    errorModel = errorModel?.error
                )
                    .toSingleDefault(true)
                    .doOnError {
//                        it.printStackTrace()
                        Log.d(TAG, "return item2: ${it.localizedMessage}");
                    }
                    .onErrorReturnItem(false)
                    .flatMap {
                        Log.d(TAG, "return item: $it");
                        Single.just(NewCommonResponseModel<NewEmptyParcelable>())
                    }

            }

    }

    private fun syncLoopInstallationRequestModel(installationRequestModel: List<LiteInstallationRequestModel>): Single<List<LiteInstallationRequestModel>> {

        val requests = mutableListOf<Single<NewCommonResponseModel<NewEmptyParcelable>>>()

        installationRequestModel.forEach {
            requests.add(syncServerInstallationRequestModel(it))
        }

        return Single.zip(requests) {
            installationRequestModel
        }
    }


    private fun syncAllInsertInstallationRequestModel(allSingles: Single<List<LiteInstallationRequestModel>>): Single<List<LiteInstallationRequestModel>> {


        return allSingles.flatMap {
            insertAllInstallationRequestToDatabase(it)
        }

    }

    private fun insertAllInstallationRequestToDatabase(installationRequestModel: List<LiteInstallationRequestModel>): Single<List<LiteInstallationRequestModel>> {

        Log.d(TAG, "installationRequestModel-sync:$installationRequestModel ");
        return Single.create { emitter ->

            try {
                val result =
                    localDb!!.liteInstallationRequestDao().insertAll(installationRequestModel)
                result.let {
                    emitter.onSuccess(installationRequestModel)
                }

            } catch (e: Exception) {
                emitter.onError(e)
            }
        }
    }

    fun processAll(otpApprovalRequestModels: List<LiteInstallationRequestModel>): Single<List<LiteInstallationRequestModel>> {
        return syncLoopInstallationRequestModel(otpApprovalRequestModels).flatMap {
            insertAllInstallationRequestToDatabase(it)
        }
    }


    //region Compress Image
    fun compressImageForAws(
        context: Context,
        inputFiles: List<ImageUploadUtil.ImageModel>
    ): MutableLiveData<List<LiteAwsImageModel>?> {
        val data = MutableLiveData<List<LiteAwsImageModel>?>()

        val newAwsImageModel = mutableListOf<LiteAwsImageModel>()

        bag.add(
            ImageUploadUtil.compress(context, inputFiles.map { it.file!! })!!
                .flatMapCompletable {
                    for (file in it) {
                        Log.d(TAG, "Success: ${file.path}\n");
                        val imageModel =
                            inputFiles.find { it.file!!.nameWithoutExtension == file.nameWithoutExtension }
                        // start
                        val image: Uri = getImageUri(
                            context,
                            rotationTest(imageModel?.file?.absolutePath),
                            file.name
                        )!!

                        val customFile = File(getRealPathFromURI(image, context)!!)
                        //end

                        newAwsImageModel.add(
                            LiteAwsImageModel(
                                tried = false,
                                fileName = customFile.name,
                                withoutExtension = customFile.nameWithoutExtension,
                                prospectId = imageModel!!.prospectId,
                                fileUri = customFile.path,
                                imageName = imageModel.imageName,
                                awsLink = null,
                                uploadedToGLPServer = false,
                                uploadedToAws = false,
                                savedInDatabase = false
                            )
                        )
                    }

                    Completable.fromAction {
                        newAwsImageModel.forEach {
                            it.savedInDatabase = true
                        }
                        localDb?.liteAwsImageModelDao()?.insertAll(newAwsImageModel)
                    }

                }
                .subscribe({
                    Log.d(TAG, "Success ---- $newAwsImageModel ")
                    data.postValue(newAwsImageModel)
                }, {
                    Log.d(TAG, "Error:${it.localizedMessage} ")
                    data.postValue(null)
                    it.printStackTrace()
                })
        )


        return data
    }


    fun getFseProspectiveFromServer(
        angazaId: String,
        prospectId: String
    ): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>? {

        val data = MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>()

        var value: NewCommonResponseModel<LiteFseProspectItemResponseModel>? = null

        bag.add(
            localDb!!.liteFseProspectResponseDao().getByProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable { prospectFromDatabase ->
                    // here delete all data from database
                    Completable.fromAction {
                        localDb!!.liteFseProspectResponseDao().delete(prospectFromDatabase)
                    }.doOnError {
                        Log.d(TAG, "Error-2: ${it.localizedMessage}");
                        data.postValue(
                            NewCommonResponseModel<LiteFseProspectResponseModel>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from server"
                                ),
                                success = false
                            )
                        )
                        it.printStackTrace()
                    }.doOnComplete {
                        //ServiceInstance.getInstance(context).service?.getFseProspectives()!!
                        ServiceInstance.getInstance(context).service?.getLiteFseProspective(
                            angazaId,
                            prospectId,
                            territory!!
                        )!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                value = it!!

                                val fromDatabase = prospectFromDatabase

                                var fromServer = value!!.responseData!!.prospect!!
                                var oldChangedData: LiteFseProspectResponseModel? = null

                                val sameDataInDatabase = fromDatabase

                                fun statusUpdateTimeHandler(
                                    oldStatus: LiteFseProspectResponseModel.StatusUpdateTime,
                                    newStatus: LiteFseProspectResponseModel.StatusUpdateTime,
                                    oldFseProspectResponseModel: LiteFseProspectResponseModel
                                ): LiteFseProspectResponseModel.StatusUpdateTime {
                                    var revisedStatus = oldStatus

                                    if (!newStatus.prospect.isNullOrEmpty()) {
                                        revisedStatus.prospect = newStatus.prospect
                                    }


                                    if (!newStatus.otpApproved.isNullOrEmpty()) {
                                        revisedStatus.otpApproved = newStatus.otpApproved
                                    }


                                    if (!newStatus.preApprovedProspect.isNullOrEmpty()) {
                                        revisedStatus.preApprovedProspect =
                                            newStatus.preApprovedProspect
                                    }

                                    if (!newStatus.checkedIn.isNullOrEmpty()) {
                                        revisedStatus.checkedIn = newStatus.checkedIn
                                    }

                                    if (!newStatus.threeWayCallVerification.isNullOrEmpty()) {
                                        revisedStatus.threeWayCallVerification =
                                            newStatus.threeWayCallVerification
                                    }

                                    if (!newStatus.installationPending.isNullOrEmpty()) {
                                        revisedStatus.installationPending =
                                            newStatus.installationPending
                                    }


                                    if (oldFseProspectResponseModel.reattemptedStage == 0) {
                                        if (!newStatus.installed.isNullOrEmpty()) {
                                            revisedStatus.installed = newStatus.installed
                                        }

                                        if (!newStatus.installationVerified.isNullOrEmpty()) {
                                            revisedStatus.installationVerified =
                                                newStatus.installationVerified
                                        }
                                    }

                                    return revisedStatus
                                }

                                fun statusUpdateObjectTimeHandler(
                                    oldStatus: List<LiteFseProspectResponseModel.StatusUpdateObjects>,
                                    newStatus: List<LiteFseProspectResponseModel.StatusUpdateObjects>,
                                    oldFseProspectResponseModel: LiteFseProspectResponseModel
                                ): List<LiteFseProspectResponseModel.StatusUpdateObjects> {
                                    var revisedStatus = oldStatus
                                    Log.e(TAG, "oldStatus ====== $oldStatus")
                                    newStatus.forEach { ns ->

                                        revisedStatus.map { rs ->

                                            if (ns.id.equals(rs.id, true)) {
                                                if (!ns.visibility!!) {
                                                    rs.visibility = ns.visibility!!
                                                }
                                                if (ns.visibility!!) {
                                                    rs.visibility = ns.visibility!!
                                                }

//                                                            if (!ns.statusTime.isNullOrEmpty()) {
//                                                                rs.statusTime = ns.statusTime!!
//                                                            }
                                                if (oldFseProspectResponseModel.reattemptedStage == 0) {
//                                                                Log.e(TAG, "===Name :: ${oldFseProspectResponseModel.name}==${oldFseProspectResponseModel.reattemptedStage} == ${ns.status}")
                                                    if (!ns.statusTime.isNullOrBlank()) {
                                                        rs.statusTime = ns.statusTime
                                                    }
                                                } else {
                                                    if (!ns.status.equals(
                                                            FseProspectiveConstant.ProspectStatus.INSTALLED,
                                                            true
                                                        )
                                                    ) {
                                                        if (!ns.status!!.equals(
                                                                FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED,
                                                                true
                                                            )
                                                        ) {
                                                            Log.e(
                                                                TAG,
                                                                "==else=Name :: ${oldFseProspectResponseModel.name}==${oldFseProspectResponseModel.reattemptedStage} == ${ns.status}"
                                                            )
                                                            if (!ns.statusTime.isNullOrBlank()) {
                                                                rs.statusTime = ns.statusTime
                                                            }
                                                        }

                                                    }
                                                }

                                                if (!ns.status.isNullOrEmpty()) {
                                                    rs.status = ns.status!!
                                                }
                                                if (!ns.showCaseName.isNullOrEmpty()) {
                                                    rs.showCaseName = ns.showCaseName!!
                                                }
                                            }
                                        }


                                    }


                                    return revisedStatus
                                }


                                fun statusHandler(oldStatus: String, newStatus: String): String {
                                    var revisedStatus = ""

                                    when (oldStatus) {
                                        /*   FseProspectiveConstant.ProspectStatus.PROSPECT -> {

                                               if (newStatus == FseProspectiveConstant.ProspectStatus.OTP_APPROVED) {
                                                   revisedStatus = FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                               } else {
                                                   revisedStatus = FseProspectiveConstant.ProspectStatus.PROSPECT
                                               }

                                           }

                                           FseProspectiveConstant.ProspectStatus.OTP_APPROVED -> {
                                               if (newStatus == FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT) {
                                                   revisedStatus = FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                               } else {
                                                   revisedStatus = FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                               }
                                           }

                                           FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT -> {
                                               if (newStatus == FseProspectiveConstant.ProspectStatus.CHECKED_IN) {
                                                   revisedStatus = FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                               } else {
                                                   revisedStatus = FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                               }
                                           }

                                           FseProspectiveConstant.ProspectStatus.CHECKED_IN -> {

                                               if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                   revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                               } else if (newStatus == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL) {
                                                   revisedStatus = FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                               } else {
                                                   revisedStatus = FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                               }
                                           }

                                           FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL -> {
                                               if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                   revisedStatus = FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                               } else {
                                                   revisedStatus = FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                               }
                                           }
*/

                                        FseProspectiveConstant.ProspectStatus.PROSPECT -> {
//
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PROSPECT
                                            }

                                        }

                                        FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                            }
                                        }

                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLED) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLED
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.INSTALLED -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                            } else if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLED
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                            }
                                        }

                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            }
                                        }

                                        else -> {
                                            revisedStatus =
                                                FseProspectiveConstant.ProspectStatus.PROSPECT
                                        }

                                    }

                                    return revisedStatus
                                }

                                sameDataInDatabase?.let {

                                    sameDataInDatabase.approved = fromServer.approved
                                    sameDataInDatabase.message = fromServer.message
                                    sameDataInDatabase.customerAddress = fromServer.customerAddress

                                    sameDataInDatabase.name = fromServer.name
                                    sameDataInDatabase.otp = fromServer.otp
                                    sameDataInDatabase.productName = fromServer.productName
                                    sameDataInDatabase.status = statusHandler(
                                        sameDataInDatabase.status!!,
                                        fromServer.status!!
                                    )
                                    sameDataInDatabase.statusUpdateTime = statusUpdateTimeHandler(
                                        sameDataInDatabase.statusUpdateTime!!,
                                        fromServer.statusUpdateTime!!,
                                        sameDataInDatabase
                                    )
                                    sameDataInDatabase.ticketType = fromServer.ticketType
                                    sameDataInDatabase.accountNumber = fromServer.accountNumber
                                    sameDataInDatabase.installationPicture =
                                        fromServer.installationPicture
                                    sameDataInDatabase.customerPhoneNumber =
                                        fromServer.customerPhoneNumber
                                    sameDataInDatabase.area = fromServer.area

                                    //new added test it
                                    sameDataInDatabase.prospectUpdatedAt =
                                        fromServer.prospectUpdatedAt ?: ""
                                    sameDataInDatabase.prospectLocation =
                                        fromServer.prospectLocation
                                    sameDataInDatabase.sampleImages = fromServer.sampleImages
                                    sameDataInDatabase.installationPictures =
                                        fromServer.installationPictures
                                    sameDataInDatabase.statusUpdateObjects =
                                        statusUpdateObjectTimeHandler(
                                            sameDataInDatabase.statusUpdateObjects!!,
                                            fromServer.statusUpdateObjects!!,
                                            sameDataInDatabase
                                        )


                                    oldChangedData = sameDataInDatabase

                                }
                                //need to add some new attributes here
                                //}


                                val resultData = oldChangedData


                                if (resultData != null) {

                                    //data.postValue(value)
                                    fromServer = resultData
                                    fseProspectiveFromServerLogic(
                                        data,
                                        NewCommonResponseModel(
                                            responseData = fromServer,
                                            success = true
                                        )
                                    )
                                    //add to database

                                } else {
                                    data.postValue(
                                        NewCommonResponseModel<LiteFseProspectResponseModel>(
                                            error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable get data from server"
                                            ),
                                            success = false
                                        )
                                    )
                                }
                            }, {
                                Log.d(TAG, "Error-1: ${it.localizedMessage}");

                                data.postValue(
                                    NewCommonResponseModel<LiteFseProspectResponseModel>(
                                        error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable get data from server"
                                        ),
                                        success = false
                                    )
                                )

                                it.printStackTrace()
                            })
                    }
                }.doOnError {
                    Log.d(TAG, "Error-1: ${it.localizedMessage}");
                    data.postValue(
                        NewCommonResponseModel<LiteFseProspectResponseModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from server"
                            ),
                            success = false
                        )
                    )
                    it.printStackTrace()


                }.subscribe({
//                    Log.d(TAG, " on Success ===");
                }, {
                    Log.d(TAG, " Error:${it.printStackTrace()}");
                })

        )

        return data
    }

    private fun fseProspectiveFromServerLogic(
        liveData: MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>,
        responseData: NewCommonResponseModel<LiteFseProspectResponseModel>
    ) {

        bag.add(
            Completable.fromAction {
                localDb?.liteFseProspectResponseDao()?.insert(responseData.responseData!!)
            }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Insertion:Completed ")
                    preference?.setFseProspectLastSynced(Util.getCurrentLocalFormattedDateForSync())
                    liveData.postValue(responseData)
                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })
        )

    }


    fun awsRX(
        context: Context,
        requestModel: BaseRequestModel
    ): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
        val data = MutableLiveData<CommonResponseModel<AWSResponseModel>>()

        bag.add(
            ServiceInstance.getInstance(context).service!!.awsRx(requestModel)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "||=======${it}")
                    data.postValue(it)

                }, {
                    Log.e(TAG, "||=======EROORRRR = $it")
                    data.postValue(
                        CommonResponseModel<AWSResponseModel>().apply {
                            this.Error =
                                com.greenlightplanet.kazi.member.Error(MessageToUser = "Unable to send data to server")
                            this.Success = false
                        }
                    )
                })
        )

        return data

    }

    fun getFseProsResponseModelFromProspectID(prospectId: String): MutableLiveData<LiteFseProspectResponseModel> {

        val data = MutableLiveData<LiteFseProspectResponseModel>()

        bag.add(
            localDb!!.liteFseProspectResponseDao().getBySingleProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "||======Success:: = $it")
                    data.postValue(it)
                }, {
                    it.printStackTrace()
                    data.postValue(null)
                    Log.e(TAG, "||=======EROORRRR = $it")
                })
        )

        return data
    }


    //endregion

    fun getAllInstallationFSE(): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {

        val data = MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>()


        localDb?.let { appDatabase ->
            bag.add(

                appDatabase.liteFseProspectResponseDao().getAll()
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        Log.d(TAG, "DB-EO-List: ${it}")

                        var list = it.filter {
                            it.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING || it.status == FseProspectiveConstant.ProspectStatus.INSTALLED
                                    || it.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED || it.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                        }

                        data.postValue(
                            NewCommonResponseModel<LiteFseProspectResponseData>(
                                responseData = LiteFseProspectResponseData(prospects = list),
                                success = true
                            )
                        )
                    }, { t ->
                        Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        data.postValue(
                            NewCommonResponseModel<LiteFseProspectResponseData>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable to find data in database"
                                ),
                                success = false
                            )
                        )
                    })

            )
        }

        return data
    }


    //region ROTATION AFTER COMPRESS
    private fun getRealPathFromURI(contentURI: Uri, context: Context): String? {
        val result: String?
        val cursor: Cursor? = context.contentResolver.query(contentURI, null, null, null, null)
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentURI.path
        } else {
            cursor.moveToFirst()
            val idx: Int = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA)
            result = cursor.getString(idx)
            cursor.close()
        }
        return result
    }

    fun getImageUri(inContext: Context, inImage: Bitmap, title: String): Uri? {
        val bytes = ByteArrayOutputStream()
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val path =
            MediaStore.Images.Media.insertImage(inContext.contentResolver, inImage, title, null)
        return Uri.parse(path)
    }

    private fun rotationTest(uri: String?): Bitmap {

        var bitmappath: Bitmap? = null
        var bitmap: Bitmap? = null

        bitmappath = BitmapFactory.decodeFile(uri)
        bitmap = Bitmap.createScaledBitmap(bitmappath!!, 700, 700, true)

        ////-----------To Orient a Picture to Potrait---------
        val bounds: BitmapFactory.Options = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeFile(uri!!, bounds)

        val opts: BitmapFactory.Options = BitmapFactory.Options()
        val bm: Bitmap = BitmapFactory.decodeFile(uri, opts)
        val exif = android.media.ExifInterface(uri!!)
        val orientString: String = exif.getAttribute(android.media.ExifInterface.TAG_ORIENTATION)!!

        var orientation: Int = 0
        orientation = Integer.parseInt(orientString)

        var rotationAngle = 0
        if (orientation == android.media.ExifInterface.ORIENTATION_ROTATE_90) rotationAngle = 90
        if (orientation == android.media.ExifInterface.ORIENTATION_ROTATE_180) rotationAngle = 180
        if (orientation == android.media.ExifInterface.ORIENTATION_ROTATE_270) rotationAngle = 270

        val matrix = Matrix()
        matrix.setRotate(
            rotationAngle.toFloat(), (bm.getWidth() / 2).toFloat(),
            (bm.getHeight() / 2).toFloat()
        )
        val rotatedBitmap: Bitmap =
            Bitmap.createBitmap(bm, 0, 0, bounds.outWidth, bounds.outHeight, matrix, true)
        return rotatedBitmap
    }

    //endregion



    fun destroy() {

        Log.d(TAG, "Repo : Distroyed");
        bag.clear()

    }

}
