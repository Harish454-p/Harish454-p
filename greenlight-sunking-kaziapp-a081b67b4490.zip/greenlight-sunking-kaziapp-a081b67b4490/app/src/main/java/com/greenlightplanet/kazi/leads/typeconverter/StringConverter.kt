package com.greenlightplanet.kazi.leads.typeconverter

import androidx.room.TypeConverter


class StringConverter {

    @TypeConverter
    fun fromList(strings: List<String>?): String? {
        if (strings == null) {
            return null
        }
        var string = "";
        for (s in strings) string += ("$s,");
        return string;
    }

    @TypeConverter
    fun toList(concatenatedStrings: String?): List<String>? {
        if (concatenatedStrings == null) {
            return null
        }
        val myStrings = mutableListOf<String>()
        for (s in concatenatedStrings.split(",")) {
            myStrings.add(s);
        }
        return myStrings;
    }

}
