package com.greenlightplanet.kazi.dashboard.model.response

import java.io.Serializable
import android.os.Parcelable

import com.google.gson.annotations.SerializedName


import androidx.room.PrimaryKey

import androidx.room.Entity

import androidx.room.ColumnInfo
import kotlinx.parcelize.Parcelize


@Parcelize
@Entity(tableName = "AppVersionResponse")
data class AppVersionResponse(
    @ColumnInfo(name = "appVersion")
    @SerializedName("appVersion")
    var appVersion: String?, // 21.0.33
    @ColumnInfo(name = "appVersionCode")
    @SerializedName("appVersionCode")
    var appVersionCode: Int?, // 73
    @ColumnInfo(name = "forceLogout")
    @SerializedName("forceLogout")
    var forceLogout: Boolean?, // false
    @ColumnInfo(name = "forceUpdateUrl")
    @SerializedName("forceUpdateUrl")
    var forceUpdateUrl: String?, // https://s3.amazonaws.com/glpapps/kazi/kazi.apk
    @ColumnInfo(name = "fseAccuracy")
    @SerializedName("fseAccuracy")
    var fseAccuracy: Int?, // 200
    @ColumnInfo(name = "checkInAccuracy")
    @SerializedName("checkInAccuracy")
    var checkInAccuracy: Int?, // 200
    @ColumnInfo(name = "isForceUpdate")
    @SerializedName("isForceUpdate")
    var isForceUpdate: Boolean?, // false
    @ColumnInfo(name = "showProspectTab")
    @SerializedName("showProspectTab")
    var showProspectTab: Boolean = false, // false
    @ColumnInfo(name = "showWebViewTab")
    @SerializedName("showWebViewTab")
    var showWebViewTab: Boolean = false, // false
    @ColumnInfo(name = "message")
    @SerializedName("message")
    var message: String?, // Please update the application to continue.
    @ColumnInfo(name = "prospectDistanceDetails")
    @SerializedName("prospectDistanceDetails")
    var prospectDistanceDetails: List<ProspectDistanceDetail?>?,
    @ColumnInfo(name = "CountryModel")
    @SerializedName("listOfCountries")
    var countries : List<CountryModel>?
) : Parcelable {
    @Parcelize
    @Entity(tableName = "ProspectDistanceDetail")
    data class ProspectDistanceDetail(
        @ColumnInfo(name = "allowedDistance")
        @SerializedName("allowedDistance")
        var allowedDistance: Int?, // 12
        @ColumnInfo(name = "country")
        @SerializedName("country")
        var country: String?, // NIGERIA
        @ColumnInfo(name = "mapCircleRadius")
        @SerializedName("mapCircleRadius")
        var mapCircleRadius: Int? // 10
    ) : Parcelable
}

