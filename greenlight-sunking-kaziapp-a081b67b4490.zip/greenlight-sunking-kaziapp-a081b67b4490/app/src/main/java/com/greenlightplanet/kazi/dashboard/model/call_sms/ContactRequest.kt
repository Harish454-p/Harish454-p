package com.greenlightplanet.kazi.dashboard.model.call_sms


import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "ContactRequest")
data class ContactRequest(
		@PrimaryKey
		@SerializedName("localId")
		var localId: String, // 122
		@SerializedName("name")
		var name: String?, // defaaa
		@SerializedName("numbers")
		var numbers: String?, // 3422252
		@SerializedName("serverId")
		var serverId: String? = null, // 13
		@SerializedName("status")
		var status: String?, // UPDATED
		@SerializedName("uploadedToServer")
		var uploadedToServer: Boolean = false // UPDATED
) : Parcelable
