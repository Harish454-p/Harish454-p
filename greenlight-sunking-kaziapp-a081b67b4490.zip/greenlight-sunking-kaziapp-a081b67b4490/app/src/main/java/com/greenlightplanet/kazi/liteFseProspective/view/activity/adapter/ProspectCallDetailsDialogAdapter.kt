package com.greenlightplanet.kazi.liteFseProspective.view.activity.adapter


import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.ProspectDetailsDialogItemBinding
import com.greenlightplanet.kazi.liteFseProspective.model.ProspectCallDetail
import com.greenlightplanet.kazi.utils.Util
import kotlinx.android.extensions.LayoutContainer
import org.jetbrains.annotations.NotNull


class ProspectCallDetailsDialogAdapter(val context: Context, var list: List<ProspectCallDetail>)
    : RecyclerView.Adapter<ProspectCallDetailsDialogAdapter.ViewHolder>() {


    override fun onCreateViewHolder(@NotNull p0: ViewGroup, viewType: Int): ViewHolder {

        val itemBinding = ProspectDetailsDialogItemBinding.inflate(
            LayoutInflater.from(p0.context), p0, false)
        return ViewHolder(itemBinding)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = list.get(position)

      holder.bind(data)
    }

    inner class ViewHolder( val itemBinding: ProspectDetailsDialogItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(data: ProspectCallDetail) {
            itemBinding.tvPhoneNumber.text = "${data.phoneNumber}"
            itemBinding.tvCallingTime.text = if (data.callingTime.isNullOrEmpty()) {
                "NA"
            } else {
                "${Util.fseUiDateFormatter(data.callingTime!!)}"
            }
            //holder.tvRequestDate.text = "${Util.fseUiDateFormatter(data.timestamp!!)}"
            itemBinding.tvFeedback.text = "${data.dispositionCode}"

        }
    }


    override fun getItemCount(): Int {
        return list.size
    }


}
