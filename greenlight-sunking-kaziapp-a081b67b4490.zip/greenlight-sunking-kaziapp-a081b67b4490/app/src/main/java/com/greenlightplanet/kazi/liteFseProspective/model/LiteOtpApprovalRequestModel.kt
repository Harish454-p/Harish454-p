package com.greenlightplanet.kazi.liteFseProspective.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "LiteOtpApprovalRequest")
data class LiteOtpApprovalRequestModel(
        @PrimaryKey
        @ColumnInfo(name = "prospectId")
        @SerializedName("prospectId")
        var prospectId: String, // PP12345
        @ColumnInfo(name = "otpVerificationTime")
        @SerializedName("otpVerificationTime")
        var otpVerificationTime: String = "", // 2019-12-23 13:54:22
        @ColumnInfo(name = "unsuccessfulAttempts")
        @SerializedName("unsuccessfulAttempts")
        var unsuccessfulAttempts: Int = 0,// 5
        @ColumnInfo(name = "angazaId")
        @SerializedName("angazaId")
        var angazaId: String?, // US000001
        @ColumnInfo(name = "country")
        @SerializedName("country")
        var country: String // Uganda
) : Parcelable
