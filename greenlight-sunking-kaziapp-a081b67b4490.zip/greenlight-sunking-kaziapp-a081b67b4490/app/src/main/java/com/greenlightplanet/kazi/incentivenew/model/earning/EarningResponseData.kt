package com.greenlightplanet.kazi.incentivenew.model.earning

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Created by Rahul on 09/12/20.
 */


@Parcelize
@Entity
data class EarningResponseData(

        @PrimaryKey
        @ColumnInfo
        @SerializedName("earningsFields") val earningsFields: List<EarningsFields>
) : Parcelable