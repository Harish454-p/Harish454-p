package com.greenlightplanet.kazi.fse.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import android.os.Parcelable
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import kotlinx.android.parcel.Parcelize

@Parcelize
data class FseHistoryResponse(
        @ColumnInfo(name = "Request")
        @SerializedName("Request")
        var request: Request?,
        @ColumnInfo(name = "ResponseData")
        @SerializedName("ResponseData")
        var responseData: ResponseData?,
        @ColumnInfo(name = "ResponseStatus")
        @SerializedName("ResponseStatus")
        var responseStatus: Int?, // 200
        @ColumnInfo(name = "Success")
        @SerializedName("Success")
        var success: Boolean? // true
) : Parcelable {
    @Parcelize
    @Entity(tableName = "FseHistoryResponseData")
    data class ResponseData(


            @ColumnInfo(name = "id")
            @PrimaryKey(autoGenerate = true)
            @SerializedName("id")
            var id: Int?,

            @ColumnInfo(name = "totalCustomersCommitment")
            @SerializedName("totalCustomersCommitment")
            var totalCustomersCommitment: Int?,

            @ColumnInfo(name = "totalCustomersPaid")
            @SerializedName("totalCustomersPaid")
            var totalCustomersPaid: Int?,

            @ColumnInfo(name = "fseHistory")
            @SerializedName("fseHistory")
            var fseHistory: List<FseHistory?>?,

            @ColumnInfo(name = "targetVisit")
            @SerializedName("targetVisit")
            var targetVisit: Int?,

            @ColumnInfo(name = "todaysVisit")
            @SerializedName("todaysVisit")
            var todaysVisit: Int?,

            @ColumnInfo(name = "hitRate")
            @SerializedName("hitRate")
            var hitRate: Int?


    ) : Parcelable

    @Parcelize
    data class Request(
            @ColumnInfo(name = "ExecutionTime")
            @SerializedName("ExecutionTime")
            var executionTime: Double? // 9.882
    ) : Parcelable


    class FseHistoryConverter {


        @TypeConverter
        fun fromFseHistoryList(fseHistoryList: List<FseHistory>?): String? {
            if (fseHistoryList == null) {
                return null
            }
            val gson = Gson()
            val type = object : TypeToken<List<FseHistory>>() {

            }.type
            return gson.toJson(fseHistoryList, type)
        }

        @TypeConverter
        fun toFseHistoryList(fseHistoryListString: String?): List<FseHistory>? {
            if (fseHistoryListString == null) {
                return null
            }
            val gson = Gson()
            val type = object : TypeToken<List<FseHistory>>() {

            }.type
            return gson.fromJson(fseHistoryListString, type)
        }

    }
}
