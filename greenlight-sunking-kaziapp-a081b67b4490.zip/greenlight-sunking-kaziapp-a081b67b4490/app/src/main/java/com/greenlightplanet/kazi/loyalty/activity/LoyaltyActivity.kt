package com.greenlightplanet.kazi.loyalty.activity

import android.content.SharedPreferences
import android.graphics.PorterDuff
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import androidx.annotation.NonNull
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.LoyaltyMainBinding
import com.greenlightplanet.kazi.loyalty.fragment.AchievementDashBoard
import com.greenlightplanet.kazi.loyalty.fragment.PassbookFragment
import com.greenlightplanet.kazi.loyalty.fragment.ProfileFragment
import com.greenlightplanet.kazi.loyalty.fragment.StoreFragment
import com.greenlightplanet.kazi.loyalty.listner.onBottomItemSet
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.Constants.Companion.LEADERBOARD_TAB
import com.greenlightplanet.kazi.utils.Constants.Companion.LOYALTYSYNC
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import uk.co.deanwild.materialshowcaseview.MaterialShowcaseSequence
import uk.co.deanwild.materialshowcaseview.MaterialShowcaseView
import uk.co.deanwild.materialshowcaseview.ShowcaseConfig


/**
 * Created by Rahul on 06/04/21.
 */
class LoyaltyActivity : BaseActivity(), BottomNavigationView.OnNavigationItemSelectedListener,
    onBottomItemSet, SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var binding: LoyaltyMainBinding
    var navigation: BottomNavigationView? = null
    var preference: GreenLightPreference? = null
    var onShowCaseClick: OnShowCaseClick? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContentView(R.layout.loyalty_main)
        binding = LoyaltyMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        init()
    }

    override fun onStart() {
        super.onStart()
        preference?.registerPreference(this, this)
    }

    override fun onDestroy() {
        super.onDestroy()
        preference?.unRegisterPreference(this, this)
    }

    fun init() {
        preference = GreenLightPreference(this)
        binding.tvVersionId.text = "V:" + BuildConfig.VERSION_NAME
        Util.setToolbar(this, binding.toolbar2!!)
        binding.toolbar2.navigationIcon?.setColorFilter(
            resources.getColor(R.color.black),
            PorterDuff.Mode.SRC_ATOP
        );
        loadFragment(ProfileFragment(), resources.getString(R.string.title_profile))
        binding.toolbarTitle.text = resources.getString(R.string.title_profile)
        Util.addEvent("350", "Loyalty", "user_click_on_dashboard_to_enter_loyalty")


        val prefrence: GreenLightPreference? = GreenLightPreference(this)
        binding.tvLastUpdateId.text = prefrence?.getLoyaltyLastSync()


        navigation = findViewById<BottomNavigationView>(R.id.navigation)
        navigation?.setOnNavigationItemSelectedListener(this)

        val menuView = navigation?.getChildAt(0)
        val profile = menuView?.findViewById<View>(R.id.navigation_profile)
        val achievement = menuView?.findViewById<View>(R.id.navigation_achievements)
        val store = menuView?.findViewById<View>(R.id.navigation_store)
        val passbook = menuView?.findViewById<View>(R.id.navigation_passbook)
        //   MaterialShowcaseView.resetSingleUse(this, "SHOWCASE_ID");

        presentShowcaseSequence(profile, achievement, store, passbook)

    }

    private fun presentShowcaseSequence(
        profile: View?,
        achievement: View?,
        store: View?,
        passbook: View?
    ) {
        val config = ShowcaseConfig()
        config.delay = 100 // half second between each showcase view
        val sequence = MaterialShowcaseSequence(this, "SHOWCASE_ID")

        sequence.setOnItemShownListener { itemView, position -> // onShowCaseClick?.onInAppTutorialTab(position)

            when (position) {
                1 -> {
                    loadFragment(
                        AchievementDashBoard(),
                        resources.getString(R.string.title_achievements)
                    )
                    selectBottomNavigationOption(position)
                }
                2 -> {
                    loadFragment(StoreFragment(), resources.getString(R.string.title_store))
                    selectBottomNavigationOption(position)

                }
                3 -> {
                    loadFragment(PassbookFragment(), resources.getString(R.string.title_passbook))
                    selectBottomNavigationOption(position)

                }
                else -> {
                    loadFragment(ProfileFragment(), resources.getString(R.string.title_profile))
                    selectBottomNavigationOption(0)

                }
            }
        }
        sequence.setOnItemDismissedListener { itemView, position -> //onShowCaseClick?.onInAppTutorialTab(position)

            when (position) {
                3 -> {
                    loadFragment(ProfileFragment(), resources.getString(R.string.title_passbook))
                    selectBottomNavigationOption(0)

                }
            }
        }
        sequence.setConfig(config)
        // sequence.addSequenceItem(profile, "Check your Points, Ranks & Goals. Click on Leaderboard & compare your performance with other agents!", "GOT IT")
        sequence.addSequenceItem(
            MaterialShowcaseView.Builder(this)
                .setSkipText("SKIP")
                .setTarget(profile)
                .setDismissText("GOT IT")
                .setContentText("Check your Points, Ranks & Goals. Click on Leaderboard & compare your performance with other agents!")
                .withCircleShape()
                .build()
        )
        sequence.addSequenceItem(
            MaterialShowcaseView.Builder(this)
                .setSkipText("SKIP")
                .setTarget(achievement)
                .setDismissText("GOT IT")
                .setContentText("Find out your Achieved & Pending Goals. Keep checking this section for new goals!")
                .withCircleShape()
                .build()
        )
        sequence.addSequenceItem(
            MaterialShowcaseView.Builder(this)
                .setTarget(store)
                .setSkipText("SKIP")
                .setDismissText("GOT IT")
                .setContentText("Earn more points, win these rewards! Click on any reward to get the details.")
                .withCircleShape()
                .build()
        )
        sequence.addSequenceItem(
            MaterialShowcaseView.Builder(this)
                .setTarget(passbook)
                .setDismissText("GOT IT")
                .setContentText("Track your Points and see what you earned & what you used.")
                .withCircleShape()
                .build()
        )
        sequence.start()
    }

    override fun onNavigationItemSelected(@NonNull item: MenuItem): Boolean {
        var fragment: Fragment? = null
        binding.toolbarTitle.text = item.title.toString()
        when (item.getItemId()) {
            R.id.navigation_profile -> fragment = ProfileFragment()
            R.id.navigation_achievements -> fragment = AchievementDashBoard()
            R.id.navigation_store -> fragment = StoreFragment()
            R.id.navigation_passbook -> fragment = PassbookFragment()
        }
        return loadFragment(fragment, item.title.toString())
    }

    private fun loadFragment(fragment: Fragment?, title: String): Boolean {

        if (fragment != null) { // .setCustomAnimations(R.anim.move_in, R.anim.move_out)

            supportFragmentManager
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(title)
                .commit()
            return true
        }
        return false
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()

        return true
    }


    fun selectBottomNavigationOption(index: Int) {
        var index = index
        when (index) {
            0 -> index = R.id.navigation_profile
            1 -> index = R.id.navigation_achievements
            2 -> index = R.id.navigation_store
            3 -> index = R.id.navigation_passbook
        }
        navigation?.setSelectedItemId(index)

    }


    override fun changeTab(comm: Int?) {

        if (comm == LEADERBOARD_TAB) {
            binding.toolbarTitle.text = resources.getString(R.string.leaderboard)
        } else {
            comm?.let { selectBottomNavigationOption(it) }

        }
    }


    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        if (key.equals(LOYALTYSYNC)) {
            val prefrence: GreenLightPreference? = GreenLightPreference(this)
            binding.tvLastUpdateId.text = prefrence?.getLoyaltyLastSync()


        }
    }


    fun setListener(myFragment: ProfileFragment) {
        try {
            onShowCaseClick = myFragment
        } catch (e: ClassCastException) {
        }
    }

    interface OnShowCaseClick {

        fun onInAppTutorialTab(type: Int)


    }

    override fun onBackPressed() {
        val fragments = supportFragmentManager.backStackEntryCount

        val tag =
            supportFragmentManager.getBackStackEntryAt(supportFragmentManager.backStackEntryCount - 1).name

        //  chnage(tag)


        if (fragments == 1) {
            finish()
        } else if (fragmentManager.backStackEntryCount > 1) {

            fragmentManager.popBackStack()

        } else {
            super.onBackPressed()
            Log.e("kjfvjkdfvndfv", "${tag}")
            if (tag.equals(resources.getString(R.string.title_profile))) {
                finish()
            } else {
                clearBackStack()
                changeTab(0)

            }

        }


    }

    private fun clearBackStack() {
        val manager = supportFragmentManager
        if (manager.backStackEntryCount > 0) {
            val first = manager.getBackStackEntryAt(0)
            manager.popBackStack(first.id, FragmentManager.POP_BACK_STACK_INCLUSIVE)
        }
    }
    /* fun chnage(tag: String?) {
         when (tag) {
             resources.getString(R.string.title_profile) -> navigation?.checkItem(R.id.navigation_profile)
             resources.getString(R.string.title_achievements) -> navigation?.checkItem(R.id.navigation_achievements)
             resources.getString(R.string.title_store) -> navigation?.checkItem(R.id.navigation_store)
             resources.getString(R.string.title_passbook) -> navigation?.checkItem(R.id.navigation_passbook)
         }
     }

     internal fun BottomNavigationView.checkItem(actionId: Int) {
         menu.findItem(actionId)?.isChecked = true
     }*/
}