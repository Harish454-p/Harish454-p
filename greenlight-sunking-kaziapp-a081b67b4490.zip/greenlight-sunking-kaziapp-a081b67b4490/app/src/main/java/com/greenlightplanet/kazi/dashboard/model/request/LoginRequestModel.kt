package com.greenlightplanet.kazi.dashboard.model.request

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
class LoginRequestModel:Parcelable {

    @SerializedName("activityType")
    var activityType : String?="LOGIN"

    @SerializedName("phoneNumber")
    var phoneNumber : String?=null

    @SerializedName("password")
    var password : String?=null

    @SerializedName("imei")
    var imei:String?=null



}
