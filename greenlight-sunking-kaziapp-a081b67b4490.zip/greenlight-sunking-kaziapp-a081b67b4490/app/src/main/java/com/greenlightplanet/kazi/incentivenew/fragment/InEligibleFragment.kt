package com.greenlightplanet.kazi.incentivenew.fragment


import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentEligibleBinding
import com.greenlightplanet.kazi.incentivenew.adapter.EligibleAdapter
import com.greenlightplanet.kazi.incentivenew.model.incentive.Accounts
import com.greenlightplanet.kazi.incentivenew.model.incentive.AgentIncentiveResponseData
import com.greenlightplanet.kazi.utils.Constants
import com.greenlightplanet.kazi.utils.Util


class InEligibleFragment : Fragment(), EligibleAdapter.MyDateData {

    private var _binding: FragmentEligibleBinding? = null
    private val binding get() = _binding!!

    // var recyclerView: RecyclerView? = null
    var agentIncentiveResponseData: AgentIncentiveResponseData? = null


    var adapterList: MutableList<Accounts> = mutableListOf()
    var adapter: EligibleAdapter? = null

    var sortType = 1
    var sortAttribute = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentEligibleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        val bundlesales = arguments

        Util.addEvent("314", "InEligibleScreen", "InEligibleScreen")
        binding.tvIncentiveKey.text = getString(R.string.header_incentive_missed)
        agentIncentiveResponseData =
            bundlesales?.getParcelable<AgentIncentiveResponseData>("inEligible")


        agentIncentiveResponseData?.accounts?.filter { it.isEligible != true }
            ?.let { setAdapter(it) }


        clickHander()


    }

    override fun selectedData(date: String, position: Int) {

    }

    fun setAdapter(mutableList: List<Accounts>) {
        adapterList.clear()
        adapterList.addAll(mutableList)

        if (adapterList.size > 0) {
            binding.tvNoData.visibility = View.GONE
        } else {
            binding.tvNoData.visibility = View.VISIBLE
        }

        if (adapter == null) {
            // adapter = adapterList.filter { it.isEligible!! }.let { EligibleAdapter(it, this, requireContext()) }
            adapter = EligibleAdapter(adapterList, this, requireContext())
            binding.recyclerView?.setHasFixedSize(true)
            binding.recyclerView?.layoutManager = LinearLayoutManager(requireContext())
            binding.recyclerView?.adapter = adapter
        }
        adapter?.notifyDataSetChanged()

    }

    //region Sorting Functions
    private fun byAccountNumber(mutableList: MutableList<Accounts>) {

        sortAttribute = 3
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    it.accountNumber.toDouble()
                }
            } else {
                sortType = 1
                mutableList.sortBy {
                    it.accountNumber.toDouble()
                }
            }

//            sortPendingAmount(mutableList, sortType)
            binding.tvAccountNumerKey.setBackgroundColor(Color.GRAY)
            adapter?.notifyDataSetChanged()

        }
    }

    fun byCustomerName(mutableList: MutableList<Accounts>) {

        sortAttribute = 2
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    it.registrationDate
                }

            } else {
                sortType = 1
                mutableList.sortBy {
                    it.registrationDate
                }
            }

//            sortCustomerName(mutableList, sortType)
            binding.tvRegistrationDateKey.setBackgroundColor(Color.GRAY)
            adapter?.notifyDataSetChanged()
        }
    }

    fun byProductName(mutableList: MutableList<Accounts>) {

        sortAttribute = 1
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    it.product
                }
            } else {
                sortType = 1
                mutableList.sortBy {
                    it.product
                }
            }

//            sortByAccountNumber(mutableList, sortType)
            binding.tvProductNameKey.setBackgroundColor(Color.GRAY)
            adapter?.notifyDataSetChanged()
        }
    }

    fun byIncentiveEarn(mutableList: MutableList<Accounts>) {

        sortAttribute = 4
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    it.incentiveEarned
                }
            } else {
                sortType = 1
                mutableList.sortBy {
                    it.incentiveEarned
                }
            }

            binding.tvIncentiveKey.setBackgroundColor(Color.GRAY)
            adapter?.notifyDataSetChanged()
        }
    }


    fun refreshSortBackground() {
        binding.tvRegistrationDateKey.setBackgroundColor(Color.BLACK)
        binding.tvAccountNumerKey.setBackgroundColor(Color.BLACK)
        binding.tvProductNameKey.setBackgroundColor(Color.BLACK)
        binding.tvIncentiveKey.setBackgroundColor(Color.BLACK)
    }

    private fun clickHander() {
        binding.tvRegistrationDateKey.setOnClickListener { v -> byCustomerName(adapterList) }
        binding.tvAccountNumerKey.setOnClickListener { v -> byAccountNumber(adapterList) }
        binding.tvProductNameKey.setOnClickListener { v -> byProductName(adapterList) }
        binding.tvIncentiveKey.setOnClickListener { v -> byIncentiveEarn(adapterList) }

    }
}
