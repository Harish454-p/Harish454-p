package com.greenlightplanet.kazi.incentivenew.dao.converter

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.incentivenew.model.summary.CheckListFields
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryFields
import com.greenlightplanet.kazi.pricegroup.model.Pricing_group

class CheckListFieldConverter {

    @TypeConverter
    fun fromCheckListFieldList(list: List<CheckListFields>?): String? {
        if (list == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<CheckListFields>>() {

        }.type
        return gson.toJson(list, type)
    }

    @TypeConverter
    fun toCheckListFieldList(string: String?): List<CheckListFields>? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<CheckListFields>>() {

        }.type
        return gson.fromJson(string, type)
    }

}


