package com.greenlightplanet.kazi.leads.view.adapter

import android.content.Context
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.greenlightplanet.kazi.databinding.AdapterCustomerLeadsFeedbackBinding
import com.greenlightplanet.kazi.leads.extras.AdapterUtils
import com.greenlightplanet.kazi.leads.model.LeadsCallDetail
import com.greenlightplanet.kazi.leads.model.LeadsIntent

class CustomerLeadsFeedbackAdapter constructor(private val context: Context, private val values: List<LeadsCallDetail>, private val intents: List<LeadsIntent>?) :
        RecyclerView.Adapter<CustomerLeadsFeedbackAdapter.ViewHolder>() {


    companion object {
        public const val TAG = "CustomerLeadsFeedbackAdapter"

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemBinding = AdapterCustomerLeadsFeedbackBinding.inflate(LayoutInflater.from(parent.context)
                , parent, false)
        return ViewHolder(itemBinding)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val callDetail = values.get(position)

        holder.bind(callDetail,holder.itemView)

    }


    override fun getItemCount(): Int = values.size

    inner class ViewHolder(val itemBinding: AdapterCustomerLeadsFeedbackBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(callDetail: LeadsCallDetail, itemView: View) {
            itemBinding.tvNo.text = "${position + 1}."
            itemBinding.tvCallDate.text = AdapterUtils.dateConvertertCalledUTCtoLocal(callDetail.calledDate!!)
            itemBinding.tvCallDuration.text = "${callDetail.callDuration} seconds"

            itemBinding.tvOption.setOnClickListener {

                if (itemBinding.llFeedbackDetail.visibility == View.VISIBLE) {
                    itemBinding.llFeedbackDetail.visibility = View.GONE
                    itemBinding.tvOption.rotation = 0f
                } else {
                    itemBinding.llFeedbackDetail.visibility = View.VISIBLE
                    itemBinding.tvOption.rotation = 180f
                }

            }

            itemView.setOnClickListener { itemBinding.tvOption.performClick() }

            itemBinding.tvPhoneNo.text = callDetail.contactedNumber
            itemBinding.tvPromiseDate.text = callDetail.newVisitDate ?: "NA"
            var feedbackIntent = intents?.find { it.intentId == callDetail.intent }?.intent

            callDetail.otherReason?.let {
                if (it.isNullOrEmpty()) {
                    feedbackIntent = "$feedbackIntent"
                } else {
                    feedbackIntent = "$feedbackIntent\n$it"
                }
            }

            itemBinding.tvIntent.text = feedbackIntent
        }
    }

}
