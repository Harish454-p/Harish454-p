package com.greenlightplanet.kazi.collectiongoal.view.activity

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityThisWeekIncentiveBinding
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.summary.model.SummaryModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher

class ThisWeekIncentiveActivity : BaseActivity() {

    private lateinit var binder: ActivityThisWeekIncentiveBinding
    var preference: GreenLightPreference? = null
    var activity: AppCompatActivity? = null
    var loginResponseModel: LoginResponseModel? = null
    var isFromNotification = false
    var mHomeWatcher: HomeWatcher? = null
    var summaryModel: SummaryModel? = null
    var bundle = Bundle()
    var flags: String = ""


    val TAG = "ThisWeekIncentiveActivity"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binder = ActivityThisWeekIncentiveBinding.inflate(layoutInflater)
        setContentView(binder.root)

        initialize()
    }


    fun initialize() {
        activity = this
        Util.setToolbar(this, this.binder.toolbar)

        bundle = intent.extras!!

        preference = GreenLightPreference.getInstance(this)
        loginResponseModel = preference?.getLoginResponseModel()
        summaryModel = bundle.getParcelable("collectionGoalThisWeek")
        flags = intent.getStringExtra("flag").toString()

        binder.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this)
        binder.tvTaskLastSaved.text = data?.summary

        if (summaryModel?.collectionGoalCurrentWeek!=null){
            Log.d("CheckingModelData1",summaryModel?.collectionGoalCurrentWeek?.weekString.toString())
            setData(summaryModel?.collectionGoalCurrentWeek)
        }else{
            binder.thisWeekClData.visibility = View.GONE
            binder.tvNoData.visibility = View.VISIBLE
        }
        Log.d("CheckingFlag",flags)

    }

    @SuppressLint("SetTextI18n")
    private fun setData(collectionGoalCommonWeek: SummaryModel.CollectionGoalCommonWeek?) {

        val symbol = preference?.getCountryResponseModel()?.countryCurrency ?: "NA"

        binder.tvcustTarget.text = collectionGoalCommonWeek?.targetAccount.toString()+"(A)"
        binder.tvCustomerAchievedCount.text = collectionGoalCommonWeek?.doneAccount.toString()+"(B)"
        binder.tvcustTargetCompleted.text = "${Util.checkBlank(collectionGoalCommonWeek?.percentage.toString(), applicationContext)}%"

        binder.tvAmountCollected.text = Util.checkBlank(collectionGoalCommonWeek?.weekCollection
            ?.let { Util.formatAmount(it) } + " " + symbol, applicationContext)

        binder.tvCommission.text = collectionGoalCommonWeek?.commissionPercentage.toString() +"%"

        binder.tvCommissionIncentive.text =
            Util.checkBlank(collectionGoalCommonWeek?.commission?.let { Util.formatAmount(it) } + " " + symbol,
                applicationContext)

        binder.tvDate.text = collectionGoalCommonWeek?.weekString.toString()


    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        finish()
        return true
    }

}