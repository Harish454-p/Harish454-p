package com.greenlightplanet.kazi.fseProspective.view.activity

import android.Manifest
import android.app.Activity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.location.Location
import android.os.Bundle
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan
import android.util.Log
import android.view.MenuItem
import android.view.View
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.fseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseModel
import com.greenlightplanet.kazi.fseProspective.model.RegistrationCheckinRequestModel
import com.greenlightplanet.kazi.fseProspective.view.activity.checkInMap.CheckInMapActivity
import com.greenlightplanet.kazi.fseProspective.viewmodel.RegistrationViewModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener


class RegistrationActivity : BaseActivity() {

    public val TAG = "RegistrationActivity"


    var fseProspectResponseModel: FseProspectResponseModel? = null
    lateinit var viewModel: RegistrationViewModel
    var loginResponseData: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    var registrationCheckinRequestModel: RegistrationCheckinRequestModel? = null
    var checkInAccuracy: Double? = null
    private val PERMISSION_REQUEST_CODE: Int = 102
	var mHomeWatcher: HomeWatcher? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        Util.setToolbar(this, toolbar)
        preference = GreenLightPreference.getInstance(this)

        loginResponseData = preference?.getLoginResponseModel()

        checkInAccuracy = preference?.getCheckInAccuracy()?.toDouble()

        viewModel = ViewModelProviders.of(this).get(RegistrationViewModel::class.java)

//        initializeExtras()
//        initialize()
//        clickHandler()

		mHomeWatcher = HomeWatcher(this)
		mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
			override fun onHomePressed() {
				Log.i(TAG, "onHomePressed")
				finish()
			}
		})
		mHomeWatcher!!.startWatch()
    }

 /*   private fun clickHandler() {

        btnCheckIn.setOnClickListener {

            *//*Util.customFseRationaleDialog(
                    context = this@RegistrationActivity,
                    title = null,
                    hideNegative = false,
                    message = "Are you sure to check in and register this customer?",
                    positveSelected = {
                        it.dismiss()
                        processCheckIn(this@RegistrationActivity, Util.isOnline(this@RegistrationActivity), fseProspectResponseModel!!)
                    },
                    negativeSeleted = {
                        it.dismiss()
                    }
            )*//*

            if (checkPersmission()) {
                if (!Util.enableGPSIfPossible(RegistrationActivity@ this)) {
                    startActivityForResult(Intent(this, CheckInMapActivity::class.java), 1109)
                }
            } else {
                requestPermission()
            }

        }

        ivSync.setOnClickListener {

            if (Util.isOnline(this@RegistrationActivity)) {
                if ((registrationCheckinRequestModel != null) && fseProspectResponseModel!!.isChanged) {
                    //you have data to sync
                    viewModel.sendRegistrationCheckinRequestToServerForceUpload(
                            registrationCheckinRequestModel = registrationCheckinRequestModel!!,
                            showProgress = {
                                showProgressDialog(this)
                            }).observe(this, Observer {

                        viewModel.getFseProspectiveFromServer(loginResponseData!!.angazaId!!, fseProspectResponseModel!!.prospectId)?.observe(this, Observer {
                            Log.d(TAG, "it-getFseProspectiveFromServer-01:${it} ");
                            if (it != null) {
                                if ((it.success) && (it.responseData != null)) {

                                    setValue(it.responseData!!)
                                    //alphaMethod(it.responseData!!)
                                } else {
                                    alphaMethod(fseProspectResponseModel!!)
                                }
                            } else {
                                alphaMethod(fseProspectResponseModel!!)
                            }

                            cancelProgressDialog()
                        })
                    })
                } else {
                    //you don't have data to sync
//                    Util.showToast("Sync not required", this)
                    *//*Util.customFseRationaleDialog(this, "",
                            hideNegative = true,
                            titleSpanned = null,
                            hideTitle = true,
                            message = "Sync Not Required",
                            positveSelected = {
                                it.dismiss()
                            },
                            negativeSeleted = {
                                it.dismiss()
                            }
                    )*//*

                    viewModel.getFseProspectiveFromServer(loginResponseData!!.angazaId!!, fseProspectResponseModel!!.prospectId, showProgress = {
                        showProgressDialog(this)
                    })?.observe(this, Observer {
                        Log.d(TAG, "it-getFseProspectiveFromServer-11:${it} ");
                        if (it != null) {
                            if ((it.success) && (it.responseData != null)) {

                                setValue(it.responseData!!)
                                //alphaMethod(it.responseData!!)
                            } else {
                                alphaMethod(fseProspectResponseModel!!)
                            }
                        } else {
                            alphaMethod(fseProspectResponseModel!!)
                        }

                        cancelProgressDialog()
                    })
                }
            } else {
//                Util.showToast("No Internet", this)
                Util.customFseRationaleDialog(this, "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = "Please Check your Internet",
                        positveSelected = {
                            it.dismiss()
                        },
                        negativeSeleted = {
                            it.dismiss()
                        }
                )
            }

        }


    }

    //private fun processCheckIn(context: Context, isOnline: Boolean, fseProspectResponseModel: FseProspectResponseModel) {
    private fun processCheckIn(context: Context, isOnline: Boolean, fseProspectResponseModel: FseProspectResponseModel, location: Location) {
        viewModel.processCheckIn2(
                context = context,
                isOnline = isOnline,
                prospectID = fseProspectResponseModel.prospectId,
                angazaId = loginResponseData!!.angazaId!!,
                area = fseProspectResponseModel.area,
                location = location,
                prospectAllowedDistance = fseProspectResponseModel.prospectAllowedDistance,
                showProgress = {
                    showProgressDialog(context)
                }
        )?.observe(this, Observer {
            cancelProgressDialog()

            //if (isOnline) { // todo And check if all is ok successfull

            alphaMethod(fseProspectResponseModel)

            if (it!!.success) {
                Util.customFseCompletionDialog(
                        context = context,
                        title = "Check-In Successful",
                        //message = "Check-In done successfully.\n\nPlease start the installation process after Call center verification.",
                        message = " Please wait for call center verification and then proceed for angaza customer activation",
                        okSelected = {
                            it.dismiss()
                            //backpress //add your addditional logic here
                            this@RegistrationActivity.onBackPressed()
                        })
            } else {

                if (it.error?.code == 1001) {

                    Util.customFseCompletionDialog(
                            context = context,
                            hideTitle = true,
                            title = null,
                            message = "Your Check-In has failed the distance criteria check.\n" +
                                    "This Prospect will now be re-assigned. Please contact your ABM",
                            okSelected = {
                                it.dismiss()
                                //backpress //add your addditional logic here
                                this@RegistrationActivity.onBackPressed()
                            })
                } else {

//                    Util.showToast("Unable to send registration to the server", this)
                    Util.customFseRationaleDialog(this, "",
                            hideNegative = true,
                            titleSpanned = null,
                            hideTitle = true,
                            message = "Unable to send registration to the server",
                            positveSelected = {
                                it.dismiss()
                            },
                            negativeSeleted = {
                                it.dismiss()
                            }
                    )
                }

            }

        })
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item?.itemId) {
            android.R.id.home -> {

                onBackPressed()

                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }


    fun initializeExtras() {

        if (intent.hasExtra("data")) {

            fseProspectResponseModel = intent.getParcelableExtra("data")

        }

    }

    fun initialize() {

        fseProspectResponseModel?.let {
            setValue(it)
        }


    }

    private fun setValue(fseProspectResponseModel: FseProspectResponseModel) {

        tv_CustomerName.text = fseProspectResponseModel.name
        tv_CustomerAddress.text = fseProspectResponseModel.customerAddress
        tv_PhoneNumber.text = fseProspectResponseModel.customerPhoneNumber
        tv_ProspectID.text = fseProspectResponseModel.prospectId
        //tv_AccountNo.text = fseProspectResponseModel.accuntNumber//not available
        //tv_TicketGenerationDate.text = fseProspectResponseModel.statusUpdateTime //no idea what value to set
        //tv_TypeOfTicket.text = fseProspectResponseModel.name // customer address not available
        //tv_VerificationDate.text = fseProspectResponseModel.name // customer address not available


        setProspectProgress(fseProspectResponseModel.statusUpdateTime)

        alphaMethod(fseProspectResponseModel)


    }

    fun alphaMethod(fseProspectResponseModel: FseProspectResponseModel) {
        viewModel.getCombineRequestModel(fseProspectResponseModel.prospectId).observe(this, Observer {


            Log.d(TAG, " getCombineRequestModel:$it ");

            it?.fseProspectResponseModel?.let {
                this.fseProspectResponseModel = it

                if (!(it.statusUpdateTime?.checkedIn.isNullOrBlank())) {
                    btnCheckIn.visibility = View.GONE


                    tv_CheckedInDate.text = Util.fseUiDateFormatter(it.statusUpdateTime?.checkedIn!!)
                    //img_CheckedIn
                    //img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

                    if (!it.approved) {

                        if (it.status == FseProspectiveConstant.ProspectStatus.CHECKED_IN) {

                            img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_cancel))
                            img_CheckedIn.setOnClickListener {
                                errorMessage(this.fseProspectResponseModel!!)
                            }

                        } else {
                            img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                        }
                    } else {
                        img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                    }

                }
            }


            if (it?.registrationCheckinRequestModel == null) {

                val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                ivSyncColor.setImageDrawable(backgroundDrawable)

            } else {
                registrationCheckinRequestModel = it?.registrationCheckinRequestModel

                if (this.fseProspectResponseModel!!.isChanged) {


                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.RED)
                    ivSyncColor.setImageDrawable(backgroundDrawable)
                } else {

                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                    ivSyncColor.setImageDrawable(backgroundDrawable)

                }
                //btnCheckIn.visibility = View.GONE

            }

            it?.fseError?.let {

                Log.d(TAG, " it?.fseError? :${this.fseProspectResponseModel!!.errorOccurred} ");
                if (this.fseProspectResponseModel!!.errorOccurred && (it.errorType == FseProspectiveConstant.ProspectiveType.REGISTRATION)) {
                    llError.visibility = View.VISIBLE
                    tvErrorMessage.text = it.messageToUser
                }
            }
        })
    }

    private fun setProspectProgress(statusUpdateTime: FseProspectResponseModel.StatusUpdateTime?) {
        if (!statusUpdateTime?.prospect.isNullOrEmpty()) {
//            tv_ProspectDate.text = statusUpdateTime?.prospect
            tv_ProspectDate.text = Util.fseUiDateFormatter(statusUpdateTime?.prospect!!)
            img_Prospect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
        } else {
            tv_ProspectDate.text = ""
            img_Prospect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
        }


        if (!statusUpdateTime?.otpApproved.isNullOrEmpty()) {
            tv_OTPDate.text = statusUpdateTime?.otpApproved
            if (!statusUpdateTime?.otpApproved.isNullOrEmpty()) {
//            tv_OTPDate.text = statusUpdateTime?.otpApproval
                tv_OTPDate.text = Util.fseUiDateFormatter(statusUpdateTime?.otpApproved!!)
                img_Otp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
            } else {
                tv_OTPDate.text = ""
                img_Otp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }

            if (!statusUpdateTime?.preApprovedProspect.isNullOrEmpty()) {
                tv_PreApprovedDate.text = Util.fseUiDateFormatter(statusUpdateTime!!.preApprovedProspect!!)
//            tv_PreApprovedDate.text = statusUpdateTime?.preApprovedProspect
                //img_PreApproved
                //img_PreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

                if (!fseProspectResponseModel!!.approved) {

                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT) {

                        img_PreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_cancel))
                        btnCheckIn.visibility = View.GONE
                        img_PreApproved.setOnClickListener {
                            errorMessage(fseProspectResponseModel!!)
                        }
                    } else {
                        img_PreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                    }
                } else {
                    img_PreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                }

            } else {
                tv_PreApprovedDate.text = ""
                img_PreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }


            if (!statusUpdateTime?.checkedIn.isNullOrEmpty()) {
//            tv_CheckedInDate.text = statusUpdateTime?.checkedIn
                tv_CheckedInDate.text = Util.fseUiDateFormatter(statusUpdateTime?.checkedIn!!)
                //img_CheckedIn
                //img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

                if (!fseProspectResponseModel!!.approved) {

                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.CHECKED_IN) {

                        img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_cancel))
                        btnCheckIn.visibility = View.GONE
                        img_CheckedIn.setOnClickListener {
                            errorMessage(fseProspectResponseModel!!)
                        }

                    } else {
                        img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                    }
                } else {
                    img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                }

            } else {
                tv_CheckedInDate.text = ""
                img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }



            if (!statusUpdateTime?.threeWayCallVerification.isNullOrEmpty()) {
//            tv_CCverif.text = statusUpdateTime?.threeWayCallVerificationx
                tv_CCverif.text = Util.fseUiDateFormatter(statusUpdateTime?.threeWayCallVerification!!)
                //img_CheckedIn
                //img_CheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))


                if (!fseProspectResponseModel!!.approved) {

                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL) {

                        img_CCVerif.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_cancel))
                        btnCheckIn.visibility = View.GONE
                        img_CCVerif.setOnClickListener {
                            errorMessage(fseProspectResponseModel!!)
                        }
                    } else {
                        img_CCVerif.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                    }
                } else {
                    img_CCVerif.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                }

            } else {
                tv_CCverif.text = ""
                img_CCVerif.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }


            if (!statusUpdateTime?.installed.isNullOrEmpty()) {
//            tv_InstallPendDate.text = statusUpdateTime?.installationPending
                tv_InstallPendDate.text = Util.fseUiDateFormatter(statusUpdateTime?.installed!!)
                //img_istallationP
                img_istallationP.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                tv_InstallPendDate.text = ""
                img_istallationP.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
            }

            *//*if (!statusUpdateTime?.installed.isNullOrEmpty()) {
//            tv_InstallCompleteDate.text = statusUpdateTime?.installed
                tv_InstallCompleteDate.text = Util.fseUiDateFormatter(statusUpdateTime?.installed!!)
                //img_InstallComplete
                img_InstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                tv_InstallCompleteDate.text = ""
                img_InstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }*//*


            if (!statusUpdateTime?.installationVerified.isNullOrEmpty()) {
//            tv_InstallCompleteDate.text = statusUpdateTime?.installed
                tv_InstallCompleteDate.text = Util.fseUiDateFormatter(statusUpdateTime?.installationVerified!!)
                //img_InstallComplete
                img_InstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                tv_InstallCompleteDate.text = ""
                img_InstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
            }
        }
    }

    private fun errorMessage(fseProspectResponseModel: FseProspectResponseModel) {
        Util.customFseCompletionDialog(
                context = this,
                hideTitle = true,
                title = null,
                message = fseProspectResponseModel.message,
                okSelected = {
                    it.dismiss()
                }
        )
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)


        if (requestCode == 1109) {
            if (resultCode == Activity.RESULT_OK) {
                val location = data?.getParcelableExtra<Location>("location_result")


                if (location != null) {

                    if (location.accuracy < checkInAccuracy!!) {

                        processCheckIn(this@RegistrationActivity, Util.isOnline(this@RegistrationActivity), fseProspectResponseModel!!, location)
                    } else {
                        showLowAccuracyDialog(location)

                    }

                } else {

                    Util.customFseCompletionDialog(
                            context = this,
                            hideTitle = true,
                            message = "Accuracy not detected\nPlease Check-In again",
                            okSelected = {
                                it.dismiss()
                                //upload image
                            },
                            title = null
                    )

                }

            }
            if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
            }
        }
    }

    private fun checkPersmission(): Boolean {
        return (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }


    private fun requestPermission() {
        ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {

//                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//
//                }
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (!Util.enableGPSIfPossible(RegistrationActivity@ this)) {
                        startActivityForResult(Intent(this, CheckInMapActivity::class.java), 1109)
                    }
                }
            }
        }
    }

    fun showLowAccuracyDialog(location: Location) {


        Log.d(TAG, "ACCURRACY - showLowAccuracyDialog :${location?.accuracy} ");
        //show accuracy here inside dialog
        //fetchAccuray()


        val title = "Accuracy is Low"
        val spannable = SpannableString(title)
        spannable.setSpan(
                StyleSpan(Typeface.BOLD),
                0, title.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

        Util.customFseCompletionDialog(
                context = this,
                hideTitle = false,
                message = "Please click Check-In again for better results.",
                titleSpanned = spannable,
                okSelected = {
                    it.dismiss()
                    //upload image
                    //bag.clear()
                },
                title = null

        )

    }


	override fun onDestroy() {
		super.onDestroy()
		mHomeWatcher?.stopWatch();

	}*/
}
