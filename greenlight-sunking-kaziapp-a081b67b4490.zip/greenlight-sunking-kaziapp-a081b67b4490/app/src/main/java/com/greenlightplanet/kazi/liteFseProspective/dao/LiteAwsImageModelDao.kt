package com.greenlightplanet.kazi.liteFseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.liteFseProspective.model.LiteAwsImageModel
import io.reactivex.Single

@Dao
interface LiteAwsImageModelDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(liteAwsImageModel: List<LiteAwsImageModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(liteAwsImageModel: LiteAwsImageModel): Long

    @Delete
    fun delete(liteAwsImageModel: LiteAwsImageModel): Int

    @Query("DELETE FROM LiteAwsImageModel")
    fun deleteAll(): Int

    @Query("SELECT * FROM LiteAwsImageModel")
    fun getAll(): Single<List<LiteAwsImageModel>>

    @Query("SELECT * FROM LiteAwsImageModel LIMIT 1")
    fun get(): Single<LiteAwsImageModel>

    @Query("SELECT COUNT(*) from LiteAwsImageModel")
    fun count(): Int

    @Query("SELECT * FROM LiteAwsImageModel WHERE prospectId=:prospectId LIMIT 1")
    fun getByProspectId(prospectId: String): Single<LiteAwsImageModel>?

    @Query("SELECT * FROM LiteAwsImageModel WHERE prospectId=:prospectId")
    fun getByALLProspectId(prospectId: String): Single<List<LiteAwsImageModel>>

    @Query("SELECT * FROM LiteAwsImageModel WHERE prospectId IN (:prospectId)")
    fun getAllByProspectID(prospectId: List<String>): Single<List<LiteAwsImageModel>?>

}
