package com.greenlightplanet.kazi.incentivenew.model.tvinstallation

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Created by Rahul on 14/12/20.
 */

@Parcelize
@Entity
data class AccountsList (

        @SerializedName("registrationDate") val registrationDate : String?,

        @PrimaryKey
        @SerializedName("accountNumber") val accountNumber : Int ,

        @ColumnInfo
        @SerializedName("isEligible") val isEligible : Boolean?


):Parcelable