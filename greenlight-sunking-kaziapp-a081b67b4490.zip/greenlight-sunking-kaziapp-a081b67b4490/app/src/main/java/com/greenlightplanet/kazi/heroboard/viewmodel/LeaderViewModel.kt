package com.greenlightplanet.kazi.heroboard.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.heroboard.model.HeroboardModel
import com.greenlightplanet.kazi.heroboard.repo.LeaderRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel

class LeaderViewModel(application: Application) : AndroidViewModel(application) {

    val repo = LeaderRepo.getInstance(application)


    fun getLeaderModel(anganzaID: String): MutableLiveData<NewCommonResponseModel<HeroboardModel>> {
        return repo.getLeaderBoardData(anganzaID)
    }

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }


}
