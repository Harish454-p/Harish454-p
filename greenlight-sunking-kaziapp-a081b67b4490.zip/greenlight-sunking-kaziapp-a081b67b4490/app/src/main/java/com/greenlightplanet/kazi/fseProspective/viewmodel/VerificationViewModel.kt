package com.greenlightplanet.kazi.fseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import com.greenlightplanet.kazi.fseProspective.model.CombineRequestModel
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseData
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseModel
import com.greenlightplanet.kazi.fseProspective.model.OtpApprovalRequestModel
import com.greenlightplanet.kazi.fseProspective.repo.ProspectiveRepo
import com.greenlightplanet.kazi.fseProspective.repo.VerificationRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable

class VerificationViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "VerificationViewModel"

    }

    private val repository = ProspectiveRepo(context = application.applicationContext)
    val repo = VerificationRepo.getInstance(application)

    fun processOtp(context: Context, isOnline: Boolean, isValid: Boolean, prospectID: String, angazaId: String, unsuccessfulAttempt: Int = 0,country:String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

        showProgress()

        if (isValid) {
            return repo.onValidOtp(isOnline, prospectID, angazaId,country)
        } else {
            return repo.onInvalidOtp(isOnline, prospectID, angazaId, unsuccessfulAttempt,country)
        }
    }

    fun getCombineRequestModel(prospectID: String): MutableLiveData<CombineRequestModel?> {
        return repo.getCombineRequestModel(prospectID)
    }

    fun sendOtpApprovalToServerForceUpload(isValid: Boolean, otpApprovalRequest: OtpApprovalRequestModel, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return repo.sendOtpApprovalToServerForceUpload(isValid, otpApprovalRequest)
    }

    fun getFseProspectiveFromServer(angazaId:String,prospectId:String,showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>? {
        showProgress()
        return repo.getFseProspectiveFromServer(angazaId,prospectId)
    }

    //region registration list...
    fun getFseProspectiveFromDatabase() : MutableLiveData<NewCommonResponseModel<FseProspectResponseData>> {
        return repository.getFseProspectiveFromDatabase()!!
    }
    //endregion

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
        repository.destroy()
    }

}
