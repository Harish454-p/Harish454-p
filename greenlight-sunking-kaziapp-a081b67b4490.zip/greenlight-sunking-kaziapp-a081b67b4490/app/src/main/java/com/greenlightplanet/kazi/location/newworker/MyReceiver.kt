package com.greenlightplanet.kazi.location.newworker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.location.Location
import android.util.Log

class MyReceiver : BroadcastReceiver() {
	override fun onReceive(context: Context, intent: Intent) {
		val location = intent.getParcelableExtra<Location>(LocationUpdatesService.EXTRA_LOCATION)
		if (location != null) {
//			Toast.makeText(context, Utils.getLocationText(location),
//				Toast.LENGTH_SHORT).show()
			Log.d("MyReceiver", "location: " + Utils.getLocationText(location));
		}
	}
}
