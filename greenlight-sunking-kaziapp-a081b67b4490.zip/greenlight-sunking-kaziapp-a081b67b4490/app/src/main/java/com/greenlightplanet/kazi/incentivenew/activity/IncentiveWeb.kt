package com.greenlightplanet.kazi.incentivenew.activity

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.webkit.WebView
import android.webkit.WebViewClient
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivitySalesBinding
import com.greenlightplanet.kazi.databinding.IncentivewebviewBinding
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.Util


/**
 * Created by Rahul on 14/12/20.
 */
class IncentiveWeb : BaseActivity() {

    var link: String? = null
    private lateinit var binding: IncentivewebviewBinding

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = IncentivewebviewBinding.inflate(layoutInflater)
        setContentView(binding.root)


       // setContentView(R.layout.incentivewebview)
        Util.setToolbar(this, binding.toolbar2!!)

        Util.addEvent("311", "IncentiveWebScreen", "EarningScreen_to_IncentiveWebScreen")

        link = intent.getStringExtra("link")
        val web = findViewById(R.id.web) as WebView

        link?.let { web.loadUrl(it) }

        web.settings.javaScriptEnabled = true

        web.webViewClient = WebViewClient()
        web.webViewClient = myWebViewClient()

    }

    class myWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            view.loadUrl(url)
            return true
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()

        return true
    }

}