package com.greenlightplanet.kazi.leads.dao

import androidx.room.*
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead
import io.reactivex.Single

@Dao
interface LeadsCrossSalesLeadDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(CrossSalesLead: List<LeadsCrossSalesLead>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(CrossSalesLead: LeadsCrossSalesLead): Long

    @Delete
    fun delete(CrossSalesLead: LeadsCrossSalesLead): Int

    @Query("DELETE FROM LeadsCrossSalesLead")
    fun deleteAll(): Int

    @Query("SELECT * FROM LeadsCrossSalesLead")
    fun getAll(): Single<List<LeadsCrossSalesLead>>

    @Query("SELECT * FROM LeadsCrossSalesLead LIMIT 1")
    fun get(): Single<LeadsCrossSalesLead>

    @Query("SELECT * FROM LeadsCrossSalesLead WHERE accountNumber=:accountNumber LIMIT 1")
    fun getByAccountNumber(accountNumber: String): Single<LeadsCrossSalesLead>?

    @Query("SELECT COUNT(*) from LeadsCrossSalesLead")
    fun count(): Single<Int>
}
