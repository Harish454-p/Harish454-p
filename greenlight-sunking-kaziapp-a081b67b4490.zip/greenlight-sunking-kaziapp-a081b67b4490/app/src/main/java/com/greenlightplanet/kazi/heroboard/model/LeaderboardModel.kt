package com.greenlightplanet.kazi.heroboard.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "leaderBoard",primaryKeys = ["eoAngazaId","month","geography"])
data class LeaderboardModel(
        @ColumnInfo(name = "eoAngazaId")
        @SerializedName("eoAngazaId")
        var eoAngazaId: String,
        @ColumnInfo(name = "eoName")
        @SerializedName("eoName")
        var eoName: String?,
        @ColumnInfo(name = "geography")
        @SerializedName("geography")
        var geography: String,
        @ColumnInfo(name = "area")
        @SerializedName("area")
        var area: String?,
        @ColumnInfo(name = "year")
        @SerializedName("year")
        var year: String?,
        @ColumnInfo(name = "geographyName")
        @SerializedName("geographyName")
        var geographyName: String,
        @ColumnInfo(name = "imageUrl")
        @SerializedName("imageUrl")
        var imageUrl: String?,
        @ColumnInfo(name = "month")
        @SerializedName("month")
        var month: String,
        @ColumnInfo(name = "sales")
        @SerializedName("sales")
        var sales: Double,
        @ColumnInfo(name = "salesRank")
        @SerializedName("salesRank")
        var salesRank: Int
) : Parcelable
