package com.greenlightplanet.kazi.fseProspective.repo

import android.annotation.SuppressLint
import android.content.Context
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.room.EmptyResultSetException
import com.google.gson.Gson
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.fseProspective.extras.ErrorUtils
import com.greenlightplanet.kazi.fseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.fseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.fseProspective.model.*
import com.greenlightplanet.kazi.fseProspective.model.CombineRequestModel
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.*

class InstallationRepo(val context: Context) {

    companion object : SingletonHolderUtil<InstallationRepo, Context>(::InstallationRepo) {
        public const val TAG = "InstallationRepo"
    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    var gson: Gson? = null
    //var country: String? = null

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context!!)
            //country = preference?.getLoginResponseModel()?.country
            gson = Gson()

        } catch (e: Exception) {
            Log.d(TAG, ":Error ");
        }
    }

    private val territory: String? by lazy {
        preference?.getLoginResponseModel()?.territory
    }


    fun updateFseProspect(fseProspectResponseModel: FseProspectResponseModel): MutableLiveData<FseProspectResponseModel> {
        val data = MutableLiveData<FseProspectResponseModel>()

        bag.add(
            Completable.fromAction {
                localDb?.fseProspectResponseDao()?.insert(fseProspectResponseModel)
            }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(fseProspectResponseModel)
                }, { data.postValue(null) })
        )


        return data
    }


    //This is called when activity is loaded and installation is perform
    fun getCombineRequestModel(prospectId: String): MutableLiveData<CombineRequestModel> {

        val data = MutableLiveData<CombineRequestModel>()
        val combineModel = CombineRequestModel()


        try {
            bag.add(
                localDb?.fseProspectResponseDao()?.getByProspectId(prospectId)!!
                    .flatMap {
                        combineModel.fseProspectResponseModel = it
                        localDb?.installationRequestDao()?.getByProspectId(prospectId)
                    }.flatMap {
                        combineModel.installationRequestModels = it
                        localDb?.fseErrorDao()?.getByProspectId(prospectId)
                    }
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .doFinally { data.postValue(combineModel) }
                    .onErrorResumeNext {
                        if (it is EmptyResultSetException) Single.just(
                            FseError(
                                prospectId,
                                it.localizedMessage,
                                500,
                                it.message,
                                "No Data Available",
                                it.message
                            )
                        ) //<< an empty container is returned.
                        else Single.error(it)
                    }
                    .doOnError {
                        Log.d(TAG, "Error-1: ${it.localizedMessage}");
                        it.printStackTrace()
                    }
                    .subscribe({
                        combineModel.fseError = it
                    }, {
                        it.printStackTrace()
                        Log.d(TAG, "ERROR:${it.localizedMessage} ");
                    })
            )
        } catch (e: Exception) {
            Log.e("Error", "${e}")
        }
        return data
    }


    //Force Sync-Installation is perform for a particular prospect
    fun sendInstallationRequestToServerForce(
        installationRequestModel: InstallationRequestModel,
        fileModel: List<AwsImageModel>
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()
        bag.add(
            ServiceInstance.getInstance(context).service?.postInstallation(
                prospectId = installationRequestModel.prospectId,
                installationRequestModel = installationRequestModel
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable {
                    if (it.success) {
                        data.postValue(it)
                        performIsChanged(
                            installationRequestModel.prospectId,
                            false,
                            installationRequestModel.installationCompletedTime!!
                        )
                            .mergeWith {
//                                            fileModel.uploadedToGLPServer = true
//                                            fileModel.savedInDatabase = true
                                fileModel.forEach {
                                    it.uploadedToGLPServer = true
                                    it.savedInDatabase = true
                                }
//                                            localDb?.liteAwsImageModelDao()?.insert(fileModel)
                                localDb?.awsImageModelDao()?.insertAll(fileModel)

                            }
                    } else {
                        data.postValue(it)
                        performIsChanged(
                            prospectId = installationRequestModel.prospectId,
                            isChanged = false,
                            errorOccurred = true,
                            errorModel = it.error
                        )
                    }


                }.subscribe({}, { t ->

                    com.greenlightplanet.kazi.liteFseProspective.extras.ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "sendInstallationRequestToServerForce",
                        "Unable to send data to server",
                        data
                    )

                })
        )
        return data
    }


    //Performing installation based on Online/Offline automatically
    fun performInstallation(
        context: Context,
        fseProspectResponseModel: FseProspectResponseModel?,
        isOnline: Boolean,
        prospectId: String,
        angazaId: String,
        accountNumber: String,
        installationAttempted: Int,
        fileModel: List<AwsImageModel>/*, location: Location*/
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()
        val imageList: MutableList<InstallationRequestModel.ImagesList> = mutableListOf()
        imageList.clear()
        val fseLoc = fseProspectResponseModel!!.prospectLocation
        if (fseProspectResponseModel.isInstallationChanged!!) {
            for (fse in fseProspectResponseModel.installationPictures!!) {
                if (fse.isRejected!!) {
                    imageList.add(
                        InstallationRequestModel.ImagesList(
                            installationPictures = fse.url,
                            latitude = fseLoc!!.latitude.toString(),
                            longitude = fseLoc.longitude.toString(),
                            accuracy = fseLoc.accuracy.toString(),
                            attempt = fse.attempt.plus(1),
                            imageName = fse.name
                        )
                    )
                } else {
                    imageList.add(
                        InstallationRequestModel.ImagesList(
                            installationPictures = fse.url,
                            latitude = fseLoc!!.latitude.toString(),
                            longitude = fseLoc.longitude.toString(),
                            accuracy = fseLoc.accuracy.toString(),
                            attempt = fse.attempt,
                            imageName = fse.name
                        )
                    )
                }

            }
        } else {
            for (fse in fseProspectResponseModel.installationPictures!!) {
                if (fse.isRejected!!) {
                    imageList.add(
                        InstallationRequestModel.ImagesList(
                            installationPictures = fse.url,
                            latitude = fseLoc!!.latitude.toString(),
                            longitude = fseLoc.longitude.toString(),
                            accuracy = fseLoc.accuracy.toString(),
                            attempt = fse.attempt.plus(1),
                            imageName = fse.name
                        )
                    )
                } else {
                    imageList.add(
                        InstallationRequestModel.ImagesList(
                            installationPictures = fse.url,
                            latitude = fseLoc!!.latitude.toString(),
                            longitude = fseLoc.longitude.toString(),
                            accuracy = fseLoc.accuracy.toString(),
                            attempt = installationAttempted,
                            imageName = fse.name
                        )
                    )
                }

            }
        }


        val installationRequestModel = InstallationRequestModel(
            images = imageList,
            prospectId = prospectId,
            angazaId = angazaId,
            installationCompletedTime = Util.fseDateToUtcFormatted(Date()),
            accountNumber = accountNumber,
            installationAttempted = installationAttempted,
            country = preference?.getLoginResponseModel()?.country ?: ""
        )

        //Insert Lat-long to Database first
        insertInstallationRequestToDatabase(isOnline, data, installationRequestModel, fileModel)

        return data
    }

    fun performInstallation2(
        context: Context,
        fseProspectResponseModel: FseProspectResponseModel?,
        isOnline: Boolean,
        prospectId: String,
        fileModel: List<AwsImageModel>
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()

        bag.add(
            localDb!!.installationRequestDao().getByProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .subscribeOn(Schedulers.io())
                .subscribe({

                    it.images!!.map { data ->
                        fileModel.find { it.imageName == data.imageName }?.let {
                            data.installationPictures = it.awsLink
                        }
                    }
                    Log.e(TAG, "installationRequestModel === $it")

                    Log.e(TAG, "fileModel === $fileModel")
                    insertInstallationRequestToDatabase(isOnline, data, it, fileModel)
                }, { t ->

                    ErrorUtils.errorHandler(
                        gson, t,
                        TAG,
                        "performInstallation2",
                        "Unable to send data to server",
                        data
                    )

                })
        )


        return data
    }


    private fun sendInstallationRequestToServer(
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        installationRequestModel: InstallationRequestModel,
        fileModel: List<AwsImageModel>
    ) {

        var response: NewCommonResponseModel<NewEmptyParcelable>? = null

        bag.add(
            ServiceInstance.getInstance(context).service?.postInstallation(
                prospectId = installationRequestModel.prospectId,
                installationRequestModel = installationRequestModel
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "sendInstallationRequestToServer-subscribe:$response");
//                            liveData.postValue(response)

                    if (it.success) {

                        val list = mutableListOf<Completable>()
                        fileModel.forEach {
                            it.uploadedToGLPServer = true
                            it.savedInDatabase = true
                        }
                        list.add(
                            performIsChanged(
                                installationRequestModel.prospectId,
                                false,
                                installationRequestModel.installationCompletedTime!!
                            )
                        )
                        list.add(
                            Completable.fromAction {
//                                            localDb?.liteAwsImageModelDao()?.insert(fileModel)
                                localDb?.awsImageModelDao()?.insertAll(fileModel)
                            }
                        )

                        bag.add(
                            Completable.merge(list).subscribe({
                                Log.d(TAG, "sendInstallationRequestToServer-subscribe1:$response");
                                liveData.postValue(response)
                                localDb?.let {
                                    it.installationRequestDao().delete(installationRequestModel)
                                }
                            }, {
                                /*Log.d(TAG, "sendInstallationRequestToServer-subscribe2:$response");
                                liveData.postValue(response)*/
                                Log.d(TAG, "API-Error3: ${it.localizedMessage}")
                            })
                        )

                    } else {
                        bag.add(
                            performIsChanged(
                                prospectId = installationRequestModel.prospectId,
                                isChanged = false,
                                errorOccurred = true,
                                errorModel = it.error
                            )
                                .observeOn(Schedulers.io())
                                .subscribeOn(Schedulers.io())
                                .subscribe({
                                    Log.d(
                                        TAG,
                                        "sendInstallationRequestToServer-subscribe3:$response"
                                    );
                                    liveData.postValue(response)
                                }, {
                                    //Log.d(TAG, "sendInstallationRequestToServer-subscribe4:$response");
                                    //liveData.postValue(response)
                                    Log.d(TAG, "API-Error4: ${it.localizedMessage}")

                                })
                        )

                    }
//                            liveData.postValue(it)

                }, { t ->

                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "sendInstallationRequestToServer",
                        "Unable to send data to server",
                        liveData
                    )

                })
        )
    }


    /*
    * After getting latlong first insert data to database
    *
    *
    * */

    private fun insertInstallationRequestToDatabase(
        isOnline: Boolean,
        liveData: MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>,
        installationRequestModel: InstallationRequestModel,
        fileModel: List<AwsImageModel>
    ) {

        localDb?.let {
            bag.add(
                //Inserting Lat-Long to database
                Completable.fromAction {
                    it.installationRequestDao().insert(installationRequestModel)
                }
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        //after lat-long insertion in database
                        //Perform is Change
                        performIsChanged(
                            prospectId = installationRequestModel.prospectId,
                            isChanged = true,
                            installationAttempted = installationRequestModel.installationAttempted
                        )
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                //after performing change in fseprospectModel
                                //Inserting AwsImageModel to database
                                Completable.fromAction {
                                    fileModel.forEach {
                                        it.savedInDatabase = true
                                    }
                                    localDb?.awsImageModelDao()?.insertAll(fileModel)

                                }.subscribeOn(Schedulers.io())
                                    .observeOn(Schedulers.io())
                                    .subscribe({
                                        //after inserting AwsImageModel to database
                                        if (isOnline) {
                                            //If online send the (already) saved Installation request to server
                                            sendInstallationRequestToServer(
                                                liveData,
                                                installationRequestModel,
                                                fileModel
                                            )
                                        } else {
                                            //If not online notify the view by live data
                                            //successfully inserted to database
                                            liveData.postValue(
                                                NewCommonResponseModel<NewEmptyParcelable>(
                                                    success = true
                                                )
                                            )
                                        }
                                    }, {
                                        //Error occured while save awsImageMolde to database
                                        liveData.postValue(
                                            NewCommonResponseModel<NewEmptyParcelable>(
                                                error = NewCommonResponseModel.Error(
                                                    messageToUser = "Unable to send data to server"
                                                ),
                                                success = false
                                            )
                                        )
                                    })

                            }, {
                                //Error occurred while performing change in fseprospectModel
                                Log.d(TAG, "DB-Error: ${it.localizedMessage}")
                                liveData.postValue(null)
                                liveData.postValue(
                                    NewCommonResponseModel<NewEmptyParcelable>(
                                        error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable to send data to server"
                                        ),
                                        success = false
                                    )
                                )

                            })

                    }, { t ->

                        ErrorUtils.errorHandler(
                            gson,
                            t,
                            TAG,
                            "insertInstallationRequestToDatabase",
                            "Unable to send data to server",
                            liveData
                        )
                    })

            )
        }

    }


    private fun performIsChanged(
        prospectId: String,
        isChanged: Boolean,
        date: String = "",
        installationAttempted: Int? = null,
        errorOccurred: Boolean = false,
        errorModel: NewCommonResponseModel.Error? = null
    ): Completable {

        return localDb!!.fseProspectResponseDao().getByProspectId(prospectId)!!.flatMapCompletable {
            Log.d(TAG, "alpha 1abcd: ");
            val value = it
            value.isChanged = isChanged
            value.errorOccurred = errorOccurred

            if (installationAttempted != null) {
                value.installationAttempted = installationAttempted
            }

            if (isChanged) {
                value.reattemptedStage = 2
            }

            val fseError = FseError(
                prospectId = prospectId,
                errorType = FseProspectiveConstant.ProspectiveType.INSTALLATION,
                code = errorModel?.code,
                errorClass = errorModel?.errorClass,
                errorTrace = errorModel?.errorTrace,
                messageToUser = errorModel?.messageToUser
            )

            if (!isChanged && !errorOccurred && date.isNotEmpty()) {
                value.statusUpdateTime?.installed = date
                value.approved = true
                value.status = FseProspectiveConstant.ProspectStatus.INSTALLED
                value.reattemptedStage = 0
            }


            val list = mutableListOf<Completable>()

            list.add(
                Completable.fromAction {
                    localDb!!.fseProspectResponseDao().insert(value)

                }
            )
            if (errorOccurred) {
                list.add(
                    Completable.fromAction {
                        localDb!!.fseErrorDao().insert(fseError)
                    }
                )
            }

            Completable.merge(list)

        }
    }

    //AwsImageModel logics

    fun insertAwsImageModelToDatabase(
        inputFiles: List<AwsImageModel>,
        isUploadedToAws: Boolean?
    ): MutableLiveData<List<AwsImageModel>?> {
        val data = MutableLiveData<List<AwsImageModel>?>()

        inputFiles.forEach { each ->
            each.savedInDatabase = true
            isUploadedToAws?.let {
                each.uploadedToAws = isUploadedToAws
            }

        }

        bag.add(
            Completable.fromAction {
                localDb?.awsImageModelDao()?.insertAll(inputFiles)
            }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "alpha2: ");
                    data.postValue(inputFiles.toMutableList())
                }, {
                    data.postValue(null)
                    Log.d(TAG, "Error:${it.localizedMessage} ");
                    it.printStackTrace()
                })
        )

        return data

    }


    fun getInstallationRequestModelByProspectId(prospectId: String): MutableLiveData<InstallationRequestModel> {

        val data = MutableLiveData<InstallationRequestModel>()

        bag.add(
            localDb!!.installationRequestDao().getByProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(it)
                }, {
                    it.printStackTrace()
                    data.postValue(null)
                })
        )

        return data
    }

    fun getAwsImageModelByProspectId(prospectId: String): MutableLiveData<AwsImageModel> {

        val data = MutableLiveData<AwsImageModel>()

        bag.add(
            localDb!!.awsImageModelDao().getByProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(it)
                }, {
                    it.printStackTrace()
                    data.postValue(null)
                })
        )

        return data
    }

    fun getAllAwsImageModelByProspectId(prospectId: String): MutableLiveData<List<AwsImageModel>> {

        val data = MutableLiveData<List<AwsImageModel>>()

        bag.add(
//                localDb!!.liteAwsImageModelDao().getByProspectId(prospectId)!!
            localDb!!.awsImageModelDao().getByALLProspectId(prospectId)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(it)
                }, {
                    it.printStackTrace()
                    data.postValue(null)
                })
        )

        return data
    }

    ///new

    private fun syncServerInstallationRequestModel(installationRequestModel: InstallationRequestModel): Single<NewCommonResponseModel<NewEmptyParcelable>> {


        return ServiceInstance.getInstance(context).service?.postInstallation(
            prospectId = installationRequestModel.prospectId,
            installationRequestModel = installationRequestModel
        )!!
            .subscribeOn(Schedulers.newThread())
            .flatMap {
                Single.create<NewCommonResponseModel<NewEmptyParcelable>> { emitter ->

                    try {

                        //performIsChanged(registrationCheckinRequestModel.prospectId, false).subscribe({ emitter.onSuccess(it) }, { emitter.onError(it) })
                        if (it.success) {
                            performIsChanged(
                                installationRequestModel.prospectId,
                                false,
                                installationRequestModel.installationCompletedTime!!
                            ).subscribe({ emitter.onSuccess(it) }, { emitter.onError(it) })
                        } else {
                            performIsChanged(
                                prospectId = installationRequestModel.prospectId,
                                isChanged = false,
                                errorOccurred = true,
                                errorModel = it.error
                            ).subscribe({ emitter.onSuccess(it) }, { emitter.onError(it) })
                        }


                    } catch (e: Exception) {
                        emitter.onError(e)
                    }
                }

            }
            .doOnSuccess {
                Log.d(
                    TAG,
                    " inserting-syncServerInstallationRequestModel:${installationRequestModel.prospectId} "
                );
                Completable.fromAction {
                    // logic
                    if (it.success) {
                        performIsChanged(
                            installationRequestModel.prospectId,
                            false,
                            installationRequestModel.installationCompletedTime!!
                        )
                    } else {
                        performIsChanged(
                            prospectId = installationRequestModel.prospectId,
                            isChanged = false,
                            errorOccurred = true,
                            errorModel = it.error
                        )
                    }

                }.subscribe({
                    Log.d(TAG, " on Success ===");
                },{
                    Log.d(TAG, " Error:${it.printStackTrace()}");
                })

            }
            .onErrorResumeNext { it ->


                val isApi = it is retrofit2.HttpException

                var errorModel: NewCommonResponseModel<NewEmptyParcelable>? = null

                if (isApi) {
                    val error = it as HttpException
                    val errorBody = error.response().errorBody()?.string()
                    errorModel = gson?.fromJson<NewCommonResponseModel<NewEmptyParcelable>>(
                        errorBody,
                        NewCommonResponseModel::class.java
                    )

                } else {


                    errorModel = NewCommonResponseModel<NewEmptyParcelable>(
                        error = NewCommonResponseModel.Error(
                            messageToUser = it.localizedMessage
                        ),
                        success = false

                    )

                }

                Log.d(
                    TAG,
                    " inserting-syncServerInstallationRequestModel-Error:${installationRequestModel.prospectId} "
                );





                performIsChanged(
                    prospectId = installationRequestModel.prospectId,
                    isChanged = false,
                    errorOccurred = true,
                    errorModel = errorModel?.error
                )
                    .toSingleDefault(true)
                    .doOnError {
                        it.printStackTrace()
                        Log.d(TAG, "return item2: ${it.localizedMessage}");
                    }
                    .onErrorReturnItem(false)
                    .flatMap {
                        Log.d(TAG, "return item: $it");
                        Single.just(NewCommonResponseModel<NewEmptyParcelable>())
                    }

            }

    }

    private fun syncLoopInstallationRequestModel(installationRequestModel: List<InstallationRequestModel>): Single<List<InstallationRequestModel>> {

        val requests = mutableListOf<Single<NewCommonResponseModel<NewEmptyParcelable>>>()

        installationRequestModel.forEach {
            requests.add(syncServerInstallationRequestModel(it))
        }

        return Single.zip(requests) {
            installationRequestModel
        }
    }


    private fun syncAllInsertInstallationRequestModel(allSingles: Single<List<InstallationRequestModel>>): Single<List<InstallationRequestModel>> {


        return allSingles.flatMap {
            insertAllInstallationRequestToDatabase(it)
        }

    }

    private fun insertAllInstallationRequestToDatabase(installationRequestModel: List<InstallationRequestModel>): Single<List<InstallationRequestModel>> {

        Log.d(TAG, "installationRequestModel-sync:$installationRequestModel ");
        return Single.create { emitter ->

            try {
                val result = localDb!!.installationRequestDao().insertAll(installationRequestModel)
                result.let {
                    emitter.onSuccess(installationRequestModel)
                }

            } catch (e: Exception) {
                emitter.onError(e)
            }
        }
    }

    fun processAll(otpApprovalRequestModels: List<InstallationRequestModel>): Single<List<InstallationRequestModel>> {
        return syncLoopInstallationRequestModel(otpApprovalRequestModels).flatMap {
            insertAllInstallationRequestToDatabase(it)
        }
    }


    //region Compress Image
    fun compressImageForAws(
        context: Context,
        inputFiles: List<ImageUploadUtil.ImageModel>
    ): MutableLiveData<List<AwsImageModel>?> {
        val data = MutableLiveData<List<AwsImageModel>?>()

        val newAwsImageModel = mutableListOf<AwsImageModel>()

        bag.add(
            ImageUploadUtil.compress(context, inputFiles.map { it.file!! })!!
                .flatMapCompletable {
                    for (file in it) {
                        Log.d(TAG, "Success: ${file.path}\n");
                        val imageModel =
                            inputFiles.find { it.file!!.nameWithoutExtension == file.nameWithoutExtension }

                        // start
                        val image: Uri = getImageUri(
                            context,
                            rotationTest(imageModel?.file?.absolutePath),
                            file.name
                        )!!

                        val customFile = File(getRealPathFromURI(image, context)!!)
                        //end

                        newAwsImageModel.add(
                            AwsImageModel(
                                tried = false,
                                fileName = customFile.name,
                                withoutExtension = customFile.nameWithoutExtension,
                                prospectId = imageModel!!.prospectId,
                                fileUri = customFile.path,
                                imageName = imageModel.imageName,
                                awsLink = null,
                                uploadedToGLPServer = false,
                                uploadedToAws = false,
                                savedInDatabase = false
                            )
                        )
                    }

                    Completable.fromAction {
                        newAwsImageModel.forEach {
                            it.savedInDatabase = true
                        }
                        localDb?.awsImageModelDao()?.insertAll(newAwsImageModel)
                    }

                }
                .subscribe({

                    data.postValue(newAwsImageModel)


                }, {
                    Log.d(TAG, "Error:${it.localizedMessage} ");
                    data.postValue(null)
                    it.printStackTrace()
                })
        )


        return data
    }


    @SuppressLint("CheckResult")
    fun getFseProspectiveFromServer(
        angazaId: String,
        prospectId: String
    ): MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>? {

        val data = MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>()

        var value: NewCommonResponseModel<FseProspectItemResponseModel>? = null

        bag.add(

            localDb!!.fseProspectResponseDao().getByProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable { prospectFromDatabase ->
                    // here delete all data from database
                    Completable.fromAction {
                        localDb!!.fseProspectResponseDao().delete(prospectFromDatabase)
                    }.doOnError {
                        Log.d(TAG, "Error-2: ${it.localizedMessage}");
                        data.postValue(
                            NewCommonResponseModel<FseProspectResponseModel>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from server"
                                ),
                                success = false
                            )
                        )
                        it.printStackTrace()
                    }.doOnComplete {
                        //ServiceInstance.getInstance(context).service?.getFseProspectives()!!
                        ServiceInstance.getInstance(context).service?.getFseProspective(
                            angazaId,
                            prospectId,
                            territory!!
                        )!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                value = it!!

                                val fromDatabase = prospectFromDatabase

                                var fromServer = value!!.responseData!!.prospect!!

                                var oldChangedData: FseProspectResponseModel? = null

                                val sameDataInDatabase = fromDatabase

                                fun statusUpdateTimeHandler(
                                    oldStatus: FseProspectResponseModel.StatusUpdateTime,
                                    newStatus: FseProspectResponseModel.StatusUpdateTime,
                                    oldFseProspectResponseModel: FseProspectResponseModel
                                ): FseProspectResponseModel.StatusUpdateTime {
                                    var revisedStatus = oldStatus

                                    if (!newStatus.prospect.isNullOrEmpty()) {
                                        revisedStatus.prospect = newStatus.prospect
                                    }


                                    if (!newStatus.otpApproved.isNullOrEmpty()) {
                                        revisedStatus.otpApproved = newStatus.otpApproved
                                    }


                                    if (!newStatus.preApprovedProspect.isNullOrEmpty()) {
                                        revisedStatus.preApprovedProspect =
                                            newStatus.preApprovedProspect
                                    }

                                    if (!newStatus.checkedIn.isNullOrEmpty()) {
                                        revisedStatus.checkedIn = newStatus.checkedIn
                                    }

                                    if (!newStatus.threeWayCallVerification.isNullOrEmpty()) {
                                        revisedStatus.threeWayCallVerification =
                                            newStatus.threeWayCallVerification
                                    }

                                    if (!newStatus.installationPending.isNullOrEmpty()) {
                                        revisedStatus.installationPending =
                                            newStatus.installationPending
                                    }


                                    if (oldFseProspectResponseModel.reattemptedStage == 0) {
                                        if (!newStatus.installed.isNullOrEmpty()) {
                                            revisedStatus.installed = newStatus.installed
                                        }

                                        if (!newStatus.installationVerified.isNullOrEmpty()) {
                                            revisedStatus.installationVerified =
                                                newStatus.installationVerified
                                        }
                                    }

                                    return revisedStatus
                                }

                                fun statusHandler(oldStatus: String, newStatus: String): String {
                                    var revisedStatus = ""

                                    when (oldStatus) {
                                        FseProspectiveConstant.ProspectStatus.PROSPECT -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.OTP_APPROVED) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PROSPECT
                                            }

                                        }

                                        FseProspectiveConstant.ProspectStatus.OTP_APPROVED -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.CHECKED_IN) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.CHECKED_IN -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            } else if (newStatus == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLED) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLED
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.INSTALLED -> {
                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                            } else if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLED
                                            }
                                        }
                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                            }
                                        }

                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT -> {

                                            if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                            } else {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                            }
                                        }

                                        else -> {
                                            revisedStatus =
                                                FseProspectiveConstant.ProspectStatus.PROSPECT
                                        }

                                    }

                                    return revisedStatus
                                }

                                sameDataInDatabase?.let {

                                    sameDataInDatabase.approved = fromServer.approved
                                    sameDataInDatabase.message = fromServer.message
                                    sameDataInDatabase.customerAddress = fromServer.customerAddress

                                    sameDataInDatabase.name = fromServer.name
                                    sameDataInDatabase.otp = fromServer.otp
                                    sameDataInDatabase.productName = fromServer.productName
                                    sameDataInDatabase.status = statusHandler(
                                        sameDataInDatabase.status!!,
                                        fromServer.status!!
                                    )
                                    sameDataInDatabase.statusUpdateTime = statusUpdateTimeHandler(
                                        sameDataInDatabase.statusUpdateTime!!,
                                        fromServer.statusUpdateTime!!,
                                        sameDataInDatabase
                                    )
                                    sameDataInDatabase.ticketType = fromServer.ticketType
                                    sameDataInDatabase.accountNumber = fromServer.accountNumber
                                    sameDataInDatabase.installationPicture =
                                        fromServer.installationPicture
                                    sameDataInDatabase.customerPhoneNumber =
                                        fromServer.customerPhoneNumber
                                    sameDataInDatabase.area = fromServer.area
                                    //

                                    sameDataInDatabase.prospectLocation = fromServer.prospectLocation
                                    sameDataInDatabase.sampleImages = fromServer.sampleImages
                                    sameDataInDatabase.installationPictures = fromServer.installationPictures
                                    oldChangedData = sameDataInDatabase

                                }
                                //need to add some new attributes here
                                //}


                                val resultData = oldChangedData


                                if (resultData != null) {

                                    //data.postValue(value)
                                    fromServer = resultData
                                    fseProspectiveFromServerLogic(
                                        data,
                                        NewCommonResponseModel(
                                            responseData = fromServer,
                                            success = true
                                        )
                                    )
                                    //add to database

                                } else {
                                    data.postValue(
                                        NewCommonResponseModel<FseProspectResponseModel>(
                                            error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable get data from server"
                                            ),
                                            success = false
                                        )
                                    )
                                }
                            }, {
                                Log.d(TAG, "Error-1: ${it.localizedMessage}");

                                data.postValue(
                                    NewCommonResponseModel<FseProspectResponseModel>(
                                        error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable get data from server"
                                        ),
                                        success = false
                                    )
                                )

                                it.printStackTrace()
                            })
                    }
                }.doOnError {
                    Log.d(TAG, "Error-1: ${it.localizedMessage}");
                    data.postValue(
                        NewCommonResponseModel<FseProspectResponseModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from server"
                            ),
                            success = false
                        )
                    )
                    it.printStackTrace()


                }.subscribe({
                    Log.d(TAG, " on Success ===");
                },{
                    Log.d(TAG, " Error:${it.printStackTrace()}");
                })

        )

        return data
    }

    private fun fseProspectiveFromServerLogic(
        liveData: MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>,
        responseData: NewCommonResponseModel<FseProspectResponseModel>
    ) {

        bag.add(
            Completable.fromAction {
                localDb?.fseProspectResponseDao()?.insert(responseData.responseData!!)
            }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Insertion:Completed ")
                    preference?.setFseProspectLastSynced(Util.getCurrentLocalFormattedDateForSync())
                    liveData.postValue(responseData)
                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })
        )

    }


    fun awsRX(
        context: Context,
        requestModel: BaseRequestModel
    ): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
        val data = MutableLiveData<CommonResponseModel<AWSResponseModel>>()

        bag.add(
            ServiceInstance.getInstance(context).service!!.awsRx(requestModel)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "||=======${it}")
                    data.postValue(it)

                }, {
                    Log.e(TAG, "||=======EROORRRR = $it")
                    data.postValue(
                        CommonResponseModel<AWSResponseModel>().apply {
                            this.Error =
                                com.greenlightplanet.kazi.member.Error(MessageToUser = "Unable to send data to server")
                            this.Success = false
                        }
                    )
                })
        )

        return data

    }

    //endregion

    fun getFseProsResponseModelFromProspectID(prospectId: String): MutableLiveData<FseProspectResponseModel> {

        val data = MutableLiveData<FseProspectResponseModel>()

        bag.add(
            localDb!!.fseProspectResponseDao().getBySingleProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "||======Success:: = $it")
                    data.postValue(it)
                }, {
                    it.printStackTrace()
                    data.postValue(null)
                    Log.e(TAG, "||=======EROORRRR = $it")
                })
        )

        return data
    }

    //region ROTATION AFTER COMPRESS
    private fun getRealPathFromURI(contentURI: Uri, context: Context): String? {
        val result: String?
        val cursor: Cursor? = context.contentResolver.query(contentURI, null, null, null, null)
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentURI.path
        } else {
            cursor.moveToFirst()
            val idx: Int = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA)
            result = cursor.getString(idx)
            cursor.close()
        }
        return result
    }

    fun getImageUri(inContext: Context, inImage: Bitmap, title: String): Uri? {
        val bytes = ByteArrayOutputStream()
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val path =
            MediaStore.Images.Media.insertImage(inContext.contentResolver, inImage, title, null)
        return Uri.parse(path)
    }

    private fun rotationTest(uri: String?): Bitmap {

        var bitmappath: Bitmap? = null
        var bitmap: Bitmap? = null

        bitmappath = BitmapFactory.decodeFile(uri)
        bitmap = Bitmap.createScaledBitmap(bitmappath!!, 700, 700, true)

        ////-----------To Orient a Picture to Potrait---------
        val bounds: BitmapFactory.Options = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeFile(uri!!, bounds)

        val opts: BitmapFactory.Options = BitmapFactory.Options()
        val bm: Bitmap = BitmapFactory.decodeFile(uri, opts)
        val exif = android.media.ExifInterface(uri!!)
        val orientString: String = exif.getAttribute(android.media.ExifInterface.TAG_ORIENTATION)!!

        var orientation: Int = 0
        orientation = Integer.parseInt(orientString)

        var rotationAngle = 0
        if (orientation == android.media.ExifInterface.ORIENTATION_ROTATE_90) rotationAngle = 90
        if (orientation == android.media.ExifInterface.ORIENTATION_ROTATE_180) rotationAngle = 180
        if (orientation == android.media.ExifInterface.ORIENTATION_ROTATE_270) rotationAngle = 270

        val matrix = Matrix()
        matrix.setRotate(
            rotationAngle.toFloat(), (bm.getWidth() / 2).toFloat(),
            (bm.getHeight() / 2).toFloat()
        )
        val rotatedBitmap: Bitmap =
            Bitmap.createBitmap(bm, 0, 0, bounds.outWidth, bounds.outHeight, matrix, true)
        return rotatedBitmap
    }

    //endregion




    fun destroy() {

        Log.d(TAG, "Repo : Distroyed");
        bag.clear()

    }

}
