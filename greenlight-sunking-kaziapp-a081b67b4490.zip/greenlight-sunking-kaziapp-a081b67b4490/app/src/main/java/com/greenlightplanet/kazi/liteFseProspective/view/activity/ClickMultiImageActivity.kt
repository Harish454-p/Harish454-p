package com.greenlightplanet.kazi.liteFseProspective.view.activity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan
import android.util.Log
import android.view.MenuItem
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.google.android.gms.location.LocationRequest
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityClickMutliImageBinding
import com.greenlightplanet.kazi.liteFseProspective.extras.AmazonS3Helper
import com.greenlightplanet.kazi.liteFseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.liteFseProspective.model.LiteAwsImageModel
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import com.greenlightplanet.kazi.liteFseProspective.view.activity.adapter.MultiImageClickAdapter
import com.greenlightplanet.kazi.liteFseProspective.view.activity.checkInMap.LiteCheckInMapActivity
import com.greenlightplanet.kazi.liteFseProspective.viewmodel.ClickMultiViewModel
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.Constants
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.DexterError
import com.karumi.dexter.listener.PermissionRequestErrorListener
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import pl.charmas.android.reactivelocation2.ReactiveLocationProvider
import java.io.File
import java.io.IOException


class ClickMultiImageActivity : BaseActivity(),
    MultiImageClickAdapter.MultiImageClickAdapterCallback, AmazonS3Helper.AmazonS3HelperCallback {

    private lateinit var binding: ActivityClickMutliImageBinding
    var fseProspectResponseModel: LiteFseProspectResponseModel? = null
    var amazonS3Helper: AmazonS3Helper? = AmazonS3Helper(this)
    var loginResponseData: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    var circularProgressDrawable: CircularProgressDrawable? = null
    private val bag: CompositeDisposable = CompositeDisposable()
    var currentLocation: Location? = null
    var mHomeWatcher: HomeWatcher? = null

    //
    var adapterList: MutableList<LiteFseProspectResponseModel.InstallationPictures> =
        mutableListOf()
    var adapter: MultiImageClickAdapter? = null
    lateinit var viewModel: ClickMultiViewModel
    var prospectId = ""
    var installPic: LiteFseProspectResponseModel.InstallationPictures? = null
    var imagePos = 0
    var isOnlyImage = false

    private val REQUEST_CAMERA: Int = 1;
    private val PERMISSION_REQUEST_CODE: Int = 101
    private var outputImgUri: String? = null

    companion object {
        public const val TAG = "ClickMultiImageAct"
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //  setContentView(R.layout.activity_click_mutli_image)
        binding = ActivityClickMutliImageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        Util.setToolbar(this, toolbar)
        preference = GreenLightPreference.getInstance(this)
        viewModel = ViewModelProviders.of(this).get(ClickMultiViewModel::class.java)
        loginResponseData = preference?.getLoginResponseModel()
        circularProgressDrawable = CircularProgressDrawable(this)
        binding.tvAppBottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        binding.tvLastSaved.text =
            "${getString(R.string.last_saved_key)} ${preference?.getFseProspectLastSynced()}"
        val layoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager
        initializeExtras()
        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                finish()
            }
        })
        mHomeWatcher!!.startWatch()

        binding.tvSubmit.setOnClickListener {
            val aaa = adapterList.filter { it.phoneUrl.isNullOrBlank() }.count()
            val isChck = adapterList.filter { it.isNewImage == true }.count()
            if (fseProspectResponseModel!!.isInstallationChanged!!) {
                if (isChck == 0) {
                    showRationaleDialog(fseProspectResponseModel!!)
                } else {
//                    Util.showToast(this, "Please upload all images to Submit.")
                    Util.customFseRationaleDialog(this, "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = "Please upload all images to Submit.",
                        positveSelected = {
                            it.dismiss()
                        },
                        negativeSeleted = {
                            it.dismiss()
                        }
                    )
                }
            } else {
                if (aaa == 0) {
                    showRationaleDialog(fseProspectResponseModel!!)
                } else {
//                    Util.showToast(this, "Please upload all images to Submit.")
                    Util.customFseRationaleDialog(this, "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = "Please upload all images to Submit.",
                        positveSelected = {
                            it.dismiss()
                        },
                        negativeSeleted = {
                            it.dismiss()
                        }
                    )
                }
            }

        }
    }

    private fun initializeExtras() {
        amazonS3Helper?.initializer()
        amazonS3Helper?.amazonS3HelperCallback = this
        if (intent.hasExtra("prospectId")) {
            prospectId = intent.getStringExtra("prospectId")!!
            val createdList: MutableList<LiteFseProspectResponseModel.InstallationPictures> =
                mutableListOf()
            showProgressDialog(this)
            viewModel.getFseProsResponseModelFromProspectID(prospectId)
                .observe(this, Observer {
                    fseProspectResponseModel = it
                    cancelProgressDialog()
                    binding.tvAccountNumber.text = fseProspectResponseModel!!.accountNumber ?: ""
                    Log.e("prospectDataServer", "" + fseProspectResponseModel)
                    if (fseProspectResponseModel!!.installationPictures.isNullOrEmpty()) {
                        fseProspectResponseModel!!.sampleImages!!.forEach {
                            createdList.add(
                                LiteFseProspectResponseModel.InstallationPictures(
                                    name = it.name,
                                    sampleimage = it.url,
                                    phoneUrl = "",
                                    isRejected = false,
                                    isNewImage = false,
                                    attempt = 0,
                                    url = ""
                                )
                            )
                        }
                        fseProspectResponseModel!!.installationPictures = createdList
                    }

                    if (fseProspectResponseModel!!.isInstallationChanged!!) {
                        fseProspectResponseModel!!.installationPictures!!.forEach { ins ->
                            ins.phoneUrl = ins.url
                            if (ins.isRejected!!) {
//                                    ins.isNewImage = true
                                if (ins.isReattemptClick) {
                                    ins.isNewImage = false
                                } else {
                                    ins.isNewImage = true
                                }
                            }
                            //for sample adding image
                            fseProspectResponseModel!!.sampleImages!!.forEach { si ->
                                if (ins.name!!.equals(si.name, true)) {
                                    ins.sampleimage = si.url
                                }
                            }
                        }
                    }

                    loadImageForOffline(fseProspectResponseModel!!.installationPictures!!)
                    setAdapter(fseProspectResponseModel!!.installationPictures!!.toMutableList())


                })
        }
    }

    //region Picture
    @SuppressLint("NewApi")
    fun takePicture(position: Int, isOnlyImage: Boolean, url: String) {

        if (url.isNullOrBlank()) {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            val fileaa: File = createFile()
            outputImgUri = fileaa.absolutePath

/*commented to test solve bug*/
//                        val adapterItem = adapterList.get(position)
//                        adapterItem.phoneUrl = outputImgUri
//                        if (adapterItem.isRejected) {
//                            adapterItem.url = outputImgUri
//                            adapterItem.isNewImage = false
//                            adapterItem.isReattemptClick = true
//                        }
//                        fseProspectResponseModel!!.installationPictures = adapterList
/**/

            val Prouri: Uri = FileProvider.getUriForFile(
                this,
                "com.greenlightplanet.kazi.update.FileImageProvider", fileaa
            )
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Prouri)
            startActivityForResult(cameraIntent, REQUEST_CAMERA)
        } else {
            circularProgressDrawable?.strokeWidth = 5f
            circularProgressDrawable?.centerRadius = 30f
            circularProgressDrawable?.start()

            Log.e("kokokoko", "${url}")
            Util.CustomInstallationDialog(context = this,
                url = url,
                onDialogShow = { Dialog, image, gotItBtn ->
                    Glide.with(this)
                        .load(url)
                        .diskCacheStrategy(DiskCacheStrategy.DATA)
                        .apply(
                            RequestOptions()
                                .placeholder(circularProgressDrawable)
                                .error(R.mipmap.ic_launcher_round)
                        )
                        .into(image)

                },
                onCancel = {
                    bag.clear()
                    dialog?.dismiss()
                },
                imgGotSample = {
                    bag.clear()
                    val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    val fileaa: File = createFile()
                    outputImgUri = fileaa.absolutePath
                    /*commented to test solve bug*/
//                        val adapterItem = adapterList.get(position)
//                        adapterItem.phoneUrl = outputImgUri
//                        if (adapterItem.isRejected) {
//                            adapterItem.url = outputImgUri
//                            adapterItem.isNewImage = false
//                            adapterItem.isReattemptClick = true
//                        }
//                        fseProspectResponseModel!!.installationPictures = adapterList
                    /**/
                    val Prouri: Uri = FileProvider.getUriForFile(
                        this,
                        "com.greenlightplanet.kazi.update.FileImageProvider", fileaa
                    )
                    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Prouri)
                    startActivityForResult(cameraIntent, REQUEST_CAMERA)
                    it.dismiss()
                })
        }

    }

    @Throws(IOException::class)
    fun createFile(): File {
        // Create an image file name
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "Kazi_${System.currentTimeMillis()}", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        ).apply {
            // Save a file: path for use with ACTION_VIEW intents
            outputImgUri = absolutePath
        }

    }

    //endregion

    override fun onClickPhoto(
        position: Int,
        installPics: LiteFseProspectResponseModel.InstallationPictures,
        value: LiteFseProspectResponseModel
    ) {
        installPic = installPics
        imagePos = position
        if (checkPermission()) {
            if (currentLocation == null) {
                isOnlyImage = false
            } else {
                try {
                    isOnlyImage =
                        currentLocation?.accuracy ?: Float.MAX_VALUE <= preference?.getFseAccuracy()
                            ?.toFloat() ?: 200F
                } catch (e: Exception) {
                    Log.e(TAG, "onClickPhoto: $e")
                }
            }

            if (!isOnlyImage) {
                if (!Util.enableGPSIfPossible(this)) {
//                    takePicture(0, false, installPics.sampleimage!!)
                    callCheckInMapAct()
                }
            } else {
                takePicture(position, isOnlyImage, installPics.sampleimage ?: "")
            }
//            }
        } else {
//			requestPermission()
            requestAllPermission(
                this,
                arrayListOf(
                    Manifest.permission.CAMERA,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
            )
        }

    }

    override fun onImageClick(
        position: Int,
        installPics: LiteFseProspectResponseModel.InstallationPictures,
        value: LiteFseProspectResponseModel
    ) {
        val data = value.installationPictures!!.get(position)
//        if (data.url.isNullOrEmpty()) {
//            ImageUploadUtil.ImageEnlargeDialog(this, value.installationPictures!!.get(position).phoneUrl!!)
//        } else {
//            ImageUploadUtil.ImageEnlargeDialog(this, value.installationPictures!!.get(position).url!!)
//        }
        if (data.phoneUrl.isNullOrEmpty()) {
            ImageUploadUtil.ImageEnlargeDialog(
                this,
                value.installationPictures!!.get(position).url!!
            )
        } else {
            ImageUploadUtil.ImageEnlargeDialog(
                this,
                value.installationPictures!!.get(position).phoneUrl!!
            )
        }
    }

    private fun loadImageForOffline(installPics: List<LiteFseProspectResponseModel.InstallationPictures>) {
        if (Util.isOnline(this)) {
            for (ins in installPics) {
                if (!ins.url.isNullOrBlank()) {
                    Glide.with(this)
                        .load(ins.sampleimage)
                        .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC).preload()
//                            .apply(RequestOptions()
//                                    .centerCrop()).preload()
                }
            }
        }
    }

    fun setAdapter(list: MutableList<LiteFseProspectResponseModel.InstallationPictures>) {
        adapterList.clear()
        adapterList.addAll(list)

        if (adapter == null) {
            adapter = MultiImageClickAdapter(this, adapterList, fseProspectResponseModel)
            adapter!!.multiImageClickAdapterCallback = this
            binding.recyclerView.adapter = adapter
        }
        adapter!!.notifyDataSetChanged()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQUEST_CAMERA) {
            if (resultCode == Activity.RESULT_OK) {
                val adapterItem = adapterList.get(imagePos)
                adapterItem.phoneUrl = outputImgUri
                if (adapterItem.isRejected) {
                    adapterItem.url = outputImgUri
                    adapterItem.isNewImage = false
                    adapterItem.isReattemptClick = true
                }
                fseProspectResponseModel!!.installationPictures = adapterList
                onImageCaptured()

            }
        }
        if (requestCode == 1109) {
            if (resultCode == Activity.RESULT_OK) {
                val location = data?.getParcelableExtra<Location>("location_result")

                if (location != null) {
                    currentLocation = location
                    if (currentLocation == null || preference?.getFseAccuracy().isNullOrEmpty()) {
                        Log.e(
                            TAG,
                            "AccuracyDialog-1 = currentLocation:$currentLocation|preference?.getFseAccuracy():${preference?.getFseAccuracy()}"
                        )
                        showLowAccuracyDialogInstallation()
                    } else {
                        if (currentLocation!!.accuracy > preference?.getFseAccuracy()
                                ?.toFloat() ?: 200F
                        ) {
                            Log.e(
                                TAG,
                                "AccuracyDialog-2 = currentLocation:$currentLocation|preference?.getFseAccuracy():${preference?.getFseAccuracy()}"
                            )
                            showLowAccuracyDialogInstallation()
                        } else {
                            Log.e(
                                TAG,
                                "AccuracyDialog-3 = currentLocation:$currentLocation|preference?.getFseAccuracy():${preference?.getFseAccuracy()}"
                            )
                            takePicture(imagePos, false, installPic!!.sampleimage ?: "")
                        }
                    }

                } else {

                    Util.customFseCompletionDialog(
                        context = this,
                        hideTitle = true,
                        message = "Accuracy not detected\nPlease Check-In again",
                        okSelected = {
                            it.dismiss()
                            //upload image
                        },
                        title = null
                    )

                }

            }
            if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
            }
        }

        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item?.itemId) {
            android.R.id.home -> {

                onBackPressed()

                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    //region Location

    private fun fetchAccuracy() {
        getCurrentLoc().observe(this, Observer {
            it?.let {
                currentLocation = it
                Log.d(TAG, "ACCURRACY :${currentLocation?.accuracy} ");
                Log.e("|| == ", "${it.latitude},${it.longitude}")
            }
        })
    }


    fun getCurrentLoc(): MutableLiveData<Location> {

        val data = MutableLiveData<Location>()

        bag.add(
            newGetCurrentLocation(this)!!.subscribe({
                data.postValue(it)
            }, {
                data.postValue(null)
            })
        )
        return data
    }

    @SuppressLint("MissingPermission")
    fun newGetCurrentLocation(context: Context): Observable<Location>? {
        val request = LocationRequest.create() //standard GMS LocationRequest
            .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            .setNumUpdates(50).setInterval(20)

        val locationProvider = ReactiveLocationProvider(context)
        return locationProvider.getUpdatedLocation(request)

    }

    //endregion

    override fun onDestroy() {
        super.onDestroy()
        amazonS3Helper?.amazonS3HelperCallback = null
        amazonS3Helper = null
        bag.clear()
        mHomeWatcher?.stopWatch()

    }

    override fun onAllUploadCompleted(fileModelsList: List<LiteAwsImageModel>) {
        cancelProgressDialog()
        //send Data to server
        fileModelsList.forEach { it.tried = false }
        Log.e(TAG, "onAllUploadCompleted:fileModelsList2 = $fileModelsList ")
        val isOnline = Util.isOnline(this)
        fseProspectResponseModel!!.installationPictures!!.map { data ->
            fileModelsList.find { it.imageName == data.name }?.let {
                data.url = it.awsLink
            }
        }
        viewModel.insertAwsImageModelToDatabase(fileModelsList, true).observe(this, Observer {

            Log.e(
                TAG,
                "fseProspectResponseModel!!.installationAttempted:${fseProspectResponseModel!!.installationAttempted} "
            )
            viewModel.performInstallation2(
                context = this,
                isOnline = isOnline,
                fseProspectResponseModel = fseProspectResponseModel,
                prospectId = fseProspectResponseModel!!.prospectId,
                fileModel = fileModelsList,
                //location = currentLocation!!,
                showProgress = {
                    if (!isProgressShowing()) {
                        showProgressDialog(this)
                    }
                }
            ).observe(this, Observer {
//                alphaMethodInstallation(fseProspectResponseModel!!)
                cancelProgressDialog()
                Log.d(TAG, ":step2$it")

                finishThisAct()
            })

        })

    }

    private fun awsImageUploadHandler(fileModels: List<LiteAwsImageModel>, isForService: Boolean) {
        Log.d(TAG, "awsImageUploadHandler: fileModels : $fileModels")

        Log.d(
            TAG,
            "awsImageUploadHandler: preference?.getAwsAccess().isNullOrEmpty() : ${
                preference?.getAwsAccess().isNullOrEmpty()
            }"
        )
        Log.d(
            TAG,
            "awsImageUploadHandler: preference?.getAwsSecret().isNullOrEmpty() : ${
                preference?.getAwsSecret().isNullOrEmpty()
            }"
        )

        if (preference?.getAwsAccess().isNullOrEmpty() || preference?.getAwsSecret()
                .isNullOrEmpty()
        ) {
            viewModel.awsRX(this, BaseRequestModel().apply {
                this.angazaId = loginResponseData?.angazaId
                this.country = loginResponseData?.country
            }).observe(this, Observer {

                Log.d(TAG, "awsImageUploadHandler: it: $it")

                if (it == null || it.Success == false || it.ResponseData?.accessKey.isNullOrEmpty() || it.ResponseData?.secretKey.isNullOrEmpty()) {
                    Log.d(TAG, "awsImageUploadHandler: it2: $it")
                    Util.customFseCompletionDialog(
                        context = this,
                        hideTitle = true,
                        title = null,
                        message = "Unable to upload images please try again later",
                        okSelected = {
                            it.dismiss()
                        }
                    )
                } else {
                    Log.d(TAG, "awsImageUploadHandler: it3: $it")
                    preference?.setAwsAccess(it.ResponseData?.accessKey!!)
                    preference?.setAwsSecret(it.ResponseData?.secretKey!!)
                    amazonS3Helper?.startUploadProcess(fileModels, isForService)
                }
            })
        } else {
            Log.d(TAG, "awsImageUploadHandler: it4: fileModels : $fileModels")
            Log.d(TAG, "awsImageUploadHandler: it4: amazonS3Helper : $amazonS3Helper")
            amazonS3Helper?.startUploadProcess(fileModels, isForService)
        }
    }

    //region Location Accuracy Check
    private fun onImageCaptured() {

        outputImgUri?.let {
            Log.d(TAG, "outputImgUri-test:$outputImgUri");

            //if (true) {
            if (currentLocation == null || preference?.getFseAccuracy().isNullOrEmpty()) {
                Log.e(
                    TAG,
                    "onImageCaptured-1 = currentLocation:$currentLocation|preference?.getFseAccuracy():${preference?.getFseAccuracy()}"
                )
                showLowAccuracyDialogInstallation()
            } else {
                if (currentLocation!!.accuracy > preference?.getFseAccuracy()?.toFloat() ?: 200F) {
                    Log.e(
                        TAG,
                        "onImageCaptured-2 = currentLocation:$currentLocation|preference?.getFseAccuracy():${preference?.getFseAccuracy()}"
                    )
                    showLowAccuracyDialogInstallation()
                } else {
                    Log.e(
                        TAG,
                        "onImageCaptured-3 = currentLocation:$currentLocation|preference?.getFseAccuracy():${preference?.getFseAccuracy()}"
                    )
//                    showRationaleDialog(outputImgUri!!, fseProspectResponseModel!!)
                    val pfg: LiteFseProspectResponseModel.ProspectLocation =
                        LiteFseProspectResponseModel.ProspectLocation(
                            currentLocation!!.latitude,
                            currentLocation!!.longitude,
                            currentLocation!!.accuracy
                        )
                    fseProspectResponseModel!!.prospectLocation = pfg
                    viewModel.updateFseProspect(fseProspectResponseModel!!).observe(this, Observer {
                        Log.e(TAG, "-----:::: Updated  == $fseProspectResponseModel")
                        currentLocation!!.latitude = it!!.prospectLocation!!.latitude!!
                        currentLocation!!.longitude = it.prospectLocation!!.longitude!!
                        currentLocation!!.accuracy = it.prospectLocation!!.accuracy!!
                    })
                    adapter!!.notifyDataSetChanged()
                }
            }
        }
    }

    private fun showLowAccuracyDialogInstallation() {
        Log.d(TAG, "ACCURRACY - showLowAccuracyDialog :${currentLocation?.accuracy} ");
        //show accuracy here inside dialog
        fetchAccuracy()

        val title = "Your Image accuracy is Low"
        val spannable = SpannableString(title)
        spannable.setSpan(
            StyleSpan(Typeface.BOLD),
            0, title.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        Util.customFseCompletionDialog(
            context = this,
            hideTitle = false,
            message = "Please click the image again for better results.",
            titleSpanned = spannable,
            okSelected = {
                it.dismiss()
                //upload image
                bag.clear()
            },
            title = null
        )
    }

    private fun showRationaleDialog(fseProspectResponseModel: LiteFseProspectResponseModel) {

//        . You Image accuracy is high.
        val title = "Images Captured Successfully"
        val spannable = SpannableString(title)
        spannable.setSpan(
            StyleSpan(Typeface.BOLD),
            0, title.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        Util.customFseRationaleDialog(
            context = this,
            titleSpanned = spannable,
            //title = "Image Captured Successfully. You Image accuracy is high.",
            message = "Are you sure you want to complete installation for this customer?",
            setCanceledOnTouchOutside = false,
            positveSelected = {
                it.dismiss()
                //upload image
                Log.d(TAG, "showRationaleDialog: ${fseProspectResponseModel.isInstallationChanged}")
                if (fseProspectResponseModel.isInstallationChanged!!) {
                    var fseRejected =
                        fseProspectResponseModel.installationPictures!!.filter { it.isRejected == true }
                    if (fseRejected.isNullOrEmpty()) {
                        fseRejected = fseProspectResponseModel.installationPictures!!
                    }
                    Log.d(TAG, "showRationaleDialog:fseRejected => $fseRejected ")
                    processImageCompression(this, fseRejected, fseProspectResponseModel.prospectId)
                } else {
                    processImageCompression(
                        this,
                        fseProspectResponseModel.installationPictures!!,
                        fseProspectResponseModel.prospectId
                    )
                }

            },
            negativeSeleted = {
                it.dismiss()
                Log.d(
                    TAG,
                    "Accuracy: ${if (currentLocation != null) currentLocation!!.accuracy.toString() else "NA"} "
                );
//				grp_step1.visibility = View.GONE
//              imageView.visibility = View.GONE
            },
            title = null
        )
    }

    //endregion

    private fun processImageCompression(
        context: Context,
        imagesPath: List<LiteFseProspectResponseModel.InstallationPictures>,
        prospectId: String
    ) {
        val imageModels = mutableListOf<ImageUploadUtil.ImageModel>()

        for (i in imagesPath) {
            val file = File(i.phoneUrl!!)
            imageModels.add(
                ImageUploadUtil.ImageModel(
                    file = file,
                    prospectId = prospectId,
                    imageName = i.name!!
                )
            )
        }

        viewModel.compressImageForAws(context = context, files = imageModels, showProgress = {
            showProgressDialog(context)
        }).observe(this, Observer { awsImageModels ->
            val isOnline = Util.isOnline(context)
            if (awsImageModels != null) {
                var installAttempted = 0
                installAttempted = fseProspectResponseModel!!.installationAttempted + 1
//                val awsImageModel = awsImageModels.first()
                val awsImageModel = awsImageModels
                awsImageModel.forEach {
                    it.installationAttempted = installAttempted
                }

                Log.e(TAG, "awsImageModel === : $awsImageModel")
                fseProspectResponseModel!!.installationAttempted = installAttempted
//                currentLocation!!.latitude = fseProspectResponseModel!!.prospectLocation!!.latitude!!
//                currentLocation!!.longitude = fseProspectResponseModel!!.prospectLocation!!.longitude!!
//                currentLocation!!.accuracy = fseProspectResponseModel!!.prospectLocation!!.accuracy!!
                viewModel.performInstallation(
                    context = context,
                    isOnline = false,
                    fseProspectResponseModel = fseProspectResponseModel,
                    prospectId = fseProspectResponseModel!!.prospectId,
                    fileModel = awsImageModel,
                    angazaId = loginResponseData?.angazaId!!,
                    accountNumber = fseProspectResponseModel!!.accountNumber,
                    installationAttempted = installAttempted,
                    imageName = ""//mazhar
                ).observe(this, Observer {
                    Log.d(TAG, "instaT1:$it ")
                    it?.let {
                        if (!isOnline) {
                            Log.d(TAG, "instaT2:$it ")
                            cancelProgressDialog()
                            finishThisAct()
                        } else {
                            Log.d(TAG, "instaT3:$it awsImageModels:  $awsImageModels")
                            awsImageUploadHandler(awsImageModels, false)
                        }
                    } ?: kotlin.run {
                        Log.d(TAG, "instaT4:$it ")
                        cancelProgressDialog()
                        finishThisAct()
                    }
                    Log.d(TAG, "Offline:$it ");
                })
            } else {
                Log.d(TAG, "instaT5: ")
                cancelProgressDialog()
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (currentLocation != null) {
            outState.putDouble("lat", currentLocation!!.latitude)
            outState.putDouble("long", currentLocation!!.longitude)
            outState.putFloat("acc", currentLocation!!.accuracy)
        }
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        currentLocation?.latitude = savedInstanceState.getDouble("lat")
        currentLocation?.longitude = savedInstanceState.getDouble("long")
        currentLocation?.accuracy = savedInstanceState.getFloat("acc")
    }

    private fun finishThisAct() {
//        viewModel.updateFseProspect(fseProspectResponseModel!!).observe(this, Observer {
//            Log.e(TAG, "-----:::: Updated  == $it")
        val intent = Intent()
        intent.putExtra("fseProspectResponseModel", fseProspectResponseModel)
        setResult(Constants.CLICK_REQUEST_CODE, intent)
        finish()
//        })

    }

    override fun onBackPressed() {
        Util.customFseRationaleDialog(this, "",
            hideNegative = false,
            titleSpanned = null,
            hideTitle = true,
            message = "Your installation is in progress. Are you sure to exit?",
            positveSelected = {
                it.dismiss()
                super.onBackPressed()
            },
            negativeSeleted = {
                it.dismiss()
            }
        )


    }

    //region Permission
    private fun checkPermission(): Boolean {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//            return (ContextCompat.checkSelfPermission(
//                this,
//                Manifest.permission.CAMERA
//            ) == PackageManager.PERMISSION_GRANTED
//                    && ContextCompat.checkSelfPermission(
//                this,
//                Manifest.permission.ACCESS_FINE_LOCATION
//            ) == PackageManager.PERMISSION_GRANTED)
//        } else {
            return (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED)
//        }

    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.CAMERA,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.ACCESS_FINE_LOCATION
            ),
            PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//                    if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
//                        && grantResults[1] == PackageManager.PERMISSION_GRANTED
//                    ) {
//                        if (!Util.enableGPSIfPossible(this)) {
//                            callCheckInMapAct()
//                        }
//                    }
//                } else {
                    if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                        && grantResults[1] == PackageManager.PERMISSION_GRANTED
                        && grantResults[2] == PackageManager.PERMISSION_GRANTED
                    ) {
                        if (!Util.enableGPSIfPossible(this)) {
                            callCheckInMapAct()
                        }
                    }
//                }
            }
        }
    }

    fun requestAllPermission(activity: Context, permissions: Collection<String>) {
        Dexter.withActivity(activity as Activity?)
            .withPermissions(
                permissions
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<com.karumi.dexter.listener.PermissionRequest>?,
                    token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                }

                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                    // check if all permissions are granted
                    if (report.areAllPermissionsGranted()) {
                        callCheckInMapAct()
                    }
                    // check for permanent denial of any permission
                    if (report.isAnyPermissionPermanentlyDenied) {
                        // show alert dialog navigating to Settings
                        Util.showSettingsDialog(activity)
                    }
                }

            }).withErrorListener(object : PermissionRequestErrorListener {
                override fun onError(error: DexterError) {
                    Toast.makeText(activity, "Error occurred! ", Toast.LENGTH_SHORT).show()
                }
            })
            .onSameThread()
            .check()


    }


    //endregion

    fun callCheckInMapAct() {
        val intent = Intent(this, LiteCheckInMapActivity::class.java)
        intent.putExtra("isLite", true)
        startActivityForResult(intent, 1109)
    }

    private fun updateSharedPref(fromInternet: Boolean) {
        var data: LastSaved? = OfferUtils.loadSummaryFromPref(this)
        if (data == null) {
            data = LastSaved()

            data.clickImageLiteFSE =
                "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveSummaryToPref(this, data)
            binding.tvLastSaved.text = data.clickImageLiteFSE
//            tv_LastSaved.text = "Last Synced: ${preference?.getFseProspectLastSynced()}"

        } else {

            if (fromInternet) {
                data.clickImageLiteFSE =
                    "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveSummaryToPref(this, data)
            }
            binding.tvLastSaved.text = data.clickImageLiteFSE
        }

    }

}