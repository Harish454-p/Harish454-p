package com.greenlightplanet.kazi.agentReferral.model.referralStatus


import android.os.Parcelable
import androidx.room.ColumnInfo
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ReferralStatusModel(

    @ColumnInfo(name = "referrals")
    @SerializedName("referrals")
    var referrals: List<Referral>?

) : Parcelable {

    //region referral status typeconverters...
//    class ReferralStatusTypeConverter {
//        @TypeConverter
//        fun referralsToStr(value : List<Referral>) : String {
//            return Gson().toJson(value)
//        }
//
//        @TypeConverter
//        fun strToReferrals(value : String?) : List<Referral> {
//            return when(value) {
//                null,"" -> ArrayList<Referral>()
//                else -> Gson().fromJson<List<Referral>>(value, object : TypeToken<List<Referral>>() {}.type)
//            }
//        }
//    }
    //endregion
}