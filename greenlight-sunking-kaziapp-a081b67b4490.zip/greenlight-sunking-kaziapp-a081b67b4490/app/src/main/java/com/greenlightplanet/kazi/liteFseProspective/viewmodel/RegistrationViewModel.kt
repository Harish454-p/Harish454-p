package com.greenlightplanet.kazi.liteFseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.location.Location
import com.greenlightplanet.kazi.liteFseProspective.model.CombineRequestModel
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import com.greenlightplanet.kazi.liteFseProspective.model.LiteRegistrationCheckinRequestModel
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteRegistrationRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable

class RegistrationViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "RegistrationViewModel"

    }

    val repo = LiteRegistrationRepo.getInstance(application)


    fun processCheckIn(context: Context, isOnline: Boolean, prospectID: String, angazaId: String, area: String,  prospectAllowedDistance: Int,showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

        showProgress()

        return repo.performCheckin(context, isOnline, prospectID, angazaId, area,prospectAllowedDistance)

    }


    fun processCheckIn2(context: Context, isOnline: Boolean, prospectID: String, angazaId: String, area: String, location: Location, prospectAllowedDistance: Int, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

        showProgress()

        return repo.performCheckin2(context, isOnline, prospectID, angazaId, area, location,prospectAllowedDistance)


    }

    fun getCombineRequestModel(prospectID: String): MutableLiveData<CombineRequestModel?> {
        return repo.getCombineRequestModel(prospectID)
    }

    fun sendRegistrationCheckinRequestToServerForceUpload(registrationCheckinRequestModel: LiteRegistrationCheckinRequestModel, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return repo.sendRegistrationCheckinRequestToServerForceUpload(registrationCheckinRequestModel)
    }

    fun getFseProspectiveFromServer(angazaId: String, prospectId: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>? {
        showProgress()
        return repo.getFseProspectiveFromServer(angazaId, prospectId)
    }

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }

}
