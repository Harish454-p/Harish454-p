package com.greenlightplanet.kazi.loyalty.converter.leaderboard

import android.accounts.Account
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.incentivenew.model.incentive.Accounts
import com.greenlightplanet.kazi.incentivenew.model.summary.CheckListFields
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryFields
import com.greenlightplanet.kazi.loyalty.model.leaderboard.User_rank
import com.greenlightplanet.kazi.pricegroup.model.Pricing_group

class UserRankConverter {

    @TypeConverter
    fun fromAUser_rank(list: List<User_rank>?): String? {
        if (list == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<User_rank>>() {

        }.type
        return gson.toJson(list, type)
    }

    @TypeConverter
    fun toUser_rank(string: String?): List<User_rank>? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<User_rank>>() {

        }.type
        return gson.fromJson(string, type)
    }

}


