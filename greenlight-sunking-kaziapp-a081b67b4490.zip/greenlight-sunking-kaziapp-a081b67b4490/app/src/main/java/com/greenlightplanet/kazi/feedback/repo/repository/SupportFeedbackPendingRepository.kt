package com.greenlightplanet.kazi.feedback.repo.repository

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackConstants
import com.greenlightplanet.kazi.feedback.repo.paging.SupportDataPagingSource
import com.greenlightplanet.kazi.feedback.repo.model.response.TicketResponseData
import com.greenlightplanet.kazi.networking.NetworkService
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class SupportFeedbackPendingRepository @Inject constructor(
    val db: AppDatabase,
    val networkService: NetworkService,
    val preference: GreenLightPreference,
    val pagingSource: SupportDataPagingSource
) {

    fun getTicketsData(pagingConfig: PagingConfig = getDefaultPageConfig()): Flow<PagingData<TicketResponseData>> {
        pagingSource.status = "Pending"
        return Pager(
            config = pagingConfig,
            pagingSourceFactory = { pagingSource }
        ).flow
    }

    fun getDefaultPageConfig(): PagingConfig {
        return PagingConfig(
            pageSize = FeedbackConstants.DEFAULT_PAGE_SIZE,
            enablePlaceholders = false
        )
    }

}
