package com.greenlightplanet.kazi.dashboard.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Html
import android.view.WindowManager
import com.bumptech.glide.Glide
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.activity.DashBoardActivity
import com.greenlightplanet.kazi.dashboard.model.response.ProfileDetailModel
import com.greenlightplanet.kazi.databinding.ActivityEoidBinding
import com.greenlightplanet.kazi.networking.APICallback
import com.greenlightplanet.kazi.networking.APIInterface
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.*
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener


class EOIDActivity : BaseActivity(), APIInterface<CommonResponseModel<ProfileDetailModel>> {


    var activity: Activity? = null
    var preference: GreenLightPreference? = null

    var mHomeWatcher: HomeWatcher? = null

    private lateinit var binding: ActivityEoidBinding
    override fun onResponse(response: CommonResponseModel<ProfileDetailModel>) {
        if (response.Success == true) {
            if (response.ResponseData != null) {

                var profileDetail = response.ResponseData
                if (profileDetail?.id == null && profileDetail?.firstName == null && profileDetail?.lastName == null && profileDetail?.area == null && profileDetail?.photoUrl == null && profileDetail?.phoneNumber == null) {
                    setOfflineData()

                } else {
                    AppDatabase.getAppDatabase(activity).userDao().insertEOID(profileDetail)
                    setProfileDetail(response.ResponseData!!)

                }

            }

        }
    }


    override fun onError() {
        var profileDetail = AppDatabase.getAppDatabase(this).userDao().getEOID()
        if (profileDetail != null) {
            setProfileDetail(profileDetail)
        } else {
            setPreferenceData()
            //  onBackPressed()
        }

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        // setContentView(R.layout.activity_eoid)

        binding = ActivityEoidBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initialize()
        //setPreferenceData()
        APICall()

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }

    // Initialized Widgets
    private fun initialize() {

        activity = this
        preference = GreenLightPreference.getInstance(this)

    }

    fun setOfflineData() {
        var profileDetail = AppDatabase.getAppDatabase(this).userDao().getEOID()

        if (profileDetail != null) {
            setProfileDetail(profileDetail)
        } else {
            setPreferenceData()
        }
    }

    // API Call for getting profile Details
    private fun APICall() {
        var profileDetailModel = AppDatabase.getAppDatabase(this).userDao().getEOID()

        if (Util.isOnline(context = this)) {

            if (Util.isConnectedFast(applicationContext) || profileDetailModel == null) {

                ServiceInstance.getInstance(this).service?.getProfile(preference?.getLoginResponseModel()?.angazaId!!)
                    ?.enqueue(object : APICallback<CommonResponseModel<ProfileDetailModel>>(
                        this as APIInterface<CommonResponseModel<ProfileDetailModel>>,
                        activity = this
                    ) {})

            } else {
                ServiceInstance.getInstance(this).service?.getProfile(preference?.getLoginResponseModel()?.angazaId!!)
                    ?.enqueue(object :
                        APIWOProgressCallback<CommonResponseModel<ProfileDetailModel>>(this as APIInterface<CommonResponseModel<ProfileDetailModel>>) {})
                onError()
            }
        } else {
            profileDetailModel = AppDatabase.getAppDatabase(activity).userDao().getEOID()
            if (profileDetailModel != null) {
                setProfileDetail(profileDetailModel)
            } else {
                setPreferenceData()
            }

        }
    }


    // To set ProfileDetails
    private fun setProfileDetail(profileDetail: ProfileDetailModel) {
        var profileDetailModel: ProfileDetailModel? = profileDetail

        if (profileDetail.firstName != null) {
            binding.tvFirstName?.text = profileDetailModel?.firstName
        }

        if (profileDetail.lastName != null) {
            binding.tvLastName?.text = profileDetailModel?.lastName
        }

        if (profileDetail.id != null) {
            if (profileDetail.id!!.equals("0", true)) {
                binding.tvID?.text = Html.fromHtml("<b>${getString(R.string.id_no_key)} </b> NA")

            } else {
                binding.tvID?.text = Html.fromHtml("<b>${getString(R.string.id_no_key)} </b> " + profileDetailModel?.id)

            }
        } else if (profileDetail.id == null) {
            binding.tvID?.text = Html.fromHtml("<b>${getString(R.string.id_no_key)} </b> NA")

        }


        if (profileDetailModel?.area != null) {
            binding.tvArea?.text = Html.fromHtml("<b>${getString(R.string.area_hq_key)}</b> " + profileDetailModel.area)
        } else {
            binding.tvArea?.text = Html.fromHtml("<b>${getString(R.string.area_hq_key)}</b> NA")
        }



        if (profileDetailModel?.phoneNumber != null) {
            binding.tvPhoneNo?.text =
                Html.fromHtml("<b>${getString(R.string.phone_no_key)}</b> " + profileDetailModel.phoneNumber)
        } else {
            binding.tvPhoneNo?.text = Html.fromHtml("<b>${getString(R.string.phone_no_key)}</b> NA")

        }

        if (profileDetailModel?.cluster != null) {
            binding.tvCluster?.text =
                Html.fromHtml("<b>${getString(R.string.cluster_key)}</b> " + profileDetailModel.cluster)
        } else {
            binding.tvCluster?.text = Html.fromHtml("<b>${getString(R.string.cluster_key)}</b> NA")

        }

        if (profileDetailModel?.photoUrl != null) {

            activity?.let {
                Glide.with(it).load(profileDetailModel.photoUrl).into(binding.ivProfile!!)
            }
        }


    }

    fun setPreferenceData() {


        binding.tvFirstName?.text = "" + preference?.getLoginResponseModel()?.firstName
        binding.tvLastName?.text = "" + preference?.getLoginResponseModel()?.lastName

        binding.tvPhoneNo?.text =
            Html.fromHtml("<b>${getString(R.string.phone_no_key)}</b> " + preference?.getLoginResponseModel()?.phoneNumber)

        binding.tvID?.text = Html.fromHtml("<b>${getString(R.string.id_no_key)}</b> NA")
        binding.tvArea?.text = Html.fromHtml("<b>${getString(R.string.area_hq_key)}</b> NA")

    }

    override fun onBackPressed() {

        val intent = Intent(this, DashBoardActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(intent)

    }

    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();

    }
}
