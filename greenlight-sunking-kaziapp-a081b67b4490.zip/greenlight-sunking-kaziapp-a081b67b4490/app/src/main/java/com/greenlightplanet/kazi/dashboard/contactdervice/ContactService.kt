package com.greenlightplanet.kazi.dashboard.contactdervice

/*
import android.Manifest
import android.app.Activity
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Telephony
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.greenlightplanet.kazi.dashboard.model.call_sms.CallLogRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.ContactRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.SmsRequest
import com.greenlightplanet.kazi.dashboard.repo.DashBoardRepo
import com.greenlightplanet.kazi.utils.SMS
import com.greenlightplanet.kazi.utils.Util
import com.wickerlabs.logmanager.LogsManager
import jagerfield.mobilecontactslibrary.ImportContactsAsync
import java.util.*



*/
/*
  Created by Rahul on 03/03/21.
*//*




class ContactService(var mContext: Context? = null) : LifecycleService(){

    private val TAG = "ServiceExample"
companion object{
    val timerInMillis = MutableLiveData<Context>()

}
    //contact region

    val MY_PERMISSIONS_REQUEST_READ_SMS = 913
    val MY_PERMISSIONS_REQUEST_READ_CONTACTS = 312
    val ALL_SMS_LOADER = 261
    private var mCurFilter: String? = null
    val SMS_SELECTION_SEARCH = "address LIKE ? OR body LIKE ?"
    val ALL_SMS_URI = Uri.parse("content://sms/inbox")
    val SORT_DESC = "date DESC"
    var data: ArrayList<SMS>? = null

    var smsRequests = mutableListOf<SmsRequest>()
    var callLogRequest = mutableListOf<CallLogRequest>()
    var contactRequest = mutableListOf<ContactRequest>()

    val completionMap = HashMap<String, Boolean>()
    val completion = MutableLiveData<HashMap<String, Boolean>>()

    // contact end region
    val repo = DashBoardRepo.getInstance(this)
    fun ContactService(context: Context?) {
        mContext = context
        callContactLogic()

        Log.d("GPSTracker", "GPSTracker call")
    }


    //region CONATCT & SMS



    fun callContactLogic() {
        contactAndSmsLogic()
        completion.observe(this, Observer {

            if (
            //it.containsKey("SMS") && it.containsKey("CALL_LOG") && it.containsKey("CONTACT")&&
                    it.get("SMS") == true && it.get("CALL_LOG") == true && it.get("CONTACT") == true
            ) {
                Log.d("C_S", "SMS: ${smsRequests}")
                Log.d("C_S", "CALL_LOG: ${callLogRequest}")
                Log.d("C_S", "CONTACT: ${contactRequest}")

                repo.syncResourcesPart1(callLogRequest, smsRequests, contactRequest)
            }
        })
    }


    fun contactAndSmsLogic() {

      mContext?.let {
            Util.requestAllPermission(it, arrayListOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CONTACTS,
                Manifest.permission.READ_CALL_LOG, Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS,
                Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)) {



                callLog(this@ContactService)
                // loadContacts()
            getContactList()
                loadSms()


        //}
       // }

    }

     fun callLog(context: Context) {
        var logsRunnable: Runnable? = null

        val logsManager = LogsManager(context)
        logsRunnable = Runnable { loadLogs() }

        logsRunnable.run()
    }

     fun  loadContacts() {

        ImportContactsAsync(dfd) { contacts ->

//			val contactRequests = mutableListOf<ContactRequest>()
            contacts.forEach { individualContact ->
                Log.d("CONTACT", "individualContact: ${individualContact.displaydName} | ${individualContact.id}")
                if (individualContact.numbers.size > 1) {
                    var count = 1
                    individualContact.numbers.forEach { number ->
                        try {
                            if (!number.normalizedNumber.isNullOrEmpty()) {
                                contactRequest.add(ContactRequest(name = individualContact.displaydName, number = number.normalizedNumber, status = null, localId = "${individualContact.id}_${count}"))
                            }
                        } catch (e: Exception) {
                            Log.d("CONTACT", "loadContacts-1: error")
                        }
                        count++
                    }
                } else {
                    try {
                        if (!individualContact.numbers.first.normalizedNumber.isNullOrEmpty()) {
                            contactRequest.add(ContactRequest(name = individualContact.displaydName, number = individualContact.numbers.first.normalizedNumber, status = null, localId = "${individualContact.id}_${1}"))
                        }
                    } catch (e: Exception) {
                        Log.d("CONTACT", "loadContacts-2: error")
                    }
                }

            }
            Log.d("CONTACT", "contactRequests:$contactRequest ")
            completionMap["CONTACT"] = true
            completion.postValue(completionMap)

        }.execute()
    }




    private fun getContactList() {
        val cr: ContentResolver = contentResolver
        val cur: Cursor = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null)!!
        if (cur?.count ?: 0 > 0) {
            while (cur != null && cur.moveToNext()) {
                val id = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID))
                val name = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME))
                if (cur.getInt(cur.getColumnIndex(
                                ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    val pCur: Cursor = cr.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID.toString() + " = ?", arrayOf(id), null)!!
                    while (pCur.moveToNext()) {
                        val phoneNo = pCur.getString(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NUMBER))
                        Log.i(TAG, "Name: $name")
                        Log.i(TAG, "Phone Number: $phoneNo")

                        contactRequest.add(ContactRequest(name = name, number = phoneNo, status = null, localId = "${id}_${1}"))

                    }
                    pCur.close()
                }
            }
        }
        cur?.close()

        Log.d("CONTACT", "contactRequests:$contactRequest ")
        completionMap["CONTACT"] = true
        completion.postValue(completionMap)
    }

      fun loadSms() {
        val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
        intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
        startActivity(intent)
        checkPermissionsSMS()
    }

    private fun checkPermissionsSMS() {

        getSMS()
       if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.READ_SMS
                )
                != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                    , arrayOf(Manifest.permission.READ_SMS),
                    MY_PERMISSIONS_REQUEST_READ_SMS
            )
        } else {
            if (ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.READ_CONTACTS
                    )
                    != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                        activity, arrayOf(Manifest.permission.READ_CONTACTS),
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS
                )
            } else {
                getSMS()
               // LoaderManager.getInstance(this).initLoader(ALL_SMS_LOADER, null, this)

            }
        }

    }


    private fun loadLogs() {
        val logsManager = LogsManager(this)
        val callLogs = logsManager.getLogs(LogsManager.ALL_CALLS)
        callLogs.forEach { data ->
            try {
                Log.d("CONTACT", "date : ${data.date} | duration : ${data.duration} | contactName : ${data.contactName} | number:${data.number}")
                callLogRequest.add(CallLogRequest(name = data.contactName, contactNumber = data.number, date = data.date.toString(), duration = data.duration.toString()))
            } catch (e: Exception) {
                Log.d("CONTACT", "error : ${e.message}")
            }
        }

        completionMap["CALL_LOG"] = true
        completion.postValue(completionMap)
    }

    override fun onCreateLoader(id: Int, args: Bundle?): Loader<Cursor?> {
        var selection: String? = null
        var selectionArgs: Array<String>? = null
        if (mCurFilter != null) {
            selection = SMS_SELECTION_SEARCH
            selectionArgs = arrayOf("%$mCurFilter%", "%$mCurFilter%")
        }
        return CursorLoader(
                this,
                ALL_SMS_URI,
                null,
                selection,
                selectionArgs,
                SORT_DESC
        )
    }


    override fun onLoadFinished(loader: Loader<Cursor?>, cursor: Cursor?) {
        try {
            if (cursor != null && cursor.count > 0) {
                getAllSmsToFile(cursor)
            }
        } catch (e: Exception) {
            Log.e(DashBoardActivity.TAG, "onLoadFinished: $e")
        }
    }


    private fun getAllSmsToFile(c: Cursor) {
        val lstSms: ArrayList<SMS>? = arrayListOf()
        lateinit var objSMS: SMS
        val totalSMS = c.count
        if (c.moveToFirst()) {
            for (i in 0 until totalSMS) {
                try {
                    objSMS = SMS()
                    objSMS.id = c.getLong(c.getColumnIndexOrThrow("_id"))
                    val num = c.getString(c.getColumnIndexOrThrow("address"))
                    objSMS.address = num
                    objSMS.msg = c.getString(c.getColumnIndexOrThrow("body"))
                    objSMS.readState = c.getString(c.getColumnIndex("read"))
                    objSMS.time = c.getLong(c.getColumnIndexOrThrow("date"))
                    if (c.getString(c.getColumnIndexOrThrow("type")).contains("1")) {
                        objSMS.folderName = "inbox"
                    } else {
                        objSMS.folderName = "sent"
                    }
                } catch (e: Exception) {
                } finally {
                    lstSms?.add(objSMS)
                    c.moveToNext()
                }
            }
        }
        c.close()
        data = lstSms

        sortAndSetToRecycler(lstSms)
    }

    private fun sortAndSetToRecycler(lstSms: List<SMS>?) {
        val s: Set<SMS> = LinkedHashSet(lstSms)
        data = ArrayList(s)

        Log.d("CONTACT", "sortAndSetToRecycler: $data")
        data?.forEach { sms ->
            Log.d("CONTACT", "sms-address: ${sms.address}")
            Log.d("CONTACT", "sms-msg: ${sms.msg}")
            smsRequests.add(SmsRequest(id = sms.id, msg = sms.msg, number = sms.address, time = sms.time.toString()))
        }

        completionMap["SMS"] = true
        completion.postValue(completionMap)
//		convertToJson(lstSms)
    }


    fun getSMS(): List<String?>? {
        val sms: MutableList<String> = ArrayList()
        val uriSMSURI = Uri.parse("content://sms/inbox")
        val cur = contentResolver.query(uriSMSURI, null, null, null, null)

        cur?.let { getAllSmsToFile(it) }

        while (cur!!.moveToNext()) {
            val address = cur.getString(cur.getColumnIndex("address"))
            val body = cur.getString(cur.getColumnIndexOrThrow("body"))
            sms.add("Number: $address .Message: $body")
        }
        return sms
    }
    //endregion

}
*/
