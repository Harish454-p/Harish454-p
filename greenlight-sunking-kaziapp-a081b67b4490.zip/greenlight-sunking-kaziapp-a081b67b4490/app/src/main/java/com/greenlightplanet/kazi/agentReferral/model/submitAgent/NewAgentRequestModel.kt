package com.greenlightplanet.kazi.agentReferral.model.submitAgent


import com.google.gson.annotations.SerializedName

data class NewAgentRequestModel(
    @SerializedName("parent_angaza_id")
    var parentAngazaId: String?,
    @SerializedName("phone_number")
    var phoneNumber: String?,
    @SerializedName("name")
    var name : String?,
    @SerializedName("territory")
    var territory: String?
)