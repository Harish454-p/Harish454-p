package com.greenlightplanet.kazi.agentReferral.model.agentreferral


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Pagination(
    @SerializedName("end_of_stream")
    var endOfStream: Boolean?,
    @SerializedName("page")
    var page: String?,
    @SerializedName("page_size")
    var pageSize: String?
) : Parcelable