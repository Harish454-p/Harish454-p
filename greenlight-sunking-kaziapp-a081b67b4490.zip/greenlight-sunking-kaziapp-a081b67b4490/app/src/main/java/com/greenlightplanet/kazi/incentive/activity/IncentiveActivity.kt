package com.greenlightplanet.kazi.incentive.activity

import android.content.Intent
import android.os.Bundle
import androidx.viewpager.widget.ViewPager
import android.util.Log
import android.widget.Toast
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.activity.DashBoardActivity
import com.greenlightplanet.kazi.utils.*
import com.greenlightplanet.kazi.incentive.adapter.IncentivePagerAdapter
import com.greenlightplanet.kazi.incentive.fragment.CollectionIncentiveFragment
import com.greenlightplanet.kazi.incentive.fragment.SalesIncentiveFragment
import com.greenlightplanet.kazi.incentive.model.IncentiveResponseModel
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityIncentiveBinding
import com.greenlightplanet.kazi.incentive.fragment.PhoneRecoveryIncentiveFragment
import com.greenlightplanet.kazi.networking.APICallback
import com.greenlightplanet.kazi.networking.APIInterface
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener


class IncentiveActivity : BaseActivity(), APIInterface<CommonResponseModel<IncentiveResponseModel>> {

private lateinit var binding: ActivityIncentiveBinding
    var loginResponseModel: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    var incentiveResponseModel: IncentiveResponseModel? = null
    var isFromNotification = false
    var mHomeWatcher: HomeWatcher? = null
    val TAG = "IncentiveActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_incentive)
        binding = ActivityIncentiveBinding.inflate(layoutInflater)
        if (intent.hasExtra("fromNotification")) {
            isFromNotification = intent.getBooleanExtra("fromNotification", false)
        }
        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        initialize()
//        APICall()
        CallApi()

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }
    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();
    }
    fun CallApi() {
        if (Util.isOnline(this)) {
			Log.d("TIME_CALC", "incentive-start:${System.currentTimeMillis()} ")
            ServiceInstance.getInstance(this).service?.getIncentive("incentives/"
                    + preference?.getLoginResponseModel()?.angazaId)?.enqueue(object : APICallback<CommonResponseModel<IncentiveResponseModel>>(this as APIInterface<CommonResponseModel<IncentiveResponseModel>>, activity = this) {})
        } else {
            onError()
        }
    }

    fun APICall() {
        val incentiveResponseModel = AppDatabase.getAppDatabase(this).userDao()
                .getIncentiveDetails(preference?.getLoginResponseModel()?.angazaId!!)

        if (Util.isConnectedFast(applicationContext) || incentiveResponseModel == null) {
            ServiceInstance.getInstance(this).service?.getIncentive("incentives/"
                    + preference?.getLoginResponseModel()?.angazaId)?.enqueue(object :
                APICallback<CommonResponseModel<IncentiveResponseModel>>(this as APIInterface<CommonResponseModel<IncentiveResponseModel>>, activity = this) {})
        } else {
            ServiceInstance.getInstance(this).service?.getIncentive("incentives/"
                    + preference?.getLoginResponseModel()?.angazaId)?.enqueue(object : APIWOProgressCallback<CommonResponseModel<IncentiveResponseModel>>(this as APIInterface<CommonResponseModel<IncentiveResponseModel>>) {})
            onError()
        }

    }

    fun initialize() {

        Util.setToolbar(this, binding.toolbar2!!)
        preference = GreenLightPreference.getInstance(this)
    }

    private fun setupViewPager(viewPager: ViewPager) {
        val adapter = IncentivePagerAdapter(supportFragmentManager)

        val collectionBundle = Bundle()
        collectionBundle.putSerializable("collection", incentiveResponseModel?.collection)

        val collection = CollectionIncentiveFragment()
        collection.arguments = collectionBundle

        val salesBundle = Bundle()
        salesBundle.putSerializable("sales", incentiveResponseModel?.sales)

        val sales = SalesIncentiveFragment()
        sales.arguments = salesBundle


        val phoneRecoveryBundle = Bundle()
        phoneRecoveryBundle.putSerializable("phoneRecovery", incentiveResponseModel?.phoneRecovery)
        phoneRecoveryBundle.putSerializable("others", incentiveResponseModel?.others)

        val phoneRecovery = PhoneRecoveryIncentiveFragment()
        phoneRecovery.arguments = phoneRecoveryBundle

        adapter.addFragment(collection, resources.getString(R.string.summry_collection))
        adapter.addFragment(sales, resources.getString(R.string.inc_sales))
        adapter.addFragment(phoneRecovery, getString(R.string.others))




        viewPager.adapter = adapter
    }

    override fun onResponse(response: CommonResponseModel<IncentiveResponseModel>) {
        if (response != null) {
			Log.d("TIME_CALC", "incentive-end:${System.currentTimeMillis()} ")

            if (response.Success!!) {
                val incentiveResponseModel = response.ResponseData
                loginResponseModel = preference?.getLoginResponseModel()
                incentiveResponseModel?.angazaId = loginResponseModel?.angazaId!!
                if (incentiveResponseModel != null) {
                    setIncentives(incentiveResponseModel)
                    AppDatabase.getAppDatabase(this).userDao().insertIncentive(incentiveResponseModel)
                    updateSharedPref(true)
					Log.d("TIME_CALC", "incentive-end:${System.currentTimeMillis()} ")
                }

            } else {
                Toast.makeText(this, "" + response.Error?.MessageToUser, Toast.LENGTH_LONG).show()
            }
        }

    }

    override fun onError() {
        val incentiveResponseModel = AppDatabase.getAppDatabase(this).userDao().getIncentiveDetails(preference?.getLoginResponseModel()?.angazaId!!)
        if (incentiveResponseModel != null) {
            setIncentives(incentiveResponseModel)
            updateSharedPref(false)
        } else {
            Util.showToast(resources.getString(R.string.no_data_available), this)
            try {
                onBackPressed()
            } catch (e: Exception) {
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()

        return true
    }

    override fun onBackPressed() {
        if (isFromNotification) {

            val intent = Intent(this, DashBoardActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        } else {

            super.onBackPressed()
        }
    }

    fun setIncentives(incentiveResponseModel: IncentiveResponseModel) {

        loginResponseModel = preference?.getLoginResponseModel()
        this.incentiveResponseModel = incentiveResponseModel
       binding. tvCountry?.text = loginResponseModel?.country
        binding. tvArea?.text = incentiveResponseModel.area
        binding. tvPhoneNo?.text = loginResponseModel?.phoneNumber
       binding.tvCluster?.text = incentiveResponseModel.cluster

        binding.tvCurrentRole?.text = incentiveResponseModel.currentRole
        setupViewPager(this. binding.viewpager!!)
        binding.tabs?.setupWithViewPager( binding.viewpager)
    }

    private fun updateSharedPref(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadIncentiveFromPref(this)

        if (data == null) {
            data = LastSaved()
            data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(this, data)
            binding.tvLastSaved.text = data.incentive

        } else {

            if (fromInternet) {
                data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(this, data)
                binding.tvLastSaved.text = data.incentive
            } else {
                binding.tvLastSaved.text = data.incentive

            }
        }

    }

}
