package com.greenlightplanet.kazi.agentReferral.ui.adapter

import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.calendar_format_display
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.stage_assessment
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.stage_telerivet_assessment
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_error
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_failed
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_in_progress
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_manual_error
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_prospect_resub
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_success
import com.greenlightplanet.kazi.agentReferral.model.referralStatusDetail.ReferralDetail
import com.greenlightplanet.kazi.agentReferral.ui.view.ReferralStatusDetailActivity
import com.greenlightplanet.kazi.databinding.AdapterReferralStatusDetailBinding
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util

class ReferralStatusDetailAdapter(private val referralStatusDetailActivity: ReferralStatusDetailActivity, var list : ArrayList<ReferralDetail>) : RecyclerView.Adapter<ReferralStatusDetailAdapter.ViewHold>() {

    val country : String? = GreenLightPreference.getInstance(referralStatusDetailActivity)
        .getLoginResponseModel()?.country

    class ViewHold(val binder : AdapterReferralStatusDetailBinding) : RecyclerView.ViewHolder(binder.root) {
        fun binInfo(
            referralStatusDetailActivity: ReferralStatusDetailActivity,
            referralDetail: ReferralDetail,
            country: String?
        ) {
            binder.run {
                txtStage.text = when(referralDetail.stage) {
                    null -> referralStatusDetailActivity.getString(R.string.na)
                    else -> referralDetail.stage
                }
                txtStatusDate.text = when(referralDetail.actTime) {
                    null,"" -> ""
                    else -> {
                        val milDate = (referralDetail.actTime!!.toDouble().toLong()) * 1000
                        DateFormat.format(calendar_format_display, milDate).toString()
                    }
                }

                imgStatus.setOnClickListener {
                    Util.addEvent(
                            id = "385",
                            name ="referral status wise details cross icon for message click",
                            event ="user_click_on_icon_for_message_status_wise_detail"
                    )
                    when(referralDetail.status) {
                        status_in_progress -> {
                            when {
                                country.equals("Nigeria", true) -> {
                                    when(referralDetail.stage) {
                                        stage_telerivet_assessment,
                                        stage_assessment -> { referralStatusDetailActivity.onDetailSelected(model = referralDetail) }
                                    }
                                }
                            }
                        }
                        status_failed,
                        status_error -> {
                            Util.customFseRationaleDialog(
                                context = referralStatusDetailActivity,
                                title = "",
                                hideNegative = true,
                                titleSpanned = null,
                                hideTitle = true,
                                message = when(referralDetail.reason)
                                {
                                    null,"" -> referralStatusDetailActivity.getString(R.string.no_data)
                                    else -> referralDetail.reason!!
                                },
                                positveSelected = {
                                    it.dismiss()
                                },
                                negativeSeleted = {
                                    it.dismiss()
                                }
                            )
                        }
                    }
                }

                when(referralDetail.status) {
                    null,
                    "",
                    status_prospect_resub,
                    status_in_progress -> imgStatus.setImageDrawable(ContextCompat.getDrawable(referralStatusDetailActivity, R.drawable.exclamation_mark))
                    status_success -> imgStatus.setImageDrawable(ContextCompat.getDrawable(referralStatusDetailActivity, R.drawable.ic_check))
                    status_manual_error,
                    status_error,
                    status_failed -> imgStatus.setImageDrawable(ContextCompat.getDrawable(referralStatusDetailActivity, R.drawable.ic_cancel))
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHold {
        val binder : AdapterReferralStatusDetailBinding = AdapterReferralStatusDetailBinding.inflate(
            LayoutInflater.from(referralStatusDetailActivity),
            parent,
            false
        )
        return ViewHold(binder)
    }

    override fun onBindViewHolder(holder: ViewHold, position: Int) {
        when(position) {
            list.size - 1 -> holder.binder.root.background = ContextCompat.getDrawable(referralStatusDetailActivity, R.drawable.square_border_with_bottom)
            else -> holder.binder.root.background = ContextCompat.getDrawable(referralStatusDetailActivity, R.drawable.square_border_without_bottom)
        }
        holder.binInfo(referralStatusDetailActivity, list[position], country)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    interface OnReferralDetail {
        fun onDetailSelected(model : ReferralDetail)
    }
}