package com.greenlightplanet.kazi.incentive.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.greenlightplanet.kazi.incentive.model.StarClubResponseModel
import com.greenlightplanet.kazi.incentive.starclubrepo.StarClubRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel

/**
 * Created by Rahul on 16/06/20.
 */
class starClubVM(application: Application) : AndroidViewModel(application)  {

    val repo = StarClubRepo.getInstance(application)

    fun getstartClubData(
            context: Context,
            angazaId: String
    ): MutableLiveData<NewCommonResponseModel<StarClubResponseModel>> {

        return repo.getStarClub(context, angazaId = angazaId)
    }
}
