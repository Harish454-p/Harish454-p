package com.greenlightplanet.kazi.incentivenew.dao.converter.referal

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.incentivenew.model.reffrel.ReferredAgents
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryFields
import com.greenlightplanet.kazi.pricegroup.model.Pricing_group

class ReferreAgentConverter {

    @TypeConverter
    fun fromReferredAgentsList(list: List<ReferredAgents>?): String? {
        if (list == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<ReferredAgents>>() {

        }.type
        return gson.toJson(list, type)
    }

    @TypeConverter
    fun toReferredAgentsList(string: String?): List<ReferredAgents>? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<ReferredAgents>>() {

        }.type
        return gson.fromJson(string, type)
    }

}


