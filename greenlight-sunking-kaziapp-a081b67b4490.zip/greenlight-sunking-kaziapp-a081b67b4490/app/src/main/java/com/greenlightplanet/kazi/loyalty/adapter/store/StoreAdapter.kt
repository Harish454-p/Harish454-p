package com.greenlightplanet.kazi.loyalty.adapter.store

import android.content.Context
import android.view.ViewGroup
import androidx.paging.PagedListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.loyalty.model.store.StoreItem
import com.greenlightplanet.kazi.loyalty.pagging.State


class StoreAdapter(val context: Context,private val retry: () -> Unit)
    : PagedListAdapter<StoreItem, RecyclerView.ViewHolder>(NewsDiffCallback) {

    private val DATA_VIEW_TYPE = 1
    private val FOOTER_VIEW_TYPE = 2
    var listener: onClickItem? = null

    private var state = State.LOADING

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == DATA_VIEW_TYPE) StoreViewHolder.create(parent)
        else StoreFooterViewHolder.create(retry, parent)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (getItemViewType(position) == DATA_VIEW_TYPE)

            getItem(position)?.let { (holder as StoreViewHolder).bind(it,listener,context) }
        else (holder as StoreFooterViewHolder).bind(state)
    }

    override fun getItemViewType(position: Int): Int {
        return if (position < super.getItemCount()) DATA_VIEW_TYPE else FOOTER_VIEW_TYPE
    }

    companion object {
        val NewsDiffCallback = object : DiffUtil.ItemCallback<StoreItem>() {
            override fun areItemsTheSame(oldItem: StoreItem, newItem: StoreItem): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: StoreItem, newItem: StoreItem): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun getItemCount(): Int {
        return super.getItemCount() + if (hasFooter()) 1 else 0
    }

    private fun hasFooter(): Boolean {
       return super.getItemCount() != 0 && (state == State.LOADING || state == State.ERROR || state ==State.OFFLINE)
       // return super.getItemCount() != 0 && (state == State.LOADING)
    }

    fun setState(state: State) {
        this.state = state
        notifyItemChanged(super.getItemCount())
    }

    interface onClickItem {

        fun onTab(storeItem: StoreItem )


    }


}