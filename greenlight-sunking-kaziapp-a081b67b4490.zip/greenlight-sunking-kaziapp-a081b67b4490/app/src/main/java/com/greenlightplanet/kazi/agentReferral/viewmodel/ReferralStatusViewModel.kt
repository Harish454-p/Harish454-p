package com.greenlightplanet.kazi.agentReferral.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.agentReferral.ReferralConstants
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_parent_phone
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_referral_date
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.sort_stage
import com.greenlightplanet.kazi.agentReferral.model.referralStatus.Referral
import com.greenlightplanet.kazi.agentReferral.model.referralStatus.ReferralStatusModel
import com.greenlightplanet.kazi.agentReferral.repo.AgentReferralRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel

class ReferralStatusViewModel(application: Application) : AndroidViewModel(application) {

    fun prepData(responseData: ReferralStatusModel) {
        responseData.referrals?.let { list ->
            statuses.addAll(ArrayList(list))
            obsAgentStatuses.postValue(statuses)
        }
    }

    fun getAgentStatus(isOnline: Boolean, childPhone: String) : MutableLiveData<NewCommonResponseModel<ReferralStatusModel>>{
        statuses.clear()
        return when(isOnline) {
            true -> repo.getReferralStatus(childPhone = childPhone)
            false -> repo.getReferralStatusFromDB(childPhone = childPhone)
        }
    }

    fun sortStatus(sortType: Int) {
        when(sortType) {
            sort_parent_phone -> {
                when(isParentPhoneASC) {
                    true -> {
                        val list = statuses.sortedWith(compareBy { it.parentPhoneNumber })
                        obsAgentStatuses.postValue(ArrayList(list))
                    }
                    false -> {
                        val list = statuses.sortedWith(compareBy { it.parentPhoneNumber }).asReversed()
                        obsAgentStatuses.postValue(ArrayList(list))
                    }
                }
                isParentPhoneASC = !isParentPhoneASC
            }
            sort_stage -> {
                when(isStageASC) {
                    true -> {
                        val list = statuses.sortedWith(compareBy { it.currentStage })
                        obsAgentStatuses.postValue(ArrayList(list))
                    }
                    false -> {
                        val list = statuses.sortedWith(compareBy { it.currentStage }).asReversed()
                        obsAgentStatuses.postValue(ArrayList(list))
                    }
                }
                isStageASC = !isStageASC
            }
            sort_referral_date -> {
                when(isReferralDate) {
                    true -> {
                        val list = statuses.sortedWith(compareBy { it.referredDateTimeStamp?.toDouble() })
                        obsAgentStatuses.postValue(ArrayList(list))
                    }
                    false -> {
                        val list = statuses.sortedWith(compareBy { it.referredDateTimeStamp?.toDouble() }).asReversed()
                        obsAgentStatuses.postValue(ArrayList(list))
                    }
                }
                isReferralDate = !isReferralDate
            }
        }
    }

    val TAG : String = "ReferralStatusViewModel"
    private var repo : AgentReferralRepo = AgentReferralRepo(context = application.applicationContext)
    private var statuses : ArrayList<Referral> = ArrayList()
    private var isParentPhoneASC : Boolean = true
    private var isStageASC : Boolean = true
    private var isReferralDate : Boolean = true

    var obsAgentStatuses : MutableLiveData<ArrayList<Referral>> = MutableLiveData()

}