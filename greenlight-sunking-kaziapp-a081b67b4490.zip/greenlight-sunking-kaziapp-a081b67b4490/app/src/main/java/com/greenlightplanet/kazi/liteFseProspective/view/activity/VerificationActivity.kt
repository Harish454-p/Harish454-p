package com.greenlightplanet.kazi.liteFseProspective.view.activity

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityVerificationBinding
import com.greenlightplanet.kazi.liteFseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import com.greenlightplanet.kazi.liteFseProspective.model.LiteOtpApprovalRequestModel
import com.greenlightplanet.kazi.liteFseProspective.viewmodel.VerificationViewModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener


class VerificationActivity : BaseActivity() {

    private lateinit var binding:ActivityVerificationBinding
    var fseProspectResponseModel: LiteFseProspectResponseModel? = null
    var loginResponseData: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    lateinit var viewModel: VerificationViewModel
    var otpApprovalRequestModel: LiteOtpApprovalRequestModel? = null
	var mHomeWatcher: HomeWatcher? = null


	companion object {

        val TAG = "VerificationActivity"
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
      //  setContentView(R.layout.activity_verification)
        binding = ActivityVerificationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        Util.setToolbar(this, toolbar)
        preference = GreenLightPreference.getInstance(this)
        loginResponseData = preference?.getLoginResponseModel()
        viewModel = ViewModelProviders.of(this).get(VerificationViewModel::class.java)

        initializeExtras()
        initialize()
        clickHandler()


        Log.d(TAG, "Country: ${preference!!.getLoginResponseModel()!!.country}")

		mHomeWatcher = HomeWatcher(this)
		mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
			override fun onHomePressed() {
				finish()
			}
		})
		mHomeWatcher!!.startWatch()
    }

    private fun clickHandler() {
        binding.SubmitOk.setOnClickListener {
            Log.d(TAG, "Otp-Entered: ${binding.otpView?.text.toString()}")
            if (binding.otpView.text.isNullOrBlank()) {
                Toast.makeText(this, "Please enter OTP", Toast.LENGTH_SHORT).show()
            } else {
                validate(this@VerificationActivity, binding.otpView?.text.toString())
            }

        }

        binding.ivSync.setOnClickListener {

            if (Util.isOnline(this@VerificationActivity)) {
                if ((otpApprovalRequestModel != null) && fseProspectResponseModel!!.isChanged) {
                    //you have data to sync
                    viewModel.sendOtpApprovalToServerForceUpload((!otpApprovalRequestModel!!.otpVerificationTime.isNullOrBlank()), otpApprovalRequestModel!!,
                            showProgress = {
                                showProgressDialog(this)
                            }).observe(this, Observer {

                        viewModel.getFseProspectiveFromServer(loginResponseData!!.angazaId!!, fseProspectResponseModel!!.prospectId)?.observe(this, Observer {
                            if (it != null) {
                                if ((it.success) && (it.responseData != null)) {

                                    setValue(it.responseData!!)
                                }else{
                                    alphaMethod(fseProspectResponseModel!!)
                                }
                            }else{
                                alphaMethod(fseProspectResponseModel!!)
                            }

                            cancelProgressDialog()
                        })

                    })
                } else {
                    //you don't have data to sync
//                    Util.showToast("Sync not required", this)
                    viewModel.getFseProspectiveFromServer(loginResponseData!!.angazaId!!, fseProspectResponseModel!!.prospectId,showProgress = {
                        showProgressDialog(this)
                    })?.observe(this, Observer {
                        if (it != null) {
                            if ((it.success) && (it.responseData != null)) {

                                setValue(it.responseData!!)
                            }else{
                                alphaMethod(fseProspectResponseModel!!)
                            }
                        }else{
                            alphaMethod(fseProspectResponseModel!!)
                        }

                        cancelProgressDialog()
                    })
                }
            } else {
//                Util.showToast("No Internet", this)
                Util.customFseRationaleDialog(this, "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = "Please check internet connection",
                        positveSelected = {
                            it.dismiss()
                        },
                        negativeSeleted = {
                            it.dismiss()
                        }
                )
            }

        }

    }


    override fun onOptionsItemSelected(item: MenuItem):Boolean {

        when (item?.itemId) {
            android.R.id.home -> {

                onBackPressed()

                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }


    fun initializeExtras() {

        if (intent.hasExtra("data")) {

            fseProspectResponseModel = intent.getParcelableExtra("data")

        }

    }

    fun initialize() {
        fseProspectResponseModel?.let {
            setValue(it)
        }
    }

    private fun setValue(fseProspectResponseModel: LiteFseProspectResponseModel) {

        binding.tvCustomerName.text = fseProspectResponseModel.name
        binding.tvCustomerAddress.text = fseProspectResponseModel.customerAddress
        binding.tvPhoneNumber.text = fseProspectResponseModel.customerPhoneNumber
        binding.tvProspectID.text = fseProspectResponseModel.prospectId
        //tv_AccountNo.text = fseProspectResponseModel.accuntNumber//not available
        //tv_TicketGenerationDate.text = fseProspectResponseModel.statusUpdateTime //no idea what value to set
        //tv_TypeOfTicket.text = fseProspectResponseModel.name // customer address not available


        Log.d(TAG, "statusUpdateTime: ${fseProspectResponseModel.statusUpdateTime}");


        alphaMethod(fseProspectResponseModel)

        if (!(fseProspectResponseModel.statusUpdateTime?.otpApproved.isNullOrBlank())) {
            binding.otpView.visibility = View.GONE
            binding.SubmitOk.visibility = View.GONE
        }

        setProspectProgress(fseProspectResponseModel.statusUpdateTime)

    }


    fun alphaMethod(fseProspectResponseModel: LiteFseProspectResponseModel) {

        viewModel.getCombineRequestModel(fseProspectResponseModel.prospectId).observe(this, Observer {

            it?.fseProspectResponseModel?.let {
                this.fseProspectResponseModel = it

                Log.d(TAG, "it-isChanged:${it} ");

            }

            if ((it?.otpApprovalRequestModel == null) && !(this.fseProspectResponseModel!!.isChanged)) {

                val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                binding.ivSyncColor.setImageDrawable(backgroundDrawable)

            } else {
                otpApprovalRequestModel = it?.otpApprovalRequestModel

                if (this.fseProspectResponseModel!!.isChanged) {
                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.RED)
                    binding.ivSyncColor.setImageDrawable(backgroundDrawable)
                } else {

                    val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.ic_cricle)
                    DrawableCompat.setTint(backgroundDrawable!!, Color.GREEN)
                    binding.ivSyncColor.setImageDrawable(backgroundDrawable)


                }

                if (!it?.otpApprovalRequestModel?.otpVerificationTime.isNullOrEmpty()) {

                    binding.imgOtp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                    binding.tvOTPDate.text = Util.fseUiDateFormatter(it!!.otpApprovalRequestModel?.otpVerificationTime!!)

                    binding.otpView.visibility = View.GONE
                    binding.SubmitOk.visibility = View.GONE

                }
            }


            it?.fseError?.let {

                if (this.fseProspectResponseModel!!.errorOccurred && (it.errorType == FseProspectiveConstant.ProspectiveType.VERIFICATION)) {
                    binding.llError.visibility = View.VISIBLE
                    binding.tvErrorMessage.text = it.messageToUser
                }
            }


        })
    }

    private fun setProspectProgress(statusUpdateTime: LiteFseProspectResponseModel.StatusUpdateTime?) {

        if (!statusUpdateTime?.prospect.isNullOrEmpty()) {
            binding.tvProspectDate.text = Util.fseUiDateFormatter(statusUpdateTime!!.prospect!!)
            //tv_ProspectDate.text = statusUpdateTime?.prospect

            //img_Prospect
            //img_Prospect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            if (!fseProspectResponseModel!!.approved) {

                if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.PROSPECT) {

                    binding.imgProspect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_cancel))
                    binding.otpView.visibility = View.GONE
                    binding.SubmitOk.visibility = View.GONE

                    binding.imgProspect.setOnClickListener {
                        errorMessage(fseProspectResponseModel!!)
                    }

                } else {
                    binding.imgProspect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                }
            } else {
                binding.imgProspect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
            }


        } else {
            binding.tvProspectDate.text = ""
            binding.imgProspect.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
        }


        if (!statusUpdateTime?.otpApproved.isNullOrEmpty()) {
//            tv_OTPDate.text = statusUpdateTime?.otpApproval
            binding.tvOTPDate.text = Util.fseUiDateFormatter(statusUpdateTime!!.otpApproved!!)
            if (!statusUpdateTime.otpApproved.isNullOrEmpty()) {
                binding.tvOTPDate.text = Util.fseUiDateFormatter(statusUpdateTime!!.otpApproved!!)
                //img_Otp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

                if (!fseProspectResponseModel!!.approved) {

                    if (fseProspectResponseModel!!.status == FseProspectiveConstant.ProspectStatus.OTP_APPROVED) {

                        binding.imgOtp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_cancel))
                        binding.otpView.visibility = View.GONE
                        binding.SubmitOk.visibility = View.GONE

                        binding.imgOtp.setOnClickListener {
                            errorMessage(fseProspectResponseModel!!)
                        }

                    } else {
                        binding.imgOtp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                    }
                } else {
                    binding.imgOtp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))
                }

            } else {
                binding.tvOTPDate.text = ""
                binding.imgOtp.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))
            }

            if (!statusUpdateTime?.preApprovedProspect.isNullOrEmpty()) {
//            tv_PreApprovedDate.text = statusUpdateTime?.preApprovedProspect
                binding.tvPreApprovedDate.text = Util.fseUiDateFormatter(statusUpdateTime!!.preApprovedProspect!!)
                //img_PreApproved
                binding.imgPreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                binding.tvPreApprovedDate.text = ""
                binding.imgPreApproved.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }


            if (!statusUpdateTime?.checkedIn.isNullOrEmpty()) {
//            tv_CheckedInDate.text = statusUpdateTime?.checkedIn
                binding.tvCheckedInDate.text = Util.fseUiDateFormatter(statusUpdateTime?.checkedIn!!)
                //img_CheckedIn
                binding.imgCheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                binding.tvCheckedInDate.text = ""
                binding.imgCheckedIn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }


            if (!statusUpdateTime?.installed.isNullOrEmpty()) {
//            tv_InstallPendDate.text = statusUpdateTime?.installationPending
                binding.tvInstallPendDate.text = Util.fseUiDateFormatter(statusUpdateTime?.installed!!)
                //img_istallationP
                binding.imgIstallationP.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                binding.tvInstallPendDate.text = ""
                binding.imgIstallationP.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }

            if (!statusUpdateTime?.installationVerified.isNullOrEmpty()) {
//            tv_InstallCompleteDate.text = statusUpdateTime?.installed
                binding.tvInstallCompleteDate.text = Util.fseUiDateFormatter(statusUpdateTime?.installationVerified!!)
                //img_InstallComplete
                binding.imgInstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                binding.tvInstallCompleteDate.text = ""
                binding.imgInstallComplete.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }


            if (!statusUpdateTime?.threeWayCallVerification.isNullOrEmpty()) {
                binding.tvCCverif.text = Util.fseUiDateFormatter(statusUpdateTime?.threeWayCallVerification!!)
                //img_InstallComplete
                binding.imgCCVerif.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.double_check))

            } else {
                binding.tvCCverif.text = ""
                binding.imgCCVerif.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.exclamation_mark))

            }
        }

    }

    fun validate(context: Context, enteredOtp: String) {

        val isValid = isValidOtp(enteredOtp)
        val isOnline = Util.isOnline(context)
        viewModel.processOtp(
                context = context,
                isOnline = isOnline,
                isValid = isValid,
                prospectID = fseProspectResponseModel?.prospectId!!,
                angazaId = loginResponseData?.angazaId!!,
                unsuccessfulAttempt = fseProspectResponseModel?.unsuccessfulOtpAttempts!!,
                country = preference!!.getLoginResponseModel()!!.country!!,
                showProgress = {
                    showProgressDialog(context)
                }
        )?.observe(this, Observer {
            cancelProgressDialog()

            //Util.showToast("Completed Otp", this)

            //if (isOnline && isValid) {
            if (it!!.success) {
                if (isValid) {//going to change in feature

                    Util.customFseCompletionDialog(
                            context = this,
                            title = "OTP Verified",
                            message = "Please proceed to Check-In after 5 minutes.",
                            okSelected = {
                                it.dismiss()
                                //backpress //add your addditional logic here
                                this@VerificationActivity.onBackPressed()
                            })

                }
            } else {
                Util.showToast("Unknown error occurred", this)
            }


            alphaMethod(fseProspectResponseModel!!)

            //do further process after integrating with live/dev api

        })

        if (isValid.not()) {
            Util.customFseCompletionDialog(
                    context = this,
                    hideTitle = true,
                    title = null,
                    message = "Invalid OTP",
                    okSelected = {

                        it.dismiss()
                        binding.otpView.text?.clear()


                    }
            )
        }
    }


    private fun errorMessage(fseProspectResponseModel: LiteFseProspectResponseModel) {
        Util.customFseCompletionDialog(
                context = this,
                hideTitle = true,
                title = null,
                message = fseProspectResponseModel.message,
                okSelected = {

                    it.dismiss()

                }
        )
    }

    private fun isValidOtp(enteredOtp: String): Boolean {
        return enteredOtp == fseProspectResponseModel?.otp!!
    }


	override fun onDestroy() {
		super.onDestroy()
		mHomeWatcher?.stopWatch();

	}

}
