package com.greenlightplanet.kazi.leads.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize
import com.google.gson.annotations.SerializedName

import android.os.Parcelable

@Parcelize
@Entity(tableName = "LeadsIntent")
data class LeadsIntent(
//    @ColumnInfo(name = "feedbacks")
//    @SerializedName("feedbacks")
//    var feedbacks: List<Int?>?,//double check this
    @ColumnInfo(name = "intent")
    @SerializedName("intent")
    var intent: String?, // other
    @PrimaryKey
    @ColumnInfo(name = "intent_id")
    @SerializedName("intent_id")
    var intentId: Int // 5
) : Parcelable
