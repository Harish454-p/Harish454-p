package com.greenlightplanet.kazi.incentivenew.activity

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivityReferelBinding
import com.greenlightplanet.kazi.incentivenew.adapter.EligibleAdapter
import com.greenlightplanet.kazi.incentivenew.adapter.ReferalAdapter
import com.greenlightplanet.kazi.incentivenew.model.incentive.Accounts
import com.greenlightplanet.kazi.incentivenew.model.reffrel.AgentReffedResponseData
import com.greenlightplanet.kazi.incentivenew.model.reffrel.ReferredAgents
import com.greenlightplanet.kazi.incentivenew.viewmodel.ReferelViewModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import java.util.*

/**
 * Created by Rahul on 07/12/20.
 */
class ReferalActivity : BaseActivity(), ReferalAdapter.MyDateData {
    private lateinit var binding:ActivityReferelBinding
    lateinit var viewModel: ReferelViewModel
    var adapterList: MutableList<ReferredAgents> = mutableListOf()
    var adapter: ReferalAdapter? = null
  //  var recyclerView: RecyclerView? = null
    var sortType = 1
    var sortAttribute = 0
    var preference: GreenLightPreference? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_referel)
        binding = ActivityReferelBinding.inflate(layoutInflater)
        setContentView(binding.root)

        preference = GreenLightPreference.getInstance(this)
        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME

        Util.setToolbar(this, binding.toolbar2!!)
        showProgressDialog(this)
        Initilize()
        clickHander()



    }

    fun Initilize(){

        Util.addEvent("309", "ReferalScreen", "EarningScreen_to_ReferalScreen")

        //recyclerView = findViewById<View>(R.id.recyclerView) as RecyclerView //US014627
        viewModel = ViewModelProviders.of(this).get(ReferelViewModel::class.java)
        viewModel.getReferel(this,preference?.getLoginResponseModel()?.angazaId ).observe(this, Observer { response ->

            if (response != null) {

                if (response.success) {
                    if (response.responseData?.referredAgents?.size!! > 0){
                        binding. tvNoData.visibility=View.GONE

                    }else{
                        binding.tvNoData.visibility=View.VISIBLE

                    }
                    cancelProgressDialog()
                    setAdapter(response.responseData)
                    updateSharedPref(true)

                } else {
                    cancelProgressDialog()
                    binding. tvNoData.visibility=View.VISIBLE
                    Toast.makeText(this, "" + response.error, Toast.LENGTH_LONG).show()
                }
            }
        })

    }
    fun setAdapter(responseData: AgentReffedResponseData?) {


        adapterList.clear()
        adapterList.addAll(responseData!!.referredAgents)

        if (adapter == null) {

            // adapter = adapterList.filter { it.isEligible!! }.let { EligibleAdapter(it, this, requireContext()) }
            adapter = ReferalAdapter(adapterList, this, this)
            binding.recyclerView?.setHasFixedSize(true)
            binding.recyclerView?.layoutManager = LinearLayoutManager(this)
            binding.recyclerView?.adapter = adapter
        }
        adapter?.notifyDataSetChanged()




       /* recyclerView = findViewById<View>(R.id.recyclerView) as RecyclerView
         adapter = responseData?.referredAgents?.let { ReferalAdapter(it, this, this) }
        recyclerView?.setHasFixedSize(true)
        recyclerView?.layoutManager = LinearLayoutManager(this)

        recyclerView?.adapter = adapter*/
    }

    override fun selectedData(date: String, position: Int) {

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()

        return true
    }

    private fun updateSharedPref(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadIncentiveFromPref(this)

        if (data == null) {
            data = LastSaved()
            data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(this, data)
            binding.tvLastSaved.text = data.incentive

        } else {

            if (fromInternet) {
                data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(this, data)
                binding. tvLastSaved.text = data.incentive
            } else {
                binding. tvLastSaved.text = data.incentive

            }
        }

    }


    //region Sorting Functions
    private fun byUnitSold(mutableList: MutableList<ReferredAgents>) {

        sortAttribute = 3
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    it.unitSold.toDouble()
                }
            } else {
                sortType = 1
                mutableList.sortBy {
                    it.unitSold.toDouble()
                }
            }

//            sortPendingAmount(mutableList, sortType)
            binding.tvUnitSoldKey.setBackgroundColor(Color.GRAY)
            adapter?.notifyDataSetChanged()

        }
    }


    fun byReferAgent(mutableList: MutableList<ReferredAgents>) {

        sortAttribute = 2
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                   it.refferedAgentName
                }

            } else {
                sortType = 1
                mutableList.sortBy {
                   it.refferedAgentName
                }
            }

            binding. tvReferAgentKey.setBackgroundColor(Color.GRAY)
            adapter?.notifyDataSetChanged()
        }
    }



    fun refreshSortBackground() {
        binding. tvReferAgentKey.setBackgroundColor(Color.BLACK)
        binding. tvUnitSoldKey.setBackgroundColor(Color.BLACK)
    }

    private fun clickHander() {
        binding. tvReferAgentKey.setOnClickListener { v -> byReferAgent(adapterList) }
        binding. tvUnitSoldKey.setOnClickListener { v -> byUnitSold(adapterList) }

    }

}