package com.greenlightplanet.kazi.collectiongoal.model.paymenthistory

import android.os.Parcelable
import androidx.annotation.Keep
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize
@Keep
@Parcelize
@Entity(tableName = "PaymentHistory")
data class PaymentHistory(

    @PrimaryKey(autoGenerate = false)
    @ColumnInfo(name = "accountNumber")
    var accountNumber:Int,

    @ColumnInfo(name = "amount")
    val amount: Int?,

    @ColumnInfo(name = "paymentDate")
    val paymentDate: String?
) :Parcelable