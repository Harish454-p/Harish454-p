package com.greenlightplanet.kazi.feedback.view.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.ItemFeedbackSupportRvBinding
import com.greenlightplanet.kazi.feedback.repo.model.response.TicketResponseData
import timber.log.Timber
import java.lang.ref.WeakReference

class SupportFeedbackAdapter(): PagingDataAdapter<TicketResponseData, SupportFeedbackAdapter.ViewHolder>(DiffUtilCallBack()) {
    lateinit var binding: ItemFeedbackSupportRvBinding
    var dataList = mutableListOf<TicketResponseData>()
    lateinit var listener: WeakReference<SupportFeedbackAdapterClickListener>
    val TAG = "SupportFeedbackAdapter"
    var isClosed = false
    var isPending = false


    fun setRvData(list: List<TicketResponseData>, isStatusClosed: Boolean = false, isStatusPending: Boolean = false) {
        clearRvData()
        isClosed = isStatusClosed
        isPending = isStatusPending
        Log.d(TAG,"$TAG: AdapterList -> $list")
        dataList.addAll(list)
        notifyDataSetChanged()

    }
    fun clearRvData() {
        dataList.clear()
        isClosed = false
        isPending = false
        Log.d(TAG,"$TAG: AdapterList Cleared ")
        notifyDataSetChanged()

    }


    fun attachListener(clickListener: WeakReference<SupportFeedbackAdapterClickListener>) {
        listener = clickListener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        binding = ItemFeedbackSupportRvBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        getItem(position)?.let {
            holder.bind(it)
            Log.d(TAG ,"$TAG: onBind -> Position: $position | Item: $it")
        }
        if (dataList.isNotEmpty()) {


        }

    }


    inner class ViewHolder(private val vBinding: ItemFeedbackSupportRvBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(holdingData: TicketResponseData) {
            Timber.d("Paging : RvItem : $holdingData")
            if (isClosed) {
                vBinding.tvTicketIdValue.text = holdingData.ticketId?:""
                vBinding.tvCloseDateValue.text = holdingData.getClosedAtUtcToLocal()?:""
                vBinding.tvCategoryValue.text = holdingData.category?:""
                vBinding.tvSubCategoryValue.text = holdingData.subCategory?:""
                Timber.d("Paging : RvItem : ConvertedClosedDate ${holdingData.getClosedAtUtcToLocal()} || TS: ${holdingData.getCreatedAtTimeStampUtc()}")
            }
            if (isPending) {
                vBinding.tvTicketIdValue.text = holdingData.ticketId?:""
                vBinding.tvCloseDateTitle.text = "Raised At"
                vBinding.tvCloseDateValue.text = holdingData.getCreatedAtUtcToLocal()?:""
                vBinding.tvCategoryValue.text = holdingData.category?:""
                vBinding.tvSubCategoryValue.text = holdingData.subCategory?:""
                Timber.d("Paging : RvItem : ConvertedPendingDate ${holdingData.getCreatedAtUtcToLocal()} || TS: ${holdingData.getClosedAtTimeStampUtc()}")
            }

            vBinding.ivNext.setOnClickListener {
                listener.get()?.onTicketItemClicked(holdingData)
            }

        }
    }

    class DiffUtilCallBack: DiffUtil.ItemCallback<TicketResponseData>() {
        override fun areItemsTheSame(oldItem: TicketResponseData, newItem: TicketResponseData): Boolean {
            return oldItem.ticketId == newItem.ticketId
        }

        override fun areContentsTheSame(oldItem: TicketResponseData, newItem: TicketResponseData): Boolean {
            return oldItem.ticketId == newItem.ticketId
        }

    }

}

interface SupportFeedbackAdapterClickListener{
    fun onTicketItemClicked(data: TicketResponseData)
}