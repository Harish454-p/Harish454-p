package com.greenlightplanet.kazi.incentivenew.fragment.tvinstallation


import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.FragmentEligibleBinding
import com.greenlightplanet.kazi.databinding.FragmentTvEligibleBinding
import com.greenlightplanet.kazi.incentivenew.adapter.tvinstallation.TvInstallationEligibleAdapter
import com.greenlightplanet.kazi.incentivenew.model.tvinstallation.AccountsList
import com.greenlightplanet.kazi.incentivenew.model.tvinstallation.Incentive_TvInstallation


class TvInstallationInEligibleFragment : Fragment(), TvInstallationEligibleAdapter.MyDateData {

    private var _binding:FragmentTvEligibleBinding ? = null

    private val binding get() = _binding!!

   // var recyclerView: RecyclerView? = null
    var incentive_TvInstallation: Incentive_TvInstallation? = null


    var adapterList: MutableList<AccountsList> = mutableListOf()
    var adapter:TvInstallationEligibleAdapter?=null

    var sortType = 1
    var sortAttribute = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
         _binding = FragmentTvEligibleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
       binding.tvProductNameKey.visibility=View.GONE

        val boundless = arguments
        incentive_TvInstallation = boundless?.getParcelable<Incentive_TvInstallation>("inEligible")

        incentive_TvInstallation?.accountsList?.filter { it.isEligible!=true }?.let { setAdapter(it) }


        clickHandler()



    }

    override fun selectedData(date: String, position: Int) {

    }

    fun setAdapter(mutableList: List<AccountsList>) {
        adapterList.clear()
        adapterList.addAll(mutableList)
        if (adapterList.size>0){
            binding.tvNoData.visibility=View.GONE

        }else{
            binding.tvNoData.visibility=View.VISIBLE
        }

        if (adapter == null) {
            // adapter = adapterList.filter { it.isEligible!! }.let { EligibleAdapter(it, this, requireContext()) }
            adapter= TvInstallationEligibleAdapter(adapterList,this,requireContext())
            binding.recyclerView?.setHasFixedSize(true)
            binding. recyclerView?.layoutManager = LinearLayoutManager(requireContext())
            binding. recyclerView?.adapter = adapter
        }
        adapter?.notifyDataSetChanged()

    }
    //region Sorting Functions
    private fun byAccountNumber(mutableList: MutableList<AccountsList>) {

        sortAttribute = 3
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    it.accountNumber.toDouble()
                }
            } else {
                sortType = 1
                mutableList.sortBy {
                    it.accountNumber.toDouble()
                }
            }

//            sortPendingAmount(mutableList, sortType)
           binding.tvAccountNumerKey.setBackgroundColor(Color.GRAY)
            adapter?.notifyDataSetChanged()

        }
    }



    fun byCustomerName(mutableList: MutableList<AccountsList>) {

        sortAttribute = 2
        refreshSortBackground()

        if (mutableList.size > 0) {

            if (sortType == 1) {
                sortType = 0
                mutableList.sortByDescending {
                    it.registrationDate
                }

            } else {
                sortType = 1
                mutableList.sortBy {
                    it.registrationDate
                }
            }

//            sortCustomerName(mutableList, sortType)
            binding.tvRegistrationDateKey.setBackgroundColor(Color.GRAY)
            adapter?.notifyDataSetChanged()
        }
    }


    private fun refreshSortBackground() {
        binding.tvRegistrationDateKey.setBackgroundColor(Color.BLACK)
        binding.tvAccountNumerKey.setBackgroundColor(Color.BLACK)
            binding.tvProductNameKey.setBackgroundColor(Color.BLACK)
    }

    private fun clickHandler() {
        binding.tvRegistrationDateKey.setOnClickListener { v -> byCustomerName(adapterList) }
            binding.tvAccountNumerKey.setOnClickListener { v -> byAccountNumber(adapterList) }

    }
}
