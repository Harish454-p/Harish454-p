package com.greenlightplanet.kazi.collectiongoal.view.activity

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.Keep
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.collectiongoal.adapter.CustomerHistoryPagerAdapter
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistory
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistoryModel
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistory
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistoryModel
import com.greenlightplanet.kazi.collectiongoal.viewmodel.CustomerHistoryViewModel
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityCustomerHistoryBinding
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher

@Keep
class CustomerHistoryActivity : BaseActivity() {


    private lateinit var binding: ActivityCustomerHistoryBinding

    var preference: GreenLightPreference? = null

    val TAG = "CustomerHistory"

    var loginResponseModel: LoginResponseModel? = null
    var activity: AppCompatActivity? = null
    var isFromNotification = false
    var mHomeWatcher: HomeWatcher? = null

    var paymentHistoryIntent: Boolean? = null
    var accountNumberString: Int? = null

    var viewPagerPagerAdapter: CustomerHistoryPagerAdapter? = null

    private val viewModel: CustomerHistoryViewModel by viewModels()

    var callingHistoryModel: CallHistoryModel? = null
    var paymentHistoryModel: PaymentHistoryModel? = null

    val paymentHistoryList = mutableListOf<PaymentHistory>()
    val callingHistoryList = mutableListOf<CallHistory>()

    var count : Int = 0
    var nextPage : Int = 1
    var nextPagePayment : Int = 1
    var methodCallCount : Int = 1


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCustomerHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)



        initialize()

    }

    @SuppressLint("LongLogTag")
    fun initialize() {

        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        activity = this
        Util.setToolbar(this, this.binding.toolbar)
        preference = GreenLightPreference.getInstance(this)
        loginResponseModel = preference?.getLoginResponseModel()

        paymentHistoryIntent = intent.extras!!.getBoolean("paymentHistory")
        accountNumberString = intent.extras!!.getInt("accountNumber")

        binding.tvNoData.visibility = View.GONE
        binding.tabLayout.visibility = View.VISIBLE

        Log.d("PaymentHistoryIntent", paymentHistoryIntent.toString())
        Log.d("AccountNumber", accountNumberString.toString())

        setupTabLayout()

        if (nextPagePayment!=0){
            getPaymentHistory(nextPagePayment)
        }

        if (nextPage!=0){
            getCallingHistoryData(nextPage)
        }

        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this@CustomerHistoryActivity)
        binding.tvLastSaved.text = data?.customerPaymentHistorySaved



    }

    private fun getPaymentHistory(nextPagePayment: Int) {

        showProgressDialog(this)

        if (!viewModel.getPaymentHistoryData(accountNumberString,nextPagePayment)?.hasActiveObservers()!!){
            viewModel.getPaymentHistoryData(accountNumberString, nextPagePayment)
                ?.observe(this, Observer { it ->

                    cancelProgressDialog()

                    if (!it.responseData?.paymentHistory.isNullOrEmpty()){

                        cancelProgressDialog()
                        Log.d(TAG, "PaymentHistorySuccess1: ${it}")
                        Log.d(TAG, "PaymentHistoryPageNumber: ${it.responseData?.pageNo}")

                        binding.tvNoData.visibility = View.GONE
                        binding.tabLayout.visibility = View.VISIBLE

                        paymentHistoryModel = it.responseData

                        if (paymentHistoryModel?.next != null){
                            this.nextPagePayment = paymentHistoryModel?.next!!.toInt()
                        }else {
                            this.nextPagePayment = 0
                        }

                        paymentHistoryList.clear()

                        paymentHistoryList.addAll(paymentHistoryModel?.paymentHistory!!)

                        methodCallCount++

                        count++

                        setAdapterData()

                    }
                    else {
                        cancelProgressDialog()
                        //handle error here
                        binding.tvNoData.visibility = View.VISIBLE
                        count++
                        setAdapterData()
                    }

                })
        }

    }

    private fun setAdapterData() {

        if (count==2){
            setAdapter()
        }
    }

    @SuppressLint("LongLogTag")
    private fun getCallingHistoryData(nextPage: Int) {
        Log.d("CallingHistoryListActivity1", "success: ${callingHistoryList}")
        Log.d("PaymentHistoryListActivity1", "success: ${paymentHistoryList}")


        viewModel.getCallingHistoryData(accountNumberString,nextPage)
            ?.observe(this, Observer { it ->

                if (!it.responseData?.callHistory.isNullOrEmpty()){

                    Log.d(TAG, "CallingHistorySuccess1: ${it}")
                    Log.d(TAG, "CallingHistoryPageNumber: ${it.responseData?.pageNo}")

                    binding.tvNoData.visibility = View.GONE
                    binding.tabLayout.visibility = View.VISIBLE

                    callingHistoryModel = it.responseData

                    if (callingHistoryModel?.next != null){
                        this.nextPage = callingHistoryModel?.next!!
                    }else {
                        this.nextPage = 0
                    }


                    callingHistoryList.clear()

                    callingHistoryList.addAll(callingHistoryModel?.callHistory!!)

                    count++
                    setAdapterData()

                }else {
                    count++
                    setAdapterData()
                    binding.tvNoData.visibility = View.VISIBLE
                    binding
                }

            })

    }

    @SuppressLint("LongLogTag", "NotifyDataSetChanged")
    private fun setAdapter() {

        cancelProgressDialog()

        if (viewPagerPagerAdapter == null) {

            Log.d("CallingHistoryListActivity", "success: ${callingHistoryList}")
            Log.d("PaymentHistoryListActivity", "success: ${paymentHistoryList}")


            Log.d("PageNumberCallingHistory",nextPage.toString())
            Log.d("PageNumberPaymentHistory",nextPagePayment.toString())

            viewPagerPagerAdapter =
                CustomerHistoryPagerAdapter(supportFragmentManager,callingHistoryList,paymentHistoryList,accountNumberString,nextPage,nextPagePayment)

            binding.viewpager.adapter = viewPagerPagerAdapter

            if (paymentHistoryIntent == true) {
                binding.toolbarTitle.text = "Payment History"
                val tab: TabLayout.Tab = binding.tabLayout.getTabAt(0)!!
                tab.select()
            }else {
                binding.toolbarTitle.text = "Calling History"
                val tab: TabLayout.Tab = binding.tabLayout.getTabAt(1)!!
                tab.select()
            }

        } else {
            binding.viewpager.adapter?.notifyDataSetChanged()
        }
    }

    private fun setupTabLayout() {
        binding.tabLayout.apply {
            addTab(this.newTab().setText("Payment History"))
            addTab(this.newTab().setText("Calling History"))

            tabGravity = TabLayout.GRAVITY_FILL

            addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab) {
                    binding.viewpager.currentItem = tab.position

                    if (tab.position == 0) {
                        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this@CustomerHistoryActivity)
                        binding.tvLastSaved.text = data?.customerPaymentHistorySaved
                        binding.toolbarTitle.text = "Payment History"
                    } else {
                        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this@CustomerHistoryActivity)
                        binding.tvLastSaved.text = data?.customerCallHistorySaved
                        binding.toolbarTitle.text = "Calling History"
                    }
                }

                override fun onTabUnselected(tab: TabLayout.Tab?) {
                }

                override fun onTabReselected(tab: TabLayout.Tab?) {
                }
            })

            binding.viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {

                override fun onPageScrollStateChanged(p0: Int) {}

                override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {}

                override fun onPageSelected(p0: Int) {
                    if (p0 == 0) {
                        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this@CustomerHistoryActivity)
                        binding.tvLastSaved.text = data?.customerPaymentHistorySaved
                        binding.toolbarTitle.text = "Payment History"
                    } else {
                        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this@CustomerHistoryActivity)
                        binding.tvLastSaved.text = data?.customerCallHistorySaved
                        binding.toolbarTitle.text = "Calling History"
                    }
                    binding.tabLayout.getTabAt(p0)?.select()

                }
            })
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        finish()
        return true
    }

//    private val onBackPressedCallback: OnBackPressedCallback =
//        object : OnBackPressedCallback(true) {
//        override fun handleOnBackPressed() {
//            finish()
//        }
//    }

//    override fun onBackPressed() {
//        super.onBackPressed()
//        finish()
//    }


}