package com.greenlightplanet.kazi.agentReferral.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.default_zero
import com.greenlightplanet.kazi.agentReferral.model.agentreferral.SuccessfullyReferredAgent
import com.greenlightplanet.kazi.agentReferral.ui.view.AgentReferralActivity
import com.greenlightplanet.kazi.databinding.AdapterChildReferralAgentBinding
import java.text.NumberFormat
import java.util.*
import kotlin.collections.ArrayList

class AgentReferralAdapter(val agentReferralActivity : AgentReferralActivity, var list : ArrayList<SuccessfullyReferredAgent>) : RecyclerView.Adapter<AgentReferralAdapter.ViewHold>() {

    class ViewHold(val binder : AdapterChildReferralAgentBinding) : RecyclerView.ViewHolder(binder.root) {
        fun bindInfo(
            agentReferralActivity: AgentReferralActivity,
            model: SuccessfullyReferredAgent
        ) {
            binder.run {
                txtAgentName.text = when(model.agentName) {
                    null -> agentReferralActivity.getString(R.string.na)
                    else -> model.agentName
                }
                txtMtdSales.text = when(model.mtdSales) {
                    null -> default_zero
                    else -> NumberFormat.getNumberInstance(Locale.getDefault()).format(model.mtdSales)
                }
                txtRegisDate.text = when(model.registeredDate) {
                    null -> agentReferralActivity.getString(R.string.na)
                    else -> model.registeredDate
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHold {
        val binder : AdapterChildReferralAgentBinding = AdapterChildReferralAgentBinding.inflate(
            LayoutInflater.from(agentReferralActivity),
            parent,
            false
        )
        return ViewHold(binder)
    }

    override fun onBindViewHolder(holder: ViewHold, position: Int) {
        holder.bindInfo(
            agentReferralActivity = agentReferralActivity,
            model = list[position]
        )
    }

    override fun getItemCount(): Int {
        return list.size
    }

    interface OnAgentReferral {
        fun onAgentReferralClick( model : SuccessfullyReferredAgent)
    }
}