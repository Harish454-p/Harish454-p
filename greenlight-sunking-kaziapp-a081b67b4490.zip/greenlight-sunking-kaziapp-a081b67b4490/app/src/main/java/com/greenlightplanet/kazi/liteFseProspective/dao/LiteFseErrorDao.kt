package com.greenlightplanet.kazi.liteFseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseError
import io.reactivex.Single

@Dao
interface LiteFseErrorDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(liteFseError: List<LiteFseError>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(liteFseError: LiteFseError): Long

    @Delete
    fun delete(liteFseError: LiteFseError): Int

    @Query("DELETE FROM LiteFseError")
    fun deleteAll(): Int

    @Query("SELECT * FROM LiteFseError")
    fun getAll(): Single<List<LiteFseError>>

    @Query("SELECT * FROM LiteFseError LIMIT 1")
    fun get(): Single<LiteFseError>

    @Query("SELECT COUNT(*) from LiteFseError")
    fun count(): Single<Int>

    @Query("SELECT * FROM LiteFseError WHERE prospectId=:prospectId LIMIT 1")
    fun getByProspectId(prospectId: String): Single<LiteFseError>?

    @Query("SELECT * FROM LiteFseError WHERE prospectID IN (:prospectId)")
    fun getAllByProspectId(prospectId: List<String>): Single<List<LiteFseError>?>


    @Query("DELETE FROM LiteFseError where prospectID LIKE :prospectId")
    fun deleteProspectById(prospectId: String)
}
