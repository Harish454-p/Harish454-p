package com.greenlightplanet.kazi.dashboard.model.call_sms


import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "SmsRequest")
data class SmsRequest(
		@PrimaryKey(autoGenerate = true)
		var id: Long? = null, // test message
		@SerializedName("msg")
		var msg: String?, // test message
		@SerializedName("number")
		var number: String?, // 1234
		@SerializedName("to_number")
		var toNumber: String?,
		@SerializedName("time")
		var time: String?, // 1613051325

		@SerializedName("uploadedToServer")
		var uploadedToServer: Boolean = false // UPDATED
)
