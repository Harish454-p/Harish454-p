package com.greenlightplanet.kazi.fse.ui


import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Toast
import androidx.navigation.ActionOnlyNavDirections
import androidx.navigation.Navigation.findNavController
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentFseCommitmentBinding
import com.greenlightplanet.kazi.databinding.HeaderFseCommitmentBinding
import com.greenlightplanet.kazi.fse.extras.custom.CustomProgress
import com.greenlightplanet.kazi.fse.extras.util.DateConversionUtil.Companion.validToSubmitCommitment
import com.greenlightplanet.kazi.fse.extras.util.IOnBackPressed
import com.greenlightplanet.kazi.fse.extras.util.SortAttrFseCommitment.ATTR_CUSTOMER_NAME
import com.greenlightplanet.kazi.fse.extras.util.SortAttrFseCommitment.ATTR_DAYS_DISABLED
import com.greenlightplanet.kazi.fse.extras.util.SortAttrFseCommitment.ATTR_SELECTION
import com.greenlightplanet.kazi.fse.extras.util.SortType.ASCENDING
import com.greenlightplanet.kazi.fse.extras.util.SortType.DESCENDING
import com.greenlightplanet.kazi.fse.model.Fse
import com.greenlightplanet.kazi.fse.model.FseDetailsResponse
import com.greenlightplanet.kazi.fse.ui.adapter.FseCommitmentAdapter
import com.greenlightplanet.kazi.fse.viewmodel.FseCommitmentViewModel
import com.greenlightplanet.kazi.task.model.response.incentiveModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.utilinterface.IDialogAction

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 *
 */
class FseCommitmentFragment : Fragment(), FseCommitmentAdapter.FseCommitmentAdapterCallback, IOnBackPressed {


  //  private lateinit var bindingHeader: HeaderFseCommitmentBinding

    private var _binding: FragmentFseCommitmentBinding? = null

    private val binding get() = _binding!!
    override fun onBackPressed(): Boolean {

        Log.d(TAG, "BACKPRESSED: ");
        /*return if (myCondition) {
            //action not popBackStack
            true
        } else {
            false
        }*/
        return true
    }


    companion object {
        public const val TAG = "FseCommitmentFragment"

        var CURRENT_SORT_ATTRIBUTE = ATTR_SELECTION
        var SORT_TYPE = ASCENDING
    }


    lateinit var viewModel: FseCommitmentViewModel
    var adapterList: MutableList<Fse> = mutableListOf()
    var searchList: MutableList<Fse> = mutableListOf()
    var baseActivity: BaseActivity? = null

    private lateinit var progressBar: CustomProgress
    var preference: GreenLightPreference? = null
    var adapter: FseCommitmentAdapter? = null

    var isTimePassed: Boolean = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        baseActivity = activity as BaseActivity
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
      //  val view = inflater.inflate(R.layout.fragment_fse_commitment, container, false)


        _binding = FragmentFseCommitmentBinding.inflate(inflater, container, false)


        progressBar = CustomProgress.getInstance(requireContext())

        preference = GreenLightPreference.getInstance(requireContext())

        viewModel = ViewModelProviders.of(this).get(FseCommitmentViewModel::class.java)

        baseActivity = activity as BaseActivity


        activity?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        isTimePassed = !validToSubmitCommitment()

        Log.d(TAG, "1 isTimePassed: $isTimePassed ");

        initData()

        return binding.root

    }


    fun initData() {

        Log.d(TAG, "TESTALPHA: ");
        activity?.findViewById<AppCompatTextView>(R.id.toolbar_title)?.setText("Disabled Accounts")

        //todo old but working
        /*viewModel.getFseCommitment(context!!, preference?.getLoginResponseModel()?.angazaId!!) {
            baseActivity?.showProgressDialog(context)
        }?.observe(this, Observer {
            //viewModel.getFseCommitment(progressBar, context!!, preference?.getLoginResponseModel()?.angazaId!!)?.observe(this, Observer {
            Log.d(TAG, "$it: ");
            baseActivity?.cancelProgressDialog()


            recyclerView.layoutManager = LinearLayoutManager(context)
            //recyclerView.setHasFixedSize(true)
            recyclerView.addItemDecoration(DividerItemDecoration(context!!, DividerItemDecoration.VERTICAL).apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider, context!!.theme))
                } else {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider))
                }
            })


            if (!(preference!!.getIsCommitmentConfirmed()!!)) {
                isTimePassed = false
            } else {
                isTimePassed = true
            }


            Log.d(TAG, "2isTimePassed: $isTimePassed ");


            submitButtonLogic(isTimePassed)

            adapterList.clear()
            adapterList.addAll(it?.toMutableList()!!)
            bySelection(adapterList!!, true)

        })


    }*/

        //todo new
        viewModel.getNewFseCommitment(requireContext(), preference?.getLoginResponseModel()?.angazaId!!) {
            baseActivity?.showProgressDialog(context)
        }?.observe(viewLifecycleOwner, Observer {
            it?.let {
                    sampleMethod(it)

            } ?: run {

                baseActivity?.cancelProgressDialog()
                viewModel.getNewFseCommitment(requireContext(), preference?.getLoginResponseModel()?.angazaId!!,forceOffline = true) {
                    baseActivity?.showProgressDialog(context)
                }?.observe(viewLifecycleOwner, Observer {
                    sampleMethod(it!!)
                })

            }
        })


    }

    //removed after some changes in project
    /*fun submitButtonLogic(isTimePassed: Boolean) {

        if (isTimePassed) {
            bt_submit.visibility = View.GONE
        } else {
            bt_submit.visibility = View.VISIBLE
        }
    }*/

    fun sampleMethod(it: FseDetailsResponse.ResponseData){

        //viewModel.getFseCommitment(progressBar, context!!, preference?.getLoginResponseModel()?.angazaId!!)?.observe(this, Observer {


        Log.d(TAG, "$it: ");
        baseActivity?.cancelProgressDialog()


       binding.recyclerView.layoutManager = LinearLayoutManager(context)
        //recyclerView.setHasFixedSize(true)
       binding.recyclerView.addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                this.setDrawable(resources.getDrawable(R.drawable.line_divider, requireContext().theme))
            } else {
                this.setDrawable(resources.getDrawable(R.drawable.line_divider))
            }
        })


        if (!(preference!!.getIsCommitmentConfirmed()!!)) {
            isTimePassed = false
        } else {
            isTimePassed = true
        }


        Log.d(TAG, "2isTimePassed: $isTimePassed ");


        //submitButtonLogic(isTimePassed)

        adapterList.clear()

        it?.let {
            it.fseList?.let {

                //todo imporove this
                adapterList.addAll(it.filterNotNull())
            }
        }

        bySelection(adapterList!!, true)


    }

    override fun onResume() {
        super.onResume()
        //progressBar.showProgressDialog()


        sortClickHandler()


        Log.d(TAG, "3isTimePassed:$isTimePassed ");
        //submitButtonLogic(isTimePassed)


       binding.btSubmit.setOnClickListener {

            //if (submitValidation()) {

            //todo show dialog box of number of selected item for confirmation
            val selectedList = adapterList?.filter { it.isSubmitted }

            //selectedList?.let {

            if (selectedList!!.isNotEmpty()) {


                Util.showDialog(requireContext(), object : IDialogAction {
                    override fun onActionDone() {

                        selectedList?.forEach { it.commitmentDate = Util.getDateYYYYMMDD() }

                        //if (BuildConfig.DEBUG) {
                        //Toast.makeText(context, "Total ${selectedList?.size} item selected", Toast.LENGTH_LONG).show()
                        //}


                        //todo add todays date in commitmentDate
                        selectedList?.let {
                            Log.d(TAG, "submit value: $it");
                            onSubmit(it)
                        }

                    }

                    override fun onActionCancel() {
                    }

                }, "Are you sure you want to submit ${selectedList.size} commitments?", true)


            } else {

                Toast.makeText(context, "Please select atleast 1 customer", Toast.LENGTH_LONG).show()

            }

            //}


            //}


        }

        binding.btViewPast.setOnClickListener {

            //goto PastFseCommitmentFragment
            findNavController(requireView()).navigate(ActionOnlyNavDirections(R.id.action_fseCommitmentFragment_to_pastFseCommitmentFragment))

        }

    }


    fun sortClickHandler() {


        binding.tvHeaderCustomerName.setOnClickListener {
            if (binding.tvNoData.visibility != View.VISIBLE) {


                /*if (tvNoData.visibility != View.VISIBLE) {
                byCustomerName(adapterList!!)
                }*/

                if (binding.etSearch.text.isNotEmpty()) {
                    byCustomerName(searchList)

                } else {
                    byCustomerName(adapterList!!)
                }

            }
        }

        binding.tvHeaderDaysDisabled.setOnClickListener {
            /*if (tvNoData.visibility != View.VISIBLE) {
            byDaysDisabled(adapterList!!)
            }*/

            if (binding.etSearch.text.isNotEmpty()) {
                byDaysDisabled(searchList)

            } else {
                byDaysDisabled(adapterList!!)
            }
        }

        binding.tvHeaderSelection.setOnClickListener {
            /*if (tvNoData.visibility != View.VISIBLE) {
            bySelection(adapterList!!)
            }*/

            if (binding.etSearch.text.isNotEmpty()) {
                bySelection(searchList)
            } else {
                bySelection(adapterList!!)

            }
        }


    }

    private fun onSubmit(fseList: List<Fse>) {


        /*viewModel.postFseCommitment(preference?.getLoginResponseModel()?.angazaId!!, fseList) { baseActivity?.showProgressDialog(context) }.observe(this, Observer {
            //viewModel.postFseCommitment(progressBar, preference?.getLoginResponseModel()?.angazaId!!, fseList).observe(this, Observer {
            Log.d(TAG, "$it: ");

            //progressBar.cancelProgressDialog()
            baseActivity?.cancelProgressDialog()

            Log.d(TAG, "samosa: " + (preference!!.getIsCommitmentConfirmed()))
            if (!(preference!!.getIsCommitmentConfirmed()!!)) {
                Toast.makeText(context, "${fseList.size} commitments have been submitted", Toast.LENGTH_LONG).show()
                isTimePassed = false
            } else {
                Toast.makeText(context, "Submission time has passed", Toast.LENGTH_LONG).show()
                isTimePassed = true
            }


            submitButtonLogic(isTimePassed)

            //todo recheck the logic
            //if all data need to be replace or only which are in response
            //setAdapter(it?.toMutableList()!!)
            //bySelection(it?.toMutableList()!!)
            //adapterList = it?.toMutableList()!!

            adapterList.clear()
            adapterList.addAll(it?.toMutableList()!!)
            bySelection(adapterList!!, true)

        })*/

        viewModel.newPostFseCommitment(preference?.getLoginResponseModel()?.angazaId!!, fseList) { baseActivity?.showProgressDialog(context) }.observe(this, Observer {
            //viewModel.postFseCommitment(progressBar, preference?.getLoginResponseModel()?.angazaId!!, fseList).observe(this, Observer {
            Log.d(TAG, "$it: ");

            //progressBar.cancelProgressDialog()
            baseActivity?.cancelProgressDialog()

            Log.d(TAG, "samosa: " + (preference!!.getIsCommitmentConfirmed()))
            if (!(preference!!.getIsCommitmentConfirmed()!!)) {
//                Toast.makeText(context, "${fseList.size} commitments have been submitted", Toast.LENGTH_LONG).show()
                Util.customFseRationaleDialog(requireActivity(), "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = "${fseList.size} commitments have been submitted",
                        positveSelected = { it.dismiss() },
                        negativeSeleted = { it.dismiss() }
                )
                isTimePassed = false
            } else {
                Util.customFseRationaleDialog(requireActivity(), "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = "Submission time has passed",
                        positveSelected = { it.dismiss() },
                        negativeSeleted = { it.dismiss() }
                )
//                Toast.makeText(context, "Submission time has passed", Toast.LENGTH_LONG).show()
                isTimePassed = true
            }


            //submitButtonLogic(isTimePassed)

            //todo recheck the logic
            //if all data need to be replace or only which are in response
            //setAdapter(it?.toMutableList()!!)
            //bySelection(it?.toMutableList()!!)
            //adapterList = it?.toMutableList()!!

            adapterList.clear()

            it?.let {
                it.fseList?.let {

                    //todo imporove this
                    adapterList.addAll(it.filterNotNull())
                }
            }
            bySelection(adapterList!!, true)

        })

    }

    private fun setAdapter(list: MutableList<Fse>, isTimePassed: Boolean) {

        if (list.isNullOrEmpty()) {

            Log.d(TAG, "isNullOrEmpty: $list")

        } else {

            Log.d(TAG, "Not isNullOrEmpty: $list")

            adapter = FseCommitmentAdapter(requireContext(), list, isTimePassed)
            adapter?.eoAdapterCallback = this

            if (binding.recyclerView?.adapter == null) {
                binding.etSearch.addTextChangedListener(textWatcher)
            }
            binding.recyclerView?.adapter = adapter
            adapter?.notifyDataSetChanged()

        }
    }


    fun byCustomerName(mutableList: MutableList<Fse>) {

        if (CURRENT_SORT_ATTRIBUTE != ATTR_CUSTOMER_NAME) {
            SORT_TYPE = ASCENDING
        }

        CURRENT_SORT_ATTRIBUTE = ATTR_CUSTOMER_NAME

        refreshSortBackground()

        if (mutableList.size > 0) {
            binding.tvNoData.visibility = View.GONE
            binding.recyclerView.visibility = View.VISIBLE

            setAdapter(viewModel.customerNameSortLogic(mutableList), isTimePassed)

            changeHeaderSortColor()

        } else {
            binding.tvNoData.visibility = View.VISIBLE
            binding.recyclerView.visibility = View.INVISIBLE
        }
    }


    fun byDaysDisabled(mutableList: MutableList<Fse>) {

        if (CURRENT_SORT_ATTRIBUTE != ATTR_DAYS_DISABLED) {
            SORT_TYPE = ASCENDING
        }

        CURRENT_SORT_ATTRIBUTE = ATTR_DAYS_DISABLED

        refreshSortBackground()

        if (mutableList.size > 0) {
            binding.tvNoData.visibility = View.GONE
            binding.recyclerView.visibility = View.VISIBLE

            setAdapter(viewModel.daysDisabledSortLogic(mutableList), isTimePassed)

            changeHeaderSortColor()

        } else {
           binding.tvNoData.visibility = View.VISIBLE
            binding.recyclerView.visibility = View.INVISIBLE
        }
    }


    fun bySelection(mutableList: MutableList<Fse>, showForceAscendingSelection: Boolean = false) {

        if (showForceAscendingSelection) {
            SORT_TYPE = DESCENDING
        } else {
            if (CURRENT_SORT_ATTRIBUTE != ATTR_SELECTION) {
                SORT_TYPE = ASCENDING
            }
        }


        CURRENT_SORT_ATTRIBUTE = ATTR_SELECTION

        refreshSortBackground()

        if (mutableList.size > 0) {
            binding.tvNoData.visibility = View.GONE
            binding.recyclerView.visibility = View.VISIBLE

            setAdapter(viewModel.selectionSortLogic(mutableList), isTimePassed)

            changeHeaderSortColor()

        } else {
            binding.tvNoData.visibility = View.VISIBLE
            binding.recyclerView.visibility = View.INVISIBLE
        }
    }


    private fun changeHeaderSortColor() {

        when (CURRENT_SORT_ATTRIBUTE) {
            ATTR_CUSTOMER_NAME -> binding.tvHeaderCustomerName.setBackgroundColor(Color.GRAY)
            ATTR_DAYS_DISABLED -> binding.tvHeaderDaysDisabled.setBackgroundColor(Color.GRAY)
            ATTR_SELECTION -> binding.tvHeaderSelection.setBackgroundColor(Color.GRAY)
        }
    }


    private fun refreshSortBackground() {
        binding.tvHeaderCustomerName?.setBackgroundColor(Color.BLACK)
        binding.tvHeaderDaysDisabled?.setBackgroundColor(Color.BLACK)
        binding.tvHeaderSelection?.setBackgroundColor(Color.BLACK)
    }


    override fun onChecked(accountNumber: String, position: Int, isChecked: Boolean) {
        Log.d(TAG, "onChecked: accountNumber = $accountNumber || position = $position || isChecked = $isChecked");
        val changedAdapter = adapterList.filter { it.accountNumber == accountNumber }?.get(0)
        changedAdapter?.isSubmitted = isChecked
        //adapterList?.get(position)?.isSubmitted = isChecked
        adapter?.notifyItemChanged(position)

    }


    private var textWatcher = object : TextWatcher {

        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
        override fun afterTextChanged(s: Editable) {

            val filterList = viewModel.searchLogic(s.toString(), adapterList!!)

            val mutablePostList: MutableLiveData<List<Fse>> = MutableLiveData()

            mutablePostList.value = filterList



            mutablePostList.observe(
                    this@FseCommitmentFragment, Observer {


                it?.let {
                    //region search result sort logic
                    if (SORT_TYPE == ASCENDING) {
                        SORT_TYPE = DESCENDING
                    } else {
                        SORT_TYPE = ASCENDING
                    }
                    //endregion

                    searchList.clear()
                    searchList.addAll(it)

                    when (CURRENT_SORT_ATTRIBUTE) {

                        /*ATTR_CUSTOMER_NAME -> byCustomerName(it.toMutableList())
                        ATTR_DAYS_DISABLED -> byDaysDisabled(it.toMutableList())
                        ATTR_SELECTION -> bySelection(it.toMutableList())*/


                        ATTR_CUSTOMER_NAME -> byCustomerName(searchList.toMutableList())
                        ATTR_DAYS_DISABLED -> byDaysDisabled(searchList.toMutableList())
                        ATTR_SELECTION -> bySelection(searchList.toMutableList())

                    }
                }

            }
            )
        }

    }


    override fun onDestroy() {
        progressBar.cancelProgressDialog()
        progressBar.destroy()
        super.onDestroy()
    }
}
