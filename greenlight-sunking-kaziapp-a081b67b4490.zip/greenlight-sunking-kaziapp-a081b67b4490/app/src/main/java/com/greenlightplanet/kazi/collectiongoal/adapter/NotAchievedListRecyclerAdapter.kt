package com.greenlightplanet.kazi.collectiongoal.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.Keep
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.collectiongoal.model.pastweekincentive.LastWeekIncentiveModel
import com.greenlightplanet.kazi.databinding.PastweekIncentiveItemLayoutBinding
import com.greenlightplanet.kazi.utils.Util

@Keep
class NotAchievedListRecyclerAdapter
constructor(private val context: Context,
            private var values: List<LastWeekIncentiveModel.AchievedAccount>)
        : RecyclerView.Adapter<NotAchievedListRecyclerAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotAchievedListRecyclerAdapter.ViewHolder {

        val itemBinding = PastweekIncentiveItemLayoutBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: NotAchievedListRecyclerAdapter.ViewHolder, position: Int) {
        val task = values[position]
        holder.bind(task, holder.itemView)
    }

    override fun getItemCount(): Int {

        Log.d("LWIncetiveAdpListSize",values.size.toString())
       return values.size
    }

    inner class ViewHolder(val itemBinding: PastweekIncentiveItemLayoutBinding)
        : RecyclerView.ViewHolder(itemBinding.root) {

        fun bind(task: LastWeekIncentiveModel.AchievedAccount, itemView: View) {

            itemBinding.tvCustomerName.text = task.customerName
            itemBinding.tvCollectedAmount.text = "${Util.formatAmount(task.collectedAmount?.toDouble() ?: 0.0)}"
            itemBinding.tvExpectedAmount.text = "${Util.formatAmount(task.expectedAmount?.toDouble() ?: 0.0)}"

        }

    }


    // method for filtering our recyclerview items.
    fun filterList(filterlist: ArrayList<LastWeekIncentiveModel.AchievedAccount>) {
        // below line is to add our filtered
        // list in our course array list.
        values = filterlist
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged()
    }
}