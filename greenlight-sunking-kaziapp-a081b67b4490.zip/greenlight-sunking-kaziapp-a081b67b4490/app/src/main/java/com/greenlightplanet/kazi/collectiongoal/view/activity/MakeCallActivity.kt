package com.greenlightplanet.kazi.collectiongoal.view.activity

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.Keep
import androidx.lifecycle.Observer
import androidx.lifecycle.distinctUntilChanged
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import com.google.gson.Gson
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.collectiongoal.adapter.MakeCallPagerAdapter
import com.greenlightplanet.kazi.collectiongoal.extra.MakeCallCustomerFilterDialog
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.collectiongoal.view.fragment.MakeCallBottomSheetSearch
import com.greenlightplanet.kazi.collectiongoal.viewmodel.MakeCallViewModel
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityMakeCallBinding
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.summary.model.SummaryModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util

@Keep
class MakeCallActivity : BaseActivity(),
    /*MakeCallBottomSheetSearch.MakeCallBottomSheetSearchCallback,*/
    MakeCallCustomerFilterDialog.MakeCallCustomerDialogCallbacks {

    lateinit var binding: ActivityMakeCallBinding

    val TAG = "MakeCallActivity"
    var preference: GreenLightPreference? = null
    var isFromNotification = false
    var loginResponseData: LoginResponseModel? = null

    var makeCallNewModel: MakeCallNewModel? = null

    private val viewModel: MakeCallViewModel by viewModels()

    private var pendingAdapterList = mutableListOf<MakeCallNewModel.ColGoalAccount>()
    private var completedAdapterList = mutableListOf<MakeCallNewModel.ColGoalAccount>()

    private var viewPagerPagerAdapter: MakeCallPagerAdapter? = null

    var summaryModel: SummaryModel? = null

    var bundle = Bundle()

    var loginResponseModel: LoginResponseModel? = null
    var fragmentType: Boolean? = true

    var commonList1 = mutableListOf<String>()
    var filterList = mutableListOf<String>()

    var selectedAccountStatus: Int = 0
    var selectedProductGroup: Int = 0
    var selectedLastCalled: Int = 0
    var selectedIsInTaskStatus: Int = 0

    var selectedMaxDateString: String? = null

    private var pendingPageNumber: Int? = null
    private var completedPageNumber: Int? = null

    private var doneAccount: Int = 0
    private var targetAccount: Int = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMakeCallBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (intent.hasExtra("fromNotification")) {
            isFromNotification = intent.getBooleanExtra("fromNotification", false)
        }

        /** Funtion For Getting Date according to passed value */

//        val cDate = DateConversionUtil.getTimeAsPerPosition(0)
//        val lDate = DateConversionUtil.getTimeAsPerPosition(2)
//        Log.d("CheckingDate", "${cDate} $lDate")


        initialize()

        binding.ivFilter.setOnClickListener {
            showFilterDialog()
        }
    }

    private fun showFilterDialog() {
        Log.d("FilterButton", "onClicked")
        MakeCallCustomerFilterDialog(
            this, filterList, selectedAccountStatus, selectedProductGroup,
            selectedLastCalled, selectedIsInTaskStatus, this
        ).show()

    }

    @SuppressLint("SetTextI18n")
    fun initialize() {
        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        Util.setToolbar(this, this.binding.toolbar)
        preference = GreenLightPreference.getInstance(this)
        loginResponseModel = preference?.getLoginResponseModel()

        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this)
        binding.tvTaskLastSaved.text = data?.makeCallSaved

        bundle = intent.extras!!
        summaryModel = intent.extras!!.getParcelable("collectionCommonWeek")

        Log.d("CheckDoneTargetData1",
            "DoneAccount ${summaryModel?.collectionGoalCurrentWeek?.doneAccount} " +
                    "+\n+ TargetAccount ${summaryModel?.collectionGoalCurrentWeek?.targetAccount}")

        when (summaryModel?.collectionGoalCurrentWeek?.doneAccount) {
            null -> doneAccount = 0
            0 -> doneAccount = 0
            else -> doneAccount = summaryModel?.collectionGoalCurrentWeek?.doneAccount!!
        }

        when (summaryModel?.collectionGoalCurrentWeek?.targetAccount) {
            null -> targetAccount = 0
            0 -> targetAccount = 0
            else -> targetAccount = summaryModel?.collectionGoalCurrentWeek?.targetAccount!!
        }

        binding.tvtargetAccounts.text = "$doneAccount/$targetAccount"

        setupTabLayout()
        getMakeCallData(1)
        initSearchView()

        binding.tvBottom.setOnClickListener {

            if (Util.isOnline(this)) {
                if (pendingPageNumber != 0 || pendingPageNumber != null) {
                    getMakeCallData(pendingPageNumber)
                }
            } else {
                Util.customFseCompletionDialog(
                    context = this,
                    hideTitle = true,
                    message = "Please check internet connection",
                    okSelected = {
                        it.dismiss()
                    },
                    title = null
                )
            }
        }

    }

    private fun initSearchView() {
        binding.ivSearch.setOnClickListener {

            //Log.d("MakeCallListSearch", "success: ${viewpagerAdapterList}")

            val dataList = mutableListOf<MakeCallNewModel.ColGoalAccount>()
            dataList.addAll(pendingAdapterList)
            dataList.addAll(completedAdapterList)

            val makeCallBottomSheetSearch: MakeCallBottomSheetSearch =
                MakeCallBottomSheetSearch.newInstance(dataList)
//            makeCallBottomSheetSearch.makeCallBottomSheetSearchCallback = this
            makeCallBottomSheetSearch.show(
                supportFragmentManager,
                "Make_Call_Bottom_Sheet_Search"
            )
        }
    }

    @SuppressLint("LongLogTag")
    private fun getMakeCallData(pageNumber: Int?) {

        showProgressDialog(this)

        viewModel.getMakeCalldata(pageNumber)?.distinctUntilChanged()?.observe(this, Observer { it ->

            cancelProgressDialog()

            Log.d("CheckPageNumberCameFromServer", it.responseData?.next.toString())
            Log.e("CheckPageNumberBothFragments",
                "Pending: $pendingPageNumber " + "Completed: $completedPageNumber")

            if (!it.responseData?.accounts.isNullOrEmpty()) {


                Log.e("CheckListSizeForBothFragments",
                    "PendingListDekhRaha: ${it.responseData?.accounts?.filter { !it.isAchieved }?.size} "
                            + "CompletedListDekhRaha: $${it.responseData?.accounts?.filter { it.isAchieved }?.size}")

                binding.tvNoData.visibility = View.GONE
                binding.tabLayout.visibility = View.VISIBLE
                makeCallNewModel = it.responseData

                //updateFragmentsList()

                setAdapter(makeCallNewModel!!)

//                val data = MutableLiveData<NewCommonResponseModel<MakeCallNewModel>>()
//
//                Log.d("PendingAdapterList", pendingAdapterList.size.toString())
//                Log.d("CompletedAdapterList", completedAdapterList.size.toString())

//                if (!pendingAdapterList.isNullOrEmpty() ||
//                    !completedAdapterList.isNullOrEmpty()
//                ) {
//
//                    Log.d("CheckpageNumber1", it.responseData!!.next.toString())
//                    val list = it.responseData?.accounts?.toMutableList()
//                    val dataList = mutableListOf<MakeCallNewModel.ColGoalAccount>()
//                    dataList.addAll(pendingAdapterList)
//                    dataList.addAll(completedAdapterList)
//                    list?.clear()
//                    list?.addAll(dataList)
//                    it.responseData?.accounts = emptyList()
//                    it.responseData?.accounts = list!!
////                    viewModel.insertFullWeeklyTargetResponseToDb(it, data)
//                    setAdapter(it.responseData!!)
//                }

            } else {
                //handle error here
                Util.showToast(this, it.error?.messageToUser.toString())
                binding.tvBottom.visibility = View.GONE
                binding.tabLayout.visibility = View.VISIBLE
            }

        })
    }

    @SuppressLint("NotifyDataSetChanged", "SetTextI18n", "LongLogTag")
    private fun setAdapter(makeCallNewModel: MakeCallNewModel) {

        cancelProgressDialog()
        Log.d("CheckpageNumber2", makeCallNewModel.next.toString())
        Log.d("CheckFragmentTypeAgain", "FragmentType: ${fragmentType}")

        Log.d("ViewPagerListSizeChecking", "success: ${makeCallNewModel.accounts?.size}")

        commonList1.clear()

        commonList1 = makeCallNewModel.accounts.map { it.productName } as MutableList<String>

        filterList.clear()

        commonList1.add(0, "All")

        filterList = removeExtraString(commonList1)

        Log.d("FilteredList", "success: ${filterList}")


        if (viewPagerPagerAdapter == null) {

            pendingAdapterList.clear()
            completedAdapterList.clear()

            pendingAdapterList.addAll(makeCallNewModel.accounts
                .filter { !it.isAchieved }.toMutableList())

            completedAdapterList.addAll(makeCallNewModel.accounts
                .filter { it.isAchieved }.toMutableList())


            val size = pendingAdapterList.size + completedAdapterList.size
            binding.textView10.text = "Weekly Target Account ($size)"
            binding.tabLayout.getTabAt(1)?.text =
                getString(R.string.completed) + "(${completedAdapterList.size})"
            binding.tabLayout.getTabAt(0)?.text =
                getString(R.string.pending) + "(${pendingAdapterList.size})"

            if (makeCallNewModel.next == 0 || makeCallNewModel.next == null) {
                binding.tvBottom.visibility = View.GONE
                pendingPageNumber = 0
            } else {
                binding.tvBottom.visibility = View.VISIBLE
                pendingPageNumber = makeCallNewModel.next
            }

            Log.d("$TAG", "completedAdapterList: ${completedAdapterList.size}")
            Log.d("$TAG", "pendingAdapterList: ${pendingAdapterList.size}")

            viewPagerPagerAdapter = MakeCallPagerAdapter(
                supportFragmentManager,
                completedAdapterList,
                pendingAdapterList,
                makeCallNewModel
            )
            binding.viewpager.adapter = viewPagerPagerAdapter
        }

        else {
            Log.d("CheckpageNumber22", makeCallNewModel.next.toString())
            Log.d("CheckFragmentTypeAgain2", "FragmentType: ${fragmentType}")
            //binding.viewpager.adapter?.notifyDataSetChanged()


            if (!makeCallNewModel.accounts.filter { !it.isAchieved }.isNullOrEmpty()){
                pendingAdapterList.clear()
                pendingAdapterList.addAll(makeCallNewModel.accounts
                    .filter { !it.isAchieved }.toMutableList())

                Log.d("PendingAdapterList", pendingAdapterList.size.toString())

                binding.tabLayout.getTabAt(0)?.text =
                    getString(R.string.pending) + "(${pendingAdapterList.size})"

                if (makeCallNewModel.next == 0 || makeCallNewModel.next == null) {
//                    Util.showToast(this.resources.getString(R.string.no_data_available), this)
                    binding.tvBottom.visibility = View.GONE
                    pendingPageNumber = 0
                } else {
                    binding.tvBottom.visibility = View.VISIBLE
                    pendingPageNumber = makeCallNewModel.next
                }

                if (selectedLastCalled == 0 && selectedProductGroup == 0
                    && selectedAccountStatus == 0 && selectedIsInTaskStatus == 0) {

                    binding.ivFilter.setColorFilter(Color.parseColor("#FFFFFF"))

                    viewModel.updatePendingFragment(pendingAdapterList)
                }
                else {
                    binding.ivFilter.setColorFilter(Color.parseColor("#FFFF33"))
                    onFilter(
                        selectedLastCalled,
                        selectedProductGroup,
                        selectedAccountStatus,
                        selectedIsInTaskStatus,
                        selectedMaxDateString
                    )
                }

            }
            else {
                if (makeCallNewModel.next == 0 || makeCallNewModel.next == null) {
//                    Util.showToast(this.resources.getString(R.string.no_data_available), this)
                    binding.tvBottom.visibility = View.GONE
                    pendingPageNumber = 0
                } else {
                    binding.tvBottom.visibility = View.VISIBLE
                    pendingPageNumber = makeCallNewModel.next
                }
            }

            if (!makeCallNewModel.accounts.filter { it.isAchieved }.isNullOrEmpty()){

                completedAdapterList.clear()
                completedAdapterList.addAll(makeCallNewModel.accounts.filter { it.isAchieved }
                    .toMutableList())

                Log.d("CompletedAdapterList", completedAdapterList.size.toString())

                binding.tabLayout.getTabAt(1)?.text =
                    getString(R.string.completed) + "(${completedAdapterList.size})"

                if (makeCallNewModel.next == 0 || makeCallNewModel.next == null) {
//                    Util.showToast(this.resources.getString(R.string.no_data_available), this)
                    binding.tvBottom.visibility = View.GONE
                    pendingPageNumber = 0
                } else {
                    binding.tvBottom.visibility = View.VISIBLE
                    pendingPageNumber = makeCallNewModel.next
                }

                viewModel.updateCompletedFragment(completedAdapterList)

            }
            else {
                if (makeCallNewModel.next == 0 || makeCallNewModel.next == null) {
//                    Util.showToast(this.resources.getString(R.string.no_data_available), this)
                    binding.tvBottom.visibility = View.GONE
                    pendingPageNumber = 0
                } else {
                    binding.tvBottom.visibility = View.VISIBLE
                    pendingPageNumber = makeCallNewModel.next
                }
            }

            val size = pendingAdapterList.size + completedAdapterList.size
            binding.textView10.text = "Weekly Target Account ($size)"
        }
    }

    private fun setupTabLayout() {

        binding.tabLayout.apply {
            addTab(
                this.newTab().setText(
                    getString(R.string.pending)
                    /** +" (" + CommonList.filter { !it.isAchieved }.size.toString() + ")" **/
                )
            )
            addTab(
                this.newTab().setText(
                    getString(R.string.completed)
                    /** +" (" + CommonList.filter { it.isAchieved }.size.toString() + ")" **/
                )
            )

            tabGravity = TabLayout.GRAVITY_FILL

            addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab) {
                    binding.viewpager.currentItem = tab.position
                    fragmentType = tab.position == 0


                    when (fragmentType) {
                        true -> {
                            binding.ivFilter.visibility = View.VISIBLE
                        }
                        false -> {
                            binding.ivFilter.visibility = View.GONE
                        }
                        else -> {}
                    }

                    Log.d("SelectedTab2", fragmentType.toString())
                }

                override fun onTabUnselected(tab: TabLayout.Tab?) {
                }

                override fun onTabReselected(tab: TabLayout.Tab?) {
                }
            })

            binding.viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {

                override fun onPageScrollStateChanged(p0: Int) {}

                override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {}

                override fun onPageSelected(p0: Int) {
                    Log.d("SelectedTab1", p0.toString())

                    binding.tabLayout.getTabAt(p0)?.select()

                }
            })
        }
    }

    private fun removeExtraString(commonList1: MutableList<String>): MutableList<String> {

        val commonList2 = mutableListOf<String>()

        for (item in commonList1) {

            if (!item.isNullOrEmpty()) {

                val k: Int = item.indexOf(" ", item.indexOf(" ") + 1)

                if (k <= 0) {
                    commonList2.add(item)
                } else {
                    val res: String = item.substring(0, k)
                    commonList2.add(res)
                }
            }
        }

        val newList = commonList2.distinct()

        return newList.toMutableList()
    }

    /* override fun gotoNewTaskProfile(position: Int, commonTaskModel: MakeCallNewModel.ColGoalAccount) {

     }

     override fun gotoNewTaskFeedback(position: Int, commonTaskModel: MakeCallNewModel.ColGoalAccount) {

     }

     override fun makeCall(position: Int, commonTaskModel: MakeCallNewModel.ColGoalAccount) {

     }

     override fun requestCallLogPermission(position: Int, commonTaskModel: MakeCallNewModel.ColGoalAccount) {

     }*/

    @SuppressLint("LongLogTag")
    override fun onFilter(
        lastCalled: Int,
        productGroup: Int,
        accountStatus: Int,
        isInTaskStatus: Int,
        selectedMaxDate: String?,
    ) {

        selectedLastCalled = lastCalled
        selectedProductGroup = productGroup
        selectedAccountStatus = accountStatus
        selectedMaxDateString = selectedMaxDate
        selectedIsInTaskStatus = isInTaskStatus

        Log.d(
            "MakeCallFilterDialog2",
            " $selectedLastCalled $selectedProductGroup " +
                    "$selectedAccountStatus $selectedIsInTaskStatus"
        )

        if (selectedLastCalled == 0 && selectedProductGroup == 0
            && selectedAccountStatus == 0 && selectedIsInTaskStatus == 0
        ) {
            binding.ivFilter.setColorFilter(Color.parseColor("#FFFFFF"))
        } else {
            binding.ivFilter.setColorFilter(Color.parseColor("#FFFF33"))
        }

        val dataList = mutableListOf<MakeCallNewModel.ColGoalAccount>()
        dataList.addAll(pendingAdapterList)
        dataList.addAll(completedAdapterList)

        //val pendingList = viewModel.getPendingTabList(viewpagerAdapterList) ?: mutableListOf()
        val firstFilter = mutableListOf<MakeCallNewModel.ColGoalAccount>()
        val secondFilter = mutableListOf<MakeCallNewModel.ColGoalAccount>()
        val thirdFilter = mutableListOf<MakeCallNewModel.ColGoalAccount>()
        val fourthFilter = mutableListOf<MakeCallNewModel.ColGoalAccount>()


        /** Product Item Filter */

        if (selectedProductGroup != 0) {
            val value = filterList.get(selectedProductGroup)
            val filterProductList = viewModel.getProductFilter(value, pendingAdapterList)
            firstFilter.addAll(filterProductList)
        } else {
            firstFilter.addAll(pendingAdapterList)
        }

        /** Account Status Item Filter */

        if (selectedAccountStatus != 0) {

            if (selectedAccountStatus == 1) {
                val filterAccountList = viewModel.getAccountFilter("DISABLED", firstFilter)
                secondFilter.addAll(filterAccountList)
            } else {
                val filterAccountList = viewModel.getAccountFilter("ENABLED", firstFilter)
                secondFilter.addAll(filterAccountList)
            }
        } else {
            secondFilter.addAll(firstFilter)
        }

        val jsonElements2 = Gson().toJsonTree(secondFilter)
        Log.d("CheckingSecondFilterList", "$secondFilter")
        Log.d("jsonElements2", "$jsonElements2")

        /** Last Called Item Filter */

        if (selectedLastCalled != 0) {
            if (selectedLastCalled == 1 && selectedMaxDateString != null) {
                val filterAccountList = viewModel.getLastCalledFilter(
                    selectedMaxDateString.toString(),
                    secondFilter,
                    selectedLastCalled
                )
                thirdFilter.addAll(filterAccountList)
            } else if (selectedLastCalled == 2 && selectedMaxDateString != null) {
                val filterAccountList = viewModel.getLastCalledFilter(
                    selectedMaxDateString.toString(),
                    secondFilter,
                    selectedLastCalled
                )
                thirdFilter.addAll(filterAccountList)
            } else if (selectedLastCalled == 3 && selectedMaxDateString != null) {
                val filterAccountList = viewModel.getLastCalledFilter(
                    selectedMaxDateString.toString(),
                    secondFilter,
                    selectedLastCalled
                )
                thirdFilter.addAll(filterAccountList)
            } else if (selectedLastCalled == 4 && selectedMaxDateString != null) {
                val filterAccountList = viewModel.getLastCalledFilter(
                    selectedMaxDateString.toString(),
                    secondFilter,
                    selectedLastCalled
                )
                thirdFilter.addAll(filterAccountList)
            }
        } else {
            thirdFilter.addAll(secondFilter)
        }

        val jsonElements3 = Gson().toJsonTree(thirdFilter)

        Log.d("CheckingFinalFIlterList", "$thirdFilter")
        Log.d("jsonElements2", "$jsonElements3")

        /** Is In Task Status Item Filter */

        if (selectedIsInTaskStatus != 0) {

            if (selectedIsInTaskStatus == 1) {
                val filterIsInTaskList = viewModel.getIsInTaskStatusFilter(true, thirdFilter)
                fourthFilter.addAll(filterIsInTaskList)
            } else {
                val filterIsInTaskList = viewModel.getIsInTaskStatusFilter(false, firstFilter)
                fourthFilter.addAll(filterIsInTaskList)
            }
        } else {
            fourthFilter.addAll(thirdFilter)
        }

        val jsonElements4 = Gson().toJsonTree(thirdFilter)

        Log.d("CheckingFinalFIlterList", "$fourthFilter")
        Log.d("jsonElements2", "$jsonElements4")


        binding.tabLayout.getTabAt(0)?.text =
            getString(R.string.pending) + " (" + fourthFilter.size.toString() + ")"

        val size = fourthFilter.size + completedAdapterList.size

        binding.textView10.text = "Weekly Target Account ($size)"

        viewModel.updatePendingFragment(fourthFilter)

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    override fun onBackPressed() {
        onBackPressedDispatcher.onBackPressed()
        finish()
    }

    override fun onResume() {
        super.onResume()
    }


}