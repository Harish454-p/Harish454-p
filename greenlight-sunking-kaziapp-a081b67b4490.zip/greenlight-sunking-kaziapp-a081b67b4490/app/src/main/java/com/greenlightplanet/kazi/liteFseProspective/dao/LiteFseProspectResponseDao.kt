package com.greenlightplanet.kazi.liteFseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import io.reactivex.Single

@Dao
interface LiteFseProspectResponseDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(liteFseProspectResponseModel: List<LiteFseProspectResponseModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(liteFseProspectResponseModel: LiteFseProspectResponseModel): Long

    @Delete
    fun delete(liteFseProspectResponseModel: LiteFseProspectResponseModel): Int

    @Query("DELETE FROM LiteFseProspectResponseModel")
    fun deleteAll(): Int

    @Query("SELECT * FROM LiteFseProspectResponseModel")
    fun getAll(): Single<List<LiteFseProspectResponseModel>>


    @Query("SELECT * FROM LiteFseProspectResponseModel LIMIT 1")
    fun get(): Single<LiteFseProspectResponseModel>


    @Query("SELECT COUNT(*) from LiteFseProspectResponseModel")
    fun count(): Single<Int>


    //@Query("SELECT * FROM LiteFseProspectResponseModel WHERE prospectId=:prospectId")

    //@Query("SELECT * FROM LiteFseProspectResponseModel WHERE prospectId=:prospectId LIMIT 1")
    @Query("SELECT * FROM LiteFseProspectResponseModel WHERE prospectId LIKE :prospectId")
    fun getByProspectId(prospectId: String): Single<LiteFseProspectResponseModel>?

    @Query("SELECT * FROM LiteFseProspectResponseModel WHERE prospectId=:prospectId LIMIT 1")
    fun getBySingleProspectId(prospectId: String): Single<LiteFseProspectResponseModel>?

    @Query("SELECT * FROM LiteFseProspectResponseModel WHERE isChanged=1")
    fun getAllIsChanged(): Single<List<LiteFseProspectResponseModel>>
}
