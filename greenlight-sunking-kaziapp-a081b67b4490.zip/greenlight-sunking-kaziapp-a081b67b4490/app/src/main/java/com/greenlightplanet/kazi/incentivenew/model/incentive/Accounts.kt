package com.greenlightplanet.kazi.incentivenew.model.incentive

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Created by Rahul on 09/12/20.
 */

@Parcelize
@Entity
data class Accounts(

    @PrimaryKey
    @ColumnInfo
    @SerializedName("accountNumber") val accountNumber: Int,

    @ColumnInfo
    @SerializedName("registrationDate") val registrationDate: String?,

    @ColumnInfo
    @SerializedName("product") val product: String?,
    @ColumnInfo
    @SerializedName("incentiveEarned") val incentiveEarned: Int?,
    @ColumnInfo
    @SerializedName("isEligible") val isEligible: Boolean?

) : Parcelable