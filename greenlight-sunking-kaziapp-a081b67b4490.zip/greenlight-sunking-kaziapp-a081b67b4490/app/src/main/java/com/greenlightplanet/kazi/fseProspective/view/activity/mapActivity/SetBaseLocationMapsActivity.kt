package com.greenlightplanet.kazi.fseProspective.view.activity.mapActivity

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.google.gson.Gson
import com.google.gson.TypeAdapter
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.activity.EOIDActivity
import com.greenlightplanet.kazi.dashboard.model.FakeLocationRequest
import com.greenlightplanet.kazi.dashboard.model.request.BaselocationRequestModel
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivitySetBaseLocationMapsBinding
import com.greenlightplanet.kazi.fseProspective.viewmodel.ProspectiveViewModel
import com.greenlightplanet.kazi.networking.ErrorResponse
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import pl.charmas.android.reactivelocation2.ReactiveLocationProvider
import retrofit2.HttpException
import java.io.IOException

/*Not used*/
class SetBaseLocationMapsActivity : BaseActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private var circle: Circle? = null
    private var LAT: Double? = null
    private var LONG: Double? = null
    var mCurrLocationMarker: Marker? = null
    var mBaseLocationMarker: Marker? = null
    var data = MutableLiveData<Location>()
    private val bag: CompositeDisposable = CompositeDisposable()
    var CurrentLoc: LatLng? = null
    var radius: Int = 0
    var acc = 0.0

    var markerAdded = false


    val TAG = "SetBaseLocationMaps"

    var preference: GreenLightPreference? = null
    var loginResponseData: LoginResponseModel? = null
    private lateinit var binding: ActivitySetBaseLocationMapsBinding
    var currentLocation: Location? = null

    lateinit var viewModel: ProspectiveViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_set_base_location_maps)
        binding = ActivitySetBaseLocationMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProviders.of(this).get(ProspectiveViewModel::class.java)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        preference = GreenLightPreference.getInstance(this)

        if (intent.hasExtra("radius")) {
            radius = intent.getIntExtra("radius", 0)
        }

        //radius = Util.getProspectDistance(this,preference?.getLoginResponseModel()?.country!!)?.mapCircleRadius?.toDouble()!!

        loginResponseData = preference?.getLoginResponseModel()
        binding.btnSetBaseLoc.setOnClickListener {

            bag.clear()

            if (LAT != null || LONG != null) {
                if (preference?.getFakeLocationSolution() == true) {
                    if (currentLocation?.isFromMockProvider == false && !Util.isMockLocationEnabled(
                            this
                        )
                    ) {
                        postBaseLocationToServer()
                    } else {
                        getFakeGpsDialog()
                    }
                } else {
                    postBaseLocationToServer()
                }

            } else {
//                Toast.makeText(this, "Click to set base location!", Toast.LENGTH_SHORT).show()
                Util.customFseRationaleDialog(this, "",
                    hideNegative = true,
                    titleSpanned = null,
                    hideTitle = true,
                    message = getString(R.string.click_to_set_base_location),
                    positveSelected = {
                        it.dismiss()
                    },
                    negativeSeleted = {
                        it.dismiss()
                    }
                )

            }


        }




        binding.myLocation.setOnClickListener {

            if (CurrentLoc != null) {
                if (preference?.getFakeLocationSolution() == true) {
                    if (currentLocation?.isFromMockProvider == false && !Util.isMockLocationEnabled(
                            this
                        )
                    ) {

                        setBaseLocationMarker(CurrentLoc!!.latitude, CurrentLoc!!.longitude)
                    } else {
                        getFakeGpsDialog()
                        sendFakeLocationToServer()
                    }
                } else {

                    setBaseLocationMarker(CurrentLoc!!.latitude, CurrentLoc!!.longitude)

                }
            } else {
//                Toast.makeText(this, "Current location not found!", Toast.LENGTH_SHORT).show()

            }

        }

    }

    private fun getFakeGpsDialog() {

        Util.customFakeLocationDialog(
            context = this,
            message = resources.getString(R.string.fakeLocation),
            positiveText = resources.getString(R.string.ok_label),
            negetiveText = resources.getString(R.string.cancel),
            poitiveSelected = {
                //add logic
                finish()
                it.dismiss()
            },
            negetiveSelected = {
                finish()
                it.dismiss()
            }
        )

    }

    private fun sendFakeLocationToServer() {
        viewModel.sendFakeLocationLog(
            this, preference?.getLoginResponseModel()?.angazaId!!,
            FakeLocationRequest(
                angazaId = preference?.getLoginResponseModel()?.angazaId!!,
                appVersionCode = BuildConfig.VERSION_CODE,
                deviceId = Util.getImeiNumber(this) ?: "",
                deviceTime = Util.getUTCCurrentDate(),
                lat = currentLocation?.latitude ?: 0.0,
                lng = currentLocation?.longitude ?: 0.0,
                module = "FSE_SET_BASE_LOCATION"
            )
        )
    }

    private fun postBaseLocationToServer() {
        showProgressDialog(this@SetBaseLocationMapsActivity)
        postBaseLocation(
            loginResponseData?.angazaId!!,
            LAT!!,
            LONG!!,
            preference?.getLoginResponseModel()?.country ?: ""
        ).observe(this, Observer { response ->

            Log.d(TAG, "Response: $response")
//            cancelProgressDialog()
//            Toast.makeText(
//                this@SetBaseLocationMapsActivity,
//                "Base Location set successfully",
//                Toast.LENGTH_SHORT
//            ).show()
//            val eoIDIntent = Intent(this@SetBaseLocationMapsActivity, EOIDActivity::class.java)
//            startActivity(eoIDIntent)

            //region new api fails checks...
            when(response) {
                null -> {
                    cancelProgressDialog()
                    Util.CustomToastDialog(
                        context = this,
                        message = getString(R.string.unable_to_send_data_to_server),
                        title = "",
                        hideTitle = true,
                        hideNegative = true,
                        positveSelected = {dialog -> dialog.dismiss() },
                        negativeSeleted = {dialog -> dialog.dismiss() }
                    )
                }
                else -> {
                    when(response.responseStatus) {
                        200 -> {
                            //recheck with success flag...
                            when(response.success) {
                                true -> {
                                    //success path...
                                    Log.d(TAG, "Response: $response")
                                    cancelProgressDialog()
                                    Toast.makeText(
                                        this@SetBaseLocationMapsActivity,
                                        "Base Location set successfully",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    val eoIDIntent = Intent(this@SetBaseLocationMapsActivity, EOIDActivity::class.java)
                                    startActivity(eoIDIntent)
                                }
                                else -> {
                                    //unsuccessful path...
                                    cancelProgressDialog()
                                    Util.CustomToastDialog(
                                        context = this,
                                        message = response.error?.messageToUser ?: getString(R.string.unable_to_send_data_to_server),
                                        title = "",
                                        hideTitle = true,
                                        hideNegative = true,
                                        positveSelected = {dialog -> dialog.dismiss() },
                                        negativeSeleted = {dialog -> dialog.dismiss() }
                                    )
                                }
                            }
                        }
                        else -> {
                            //unsuccessful path...
                            cancelProgressDialog()
                            Util.CustomToastDialog(
                                context = this,
                                message = response.error?.messageToUser ?: getString(R.string.unable_to_send_data_to_server),
                                title = "",
                                hideTitle = true,
                                hideNegative = true,
                                positveSelected = {dialog -> dialog.dismiss() },
                                negativeSeleted = {dialog -> dialog.dismiss() }
                            )
                        }
                    }
                }
            }
            //endregion

        })
    }

    private fun setBaseLocationMarker(Lat: Double, Longg: Double) {
        if (mBaseLocationMarker != null) {
            mBaseLocationMarker!!.remove()
            circle?.remove()
        }
        val innermarkerOptions = MarkerOptions()
        innermarkerOptions.position(LatLng(Lat, Longg))
        innermarkerOptions.title("Your Base Location")

        innermarkerOptions.icon(bitmapDescriptorFromVector(this, R.drawable.ic_base_home_24dp))
        mBaseLocationMarker = mMap.addMarker(innermarkerOptions)
        drawCircle(Lat, Longg, radius * 1000)
        mMap.moveCamera(CameraUpdateFactory.newLatLng(LatLng(Lat, Longg)))
        mMap.animateCamera(CameraUpdateFactory.zoomTo(11f))

        LAT = Lat
        LONG = Longg
        Log.e("Maz=onClick=LATLONG=", "lat : $LAT , long : $LONG")
    }

    fun setCurreMarker(Lat: Double, Longg: Double) {
        CurrentLoc = LatLng(Lat, Longg)
        val markerOptions = MarkerOptions()
        markerOptions.position(CurrentLoc!!)
        markerOptions.title("Current Position")
//        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN))
        markerOptions.icon(bitmapDescriptorFromVector(this, R.drawable.ic_current_location_24dp))

        if (!markerAdded) {
            mCurrLocationMarker = mMap.addMarker(markerOptions)
            markerAdded = true
            mMap.moveCamera(CameraUpdateFactory.newLatLng(CurrentLoc))
            mMap.animateCamera(CameraUpdateFactory.zoomTo(11f))
        }

        //move map camera

    }

    fun getCurrentLoc(): MutableLiveData<Location> {

        val data = MutableLiveData<Location>()

        bag.add(
            newGetCurrentLocation(this)!!.subscribe({
                data.postValue(it)

            }, {
                data.postValue(null)
            })
        )
        return data
    }

    @SuppressLint("MissingPermission")
    fun newGetCurrentLocation(context: Context): Observable<Location>? {
        val request = LocationRequest.create() //standard GMS LocationRequest
            .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            .setNumUpdates(50).setInterval(20)

        val locationProvider = ReactiveLocationProvider(context)
        return locationProvider.getUpdatedLocation(request)

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        // Add a marker in Sydney and move the camera

        getCurrentLoc().observe(this, Observer {
            it?.let {
                Log.e("|| == ", "${it.latitude},${it.longitude}")
                setCurreMarker(it.latitude, it.longitude)
                currentLocation = it

                if (it.isFromMockProvider && Util.isMockLocationEnabled(this)) {
                    getFakeGpsDialog()
                    sendFakeLocationToServer()
                }
                binding.tvAccuracy.text = "Accuracy: ${it.accuracy}m"
                acc = it.accuracy.toDouble()
            }
        })

        //Map onClick
        mMap.setOnMapClickListener {

            setBaseLocationMarker(it.latitude, it.longitude)

        }

    }

    private fun drawCircle(latitude: Double, longitude: Double, radius: Int) {
        val circleOptions = CircleOptions()
            .center(LatLng(latitude, longitude))
            .radius(radius.toDouble())
            .strokeWidth(2.0f)
            .strokeColor(ContextCompat.getColor(this, R.color.colorPrimaryDark))
            .fillColor(ContextCompat.getColor(this, R.color.colorMapShadow))
        circle?.remove() // Remove old circle.
        circle = mMap.addCircle(circleOptions) // Draw new circle.
    }

    private fun bitmapDescriptorFromVector(context: Context, vectorResId: Int): BitmapDescriptor {
        val vectorDrawable = ContextCompat.getDrawable(context, vectorResId)
        vectorDrawable!!.setBounds(
            0,
            0,
            vectorDrawable.intrinsicWidth,
            vectorDrawable.intrinsicHeight
        )
        val bitmap =
            Bitmap.createBitmap(
                vectorDrawable.intrinsicWidth,
                vectorDrawable.intrinsicHeight,
                Bitmap.Config.ARGB_8888
            )
        val canvas = Canvas(bitmap)
        vectorDrawable.draw(canvas)
        return BitmapDescriptorFactory.fromBitmap(bitmap)

    }

    fun postBaseLocation(
        angazaId: String,
        latitude: Double,
        longitude: Double,
        country: String
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>()

        val baselocationRequestModel = BaselocationRequestModel.FseBaseLocation(
            latitude = latitude,
            longitude = longitude,
            angazaId = angazaId,
            country = country,
            accuracy = acc
        )

        bag.add(
            ServiceInstance.getInstance(this).service!!.postBaselocation(
                angazaId = angazaId,
                fseBaseLocation = baselocationRequestModel
            )
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    if (it.success) {
                        data.postValue(it)
                        // add addtional logic here
                        preference!!.setBaselocationModel(
                            BaselocationRequestModel(
                                hasBaseLocation = true,
                                fseBaseLocation = baselocationRequestModel
                            )
                        )
                        preference!!.setLAT(baselocationRequestModel.latitude.toString())
                        preference!!.setLONG(baselocationRequestModel.longitude.toString())

                    } else {
                        data.postValue(it)
                    }

                }, { error ->
                    Log.d(TAG, "Error:$error ")
//                    data.postValue(
//                        NewCommonResponseModel<NewEmptyParcelable>(
//                            error = NewCommonResponseModel.Error(
//                                messageToUser = "Unable to send data to server"
//                            ),
//                            success = false
//                        )
//                    )
                    //region new impl...
                    if(error is HttpException) {
                        val body = error.response()?.errorBody()
                        val gson = Gson()
                        val adapter: TypeAdapter<ErrorResponse> = gson.getAdapter(ErrorResponse::class.java)
                        try {
                            val errorbody: ErrorResponse = adapter.fromJson(body?.string())
                            Log.d("test", " code = " + errorbody.error?.Code + " message = " + errorbody.error?.MessageToUser)
                            data.postValue(
                                NewCommonResponseModel(
                                    responseData = null,
                                    success = false,
                                    responseStatus = errorbody.error?.Code ?: error.code(),
                                    error = NewCommonResponseModel.Error(
                                        errorCause = error.localizedMessage,
                                        messageToUser = errorbody.error?.MessageToUser ?: getString(R.string.unable_to_send_data_to_server)
                                    )
                                )
                            )
                        } catch (e: IOException) {
                            Log.d("test", " Error in parsing")
                            data.postValue(
                                NewCommonResponseModel(
                                    responseData = null,
                                    success = true,
                                    responseStatus = error.code(),
                                    error = NewCommonResponseModel.Error(
                                        messageToUser = error.localizedMessage ?: getString(R.string.unable_to_send_data_to_server)
                                    )
                                )
                            )
                        }
                    } else  {
                        Log.e(TAG,"found leads create new response as ${error.localizedMessage} $error")
                        data.postValue(
                            NewCommonResponseModel(
                                responseData = null,
                                success = true,
                                responseStatus = 500,
                                error = NewCommonResponseModel.Error(
                                    messageToUser = error.localizedMessage ?: getString(R.string.unable_to_send_data_to_server)
                                )
                            )
                        )
                    }
                    //endregion
                })
        )

        return data

    }

    override fun onDestroy() {
        bag.clear()
        super.onDestroy()
    }

}
