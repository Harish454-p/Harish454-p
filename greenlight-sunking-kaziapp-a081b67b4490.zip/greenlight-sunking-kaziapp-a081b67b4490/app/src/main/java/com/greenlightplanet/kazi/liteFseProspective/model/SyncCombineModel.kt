package com.greenlightplanet.kazi.liteFseProspective.model


data class SyncCombineModel(
    var otpApprovalRequestModels: List<LiteOtpApprovalRequestModel>? = null,
    var registrationCheckinRequestModels: List<LiteRegistrationCheckinRequestModel>? = null,
    var installationRequestModels: List<LiteInstallationRequestModel>? = null
)