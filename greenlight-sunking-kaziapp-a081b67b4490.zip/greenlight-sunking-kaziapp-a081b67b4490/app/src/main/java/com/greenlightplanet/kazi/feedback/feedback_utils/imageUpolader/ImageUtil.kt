package com.greenlightplanet.kazi.feedback.feedback_utils.imageUpolader

import com.greenlightplanet.kazi.feedback.feedback_utils.imageUpolader.MediaType.Companion.toMediaTypeOrNull
import com.greenlightplanet.kazi.feedback.feedback_utils.imageUpolader.MediaType
import java.io.File
import java.io.IOException
import java.nio.charset.Charset
import kotlin.text.Charsets.UTF_8
import okhttp3.internal.Util.checkOffsetAndCount
import okio.BufferedSink
import okio.ByteString
import okio.Okio.source

abstract class RequestBody {


    abstract fun contentType(): MediaType?

    @Throws(IOException::class)
    open fun contentLength(): Long = -1L

    /** Writes the content of this request to [sink]. */
    @Throws(IOException::class)
    abstract fun writeTo(sink: BufferedSink)


    companion object {

        /**
         * Returns a new request body that transmits this string. If [contentType] is non-null and lacks
         * a charset, this will use UTF-8.
         */
        @JvmStatic
        @JvmName("create")
        fun String.toRequestBody(contentType: MediaType? = null): RequestBody {
            var charset: Charset = UTF_8
            var finalContentType: MediaType? = contentType
            if (contentType != null) {
                val resolvedCharset = contentType.charset()
                if (resolvedCharset == null) {
                    charset = UTF_8
                    finalContentType = "$contentType; charset=utf-8".toMediaTypeOrNull()
                } else {
                    charset = resolvedCharset
                }
            }
            val bytes = toByteArray(charset)
            return bytes.toRequestBody(finalContentType, 0, bytes.size)
        }


        /** Returns a new request body that transmits this. */
        @JvmOverloads
        @JvmStatic
        @JvmName("create")
        fun ByteArray.toRequestBody(
            contentType: MediaType? = null,
            offset: Int = 0,
            byteCount: Int = size
        ): RequestBody {
            checkOffsetAndCount(size.toLong(), offset.toLong(), byteCount.toLong())
            return object : RequestBody() {
                override fun contentType() = contentType

                override fun contentLength() = byteCount.toLong()

                override fun writeTo(sink: BufferedSink) {
                    sink.write(this@toRequestBody, offset, byteCount)
                }
            }
        }

        /** Returns a new request body that transmits the content of this. */
        @JvmStatic
        @JvmName("create")
        fun File.asRequestBody(contentType: MediaType? = null): RequestBody {
            return object : RequestBody() {
                override fun contentType() = contentType

                override fun contentLength() = length()
                override fun writeTo(sink: BufferedSink) {

                }


            }
        }




        @JvmOverloads
        @JvmStatic
        @Deprecated(
            message = "Moved to extension function. Put the 'content' argument first to fix Java",
            replaceWith = ReplaceWith(
                expression = "content.toRequestBody(contentType, offset, byteCount)",
                imports = ["okhttp3.RequestBody.Companion.toRequestBody"]
            ),
            level = DeprecationLevel.WARNING)
        fun create(
            contentType: MediaType?,
            content: ByteArray,
            offset: Int = 0,
            byteCount: Int = content.size
        ) = content.toRequestBody(contentType, offset, byteCount)

        @JvmStatic
        @Deprecated(
            message = "Moved to extension function. Put the 'file' argument first to fix Java",
            replaceWith = ReplaceWith(
                expression = "file.asRequestBody(contentType)",
                imports = ["okhttp3.RequestBody.Companion.asRequestBody"]
            ),
            level = DeprecationLevel.WARNING)
        fun create(contentType: MediaType?, file: File) = file.asRequestBody(contentType)
    }
}
