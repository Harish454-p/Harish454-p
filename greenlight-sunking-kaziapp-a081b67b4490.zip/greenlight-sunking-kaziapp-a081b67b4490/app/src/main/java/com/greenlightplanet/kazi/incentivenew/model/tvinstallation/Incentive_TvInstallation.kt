package com.greenlightplanet.kazi.incentivenew.model.tvinstallation

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Created by Rahul on 14/12/20.
 */

@Parcelize
@Entity
class Incentive_TvInstallation(

        @PrimaryKey
        @SerializedName("accountsList") val accountsList: List<AccountsList>
) : Parcelable