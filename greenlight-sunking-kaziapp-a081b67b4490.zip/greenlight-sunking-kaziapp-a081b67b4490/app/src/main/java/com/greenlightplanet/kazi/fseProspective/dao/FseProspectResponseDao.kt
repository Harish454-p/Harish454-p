package com.greenlightplanet.kazi.fseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseModel
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import io.reactivex.Single

@Dao
interface FseProspectResponseDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(FseProspectResponseModel: List<FseProspectResponseModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(FseProspectResponseModel: FseProspectResponseModel): Long

    @Delete
    fun delete(FseProspectResponseModel: FseProspectResponseModel): Int

    @Query("DELETE FROM FseProspectResponseModel")
    fun deleteAll(): Int

    @Query("SELECT * FROM FseProspectResponseModel")
    fun getAll(): Single<List<FseProspectResponseModel>>


    @Query("SELECT * FROM FseProspectResponseModel LIMIT 1")
    fun get(): Single<FseProspectResponseModel>


    @Query("SELECT COUNT(*) from FseProspectResponseModel")
    fun count(): Single<Int>


//    @Query("SELECT * FROM FseProspectResponseModel WHERE prospectId=:prospectId")

    //@Query("SELECT * FROM FseProspectResponseModel WHERE prospectId=:prospectId LIMIT 1")
    @Query("SELECT * FROM FseProspectResponseModel WHERE prospectId LIKE :prospectId")
    fun getByProspectId(prospectId: String): Single<FseProspectResponseModel>?

    @Query("SELECT * FROM FseProspectResponseModel WHERE prospectId=:prospectId LIMIT 1")
    fun getBySingleProspectId(prospectId: String): Single<FseProspectResponseModel>?

    @Query("SELECT * FROM FseProspectResponseModel WHERE isChanged=1")
    fun getAllIsChanged(): Single<List<FseProspectResponseModel>>
}
