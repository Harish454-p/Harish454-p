package com.greenlightplanet.kazi.heroboard.view.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager.widget.PagerAdapter
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.heroboard.extras.LeaderBoardUtil
import com.greenlightplanet.kazi.heroboard.model.LeaderboardModel
import com.greenlightplanet.kazi.heroboard.view.activity.HeroBoardActivity
import com.greenlightplanet.kazi.heroboard.view.fragment.AreaFragment
import com.greenlightplanet.kazi.heroboard.view.fragment.RegionFragment

class HeroBoardPagerAdapter(val activity : HeroBoardActivity, fm: FragmentManager, var list: List<LeaderboardModel>)
    : FragmentStatePagerAdapter(fm) {


    var areaFragment: AreaFragment? = null
    var regionFragment: RegionFragment? = null

    override fun getCount(): Int {
        return 2
    }

    override fun getItem(position: Int): Fragment {
        val fragment: Fragment? = null

        when (position) {
            0 -> {
                areaFragment = AreaFragment.newInstance(list.filter {
                    it.geography == LeaderBoardUtil.Geography.AREA
                })
                return areaFragment as Fragment
            }
            1 -> {
                regionFragment = RegionFragment.newInstance(list.filter {
                    it.geography == LeaderBoardUtil.Geography.REGION
                })
                return regionFragment as Fragment
            }
            else ->
                return fragment!!
        }
    }

    override fun getItemPosition(`object`: Any): Int {
        return PagerAdapter.POSITION_NONE
    }

    override fun getPageTitle(position: Int): CharSequence {
        var title: String? = null
        when (position) {
            0 -> {
                title = activity.getString(R.string.my_area)
                return title
            }
            1 -> {
                title = activity.getString(R.string.my_region)
                return title
            }
            else ->
                return title!!
        }
    }

}
