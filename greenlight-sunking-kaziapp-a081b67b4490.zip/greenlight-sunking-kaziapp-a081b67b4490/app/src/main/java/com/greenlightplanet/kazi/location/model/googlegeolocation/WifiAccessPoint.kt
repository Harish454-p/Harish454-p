package com.greenlightplanet.kazi.location.model.googlegeolocation


import com.google.gson.annotations.SerializedName

data class WifiAccessPoint(
    @SerializedName("age")
    var age: Int?, // 0
    @SerializedName("channel")
    var channel: Int?, // 11
    @SerializedName("macAddress")
    var macAddress: String?, // 00:25:9c:cf:1c:ac
    @SerializedName("signalStrength")
    var signalStrength: Int?, // -43
    @SerializedName("signalToNoiseRatio")
    var signalToNoiseRatio: Int? // 0
)
