package com.greenlightplanet.kazi.liteFseProspective.extras

class FseProspectiveConstant {

    object ProspectiveType {
        val VERIFICATION = "VERIFICATION"
        val REGISTRATION = "REGISTRATION"
        val INSTALLATION = "INSTALLATION"
    }//PP3455627


    object ProspectStatus {

        val PROSPECT = "PROSPECT"//step -1 - for new
        val OTP_APPROVED = "OTP_APPROVED"//step -2
        val PRE_APPROVED_PROSPECT = "PRE_APPROVED_PROSPECT"//step -3
        val CHECKED_IN = "CHECKED_IN"//step -4
        val THREE_WAY_CALL = "THREE_WAY_CALL"//step -4 = not sure about name - for new
        val INSTALLATION_PENDING = "INSTALLATION_PENDING"//step -5 - for new
        val INSTALLED = "INSTALLED"//step -6 - for new
        val INSTALLATION_VERIFIED = "INSTALLATION_VERIFIED"//step -6 - for new
        val INSTALLATION_REATTEMPT = "INSTALLATION_REATTEMPT"//step -7 - for new
    }
}
