package com.greenlightplanet.kazi.location.worker.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.alarms.AlarmUtils
import com.greenlightplanet.kazi.location.dao.LocationRequestDao
import com.google.android.gms.location.*
import com.google.android.gms.tasks.Task
import com.greenlightplanet.kazi.location.extras.FunctionalUtils
import com.greenlightplanet.kazi.location.model.LocationRequestModel
import com.greenlightplanet.kazi.location.model.LocationResponseModel
import com.greenlightplanet.kazi.location.worker.DEFAULT_INTERVAL
import com.greenlightplanet.kazi.location.worker.TASK_ALARM
import com.greenlightplanet.kazi.location.worker.TASK_TAG
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers


class HourAlarmWorkReceiver : BroadcastReceiver() {


    private val bag = CompositeDisposable()
    private lateinit var dao: LocationRequestDao
    private var localDb: AppDatabase? = null

    var mContext: Context? = null
    var preference: GreenLightPreference? = null
    lateinit var mFusedLocationClient: FusedLocationProviderClient

    companion object {

        val TAG = "HourAlarmWorkReceiver"
    }

    @RequiresApi(Build.VERSION_CODES.KITKAT)
    override fun onReceive(context: Context?, intent: Intent?) {

        Log.d(TAG, "onReceive: CALLED");

        mContext = context

        /*notificationLogic(context!!)
        runJob()*/

        localDb = AppDatabase.getAppDatabase(mContext!!)
        preference = GreenLightPreference.getInstance(mContext!!)
        dao = localDb!!.locationRequestDao()

        preference?.setLastCalledWorker(System.currentTimeMillis())

        bag.add(
                abcdanotherSendLocationToApi(Util.isOnline(context))
//                        .observeOn(Schedulers.trampoline())
//                        .subscribeOn(Schedulers.trampoline())
                        .observeOn(Schedulers.io())
                        .subscribeOn(Schedulers.io())
                        .subscribe({
                            //AlarmUtils.setAlarm(mContext!!, 2)
                            //AlarmUtils.setAlarm(mContext!!, 2)

                            var locationInterval = preference?.getLocationIntervalWM() ?: DEFAULT_INTERVAL
                            if (locationInterval <= 0) {
                                locationInterval = DEFAULT_INTERVAL
                            }
                            Log.d(TAG, "locationInterval:$locationInterval ");

                            AlarmUtils.setAlarm(mContext!!, locationInterval)

                            Log.d(TASK_TAG, "anotherSendLocationToApi-success: ${it}");
                            bag.clear()

                        }, {
                            //                            AlarmUtils.setAlarm(mContext!!, 2)
                            //AlarmUtils.setAlarm(mContext!!, 2)
                            var locationInterval = preference?.getLocationInterval() ?: DEFAULT_INTERVAL
                            if (locationInterval <= 0) {
                                locationInterval = DEFAULT_INTERVAL
                            }
                            Log.d(TAG, "locationInterval:$locationInterval ");

                            AlarmUtils.setAlarm(mContext!!, locationInterval)

                            Log.d(TASK_TAG, "anotherSendLocationToApi-error: ${it.localizedMessage}");
                            bag.clear()

                        })
        )





/*

        //sample start
        val dateTime = getCurrentUtcDateTime()

        dateTimeFormatted = getCurrentUtcDateTimeFormatted(dateTime)

        val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
        utcFormat.timeZone = TimeZone.getTimeZone("UTC")

        Log.d(TAG, ":dateTimeFormatted$dateTimeFormatted ")


        milliseconds = utcFormat.parse(dateTimeFormatted).time

        //sample end
*/


        /*val gps = GPSTracker(context!!)

        val loc = gps.getLocation()
        Log.d(TAG, "gps-location: $loc");

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

        if (isLocationEnabled(context)) {

            Log.d(TAG, "isLocationEnabled:${isLocationEnabled(context)} ");

            mFusedLocationClient.lastLocation.addOnCompleteListener { task ->
                var location: Location? = task.result
                if (location == null) {
                    Log.d(TAG, "location-null: ");

                    //requestNewLocationData()
                } else {

                    Log.d(TAG, "location-not-null:$location ");
                }
            }

        } else {
            Log.d(TAG, "isLocationEnabled:${isLocationEnabled(context)} ");
        }*/




        /*FunctionalUtils.turnGPSOn(context!!)
        bag.add(
                sendLocationToApi(Util.isOnline(context))
                        //                        .observeOn(Schedulers.trampoline())
                        //                        .subscribeOn(Schedulers.trampoline())
                        .observeOn(Schedulers.io())
                        .subscribeOn(Schedulers.io())
                        .subscribe({

                            Log.d(TAG, "onReceive-success: ${it}");

                            bag.clear()

                        }, {

                            Log.d(TAG, "onReceive-error: ${it.localizedMessage}");
                            bag.clear()

                        })
        )*/


        //createLocationRequest()



    }


    private fun doIfOnlineFunctionality(): Single<Int> {
        Log.d(TAG, "onReceive: CALLED-7");

        var locationRequestModels: List<LocationRequestModel>? = null
        return getAllLocationRequestModel()
                .flatMap {
                    Log.d(TAG, "onReceive: CALLED-8");

                    locationRequestModels = it
                    sendLocationRequestModelToServer(it)
                }
                .flatMap {
                    Log.d(TAG, "onReceive: CALLED-9");

                    //todo delete logic
                    deleteAllLocationRequestModelFromDB(locationRequestModels!!)
//                    Single.just(1)
                }
    }

   /* private fun sendLocationToApi(isOnline: Boolean): Single<Int> {

        Log.d(TAG, "onReceive: CALLED-1");


        return FunctionalUtils.getLocationForAlarm(mContext!!, preference?.getLoginResponseModel()?.angazaId
                ?: "", bag, TASK_ALARM)
                *//*return Single.just {
                    LocationRequestModel(
                            "US042897",
                            "23",
                            "123123123000",
                            "19.001459",
                            milliseconds,
                            dateTimeFormatted,
                            "72.816071",
                            "TEST",
                            "100",
                            "TEST",
                            100
                    )
                }*//*.flatMap {

            Log.d(TAG, "onReceive: CALLED-2");

            insertLocationRequestModelToDB(it)

        }
                .flatMap {

                    Log.d(TAG, "onReceive: CALLED-3");

                    if (isOnline) {
                        Log.d(TAG, "onReceive: CALLED-4");

                        doIfOnlineFunctionality()
                    } else {
                        Log.d(TAG, "onReceive: CALLED-5");

                        Single.just { 1331 }
                    }

                }
                .map {
                    Log.d(TAG, "onReceive: CALLED-6");

                    1
                }

        *//*return Single.just(
                LocationRequestModel(
                        "US007246",
                        "123",
                        "123123123000",
                        "19.001459",
                        milliseconds,
                        dateTimeFormatted,
                        "72.816071",
                        "TEST",
                        "100",
                        "TEST_ALARM", 24
                )).flatMap {
            insertLocationRequestModelToDB(it)
        }
                .flatMap {

                    if (isOnline) {
                        doIfOnlineFunctionality()
                    } else {

                        Single.just { 1331 }
                    }


                }
                .map {
                    1
                }*//*
    }*/


    private fun insertLocationRequestModelToDB(locationRequestModel: LocationRequestModel): Single<Long> {

        return Single.fromCallable {
            dao.insert(locationRequestModel)
        }

    }


    private fun anotherInsertLocationRequestModelToDB(locationRequestModel: LocationRequestModel): Single<Long> {

        Log.d(TASK_TAG, "anotherInsertLocationRequestModelToDB");
        return Single.fromCallable {
            dao.insert(locationRequestModel)
        }

    }

    private fun getAllLocationRequestModel(): Single<List<LocationRequestModel>> {
        Log.d(TAG, "onReceive: CALLED-11");

        return dao.getAll()
    }

    private fun sendLocationRequestModelToServer(locationRequestModels: List<LocationRequestModel>): Single<LocationResponseModel> {
        Log.d(TAG, "onReceive: CALLED-10");

        return ServiceInstance.getInstance(mContext!!).service?.sendLocation(locationRequestModels)!!
}

    private fun deleteAllLocationRequestModelFromDB(locationRequestModels: List<LocationRequestModel>): Single<Int> {

        return Single.fromCallable {
            dao.deleteAllAnother(locationRequestModels)
        }
    }


    /*
    //sample start

    fun getCurrentUtcDateTime(): Date {

        //Current Date and Time in UTC
        return Calendar.getInstance().time


    }

    fun getCurrentUtcDateTimeFormatted(date: Date): String {
        //Current Date and Time in UTC

        val utcFormat = SimpleDateFormat("dd-MM-y HH:mm:ss", Locale.ENGLISH)
        utcFormat.timeZone = TimeZone.getTimeZone("UTC")

        return utcFormat.format(date)

    }

    //sample end
    */


    /*private fun anotherSendLocationToApi(isOnline: Boolean): Single<Int> {

        Log.d(TASK_TAG, "anotherSendLocationToApi");

        return FunctionalUtils.anotherGetLocationForAlarm(mContext!!, preference?.getLoginResponseModel()?.angazaId
                ?: "", bag, TASK_ALARM)
                *//*return Single.just {
                    LocationRequestModel(
                            "US042897",
                            "23",
                            "123123123000",
                            "19.001459",
                            milliseconds,
                            dateTimeFormatted,
                            "72.816071",
                            "TEST",
                            "100",
                            "TEST",
                            100
                    )
                }*//*.flatMap {

            Log.d(TASK_TAG, "anotherSendLocationToApi-anotherGetLocationForAlarm");

            anotherInsertLocationRequestModelToDB(it)

        }.flatMap {

                    Log.d(TASK_TAG, "anotherSendLocationToApi-flatMap");

                    if (isOnline) {
                        Log.d(TASK_TAG, "anotherSendLocationToApi-flatMap-isOnline");

                        doIfOnlineFunctionality()
                    } else {
                        Log.d(TASK_TAG, "anotherSendLocationToApi-flatMap-notIsOnline");

                        Single.just { 1331 }
                    }

                }
                .map {
                    Log.d(TASK_TAG, "anotherSendLocationToApi-map");
                    1
                }

        *//*return Single.just(
                LocationRequestModel(
                        "US007246",
                        "123",
                        "123123123000",
                        "19.001459",
                        milliseconds,
                        dateTimeFormatted,
                        "72.816071",
                        "TEST",
                        "100",
                        "TEST_ALARM", 24
                )).flatMap {
            insertLocationRequestModelToDB(it)
        }
                .flatMap {

                    if (isOnline) {
                        doIfOnlineFunctionality()
                    } else {

                        Single.just { 1331 }
                    }


                }
                .map {
                    1
                }*//*
    }*/


    private fun abcdanotherSendLocationToApi(isOnline: Boolean): Single<Int> {

        Log.d(TASK_TAG, "anotherSendLocationToApi");

        return FunctionalUtils.abcdanotherGetLocationForAlarm(mContext!!, preference?.getLoginResponseModel()?.angazaId
                ?: "", bag, TASK_ALARM)
                /*return Single.just {
                    LocationRequestModel(
                            "US042897",
                            "23",
                            "123123123000",
                            "19.001459",
                            milliseconds,
                            dateTimeFormatted,
                            "72.816071",
                            "TEST",
                            "100",
                            "TEST",
                            100
                    )
                }*/.flatMap {

            Log.d(TASK_TAG, "anotherSendLocationToApi-anotherGetLocationForAlarm");

            anotherInsertLocationRequestModelToDB(it)

        }.flatMap {

                    Log.d(TASK_TAG, "anotherSendLocationToApi-flatMap");

                    if (isOnline) {
                        Log.d(TASK_TAG, "anotherSendLocationToApi-flatMap-isOnline");

                        doIfOnlineFunctionality()
                    } else {
                        Log.d(TASK_TAG, "anotherSendLocationToApi-flatMap-notIsOnline");

                        Single.just<Int>(1331)
                    }

                }


        /*return Single.just(
                LocationRequestModel(
                        "US007246",
                        "123",
                        "123123123000",
                        "19.001459",
                        milliseconds,
                        dateTimeFormatted,
                        "72.816071",
                        "TEST",
                        "100",
                        "TEST_ALARM", 24
                )).flatMap {
            insertLocationRequestModelToDB(it)
        }
                .flatMap {

                    if (isOnline) {
                        doIfOnlineFunctionality()
                    } else {

                        Single.just { 1331 }
                    }


                }
                .map {
                    1
                }*/
    }

    private fun isLocationEnabled(context: Context): Boolean {
        var locationManager: LocationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
                LocationManager.NETWORK_PROVIDER
        )
    }

    fun createLocationRequest() {
        val locationRequest = LocationRequest.create()
        locationRequest.interval = 10000
        locationRequest.fastestInterval = 5000
        locationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        val builder = LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest)
        val client = LocationServices.getSettingsClient(mContext!!)
        val task: Task<LocationSettingsResponse> = client.checkLocationSettings(builder.build())
        task.addOnSuccessListener { locationSettingsResponse ->
            if (locationSettingsResponse == null) {
                Toast.makeText(
                        mContext, "locationSettingsResponse null",
                        Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(
                        mContext, "locationSettingsResponse not null",
                        Toast.LENGTH_LONG
                ).show()


                Toast.makeText(
                        mContext, "locationSettingsResponse ${locationSettingsResponse}",
                        Toast.LENGTH_LONG
                ).show()
            }
        }
        /*task.addOnSuccessListener(mContext,
                OnSuccessListener<LocationSettingsResponse> { locationSettingsResponse ->
                    // All location settings are satisfied. The client can initialize
                    // location requests here.
                    // ...
                    Toast.makeText(
                            mContext, "Gps already open",
                            Toast.LENGTH_LONG
                    ).show()
                    if(locationSettingsResponse == null){
                        Toast.makeText(
                                mContext, "locationSettingsResponse null",
                                Toast.LENGTH_LONG
                        ).show()
                    }else{
                        Toast.makeText(
                                mContext, "locationSettingsResponse not null",
                                Toast.LENGTH_LONG
                        ).show()

                        Toast.makeText(
                                mContext, "locationSettingsResponse ${locationSettingsResponse}",
                                Toast.LENGTH_LONG
                        ).show()
                    }
                    Log.d("locationsettings", locationSettingsResponse.toString())
                })*/

        /*task.addOnFailureListener(this, OnFailureListener { e ->
            if (e is ResolvableApiException) { // Location settings are not satisfied, but this can be fixed
                // by showing the user a dialog.
                try { // Show the dialog by calling startResolutionForResult(),
                    // and check the result in onActivityResult().
                    e.startResolutionForResult(
                            mContext,
                            112
                    )
                } catch (sendEx: IntentSender.SendIntentException) { // Ignore the error.
                    Log.d("location-error", "error:$sendEx");
                }
            }
        })*/
    }
}
