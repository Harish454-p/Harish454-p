package com.greenlightplanet.kazi.dashboard.contactdervice

import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Telephony
import android.util.Log
import android.util.Log.d
import androidx.core.app.NotificationCompat
import androidx.lifecycle.MutableLiveData
import androidx.loader.app.LoaderManager
import androidx.loader.content.CursorLoader
import androidx.loader.content.Loader
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.greenlightplanet.kazi.KaziApplication
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.activity.DashBoardActivity
import com.greenlightplanet.kazi.dashboard.model.call_sms.CallLogRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.ContactRequest
import com.greenlightplanet.kazi.dashboard.model.call_sms.SmsRequest
import com.greenlightplanet.kazi.dashboard.repo.DashBoardRepo
import com.greenlightplanet.kazi.utils.SMS
import com.greenlightplanet.kazi.utils.Util.Companion.dateFormateContact
import com.wickerlabs.logmanager.LogsManager

import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import kotlin.collections.LinkedHashSet

/**
 * Created by Rahul on 24/02/21.
 */

class BackgroundTask(val context: Context, params: WorkerParameters) : Worker(context, params) {

    //contact region
    companion object {
        var data: ArrayList<SMS>? = null

    }

    val SMS_SELECTION_SEARCH = "address LIKE ? OR body LIKE ?"
    val ALL_SMS_URI = Uri.parse("content://sms/inbox")

    var smsRequests = mutableListOf<SmsRequest>()
    var callLogRequest = mutableListOf<CallLogRequest>()
    var contactRequest = mutableListOf<ContactRequest>()

    val completionMap = HashMap<String, Boolean>()
    val completion = MutableLiveData<HashMap<String, Boolean>>()
    val list: HashMap<String, Boolean> = HashMap<String, Boolean>()
    //var hashmap: HashMap<Int?, Int?> = HashMap<Int?, Int?>()


    // contact end region
    val repo = DashBoardRepo.getInstance(context)


    override fun doWork(): Result {

        d("oneTimeWorkRequest", "running  in background")

        // sendNotification("Background Task","Succcessfully done")
        callContactLogic()
        return Result.success()
    }

    private fun sendNotification(title: String, message: String) {
        val notificationManager =
            applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        //If on Oreo then notification required a notification channel.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel =
                NotificationChannel("default", "Default", NotificationManager.IMPORTANCE_DEFAULT)
            notificationManager.createNotificationChannel(channel)
        }
        val notification: NotificationCompat.Builder = NotificationCompat.Builder(
            applicationContext,
            "default"
        )
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(R.mipmap.ic_launcher)
        notificationManager.notify(1, notification.build())
    }


    //region CONTACT & SMS


    private fun callContactLogic() {


        contactAndSmsLogic()
        list.let {

            Log.e("kjbjkbjkjjkbjkb", "${it.get("SMS")} ${it.get("CALL_LOG")} ${it.get("CONTACT")}")
            if (
            //it.containsKey("SMS") && it.containsKey("CALL_LOG") && it.containsKey("CONTACT")&&
                it.get("SMS") == true && it.get("CALL_LOG") == true && it.get("CONTACT") == true
            ) {
                d("C_S", "SMS: ${smsRequests}")
                d("C_S", "CALL_LOG: ${callLogRequest}")
                d("C_S", "CONTACT: ${contactRequest.size}${contactRequest}")

                repo.syncResourcesPart1(callLogRequest, smsRequests, contactRequest)
            }
        }
    }


    private fun contactAndSmsLogic() {

        callLog()
        loadContacts()
        loadSms()
    }

    fun callLog() {
        var logsRunnable: Runnable? = null

        val logsManager = LogsManager(context)
        logsRunnable = Runnable { loadLogs() }

        logsRunnable.run()
    }

    @SuppressLint("Range")
    private fun loadContacts() {
        val cr: ContentResolver = context.contentResolver
        val cur: Cursor = cr.query(
            ContactsContract.Contacts.CONTENT_URI,
            null, null, null, null
        )!!
        if (cur?.count ?: 0 > 0) {
            while (cur != null && cur.moveToNext()) {
                val id = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID))
                val name = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME))
                if (cur.getInt(
                        cur.getColumnIndex(
                            ContactsContract.Contacts.HAS_PHONE_NUMBER
                        )
                    ) > 0
                ) {
                    val pCur: Cursor = cr.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID.toString() + " = ?",
                        arrayOf(id),
                        null
                    )!!
                    while (pCur.moveToNext()) {
                        val phoneNo = pCur.getString(
                            pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NUMBER
                            )
                        )
                        Log.i("NAME_OF_CONTACT", "Name: $name")
                        Log.i("NUMBER_OF_CONTACT", "Phone Number: $phoneNo")

                        contactRequest.add(
                            ContactRequest(
                                name = name,
                                numbers = phoneNo,
                                status = null,
                                localId = "${id}_${1}"
                            )
                        )

                    }
                    pCur.close()
                }
            }
        }
        cur?.close()
        d("CONTACT", "contactRequests:$contactRequest ")
        completionMap["CONTACT"] = true
        completion.postValue(completionMap)
        list.put("CONTACT", true)

    }


    private fun loadSms() {
        val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, context.packageName)
        context.startActivity(intent)
        getSMS()

    }


    private fun loadLogs() {
        val logsManager = LogsManager(applicationContext)
        val callLogs = logsManager.getLogs(LogsManager.ALL_CALLS)
        callLogs.forEach { data ->
            try {
                Log.d(
                    "CONTACT",
                    "date : ${dateFormateContact(data.date.toLong())} | duration : ${data.duration} | contactName : ${data.contactName} | number:${data.number}"
                )
                callLogRequest.add(
                    CallLogRequest(
                        name = data.contactName,
                        contactNumber = data.number,
                        toNumber = "",
                        date = dateFormateContact(data.date.toLong()),
                        duration = data.duration.toString()
                    )
                )
            } catch (e: Exception) {
                Log.d("CONTACT", "error : ${e.message}")
            }
        }

        completionMap["CALL_LOG"] = true
        completion.postValue(completionMap)
        list.put("CALL_LOG", true)
    }

    private fun getAllSmsToFile(c: Cursor) {
        val lstSms: ArrayList<SMS>? = arrayListOf()
        lateinit var objSMS: SMS
        val totalSMS = c.count
        if (c.moveToFirst()) {
            for (i in 0 until totalSMS) {
                try {
                    objSMS = SMS()
                    objSMS.id = c.getLong(c.getColumnIndexOrThrow("_id"))
                    val num = c.getString(c.getColumnIndexOrThrow("address"))
                    objSMS.address = num
                    objSMS.msg = c.getString(c.getColumnIndexOrThrow("body"))
                    objSMS.readState = c.getString(c.getColumnIndex("read"))
                    objSMS.time = c.getLong(c.getColumnIndexOrThrow("date"))
                    if (c.getString(c.getColumnIndexOrThrow("type")).contains("1")) {
                        objSMS.folderName = "inbox"
                    } else {
                        objSMS.folderName = "sent"
                    }
                } catch (e: Exception) {
                } finally {
                    lstSms?.add(objSMS)
                    c.moveToNext()
                }
            }
        }
        c.close()
        data = lstSms

        sortAndSetToRecycler(lstSms)
    }

    private fun sortAndSetToRecycler(lstSms: List<SMS>?) {
        val s: Set<SMS> = LinkedHashSet(lstSms)
        data = ArrayList(s)

        Log.d("CONTACT", "sortAndSetToRecycler: $data")
        data?.forEach { sms ->
            Log.d("CONTACT", "sms-address: ${sms.address}")
            Log.d("CONTACT", "sms-msg: ${sms.msg}")
            Log.e("CONTACT", "sms-msg-date: ${dateFormateContact(sms.time)}")
            smsRequests.add(
                SmsRequest(
                    id = sms.id,
                    msg = sms.msg,
                    toNumber = "",
                    number = sms.address,
                    time = dateFormateContact(sms.time)
                )
            )
        }

        completionMap["SMS"] = true
        completion.postValue(completionMap)
        list.put("SMS", true)

    }


    //endregion

    fun getSMS() { //:List<String?>? {
        val sms: MutableList<String> = java.util.ArrayList()
        val uriSMSURI = ALL_SMS_URI
        val cur = context.contentResolver.query(uriSMSURI, null, null, null, null)

        cur?.let { getAllSmsToFile(it) }

    }
}