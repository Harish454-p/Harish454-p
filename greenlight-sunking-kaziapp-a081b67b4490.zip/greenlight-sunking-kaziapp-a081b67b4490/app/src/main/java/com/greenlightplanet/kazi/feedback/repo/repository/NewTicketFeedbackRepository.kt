package com.greenlightplanet.kazi.feedback.repo.repository

import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackConstants
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.feedback.repo.model.request.CreateNewTicketRequest
import com.greenlightplanet.kazi.feedback.repo.model.response.Field
import com.greenlightplanet.kazi.networking.NetworkService
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.NetworkResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.HttpException
import timber.log.Timber
import java.io.IOException
import javax.inject.Inject


class NewTicketFeedbackRepository @Inject constructor(
    val db: AppDatabase, val networkService: NetworkService, val preference: GreenLightPreference
) {

    fun getUIWithData(territory: String) : Flow<NetworkResult<List<Field>>> =  flow {
        if (Helper.isNetworkConnected()) {
            try {
                emit(NetworkResult.Loading())
                val url = "${FeedbackConstants.BASE_URL}${FeedbackConstants.FORM_UI_ENDPOINT}$territory"
                Timber.d("NewTicketRepo: API Response: UI Data URL:  $url")
                val response = networkService.getNewTicketUIwithData(url)
                if (response.isSuccessful) {
                    response.body()?.let { response ->
                        emit(NetworkResult.Success(response.responseData.fields))
                        Timber.d("NewTicketRepo: API Response: ${response.responseData}")
                    }
                }
            } catch (e: HttpException) {
                emit(NetworkResult.Error(e.localizedMessage ?: "An unexpected error occurred"))
            } catch (e: IOException) {
                emit(NetworkResult.Error("Couldn't reach server. Check your internet connection."))
            }
        } else {
            emit(NetworkResult.Error("Couldn't reach server. Check your internet connection."))
        }
    }

    fun invokeSubmitNewTicketData(requestData: CreateNewTicketRequest, country: String) : Flow<NetworkResult<Boolean>> =  flow {
        if (Helper.isNetworkConnected()) {
            try {
                emit(NetworkResult.Loading())
                val url = "${FeedbackConstants.BASE_URL}${FeedbackConstants.CREATE_TICKETS_ENDPOINT}$country"
                val response = networkService.submitNewTicketData(url = url, createNewTicketRequest = requestData)
                if (response.isSuccessful) {
                    response.body()?.let { response ->
                        if (response.statusCode == 200) {
                            emit(NetworkResult.Success(data = true))
                            Timber.d("SubmitTicket: API Response: ${response}")
                        } else if (response.statusCode == 9901) {
                            emit(NetworkResult.Error(response.message))
                        } else if (response.statusCode == 9902){
                            emit(NetworkResult.Error(response.message))
                        } else {
                            emit(NetworkResult.Error(response.message))
                        }
                    }
                } else {
                    emit(NetworkResult.Error("Ticket not submitted. Please try again"))
                }
//                val responseData = Helper.getDummyUIResponseData()
//                Timber.d("NewTicketRepo: FakeResponse: ${responseData.fields}")
//                emit(NetworkResult.Success(data = responseData.fields))

//                else {
//                        val errorResponse = Helper.getErrorBody(response)
//                        errorResponse?.let {
//                            it.responseStatus
//                            if (it.responseStatus == 401) {
//                                emit(NetworkResult.Error("Ticket already exists. Please try again with different Category, Sub-Category and Account Number"))
//                            }
//                        }
//                    }
            } catch (e: HttpException) {
                emit(NetworkResult.Error(e.localizedMessage ?: "An unexpected error occurred"))
            } catch (e: IOException) {
                emit(NetworkResult.Error("Couldn't reach server. Check your internet connection."))
            }
        } else {
            emit(NetworkResult.Error("Couldn't reach server. Check your internet connection."))
        }
    }


}