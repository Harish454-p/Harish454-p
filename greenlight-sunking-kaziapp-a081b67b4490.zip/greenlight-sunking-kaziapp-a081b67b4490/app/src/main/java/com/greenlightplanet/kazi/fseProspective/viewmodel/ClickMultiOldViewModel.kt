package com.greenlightplanet.kazi.fseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import com.greenlightplanet.kazi.fseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.fseProspective.model.AwsImageModel
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseModel
import com.greenlightplanet.kazi.fseProspective.repo.InstallationRepo
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.networking.CommonResponseModel

import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel

class ClickMultiOldViewModel(application: Application) : AndroidViewModel(application) {

    val installationRepo = InstallationRepo.getInstance(application)

    //region start installationRepo
    fun compressImageForAws(context: Context, files: List<ImageUploadUtil.ImageModel>, showProgress: () -> Unit = {}): MutableLiveData<List<AwsImageModel>?> {
        showProgress()
        return installationRepo.compressImageForAws(context, files)
    }

    fun performInstallation(context: Context, fseProspectResponseModel: FseProspectResponseModel?, isOnline: Boolean, prospectId: String, angazaId: String, accountNumber: String, installationAttempted: Int, fileModel: List<AwsImageModel>, /*location: Location,*/ imageName: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return installationRepo.performInstallation(context, fseProspectResponseModel, isOnline, prospectId, angazaId, accountNumber, installationAttempted, fileModel/*, location*/)
    }

    fun performInstallation2(context: Context, fseProspectResponseModel: FseProspectResponseModel?, isOnline: Boolean, prospectId: String, fileModel: List<AwsImageModel>, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return installationRepo.performInstallation2(context,fseProspectResponseModel,isOnline, prospectId,fileModel)
    }

    fun insertAwsImageModelToDatabase(inputFiles: List<AwsImageModel>, isUploadedToAws: Boolean): MutableLiveData<List<AwsImageModel>?> {
        return installationRepo.insertAwsImageModelToDatabase(inputFiles, isUploadedToAws)
    }


    //
    fun updateFseProspect(fseProspectResponseModel: FseProspectResponseModel): MutableLiveData<FseProspectResponseModel> {
        return installationRepo.updateFseProspect(fseProspectResponseModel)
    }

    fun getFseProspectiveFromServerInstallation(angazaId: String, prospectId: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<FseProspectResponseModel>>? {
        showProgress()
        return installationRepo.getFseProspectiveFromServer(angazaId, prospectId)
    }

    fun awsRX(context: Context, requestModel: BaseRequestModel): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
        return installationRepo.awsRX(context, requestModel)
    }

    fun getFseProsResponseModelFromProspectID(prospectId: String): MutableLiveData<FseProspectResponseModel> {
        return installationRepo.getFseProsResponseModelFromProspectID(prospectId)
    }
    //endregion installationRepo


    override fun onCleared() {
        super.onCleared()
//        installationRepo.destroy()
    }

}
