package com.greenlightplanet.kazi.dashboard.viewmodel

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.attendance.model.AttendanceResponseModel
import com.greenlightplanet.kazi.attendance.repo.AttendanceRepo
import com.greenlightplanet.kazi.dashboard.model.response.AppVersionResponse
import com.greenlightplanet.kazi.dashboard.repo.SplashScreenRepo
import com.greenlightplanet.kazi.liteFseProspective.model.*
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteProspectiveRepo
import com.greenlightplanet.kazi.leads.repo.CustomerLeadsRepo
import com.greenlightplanet.kazi.dashboard.model.CountryResponseData
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.member.model.BaseResponseModel
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.task.model.request.TicketRequestModel
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.disposables.Disposable

class SplashScreenViewModel(application: Application) : AndroidViewModel(application) {

	companion object {
		const val TAG = "SplashScreenVM"
	}

	val repo = SplashScreenRepo.getInstance(application)

	val attendanceRepo = AttendanceRepo.getInstance(application)

	val customerLeadsRepo = CustomerLeadsRepo.getInstance(application)

	val prospectiveRepo = LiteProspectiveRepo.getInstance(application)


	fun postTask(angazaId: String, requestModel: TicketRequestModel?): MutableLiveData<CommonResponseModel<BaseResponseModel>> {
		return repo.postTask(angazaId, requestModel)
	}

	fun updateOfflineList(isOnlineAdded: Boolean, makeTrue: Boolean): Disposable {
		return attendanceRepo.updateOfflineList(isOnlineAdded, makeTrue)
	}

	fun attendanceRXPost(context: Context, angazaId: String, attendanceRequestModel: AttendanceResponseModel?): MutableLiveData<CommonResponseModel<BaseResponseModel>> {
		return attendanceRepo.attendanceRXPost(context, angazaId, attendanceRequestModel)
	}

	fun solveabc(): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
		return customerLeadsRepo.solveabc()
	}

	fun getAwsImageModelsFromDatabase(): MutableLiveData<List<LiteAwsImageModel>> {
		return prospectiveRepo.getAwsImageModelsFromDatabase()
	}

	fun getAllInOne(): MutableLiveData<SyncCombineModel> {
		return prospectiveRepo.getAllInOne()
	}

	fun alpha(syncCombineModel: SyncCombineModel): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {

		val otpList = mutableListOf<LiteOtpApprovalRequestModel>()
		val registrationCheckinList = mutableListOf<LiteRegistrationCheckinRequestModel>()
		val installationRequestList = mutableListOf<LiteInstallationRequestModel>()

		otpList.clear()
		syncCombineModel.otpApprovalRequestModels?.let {
			otpList.addAll(it)
		}

		registrationCheckinList.clear()
		syncCombineModel.registrationCheckinRequestModels?.let {
			registrationCheckinList.addAll(it)
		}

		installationRequestList.clear()
		syncCombineModel.installationRequestModels?.let {
			installationRequestList.addAll(it)
			Log.e(TAG, "installationRequestList:$installationRequestList");
		}
		return prospectiveRepo.processSyncAll(otpList, registrationCheckinList, installationRequestList)
	}

	fun insertAwsImageModelToDatabase(inputFiles: List<LiteAwsImageModel>, isUploadedToAws: Boolean): MutableLiveData<List<LiteAwsImageModel>?> {
		return prospectiveRepo.insertAwsImageModelToDatabase(inputFiles, isUploadedToAws)
	}

	fun getInstallationRequestModelFromDatabaseById(awsImageModels: List<LiteAwsImageModel>): MutableLiveData<List<LiteInstallationRequestModel>> {
		return prospectiveRepo.getInstallationRequestModelFromDatabaseById(awsImageModels)
	}


	fun awsRX(context: Context, requestModel: BaseRequestModel): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
		return repo.awsRX(context, requestModel)
	}

	fun getVersionResponse(context: Context) : MutableLiveData<NewCommonResponseModel<AppVersionResponse>> {
		return when (Util.isOnline(context)) {
			true -> {
				repo.getRXVersion()
			}
			else -> {
				MutableLiveData(
					NewCommonResponseModel<AppVersionResponse>(
						responseData = null,
						error = NewCommonResponseModel.Error(
							messageToUser = "Unable to send data to server"
						),
						success = false
					)
				)
			}
		}
	}


	fun getCountrylist(context: Context): MutableLiveData<NewCommonResponseModel<CountryResponseData>> {
		Log.d(TAG, "getCountrylist: ")
		return repo.getCountries(context)
	}
}
