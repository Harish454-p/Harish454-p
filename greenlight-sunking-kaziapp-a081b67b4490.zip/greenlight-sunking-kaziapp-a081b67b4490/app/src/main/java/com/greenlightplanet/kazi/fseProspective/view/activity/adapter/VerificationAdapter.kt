package com.greenlightplanet.kazi.fseProspective.view.activity.adapter


import android.content.Context
import android.content.Intent
import android.graphics.Color
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ProspectiveListItemBinding
import com.greenlightplanet.kazi.fseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseModel
import com.greenlightplanet.kazi.fseProspective.view.activity.MapsCheckActivity
import org.jetbrains.annotations.NotNull


class VerificationAdapter(val context: Context, var list: List<FseProspectResponseModel>) :
    RecyclerView.Adapter<VerificationAdapter.ViewHolder>() {

    var verificationAdapterCallback: VerificationAdapterCallback? = null


    override fun onCreateViewHolder(@NotNull p0: ViewGroup, viewType: Int): ViewHolder {

//        val view: View = LayoutInflater.from(p0.context).inflate(R.layout.prospective_list_item, p0, false)
//        return ViewHolder(view)
        val itemBinding =
            ProspectiveListItemBinding.inflate(LayoutInflater.from(p0.context), p0, false)
        return ViewHolder(itemBinding)

    }

    fun statusHandler(status: String): String {
        var revisedStatus = ""

        when (status) {
            FseProspectiveConstant.ProspectStatus.PROSPECT -> {

                revisedStatus = context.getString(R.string.prospect)
            }

            FseProspectiveConstant.ProspectStatus.OTP_APPROVED -> {

                revisedStatus = context.getString(R.string.otp_approved)

            }
            FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT -> {

                revisedStatus = context.getString(R.string.pre_approve_prospect)

            }
            FseProspectiveConstant.ProspectStatus.CHECKED_IN -> {

                revisedStatus = context.getString(R.string.check_in)
            }
            FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL -> {

                revisedStatus = context.getString(R.string.cc_verification)

            }
            FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING -> {

                revisedStatus = context.getString(R.string.installation_pending)

            }
            FseProspectiveConstant.ProspectStatus.INSTALLED -> {

                revisedStatus = context.getString(R.string.installed)

            }
            FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED -> {

                revisedStatus = context.getString(R.string.installation_verified)

            }
            FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT -> {

//                revisedStatus = "Installation Verified"
                revisedStatus = context.getString(R.string.installation_verified)

            }
            else -> {
                revisedStatus = context.getString(R.string.prospect)

            }

        }

        return revisedStatus
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {


        val data = list.get(position)
        holder.bind(data,holder.itemView)

    }


//    inner class ViewHolder(override val containerView: View) :
//        RecyclerView.ViewHolder(containerView), LayoutContainer

    inner class ViewHolder(val itemBinding: ProspectiveListItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root){
            fun bind (data : FseProspectResponseModel , itemView:View){

                itemBinding.tvCustomerName.text = data.name
                itemBinding.tvProductName.text = data.productName
                itemBinding.tvCurrentStatus.text = statusHandler(data.status!!)

                if (data.latitude == null && data.longitude == null) {
                    itemBinding.btnMap.visibility = View.INVISIBLE
                } else {
                    if (data.latitude == 0.0 && data.longitude == 0.0) {
                        itemBinding.btnMap.visibility = View.INVISIBLE
                    } else {
                        itemBinding.btnMap.visibility = View.VISIBLE
                    }

                }
                itemBinding.btnMap.setOnClickListener {
                    val intent = Intent(context, MapsCheckActivity::class.java)
                    intent.putExtra("LAT", data.latitude)
                    intent.putExtra("LONG", data.longitude)
                    intent.putExtra("NAME", data.name)
                    context.startActivity(intent)
                }

                if (!data.approved) {
                    itemBinding.tvCurrentStatus.setTextColor(Color.RED)
                } else {
                    itemBinding.tvCurrentStatus.setTextColor(Color.BLACK)
                }

                itemView.setOnClickListener {
                    verificationAdapterCallback?.onTapped(position, data)
                }

                if (data.errorOccurred) {
                    itemBinding.ivError.visibility = View.VISIBLE
                } else {
                    itemBinding.ivError.visibility = View.GONE
                }


            }
        }

    override fun getItemCount(): Int {
        return list.size
    }


    interface VerificationAdapterCallback {

        fun onTapped(position: Int, value: FseProspectResponseModel)

    }

}
