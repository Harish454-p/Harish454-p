package com.greenlightplanet.kazi.feedback.view.adapter

import android.R
import android.content.Context
import android.text.Editable
import android.text.InputFilter
import android.text.InputFilter.LengthFilter
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.AdapterItemNewTicketFeedbackBinding
import com.greenlightplanet.kazi.feedback.repo.model.response.Field
import timber.log.Timber
import java.lang.ref.WeakReference


class NewTicketFeedbackAdapter() : RecyclerView.Adapter<NewTicketFeedbackAdapter.ViewHolder>() {
    lateinit var binding: AdapterItemNewTicketFeedbackBinding
    var dataList = mutableListOf<Field>()
    var selectedSpinners = mutableListOf<Field>()
    var selectedSpinnerLabel = ""
    lateinit var listener: WeakReference<NewTicketAdapterClickListener>
    val TAG = "NewTicketFeedbackAdapter"
    var isClosed = false
    var isPending = false


    fun setRvData(list: List<Field>) {
        clearRvData()
        Timber.d("$TAG  : AdapterList ->  $list")
        dataList.addAll(list)
        notifyDataSetChanged()

    }

    fun addRvData(list: List<Field>) {
        Timber.d("$TAG  : AdapterList ->  $list")
        val size = dataList.size
        dataList.addAll(list)
        if (list.size > 1) {
            notifyItemRangeInserted(size, list.size)
        } else {
            notifyItemInserted(size)
        }

    }

    fun getRvDataList(): List<Field> {
        return dataList
    }

    fun clearRvData() {
        dataList.clear()
        isClosed = false
        isPending = false
        Timber.d("$TAG  : AdapterList Cleared ")
        notifyDataSetChanged()

    }


    fun attachListener(clickListener: WeakReference<NewTicketAdapterClickListener>) {
        listener = clickListener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        binding = AdapterItemNewTicketFeedbackBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (dataList.isNotEmpty()) {
            holder.bind(dataList[position], position)
            Timber.d("$TAG: onBind -> Position: $position | List: ${dataList}")
        }

    }

    override fun getItemCount(): Int = dataList.size

    inner class ViewHolder(private val vBinding: AdapterItemNewTicketFeedbackBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(holdingData: Field, index: Int) {
            when (holdingData.type) {
                "dropdown" -> {
                    vBinding.let {
                        it.tvTitleHeader.text = holdingData.heading
                        it.tvTitleHeader.visibility = View.VISIBLE
                        it.spinnerRl.visibility = View.VISIBLE
                        it.etText.visibility = View.GONE
                        it.etDescription.visibility = View.GONE

                        selectedSpinners.add(holdingData)
                        setupSpinner(vBinding.root.context, vBinding, holdingData)
                    }
                }
                "sub-dropdown" -> {
                    vBinding.let {
                        it.tvTitleHeader.text = holdingData.heading
                        it.tvTitleHeader.visibility = View.VISIBLE
                        it.spinnerRl.visibility = View.VISIBLE
                        it.etText.visibility = View.GONE
                        it.etDescription.visibility = View.GONE
                    }
                    selectedSpinners.add(holdingData)
                    setupSpinner(vBinding.root.context, vBinding, holdingData)
                }
                "textField" -> {
                    if (holdingData.heading.lowercase().trim() == "message") {
                        vBinding.let {
                            it.tvTitleHeader.text = holdingData.heading
                            it.tvTitleHeader.visibility = View.VISIBLE
                            it.spinnerRl.visibility = View.GONE
                            it.etText.visibility = View.GONE
                            it.etDescription.apply {
                                visibility = View.VISIBLE
                                setCompoundDrawablesWithIntrinsicBounds(0, 0, com.greenlightplanet.kazi.R.drawable.ic_asterisk, 0)
                                setCompoundDrawablePadding(5)
                                setFilters(
                                    arrayOf<InputFilter>(
                                        LengthFilter(2000)
                                    )
                                )
                            }

                            setupTextChangeObserver(
                                vBinding,
                                holdingData,
                                index,
                                isText = false,
                                isDesc = true
                            )
                        }
                    } else {
                        vBinding.let {
                            if (holdingData.heading.lowercase().trim() == "account no") {
                                holdingData.isAccountNoMandatory = true
                                it.etText.apply {
                                    setCompoundDrawablesWithIntrinsicBounds(0, 0, com.greenlightplanet.kazi.R.drawable.ic_asterisk, 0)
                                    setCompoundDrawablePadding(5)
                                }
                            }
                            it.tvTitleHeader.text = holdingData.heading
                            it.etText.visibility = View.VISIBLE
                            it.tvTitleHeader.visibility = View.VISIBLE
                            it.spinnerRl.visibility = View.GONE
                            it.etDescription.visibility = View.GONE
                            setupTextChangeObserver(
                                vBinding,
                                holdingData,
                                index,
                                isText = true,
                                isDesc = false
                            )

                        }
                    }
                }
                "upload" -> {
                    vBinding.let {
                        it.spinnerRl.visibility = View.GONE
                        it.etText.visibility = View.GONE
                        it.etDescription.visibility = View.GONE
                        it.tvTitleHeader.visibility = View.GONE
                    }
                }
            }

        }

    }


    private fun setupTextChangeObserver(
        binder: AdapterItemNewTicketFeedbackBinding,
        data: Field,
        index: Int,
        isText: Boolean,
        isDesc: Boolean
    ) {
        binder.etText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(text: Editable?) {
                Timber.d("SearchView: $text")
                if (isText) {
                    dataList.forEachIndexed { i, fieldData ->
                        if (fieldData.heading == data.heading) {
                            dataList[i].apply {
                                selected = text.toString().trim()
                                atRvIndex = i
                            }
                        }
                    }
                }

            }
        })

        binder.etDescription.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(text: Editable?) {
                Timber.d("SearchView: $text")
                if (isDesc) {
                    dataList.forEachIndexed { i, fieldData ->
                        if (fieldData.heading == data.heading) {
                            dataList[i].apply {
                                selected = text.toString().trim()
                                atRvIndex = i
                            }
                        }
                    }
                }
            }
        })
    }

    private fun setupSpinner(
        context: Context,
        vBinding: AdapterItemNewTicketFeedbackBinding,
        field: Field
    ) {
        var isSelected = false
        val mutableList = mutableListOf<String>()
        Timber.d("Spinner Current Item: ${field} || Parent: $selectedSpinnerLabel")
        if (field.elements.first().parentLabel != null) {
            field.elements.forEach {
                if (it.parentLabel.equals(selectedSpinnerLabel)) {
                    mutableList.add(it.label)
                    Timber.d("Spinner Current Element Parent: ${it.parentLabel} || Parent: $selectedSpinnerLabel")
                }

            }
        } else {
            field.elements.forEach {
                mutableList.add(it.label)
                Timber.d("Spinner Current Element Else: ${it.parentLabel} || Parent: $selectedSpinnerLabel")
            }


        }

        ArrayAdapter(
            context,
            R.layout.simple_spinner_item,
            mutableList
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            vBinding.spinner.adapter = adapter
        }

        vBinding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {
                /*if (selectedSpinners.isNotEmpty()) {
                    selectedSpinners
                }*/
                /*if (!field.selected.isNullOrEmpty() && !mutableList.isNullOrEmpty()) {
                    vBinding.spinner.setSelection(field.selectedSpItemIndex)
                }*/
                if (true) {
                    Timber.d("Spinner Item Clicked: ${mutableList[position]}")
                    var selectedIndex = 0
                    var size = dataList.size
                    var selectedData: Field? = null
                    dataList.forEachIndexed { index, fieldData ->
                        if (fieldData.heading == field.heading) {
                            Timber.d("Spinner Item Selected Obj: $fieldData")
                            selectedData = dataList[index].apply {
                                selected = mutableList[position]
                                atRvIndex = index
                                selectedIndex = index
                                selectedSpItemIndex = position
                                Timber.d("Spinner Item at $index Selected Obj: $this")
                            }
                            /*if (selectedData?.heading == "Category") {
                                val data = dataList.first()
                                dataList.clear()
                                dataList.add(data)
                                notifyDataSetChanged()
                            }*/

                        }
                    }
                    if (dataList.size - 1 != selectedIndex) {
                        val removeList = mutableListOf<Field>()
                        for (d in selectedIndex + 1..dataList.size - 1) {
                            removeList.add(dataList[d])
                        }
                        dataList.removeAll(removeList)
                        Timber.d("Spinner DataList After removed: $removeList || dataList size: ${dataList.size}")
                        notifyItemRangeRemoved(selectedIndex + 1, size)
                    }
                    /* selectedSpinners.forEach{
                         if (it.atRvIndex == selectedIndex) {
                             val newList = mutableListOf<Field>()
                             dataList.forEachIndexed{ i , data ->
                                 if (i <= selectedIndex) {
                                     newList.add(data)
                                 }
                             }
                             notifyItemRangeRemoved(selectedIndex+1,size)
                         }
                     }*/
                    selectedSpinnerLabel = mutableList[position]
                    listener.get()?.onSpinnerItemSelected(field, mutableList[position])

                }
                isSelected = true


            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

        }
    }

}


interface NewTicketAdapterClickListener {
    fun onTicketItemClicked(data: Field)
    fun onSpinnerItemSelected(fieldData: Field, selectedLabel: String)
}