package com.greenlightplanet.kazi.liteFseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import com.greenlightplanet.kazi.liteFseProspective.model.CombineRequestModel
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseData
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import com.greenlightplanet.kazi.liteFseProspective.model.LiteOtpApprovalRequestModel
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteProspectiveRepo
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteVerificationRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable

class VerificationViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "VerificationViewModel"

    }

    val repo = LiteVerificationRepo.getInstance(application)
    val pRepo = LiteProspectiveRepo.getInstance(application)

    fun processOtp(
        context: Context,
        isOnline: Boolean,
        isValid: Boolean,
        prospectID: String,
        angazaId: String,
        unsuccessfulAttempt: Int = 0,
        country: String,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?>? {

        showProgress()

        if (isValid) {
            return repo.onValidOtp(isOnline, prospectID, angazaId, country)
        } else {
            return repo.onInvalidOtp(isOnline, prospectID, angazaId, unsuccessfulAttempt, country)
        }
    }

    fun getCombineRequestModel(prospectID: String): MutableLiveData<CombineRequestModel?> {
        return repo.getCombineRequestModel(prospectID)
    }

    fun sendOtpApprovalToServerForceUpload(
        isValid: Boolean,
        otpApprovalRequest: LiteOtpApprovalRequestModel,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return repo.sendOtpApprovalToServerForceUpload(isValid, otpApprovalRequest)
    }

    fun getFseProspectiveFromServer(
        angazaId: String,
        prospectId: String,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>? {
        showProgress()
        return repo.getFseProspectiveFromServer(angazaId, prospectId)
    }

    fun getFseProspectiveFromDatabase(): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {
        return pRepo.getFseProspectiveFromDatabase()
    }

    fun getAllVerificationFSE(): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {
        return repo.getAllVerificationFSE()
    }

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }

}
