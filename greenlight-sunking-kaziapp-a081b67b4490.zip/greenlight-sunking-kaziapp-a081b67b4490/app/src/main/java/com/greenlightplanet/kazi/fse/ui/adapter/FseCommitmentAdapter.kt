package com.greenlightplanet.kazi.fse.ui.adapter

import android.content.Context
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.greenlightplanet.kazi.databinding.AdapterFseCommitmentBinding
import com.greenlightplanet.kazi.fse.model.Fse

class FseCommitmentAdapter constructor(private val context: Context, private val values: List<Fse?>, val isTimePassed: Boolean) :
        RecyclerView.Adapter<FseCommitmentAdapter.ViewHolder>() {


    companion object {
        public const val TAG = "FseCommitmentAdapter"
    }

    var eoAdapterCallback: FseCommitmentAdapterCallback? = null


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val itemBinding = AdapterFseCommitmentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(itemBinding)

    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val fse = values.get(position)
        holder.bind(fse,position)


    }

    override fun getItemCount(): Int = values.size


    inner class ViewHolder(val itemBinding: AdapterFseCommitmentBinding) :
        RecyclerView.ViewHolder(itemBinding.root){
        fun bind(fse: Fse?, position: Int) {

            itemBinding.tvCustomerName.text = fse?.customerName
            itemBinding.tvDaysDisabled.text = "${fse?.daysDisabled}"




            itemBinding.cbSelection.setOnCheckedChangeListener(null)


            fse?.isSubmitted?.let {
                itemBinding.cbSelection.isChecked = fse.isSubmitted
            }


            //if (true) {
            if (isTimePassed) {
                itemBinding.cbSelection.isClickable = false
                itemBinding.cbSelection.setOnCheckedChangeListener(null)
                itemBinding.cbSelection.isEnabled = false
            } else {


                itemBinding.cbSelection.isClickable = true
                itemBinding.cbSelection.isEnabled = true

                itemBinding.cbSelection.setOnCheckedChangeListener { buttonView, isChecked ->

                    eoAdapterCallback?.let {
                        it.onChecked(fse!!.accountNumber, position, isChecked)

                    }
                }
            }
        }
    }


    interface FseCommitmentAdapterCallback {

        fun onChecked(accountNumber: String, position: Int, isChecked: Boolean)

    }


}
