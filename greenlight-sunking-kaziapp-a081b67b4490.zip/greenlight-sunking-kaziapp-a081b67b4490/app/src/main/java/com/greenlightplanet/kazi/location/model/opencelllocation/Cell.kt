package com.greenlightplanet.kazi.location.model.opencelllocation


import com.google.gson.annotations.SerializedName

data class Cell(
    @SerializedName("cid")
    var cid: Int?, // 17811
    @SerializedName("lac")
    var lac: Int? // 7033
)
