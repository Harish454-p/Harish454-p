package com.greenlightplanet.kazi.dashboard.model.response

import android.os.Parcelable
import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import java.io.Serializable

@Keep
class LoginResponseModel:Serializable {

    @SerializedName("country")
    var country:String?=null
    @SerializedName("firstName")
    var firstName:String?=null
    @SerializedName("lastName")
    var lastName:String?=null
    @SerializedName("language")
    var language:String?=null
    @SerializedName("showProspectTab")
    var showProspectTab:Boolean=false
    @SerializedName("showWebViewTab")
    var showWebViewTab:Boolean=false
    @SerializedName("territory")
    var territory:String?=null
    @SerializedName("angazaId")
    var angazaId:String?=null
    @SerializedName("phoneNumber")
    var phoneNumber:String?=null
    @SerializedName("securityKey")
    var securityKey:String?=null
	override fun toString(): String {
		return "LoginResponseModel(country=$country, firstName=$firstName, lastName=$lastName, language=$language, showProspectTab=$showProspectTab, showWebViewTab=$showWebViewTab, territory=$territory, angazaId=$angazaId, phoneNumber=$phoneNumber, securityKey=$securityKey)"
	}


	/* var appVersion:String?=null
	 var appForceUpdate:String?=null*/


}
