package com.greenlightplanet.kazi.location.newworker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.util.Log

import android.widget.Toast


class GpsLocationReceiver : BroadcastReceiver() {
	override fun onReceive(context: Context, intent: Intent) {
		Log.d("GPS_PROVIDER", "Something ");

		if (intent.action!!.contains("android.intent.action.TIME_TICK")) {
			Log.d("GPS_PROVIDER", "TIME CHANGE: ");

			/*Toast.makeText(context, "in android.location.PROVIDERS_CHANGED",
				Toast.LENGTH_SHORT).show()*/
			/*val pushIntent = Intent(context, LocalService::class.java)
			context.startService(pushIntent)*/
		}else{
			Log.d("GPS_PROVIDER", "OTHER ");


//			NewAlarmUtils.setNewAlarm(context, 0)

		}
		/*Toast.makeText(context, "in android.location.PROVIDERS_CHANGED",
			Toast.LENGTH_SHORT).show()*/

	}
}
