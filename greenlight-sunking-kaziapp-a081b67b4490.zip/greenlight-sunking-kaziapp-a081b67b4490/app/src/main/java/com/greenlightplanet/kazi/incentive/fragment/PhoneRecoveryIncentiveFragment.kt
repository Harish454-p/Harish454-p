package com.greenlightplanet.kazi.incentive.fragment

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentPhoneRecoveryBinding
import com.greenlightplanet.kazi.incentive.model.others
import com.greenlightplanet.kazi.incentive.model.phoneRecovery
import com.greenlightplanet.kazi.incentive.viewmodel.starClubVM
import com.greenlightplanet.kazi.utils.Constants
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util


class PhoneRecoveryIncentiveFragment : Fragment() {

    private  var _binding :FragmentPhoneRecoveryBinding ? = null
    private val binding get() = _binding!!
    var phoneRecovery: phoneRecovery? = null
    var others: others? = null
    var preference: GreenLightPreference? = null
    var flagStartClub: Boolean = true
    lateinit var viewModel: starClubVM

    lateinit var fav: MenuItem
    var flag: Boolean = true
    var flagReumbesment: Boolean = true
    private fun setPhoneRecoveryDetails() {
        binding.tvPhoneValue.setText(Util.checkBlankNA(phoneRecovery?.phoneValue, context))
        binding.tvRecoveryAmount.text = Util.checkBlankNA(phoneRecovery?.phoneRecoveredAmount, context)
        binding.tvRemainingBalance.text = Util.checkBlankNA(phoneRecovery?.phoneBalance, context)


        binding.tvTotalAirtime.text = Util.checkBlankNAS(others?.callReimbursement, context)
        binding.tvTotalSecond.text = Util.checkBlankNASymbole(others?.totalCallDuration, context)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        _binding = FragmentPhoneRecoveryBinding.inflate(inflater, container, false)
        viewModel = ViewModelProviders.of(this).get(starClubVM::class.java)

        binding.phoneviewId.setOnClickListener(View.OnClickListener {
            phoneVisible(requireView())
        })

        binding.kaziCallviewId.setOnClickListener(View.OnClickListener { reumbesmentVisible(requireView()) })
        binding.kaziStartClub.setOnClickListener(View.OnClickListener { starClubVisible(requireView()) })

        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val bundlesales = arguments
        phoneRecovery = bundlesales?.getSerializable("phoneRecovery") as phoneRecovery?
        others = bundlesales?.getSerializable("others") as others?

        preference = GreenLightPreference.getInstance(requireActivity())
        setPhoneRecoveryDetails()
    }

    fun phoneVisible(view: View) {
        if (flag) {
            binding.showPhoneView.visibility = View.VISIBLE
            flag = false
            binding.tvOption.setRotation(Constants.ROTATION_180)
            binding.phoneviewId.setBackgroundResource(R.drawable.square_border_without_bottom)

        } else {
            binding.showPhoneView.visibility = View.GONE
            flag = true
            binding.tvOption.setRotation(Constants.ROTATION_360)
            binding.phoneviewId.setBackgroundResource(R.drawable.square_border_with_bottom)


        }
    }

    fun reumbesmentVisible(view: View) {
        if (flagReumbesment) {
            binding.showkaziReumbesmentView.visibility = View.VISIBLE
            flagReumbesment = false
            binding.tvOptionKaziCall.setRotation(Constants.ROTATION_180)
           binding.kaziCallviewId.setBackgroundResource(R.drawable.square_border_without_bottom)


        } else {
            binding.showkaziReumbesmentView.visibility = View.GONE
            flagReumbesment = true
            binding.tvOptionKaziCall.setRotation(Constants.ROTATION_360)
            binding.kaziCallviewId.setBackgroundResource(R.drawable.square_border_with_bottom)

        }

    }

    fun starClubVisible(view: View) {
        if (flagStartClub) {
            binding.showkaziStartClubView.visibility = View.VISIBLE
            flagStartClub = false
            binding.tvImgStarClub.setRotation(Constants.ROTATION_180)
            binding.kaziStartClub.setBackgroundResource(R.drawable.square_border_without_bottom)
            startClub()


        } else {
            binding.showkaziStartClubView.visibility = View.GONE
            flagStartClub = true
            binding.tvImgStarClub.setRotation(Constants.ROTATION_360)
            binding.kaziStartClub.setBackgroundResource(R.drawable.square_border_with_bottom)

        }
    }

    fun startClub() {

        viewModel.getstartClubData(requireContext(), preference?.getLoginResponseModel()?.angazaId!!).observe(viewLifecycleOwner, Observer {

            if (it?.responseData?.collectionScore != null) {
                binding.tvCollectionScroreValue.text = it?.responseData?.collectionScore.toString()
            } else {
                binding.tvCollectionScroreValue.text = "0"
            }
            if (it?.responseData?.salesPreviousMonth != null) {
                binding.tvWeightUnitValue.text = it?.responseData?.salesPreviousMonth.toString()
            } else {
                binding.tvWeightUnitValue.text = "0"
            }
            binding.tvDurationValue.text = it?.responseData?.duration ?: "0"
            binding.tvTierValue.text = it?.responseData?.tier ?: "0"
            binding.tvAirtimeIncentiveeValue.text = Util.checkBlankNAS(it?.responseData?.airtimeIncentive.toString(), context)
            binding.tvTravelIncentiveeValue.text = Util.checkBlankNAS(it?.responseData?.travelIncentive.toString(), context)
            if (it?.responseData?.ineternetBundle != null) {
                binding.tvInternetBundelValue.text = it?.responseData?.ineternetBundle.toString()
            } else {
                binding.tvInternetBundelValue.text = "0"

            }

        })
    }


}// Required empty public constructor
