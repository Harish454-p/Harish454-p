package com.greenlightplanet.kazi.incentivenew.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.incentive.model.StarClubResponseModel
import com.greenlightplanet.kazi.incentivenew.model.deduction.DeductionResponseData
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryResponseData
import com.greenlightplanet.kazi.task.model.dialogIntent.FeedbackModel
import com.greenlightplanet.kazi.task.model.dialogIntent.NotAnsweredModel
import com.greenlightplanet.kazi.task.model.response.CallDetail
import com.greenlightplanet.kazi.task.model.response.TaskMddel
import com.greenlightplanet.kazi.task.model.response.firstCall

import io.reactivex.Single

@Dao
interface DeductionDao {

    @Query("SELECT * FROM DeductionResponseData")
    fun getAllDeduction(): Single<DeductionResponseData>


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(deductionResponseData: DeductionResponseData): Long

    @Query("DELETE FROM DeductionResponseData")
    fun deleteAll(): Int




}
