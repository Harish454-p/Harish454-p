package com.greenlightplanet.kazi.incentivenew.adapter.tvinstallation


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.EligbleListItemBinding
import com.greenlightplanet.kazi.databinding.EligbleTvListItemBinding
import com.greenlightplanet.kazi.incentivenew.model.tvinstallation.AccountsList


/**
 * Created by Rahul on 03/12/20.
 */
class TvInstallationEligibleAdapter(
    private val listData: List<AccountsList>, var listener: MyDateData,
    var context: Context
) : RecyclerView.Adapter<TvInstallationEligibleAdapter.ViewHolder?>() {
    private var lastPosition = -1

    override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
    ): ViewHolder {

       val itemBinding = EligbleTvListItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(itemBinding)
    }

    override fun onBindViewHolder(
            holder: ViewHolder,
            position: Int
    ) {
        val myListData: AccountsList = listData[position]
        holder.bind(myListData)

    }

    override fun getItemCount(): Int {
        return listData.size
    }

    class ViewHolder(private val itemBinding: EligbleTvListItemBinding) : RecyclerView.ViewHolder(itemBinding.root) {

        fun bind(myListData: AccountsList) {
            itemBinding.tvRegistrationDate.text = myListData.registrationDate
            itemBinding.tvAccountNumber.text = myListData.accountNumber.toString()
            itemBinding.tvProductNameValue.visibility = View.GONE
        }
    }

    interface MyDateData {

        fun selectedData(date: String, position: Int)


    }



}