package com.greenlightplanet.kazi.incentivenew.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.incentive.model.StarClubResponseModel
import com.greenlightplanet.kazi.incentive.starclubrepo.StarClubRepo
import com.greenlightplanet.kazi.incentivenew.model.deduction.DeductionResponseData
import com.greenlightplanet.kazi.incentivenew.model.earning.EarningResponseData
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryResponseData
import com.greenlightplanet.kazi.incentivenew.repo.IncentiveRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel

/**
 * Created by Rahul on 09/12/20.
 */

class DeductionViewModel(application: Application) : AndroidViewModel(application)  {

    val repo = IncentiveRepo.getInstance(application)

    fun getDeductionata(
            context: Context,
            angazaId: String?
    ): MutableLiveData<NewCommonResponseModel<DeductionResponseData>> {

        return repo.getDeductionData(context, angazaId = angazaId)
    }
}
