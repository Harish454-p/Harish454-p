package com.greenlightplanet.kazi.atrisk.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import com.greenlightplanet.kazi.newtasks.model.CallDetailModel
import kotlinx.android.parcel.Parcelize

@Parcelize
data class AtRiskAccountModel(
    @ColumnInfo(name = "collection_account")
    @SerializedName("collection_account")
    val collectionAccount: List<CollectionAccount>
) : Parcelable {
    @Parcelize
    @Entity(tableName = "CollectionAtRiskAccount")
    data class CollectionAccount(

        @PrimaryKey
        @ColumnInfo(name = "id")
        @SerializedName("id")
        var id: Int?, // 1

        @ColumnInfo(name = "account_angaza_id")
        @SerializedName("account_angaza_id")
        var accountAngazaId: String?, // AC202841

        @ColumnInfo(name = "account_number")
        @SerializedName("account_number")
        var accountNumber: Int?, // 6032874

        @ColumnInfo(name = "address")
        @SerializedName("address")
        var address: String?, // NA

        @ColumnInfo(name = "amount_collected")
        @SerializedName("amount_collected")
        var amountCollected: Double?, // 0.0

        @ColumnInfo(name = "angaza_id")
        @SerializedName("angaza_id")
        var angazaId: String?, // US032809

        @ColumnInfo(name = "balance_amount")
        @SerializedName("balance_amount")
        var balanceAmount: Double?, // 8400.0

        @ColumnInfo(name = "collection_expected_paid")
        @SerializedName("collection_expected_paid")
        var collectionExpectedPaid: Double?, // 400.0

        @ColumnInfo(name = "collection_paid")
        @SerializedName("collection_paid")
        var collectionPaid: Double?, // 100.0

        @ColumnInfo(name = "collection_rate")
        @SerializedName("collection_rate")
        var collectionRate: Double?, // 0.0

        @ColumnInfo(name = "collection_wtd")
        @SerializedName("collection_wtd")
        var collectionWtd: Double?, // 0.0

        @ColumnInfo(name = "customer_name")
        @SerializedName("customer_name")
        var customerName: String?, // Florence Akoth Onyango

        @ColumnInfo(name = "days_disabled")
        @SerializedName("days_disabled")
        var daysDisabled: Int?, // 761

        @ColumnInfo(name = "expected_paid")
        @SerializedName("expected_paid")
        var expectedPaid: Double?, // 12800.0


        @ColumnInfo(name = "last_paid_date")
        @SerializedName("last_paid_date")
        var lastPaidDate: String?, // 2018-08-06

        @ColumnInfo(name = "latitude")
        @SerializedName("latitude")
        var latitude: Double?, // -0.3716

        @ColumnInfo(name = "longitude")
        @SerializedName("longitude")
        var longitude: Double?, // 34.9733

        @ColumnInfo(name = "owner_phone_number")
        @SerializedName("owner_phone_number")
        var ownerPhoneNumber: String?, // +254728225408

        @ColumnInfo(name = "part_of_collection_rate")
        @SerializedName("part_of_collection_rate")
        var partOfCollectionRate: String?, // Yes

        @ColumnInfo(name = "pending_payment")
        @SerializedName("pending_payment")
        var pendingPayment: String?, // 342345

        @ColumnInfo(name = "pending_to_exit_risk_permanent")
        @SerializedName("pending_to_exit_risk_permanent")
        var pendingToExitRiskPermanent: Int?, // 34

        @ColumnInfo(name = "product_name")
        @SerializedName("product_name")
        var product_name: String?, // Home 60 + Radio

        @ColumnInfo(name = "rate")
        @SerializedName("rate")
        var rate: Double?, // 0.0

        @ColumnInfo(name = "registration_date")
        @SerializedName("registration_date")
        var registrationDate: String?, // 2017-09-08

        @ColumnInfo(name = "secondary_phone_number")
        @SerializedName("secondary_phone_number")
        var secondaryPhoneNumber: String?, // +254701810205

        @ColumnInfo(name = "status")
        @SerializedName("status")
        var status: String?, // DISABLED

        @ColumnInfo(name = "total_paid")
        @SerializedName("total_paid")
        var totalPaid: Double?, // 4400.0

        @ColumnInfo(name = "sync_date")
        @SerializedName("sync_date")
        var syncDate: String = "",

        @ColumnInfo(name = "product_group")
        @SerializedName("product_group")
        var productGroup: String = "",

        //region new added while calling
        @ColumnInfo(name = "successfulCallMessage")
        @SerializedName("successfulCallMessage")
        var successfulCallMessage: String? = "",
        @ColumnInfo(name = "account_latitude")
        @SerializedName("account_latitude")
        val accountLatitude: String? = "",
        @ColumnInfo(name = "accountLongitude")
        @SerializedName("accountLongitude")
        val accountLongitude: String? = "",
        @ColumnInfo(name = "taskAttempt")
        @SerializedName("taskAttempt")
        var taskAttempt: Int?,
        @ColumnInfo(name = "taskId")
        @SerializedName("taskId")
        var taskId: Long,
        @ColumnInfo(name = "task_status")
        @SerializedName("task_status")
        var taskStatus: String? = "",
        @ColumnInfo(name = "is_task")
        @SerializedName("is_task")
        val isTask: Boolean? = false,
        @ColumnInfo(name = "alternate_contacts")
        @SerializedName("alternate_contacts")
        var alternateContacts: List<String>?,
        @ColumnInfo(name = "accountExpectedPaid")
        @SerializedName("accountExpectedPaid")
        val accountExpectedPaid: String? = "",
        @ColumnInfo(name = "call_detail")
        var callDetail: MutableList<CallDetailModel>? = mutableListOf(),
        //endregion
        @ColumnInfo(name = "eligible_for_reimbursement")
        @SerializedName("eligible_for_reimbursement")
        var eligibleForReimbursement: Boolean?


    ) : Parcelable


}

