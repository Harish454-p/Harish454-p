package com.greenlightplanet.kazi.location.worker

import android.content.Context
import android.util.Log
import androidx.work.RxWorker
import androidx.work.WorkerParameters
import com.example.alarms.AlarmUtils
import com.greenlightplanet.kazi.location.dao.LocationRequestDao
import com.greenlightplanet.kazi.location.model.LocationRequestModel
import com.greenlightplanet.kazi.location.model.LocationResponseModel
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable

class HourWorkerRx(private val context: Context, workerParams: WorkerParameters) :
	RxWorker(context, workerParams) {

	companion object {
		public const val TAG = "HourWorkerRx"
	}

	/*val bag = CompositeDisposable()
	val dao: LocationRequestDao
	val routes: Routes*/

	private val bag = CompositeDisposable()
	private var localDb: AppDatabase? = null
	private val dao: LocationRequestDao

	var preference: GreenLightPreference? = null

	init {

		localDb = AppDatabase.getAppDatabase(context)
		preference = GreenLightPreference.getInstance(context)
		dao = localDb!!.locationRequestDao()

	}


	private fun doIfOnlineFunctionality(): Single<Int>? {
		var locationRequestModels: List<LocationRequestModel>? = null
		return getAllLocationRequestModel()
			.flatMap {
				locationRequestModels = it
				sendLocationRequestModelToServer(it)
			}
			.flatMap {
				//todo delete logic
				deleteAllLocationRequestModelFromDB(locationRequestModels!!)
//                    Single.just(1)
			}
	}


	private fun insertLocationRequestModelToDB(locationRequestModel: LocationRequestModel): Single<Long> {

		return Single.fromCallable {
			dao.insert(locationRequestModel)
		}

	}

	private fun getAllLocationRequestModel(): Single<List<LocationRequestModel>> {

		return dao.getAll()
	}

	private fun sendLocationRequestModelToServer(locationRequestModels: List<LocationRequestModel>): Single<LocationResponseModel> {

		return ServiceInstance.getInstance(context).service?.sendLocation(locationRequestModels)!!
	}

	private fun deleteAllLocationRequestModelFromDB(locationRequestModels: List<LocationRequestModel>): Single<Int> {

		return Single.fromCallable {
			dao.deleteAllAnother(locationRequestModels)
		}
	}

	override fun createWork(): Single<Result> {

		Log.d(TAG, "createWork: CALLED");
		preference?.setLastCalledWorker(System.currentTimeMillis())

//        return sendLocationToApi(isOnline(context))

		/*val outputData = workDataOf("KEY_USER_ID" to 123)
		Log.d(TAG, "createWork:Called ");
		return Single.create { Result.success(outputData) }*/
		return Single.create { Result.success() }
	}

	fun setAlarm(context: Context) {

//        AlarmUtils.setAlarm(context, 2)

		var locationInterval = preference?.getLocationIntervalWM() ?: DEFAULT_INTERVAL
		if (locationInterval <= 0) {
			locationInterval = DEFAULT_INTERVAL
		}

		AlarmUtils.setAlarm(context, locationInterval)

		Log.d(TAG, "locationInterval:$locationInterval ");

	}


}
