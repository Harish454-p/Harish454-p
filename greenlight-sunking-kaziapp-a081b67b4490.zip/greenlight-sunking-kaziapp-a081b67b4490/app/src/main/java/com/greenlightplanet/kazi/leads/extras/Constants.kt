package com.greenlightplanet.kazi.leads.extras

object LEAD_TAB {
    var PENDING: String = "Pending"
    var CALLED: String = "Called"
    var RESOLVED: String = "Resolved"
}

object LEAD_STATUS {
    var PENDING: String = "PENDING"
    var REASSIGNED: String = "REASSIGNED"
    var CALLED: String = "CALLED"
}

object LEAD_INTENT{
    var CANCLE: Int = 4
    var DID_NOT_ANSWER: Int = 1
    var OTHER: Int = 5
}