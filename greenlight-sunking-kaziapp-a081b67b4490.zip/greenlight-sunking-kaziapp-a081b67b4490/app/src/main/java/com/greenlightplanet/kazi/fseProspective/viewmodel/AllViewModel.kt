package com.greenlightplanet.kazi.fseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseData
import com.greenlightplanet.kazi.fseProspective.model.FseProspectResponseModel
import com.greenlightplanet.kazi.fseProspective.repo.ProspectiveRepo
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel

class AllViewModel(application: Application) : AndroidViewModel(application) {

    private val TAG : String = "AllViewModel"
    private val repo = ProspectiveRepo(context = application.applicationContext)


    fun getFseProspectiveFromDatabase() : MutableLiveData<NewCommonResponseModel<FseProspectResponseData>> {
        return repo.getFseProspectiveFromDatabase()!!
    }

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }
}