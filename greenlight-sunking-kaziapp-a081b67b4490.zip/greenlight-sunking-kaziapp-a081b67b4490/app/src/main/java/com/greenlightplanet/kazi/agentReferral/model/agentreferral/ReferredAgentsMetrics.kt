package com.greenlightplanet.kazi.agentReferral.model.agentreferral


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ReferredAgentsMetrics(
    @SerializedName("successfully_referred_agents_count")
    var successfullyReferredAgentsCount: Int?,
    @SerializedName("total_referral_incentive_last_month")
    var totalReferralIncentiveLastMonth: String?,
    @SerializedName("total_referred_agents_count")
    var totalReferredAgentsCount: Int?,
    @SerializedName("total_sales_by_referred_agents_last_month")
    var totalSalesByReferredAgentsLastMonth: String?
) : Parcelable