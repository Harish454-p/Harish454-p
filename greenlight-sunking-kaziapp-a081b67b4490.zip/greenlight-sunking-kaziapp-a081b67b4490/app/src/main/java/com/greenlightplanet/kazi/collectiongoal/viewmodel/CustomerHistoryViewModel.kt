package com.greenlightplanet.kazi.collectiongoal.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistoryModel
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistoryModel
import com.greenlightplanet.kazi.collectiongoal.repo.SummaryNewRepository
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.newtasks.model.FeedbackIntentModel
import com.greenlightplanet.kazi.newtasks.repo.TaskRepo
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.disposables.CompositeDisposable

class CustomerHistoryViewModel(application: Application): AndroidViewModel(application) {

    var summaryRepo: SummaryNewRepository? = SummaryNewRepository.getInstance(application)

    val taskRepo = TaskRepo.getInstance(application)

    private val compositeDisposable = CompositeDisposable()

    val callDetailsData = summaryRepo?.callDetailsData

    fun getCallingHistoryData(accountNumber: Int?, nextPage: Int):
            MutableLiveData<NewCommonResponseModel<CallHistoryModel>>? {

        if (Util.isOnline(getApplication())){
            return summaryRepo?.getCallHistoryServer(accountNumber,nextPage)
        }
        else {
            return summaryRepo?.getCallingHistoryDB(accountNumber,nextPage)
        }
    }

    fun getCallingHistoryData1(accountNumber: Int?, nextPageCalling: Int):
            MutableLiveData<NewCommonResponseModel<CallHistoryModel>>? {
        return summaryRepo?.getCallHistory1(accountNumber,nextPageCalling)
    }


    fun getPaymentHistoryData(accountNumber: Int?, nextPagePayment: Int):
            MutableLiveData<NewCommonResponseModel<PaymentHistoryModel>>? {
        if (Util.isOnline(getApplication())){
            return summaryRepo?.getPaymentHistoryServer(accountNumber,nextPagePayment)
        }else {
            return summaryRepo?.getPaymentHistoryDB(accountNumber,nextPagePayment)
        }
    }

    val paymentHistoryDetailsData = summaryRepo?.paymentHistoryDetailsData

    fun getPaymentHistoryData1(accountNumber: Int?, pageNumber: Int):
            MutableLiveData<NewCommonResponseModel<PaymentHistoryModel>>? {
        return summaryRepo?.getPaymentHistory1(accountNumber,pageNumber)
    }

    fun clear() {
        compositeDisposable.dispose()
    }

    override fun onCleared() {
        super.onCleared()
        compositeDisposable.dispose()

    }

    fun getTaskIntentFromDb(): MutableLiveData<NewCommonResponseModel<FeedbackIntentModel>> {
        return taskRepo!!.getTaskIntentFromDb()
    }

    fun insertCallHistoryTargetResponseToDb(
        it: NewCommonResponseModel<CallHistoryModel>,
        data: MutableLiveData<NewCommonResponseModel<CallHistoryModel>>,
        accountNumber: Int?) {
        summaryRepo?.insertCallHistoryTargetResponseToDb(it,data,accountNumber)
    }

    fun insertPaymentHistoryTargetResponseToDb(
        it: NewCommonResponseModel<PaymentHistoryModel>,
        data: MutableLiveData<NewCommonResponseModel<PaymentHistoryModel>>,
        accountNumber: Int?,
        nextPage: Int, ) {
        summaryRepo?.insertPaymentHistoryTargetResponseToDb(it,data,accountNumber,nextPage)
    }
}