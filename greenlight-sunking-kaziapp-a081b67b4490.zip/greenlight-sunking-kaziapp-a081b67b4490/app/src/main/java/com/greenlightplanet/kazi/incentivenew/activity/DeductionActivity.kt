package com.greenlightplanet.kazi.incentivenew.activity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivityDeductionBinding
import com.greenlightplanet.kazi.incentivenew.adapter.DeductionAdapter
import com.greenlightplanet.kazi.incentivenew.model.deduction.DeductionResponseData
import com.greenlightplanet.kazi.incentivenew.viewmodel.DeductionViewModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener

/**
 * Created by Rahul on 07/12/20.
 */
class DeductionActivity : BaseActivity(), DeductionAdapter.MyDateData, DeductionAdapter.WebCallBack {

    private lateinit var binding:ActivityDeductionBinding


    private val TAG = "DeductionActivity"
    lateinit var viewModel: DeductionViewModel
    var mHomeWatcher: HomeWatcher? = null
    var preference: GreenLightPreference? = null

   // var recyclerView: RecyclerView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_deduction)
        binding = ActivityDeductionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME

        initialize()


        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }

    fun initialize() {

        Util.setToolbar(this, binding.toolbar2!!)
        preference = GreenLightPreference.getInstance(this)

        val symbol: String? = preference?.getCountryResponseModel()?.countryCurrency ?: "NA"

        val values = intent.getStringExtra("deduction")
        binding.tvDeductionAmount.text = "${getString(R.string.deduction)} : ($symbol ${values?.let { Util.formatAmount(it?.toDouble()?:0.0) }})"
        binding.tvAmountKey.text = "${getString(R.string.amount)} ($symbol)"
        Util.addEvent("305", "Deduction", "DeductionScreen")

        ApiCall()
    }

    fun ApiCall() {
        showProgressDialog(this)
        viewModel = ViewModelProviders.of(this).get(DeductionViewModel::class.java)//US015055
        viewModel.getDeductionata(this, preference?.getLoginResponseModel()?.angazaId).observe(this, Observer { response ->

            if (response != null) {

                if (response.success) {
                    if (response.success) {
                        if (response.responseData?.deductionFields?.size!! > 0) {
                            binding.tvNoData.visibility = View.GONE
                        } else {
                            binding.tvNoData.visibility = View.VISIBLE
                        }
                    }
                    cancelProgressDialog()
                    setAdapter(response.responseData)
                    updateSharedPref(true)

                } else {
                    cancelProgressDialog()
                    binding.tvNoData.visibility = View.VISIBLE
                    //  Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show()
                }
            }
        })

    }

    fun setAdapter(responseData: DeductionResponseData?) {

        //binding.recyclerView = findViewById<View>(R.id.recyclerView) as RecyclerView
        val adapter = responseData?.deductionFields?.let { DeductionAdapter(it, this, this,this) }
        binding.recyclerView?.setHasFixedSize(true)
        binding. recyclerView?.layoutManager = LinearLayoutManager(this)

        binding. recyclerView?.adapter = adapter
    }

    override fun selectedData(date: String, position: Int) {

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()

        return true
    }

    private fun updateSharedPref(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadIncentiveFromPref(this)

        if (data == null) {
            data = LastSaved()
            data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(this, data)
            binding.tvLastSaved.text = data.incentive

        } else {

            if (fromInternet) {
                data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(this, data)
                binding.tvLastSaved.text = data.incentive
            } else {
                binding.tvLastSaved.text = data.incentive

            }
        }

    }

    override fun getWebLink(link: String) {
        startActivity(Intent(this, IncentiveWeb::class.java).putExtra("link", link))
        Util.addEvent("306", "Deduction", "DeductionScreen_to_incentiveWeb_link")

    }

    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();
    }

}