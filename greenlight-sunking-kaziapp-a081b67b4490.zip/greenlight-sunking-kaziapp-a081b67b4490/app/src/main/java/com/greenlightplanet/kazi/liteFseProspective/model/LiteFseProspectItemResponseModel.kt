package com.greenlightplanet.kazi.liteFseProspective.model


import androidx.room.ColumnInfo
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class LiteFseProspectItemResponseModel(
        @ColumnInfo(name = "prospect")
        @SerializedName("prospect")
        var prospect: LiteFseProspectResponseModel?
) : Parcelable {
    /*@Parcelize
    @Entity(tableName = "%s")
    data class Prospect(
        @ColumnInfo(name = "accountNumber")
        @SerializedName("accountNumber")
        var accountNumber: String?, // 28108702
        @ColumnInfo(name = "approved")
        @SerializedName("approved")
        var approved: Boolean?, // false
        @ColumnInfo(name = "area")
        @SerializedName("area")
        var area: String?, // Sokoto
        @ColumnInfo(name = "attempt")
        @SerializedName("attempt")
        var attempt: Int?, // 0
        @ColumnInfo(name = "country")
        @SerializedName("country")
        var country: String?,
        @ColumnInfo(name = "customerAddress")
        @SerializedName("customerAddress")
        var customerAddress: String?, // arkilla state low cost, opp Biga college of education arkilla
        @ColumnInfo(name = "customerPhoneNumber")
        @SerializedName("customerPhoneNumber")
        var customerPhoneNumber: String?, // +919074711066
        @ColumnInfo(name = "installationPicture")
        @SerializedName("installationPicture")
        var installationPicture: String?, // https://s3.eu-west-2.amazonaws.com/kazi-userfiles-mobilehub-391300116/fse_prospective/Kazi_15689004252541298612991.jpg
        @ColumnInfo(name = "message")
        @SerializedName("message")
        var message: String?,
        @ColumnInfo(name = "name")
        @SerializedName("name")
        var name: String?, // Ayush Baheti
        @ColumnInfo(name = "otp")
        @SerializedName("otp")
        var otp: Int?, // 7528
        @ColumnInfo(name = "productName")
        @SerializedName("productName")
        var productName: String?, // SHS 120 + 4L
        @ColumnInfo(name = "prospectId")
        @SerializedName("prospectId")
        var prospectId: String?, // PP1010101
        @ColumnInfo(name = "status")
        @SerializedName("status")
        var status: String?, // INSTALLATION_REATTEMPT
        @ColumnInfo(name = "statusUpdateTime")
        @SerializedName("statusUpdateTime")
        var statusUpdateTime: StatusUpdateTime?,
        @ColumnInfo(name = "ticketType")
        @SerializedName("ticketType")
        var ticketType: String?, // INSTALLATION
        @ColumnInfo(name = "unsuccessfulOtpAttempts")
        @SerializedName("unsuccessfulOtpAttempts")
        var unsuccessfulOtpAttempts: Int? // 0
    ) : Parcelable {
        @Parcelize
        @Entity(tableName = "%s")
        data class StatusUpdateTime(
            @ColumnInfo(name = "checkedIn")
            @SerializedName("checkedIn")
            var checkedIn: String?, // 2019-09-19 12:07:58
            @ColumnInfo(name = "installationPending")
            @SerializedName("installationPending")
            var installationPending: String?, // 2019-09-19 12:08:58
            @ColumnInfo(name = "installationReattempt")
            @SerializedName("installationReattempt")
            var installationReattempt: String?, // 2019-09-19 12:08:58
            @ColumnInfo(name = "installationVerified")
            @SerializedName("installationVerified")
            var installationVerified: String?, // 2019-09-19 12:08:58
            @ColumnInfo(name = "installed")
            @SerializedName("installed")
            var installed: String?, // 2019-09-19 12:08:58
            @ColumnInfo(name = "otpApproved")
            @SerializedName("otpApproved")
            var otpApproved: String?, // 2019-09-19 11:41:39
            @ColumnInfo(name = "preApprovedProspect")
            @SerializedName("preApprovedProspect")
            var preApprovedProspect: String?, // 2019-08-29 13:39:19
            @ColumnInfo(name = "prospect")
            @SerializedName("prospect")
            var prospect: String?, // 2019-08-29 13:39:19
            @ColumnInfo(name = "threeWayCallVerification")
            @SerializedName("threeWayCallVerification")
            var threeWayCallVerification: String? // 2019-09-19 12:07:58
        ) : Parcelable
    }*/
}
