package com.greenlightplanet.kazi.agentReferral.model.referralStatusDetail


import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Entity(tableName = "ReferralDetail")
@Parcelize
data class ReferralDetail(
    @PrimaryKey(autoGenerate = true)
    val id : Int = 0,
    @ColumnInfo(name = "statusId")
    var statusId : Int?,
    @ColumnInfo(name = "assessment_sms_body")
    @SerializedName("assessment_sms_body")
    var assessmentSmsBody: String?,
    @ColumnInfo(name = "reason")
    @SerializedName("reason")
    var reason : String?,
    @ColumnInfo(name = "childPhone")
    var childPhone : String?,
    @ColumnInfo(name = "created_at")
    @SerializedName("created_at")
    var createdAt: String?,
    @ColumnInfo(name = "stage")
    @SerializedName("stage")
    var stage: String?,
    @ColumnInfo(name = "status")
    @SerializedName("status")
    var status: String?,
    @ColumnInfo(name = "act_time")
    @SerializedName("act_time")
    var actTime : String?
) : Parcelable