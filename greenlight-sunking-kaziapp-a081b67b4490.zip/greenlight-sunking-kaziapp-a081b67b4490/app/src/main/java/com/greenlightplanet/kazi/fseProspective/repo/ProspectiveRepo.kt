package com.greenlightplanet.kazi.fseProspective.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.os.Parcelable
import android.util.Log
import com.greenlightplanet.kazi.dashboard.model.FakeLocationRequest
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.fseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.fseProspective.model.*
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class ProspectiveRepo(val context: Context) {

    companion object :
        SingletonHolderUtil<ProspectiveRepo, Context>(::ProspectiveRepo) {
        public const val TAG = "ProspectiveRepo"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null


    //new added for sync process
    val verificationRepo = VerificationRepo.getInstance(context)
    val registrationRepo = RegistrationRepo.getInstance(context)
    val installationRepo = InstallationRepo.getInstance(context)

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context!!)

        } catch (e: Exception) {
            Log.d(TAG, ":Error ");
        }
    }


    //fun getFseProspectiveFromDatabase(): MutableLiveData<List<FseProspectResponseModel>> {
    fun getFseProspectiveFromDatabase(): MutableLiveData<NewCommonResponseModel<FseProspectResponseData>>? {

        val data = MutableLiveData<NewCommonResponseModel<FseProspectResponseData>>()


        localDb?.let { appDatabase ->
            bag.add(

                appDatabase.fseProspectResponseDao().getAll()
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        Log.d(TAG, "DB-EO-List: ${it}")

                        val value =
                            data.postValue(
                                NewCommonResponseModel<FseProspectResponseData>(
                                    responseData = FseProspectResponseData(prospects = it),
                                    success = true
                                )
                            )
                    }, { t ->
                        Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        data.postValue(
                            NewCommonResponseModel<FseProspectResponseData>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable to find data in database"
                                ),
                                success = false
                            )
                        )
                    })

            )
        }

        return data
    }


    //Not in use currently
    /*fun getFseProspectiveFromServer(angazaId: String): MutableLiveData<List<FseProspectResponseModel>> {


        var data: MutableLiveData<List<FseProspectResponseModel>> = MutableLiveData<List<FseProspectResponseModel>>()


        bag.add(

                ServiceInstance.getInstance(this).service?.getFseProspectives(angazaId)!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")

                                bag.add(

                                        fseProspectiveFromServerLogic(data, responseData)
                                )
                            }

                        }, { t ->

                            Log.d(TAG, "API-Error3: ${t.localizedMessage}")

                            data.postValue(null)
                        })
        )

        return data
    }*/

    private fun fseProspectiveFromServerLogic(
        liveData: MutableLiveData<NewCommonResponseModel<FseProspectResponseData>>,
        responseData: NewCommonResponseModel<FseProspectResponseData>
    ) {

        bag.add(
            Completable.fromAction {
                localDb?.fseProspectResponseDao()
                    ?.insertAll(responseData.responseData!!.prospects!!)
            }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Insertion:Completed ")
                    preference?.setFseProspectLastSynced(Util.getCurrentLocalFormattedDateForSync())
                    liveData.postValue(responseData)
                    Log.d("TIME_CALC", "prospect-end:${System.currentTimeMillis()} ")
                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })
        )

    }


    fun insertAwsImageModelToDatabase(
        inputFiles: List<AwsImageModel>,
        isUploadedToAws: Boolean
    ): MutableLiveData<List<AwsImageModel>?> {
        return installationRepo.insertAwsImageModelToDatabase(inputFiles, isUploadedToAws)
    }

    //fun getFseProspectiveFromServer(angazaId: String): MutableLiveData<List<FseProspectResponseModel>> {
    fun getFseProspectiveFromServer(angazaId: String): MutableLiveData<NewCommonResponseModel<FseProspectResponseData>>? {

        val data = MutableLiveData<NewCommonResponseModel<FseProspectResponseData>>()

        var value: NewCommonResponseModel<FseProspectResponseData>? = null

        Log.d("TIME_CALC", "prospect-start:${System.currentTimeMillis()} ")
        bag.add(

            localDb!!.fseProspectResponseDao().getAll()
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable { listFromDatabase ->
                    // here delete all data from database
                    Completable.fromAction {
                        localDb!!.fseProspectResponseDao().deleteAll()
                    }.doOnError {
                        Log.d(TAG, "Error-2: ${it.localizedMessage}");
                        data.postValue(
                            NewCommonResponseModel<FseProspectResponseData>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from server"
                                ),
                                success = false
                            )
                        )
                        it.printStackTrace()
                    }.doOnComplete {
                        //ServiceInstance.getInstance(context).service?.getFseProspectives()!!
                        ServiceInstance.getInstance(context).service?.getFseProspectives(/*angazaId = angazaId*/)!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                value = it

                                val databaseList = listFromDatabase.toMutableList()

                                val serverList = value!!.responseData!!.prospects!!.toMutableList()

                                //val uniqueInDb = mutableListOf<FseProspectResponseData>()

                                try {
                                    databaseList.forEach { databaseItem ->

                                        if (serverList.find { it.prospectId == databaseItem.prospectId } == null) {
                                            databaseList.remove(databaseItem)
                                        }
                                    }
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                    Log.d(
                                        TAG,
                                        "insertAwsImageModelToDatabase-error:${e.localizedMessage}"
                                    )
                                }


                                val combinedList = databaseList + serverList

                                //new Value Added in server response
                                val distinctValueFromServer = combinedList.groupBy { it.prospectId }
                                    .filter { it.value.size == 1 }
                                    .flatMap { it.value }


                                val notNewAddedServerValue =
                                    serverList.toSet().minus(distinctValueFromServer.toSet())
                                        .toMutableList()
                                val notNewAddedDatabaseValue =
                                    databaseList.toSet().minus(distinctValueFromServer.toSet())
                                        .toMutableList()

                                val oldChangedData = mutableListOf<FseProspectResponseModel>()

                                notNewAddedServerValue.forEach { itemServer ->

                                    val sameDataInDatabase =
                                        notNewAddedDatabaseValue.find { it.prospectId == itemServer.prospectId }

                                    fun statusUpdateTimeHandler(
                                        oldStatus: FseProspectResponseModel.StatusUpdateTime,
                                        newStatus: FseProspectResponseModel.StatusUpdateTime,
                                        oldFseProspectResponseModel: FseProspectResponseModel
                                    ): FseProspectResponseModel.StatusUpdateTime {
                                        var revisedStatus = oldStatus

                                        if (!newStatus.prospect.isNullOrEmpty()) {
                                            revisedStatus.prospect = newStatus.prospect
                                        }


                                        if (!newStatus.otpApproved.isNullOrEmpty()) {
                                            revisedStatus.otpApproved = newStatus.otpApproved
                                        }


                                        if (!newStatus.preApprovedProspect.isNullOrEmpty()) {
                                            revisedStatus.preApprovedProspect =
                                                newStatus.preApprovedProspect
                                        }

                                        if (!newStatus.checkedIn.isNullOrEmpty()) {
                                            revisedStatus.checkedIn = newStatus.checkedIn
                                        }

                                        if (!newStatus.threeWayCallVerification.isNullOrEmpty()) {
                                            revisedStatus.threeWayCallVerification =
                                                newStatus.threeWayCallVerification
                                        }

                                        if (!newStatus.installationPending.isNullOrEmpty()) {
                                            revisedStatus.installationPending =
                                                newStatus.installationPending
                                        }


                                        if (oldFseProspectResponseModel.reattemptedStage == 0) {
                                            //if(oldFseProspectResponseModel.reattemptedStage != 1 || oldFseProspectResponseModel.reattemptedStage != 2){
                                            if (!newStatus.installed.isNullOrEmpty()) {
                                                revisedStatus.installed = newStatus.installed
                                            }

                                            if (!newStatus.installationVerified.isNullOrEmpty()) {
                                                revisedStatus.installationVerified =
                                                    newStatus.installationVerified
                                            }
                                        }

                                        return revisedStatus
                                    }

                                    fun statusHandler(
                                        oldStatus: String,
                                        newStatus: String
                                    ): String {
                                        var revisedStatus = ""

                                        when (oldStatus) {
                                            FseProspectiveConstant.ProspectStatus.PROSPECT -> {

                                                if (newStatus == FseProspectiveConstant.ProspectStatus.OTP_APPROVED) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.PROSPECT
                                                }

                                            }

                                            FseProspectiveConstant.ProspectStatus.OTP_APPROVED -> {
                                                if (newStatus == FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.OTP_APPROVED
                                                }
                                            }
                                            FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT -> {
                                                if (newStatus == FseProspectiveConstant.ProspectStatus.CHECKED_IN) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.PRE_APPROVED_PROSPECT
                                                }
                                            }
                                            FseProspectiveConstant.ProspectStatus.CHECKED_IN -> {

                                                if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                } else if (newStatus == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.CHECKED_IN
                                                }
                                            }
                                            FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL -> {
                                                if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                                }
                                            }
                                            FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING -> {
                                                if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLED) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLED
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                }
                                            }
                                            FseProspectiveConstant.ProspectStatus.INSTALLED -> {
                                                if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                                } else if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLED
                                                }
                                            }
                                            FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED -> {

                                                if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                                }
                                            }

                                            FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT -> {

                                                if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                }
                                            }

                                            else -> {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PROSPECT
                                            }

                                        }

                                        return revisedStatus
                                    }

                                    sameDataInDatabase?.let {

                                        sameDataInDatabase.approved = itemServer.approved
                                        sameDataInDatabase.message = itemServer.message
                                        sameDataInDatabase.customerAddress =
                                            itemServer.customerAddress

                                        sameDataInDatabase.name = itemServer.name
                                        sameDataInDatabase.otp = itemServer.otp
                                        sameDataInDatabase.productName = itemServer.productName
                                        sameDataInDatabase.status = statusHandler(
                                            sameDataInDatabase.status!!,
                                            itemServer.status!!
                                        )
                                        sameDataInDatabase.statusUpdateTime =
                                            statusUpdateTimeHandler(
                                                sameDataInDatabase.statusUpdateTime!!,
                                                itemServer.statusUpdateTime!!,
                                                sameDataInDatabase
                                            )
                                        sameDataInDatabase.ticketType = itemServer.ticketType
                                        sameDataInDatabase.accountNumber = itemServer.accountNumber
                                        sameDataInDatabase.installationPicture =
                                            itemServer.installationPicture
                                        sameDataInDatabase.customerPhoneNumber =
                                            itemServer.customerPhoneNumber
                                        sameDataInDatabase.area = itemServer.area
                                        sameDataInDatabase.latitude = itemServer.latitude
                                        sameDataInDatabase.longitude = itemServer.longitude
                                        //
                                        sameDataInDatabase.prospectLocation =
                                            itemServer.prospectLocation
                                        sameDataInDatabase.sampleImages = itemServer.sampleImages
                                        sameDataInDatabase.installationPictures =
                                            itemServer.installationPictures

                                        oldChangedData.add(sameDataInDatabase)

                                    }
                                    //need to add some new attributes here
                                }


                                val resultData = oldChangedData + distinctValueFromServer


                                if (resultData.isNotEmpty()) {

                                    //data.postValue(value)
                                    value!!.responseData!!.prospects = resultData
                                    fseProspectiveFromServerLogic(data, value!!)

                                } else {
                                    data.postValue(
                                        NewCommonResponseModel<FseProspectResponseData>(
                                            error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable get data from server"
                                            ),
                                            success = false
                                        )
                                    )
                                }
                            }, {
                                Log.d(TAG, "Error-1: ${it.localizedMessage}");

                                data.postValue(
                                    NewCommonResponseModel<FseProspectResponseData>(
                                        error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable get data from server"
                                        ),
                                        success = false
                                    )
                                )

                                it.printStackTrace()
                            })
                    }
                }.doOnError {
                    Log.d(TAG, "Error-1: ${it.localizedMessage}");
                    data.postValue(
                        NewCommonResponseModel<FseProspectResponseData>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from server"
                            ),
                            success = false
                        )
                    )
//                            it.printStackTrace()
                }.subscribe({
//                    Log.d(TAG, " on Success ===");
                }, {
                    Log.d(TAG, " Error:${it.printStackTrace()}");
                })

        )

        return data
    }


    //region Sync
    fun getAwsImageModelsFromDatabase(): MutableLiveData<List<AwsImageModel>> {

        val data = MutableLiveData<List<AwsImageModel>>()
        bag.add(
            localDb?.awsImageModelDao()?.getAll()!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(it)
                }, {
                    data.postValue(null)
                })
        )

        return data
    }

    fun getOtpApprovalRequestModelFromDatabase(): MutableLiveData<List<OtpApprovalRequestModel>> {

        val data = MutableLiveData<List<OtpApprovalRequestModel>>()


        bag.add(

            localDb?.otpApprovalRequestDao()?.getAll()!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(it)
                }, {
                    data.postValue(null)
                })
        )

        return data
    }

    fun getRegistrationCheckinRequestModelFromDatabase(): MutableLiveData<List<RegistrationCheckinRequestModel>> {

        val data = MutableLiveData<List<RegistrationCheckinRequestModel>>()


        bag.add(

            localDb?.registrationCheckinRequestDao()?.getAll()!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(it)
                }, {
                    data.postValue(null)
                })
        )

        return data
    }

    fun getInstallationRequestModelFromDatabase(): MutableLiveData<List<InstallationRequestModel>> {

        val data = MutableLiveData<List<InstallationRequestModel>>()


        bag.add(

            localDb?.installationRequestDao()?.getAll()!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(it)
                }, {
                    data.postValue(null)
                })
        )

        return data
    }

    fun getInstallationRequestModelFromDatabaseById(awsImageModels: List<AwsImageModel>): MutableLiveData<List<InstallationRequestModel>> {

        val data = MutableLiveData<List<InstallationRequestModel>>()

        var installationRequestsByIds = mutableListOf<InstallationRequestModel>()

        Log.d(TAG, "DEMO:0 ")

        bag.add(
            localDb?.installationRequestDao()
                ?.getAllByProspectId(awsImageModels.map { it.prospectId })!!
                .flatMapCompletable {
                    Log.d(TAG, "DEMO:1 ");
                    installationRequestsByIds = it.toMutableList()
                    installationRequestsByIds.forEach { request ->

                        val sameAwsImageModelFilter =
                            awsImageModels.filter { it.prospectId == request.prospectId }
                        Log.d(TAG, "sameAwsImageModelFilter:1  ==== $sameAwsImageModelFilter")
                        sameAwsImageModelFilter.let {
                            /*new tried*/
                            it.forEach { list ->
                                request.images!!.map {
                                    if (it.imageName == list.imageName) {
                                        it.installationPictures = list.awsLink
                                    }
                                }
                            }
                        }
                    }

                    Completable.fromAction {
                        localDb!!.installationRequestDao().insertAll(installationRequestsByIds)
                    }

                }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "DEMO:2 ")
                    data.postValue(installationRequestsByIds)
                }, {
                    Log.d(TAG, "DEMO:3 ${it.localizedMessage}")
                    data.postValue(null)
                })
        )

        return data
    }

    fun getAllInOne2(): MutableLiveData<SyncCombineModel> {
        val data = MutableLiveData<SyncCombineModel>()

        var syncCombineModel = SyncCombineModel()
        bag.add(
            localDb?.otpApprovalRequestDao()?.getAll()?.flatMap {
                syncCombineModel.otpApprovalRequestModels = it
                localDb?.registrationCheckinRequestDao()?.getAll()!!.flatMap {
                    syncCombineModel.registrationCheckinRequestModels = it
                    localDb?.installationRequestDao()?.getAll()!!
                }
            }!!.subscribe({
                syncCombineModel.installationRequestModels = it
                data.postValue(syncCombineModel)
            }, {

                it.printStackTrace()
            })
        )

        return data

    }


    fun getAllInOne(): MutableLiveData<SyncCombineModel> {
        val data = MutableLiveData<SyncCombineModel>()

        val syncCombineModel = SyncCombineModel()
        bag.add(
            localDb?.fseProspectResponseDao()?.getAllIsChanged()?.flatMap { isChangedFse ->

                Log.d(TAG, "s1: $isChangedFse");
                Log.d(TAG, "s5: ${isChangedFse.map { it.prospectId }}");

                localDb?.otpApprovalRequestDao()
                    ?.getAllByProspectID(isChangedFse.map { it.prospectId })
                    ?.flatMap { otpApprovalRequests ->
                        Log.d(TAG, "s2: $otpApprovalRequests");
                        syncCombineModel.otpApprovalRequestModels = otpApprovalRequests
                        localDb?.registrationCheckinRequestDao()
                            ?.getAllByProspectId(isChangedFse.map { it.prospectId })!!
                            .flatMap { registrationCheckins ->
                                Log.d(TAG, "s3: $registrationCheckins")
                                syncCombineModel.registrationCheckinRequestModels =
                                    registrationCheckins
                                localDb?.installationRequestDao()
                                    ?.getAllByProspectId(isChangedFse.map { it.prospectId })!!
                            }
                    }

            }!!
                .subscribe({
                    Log.d(TAG, "s4: $it");
                    syncCombineModel.installationRequestModels = it
                    data.postValue(syncCombineModel)
                }, {
                    it.printStackTrace()
                })
        )

        return data
    }


    fun processSyncAll(
        otpList: MutableList<OtpApprovalRequestModel>,
        registrationCheckinList: MutableList<RegistrationCheckinRequestModel>,
        installationRequestList: MutableList<InstallationRequestModel>
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()


        val requests = mutableListOf<Observable<out List<Parcelable>>>()

        if (!otpList.isNullOrEmpty()) {
            requests.add(verificationRepo.processAll(otpList).toObservable())
        }


        if (!registrationCheckinList.isNullOrEmpty()) {
            requests.add(registrationRepo.processAll(registrationCheckinList).toObservable())
        }


        if (!installationRequestList.isNullOrEmpty()) {
            requests.add(installationRepo.processAll(installationRequestList).toObservable())
        }


        Log.d(TAG, "requests-realsize:${requests.size} ");

        bag.add(

            Observable.zip(requests) {
                //Log.d(TAG, "requests-newsize:${it.get(1)} ");
//                data.postValue(
//                    NewCommonResponseModel<NewEmptyParcelable>(
//                        success = true
//                    )
//                )

            }.subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "DB-EO-List2: ${it}")
                    data.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            success = true
                        )
                    )
                }, { t ->
                    t.printStackTrace()

                    //data.postValue(null)
                    data.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )
                    Log.d(TAG, "API-Error: ${t.localizedMessage}")
                })

        )

        return data

    }
    //endregion Sync


    fun awsRX(
        context: Context,
        requestModel: BaseRequestModel
    ): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
        val data = MutableLiveData<CommonResponseModel<AWSResponseModel>>()

        bag.add(
            ServiceInstance.getInstance(context).service!!.awsRx(requestModel)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "||=======${it}")
                    data.postValue(it)

                }, {
                    Log.e(TAG, "||=======EROORRRR = $it")
                    data.postValue(
                        CommonResponseModel<AWSResponseModel>().apply {
                            this.Error =
                                com.greenlightplanet.kazi.member.Error(MessageToUser = "Unable to send data to server")
                            this.Success = false
                        }
                    )
                })
        )

        return data

    }





    public fun sendFakeLocationRequestToServer(context: Context,angazaId: String, fakeLocationRequest: FakeLocationRequest): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        if (Util.isOnline(context)) {
            bag.add(
                ServiceInstance.getInstance(context).service!!.postFakeLocationLog(angazaId,fakeLocationRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        Log.e(TAG, "||FAKEAPIRESPONSE=======${it}")
                        data.postValue(it)

                    }, {
                        Log.e(TAG, "||=======EROORRRR = $it")
                        data.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false

                        ))
                    })
            )
        }
        return  data
    }

    fun destroy() {
        Log.d(TAG, "Repo : == Destroyed");
//        registrationRepo.destroy()
//        verificationRepo.destroy()
        bag.clear()

    }
}

