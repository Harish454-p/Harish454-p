package com.greenlightplanet.kazi.fse.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "Fse")
@TypeConverters(FseDetailsResponse.FseConverter::class)
class Fse constructor(
        @PrimaryKey
        @ColumnInfo(name = "accountNumber")
        @SerializedName("accountNumber")
        var accountNumber: String, // 9282828
        @ColumnInfo(name = "angazaId")
        @SerializedName("angazaId")
        var angazaId: String?, // US029933
        @ColumnInfo(name = "customerName")
        @SerializedName("customerName")
        var customerName: String?, // Yogesh Baid
        @ColumnInfo(name = "daysDisabled")
        @SerializedName("daysDisabled")
        var daysDisabled: Int?, // 56
        @ColumnInfo(name = "commitmentDate")
        @SerializedName("commitmentDate")
        var commitmentDate: String?, // 17-11-2019
        @ColumnInfo(name = "isSubmitted")
        @SerializedName("isSubmitted")
        var isSubmitted: Boolean = false // false
) : Parcelable
