@file:Suppress("DEPRECATION")

package com.greenlightplanet.kazi

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.multidex.MultiDexApplication
import androidx.preference.PreferenceManager
import com.facebook.stetho.Stetho
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.location.newworker.LocationUpdatesService
import com.greenlightplanet.kazi.location.newworker.MyReceiver
import com.greenlightplanet.kazi.location.newworker.NewFourgroundService
import com.greenlightplanet.kazi.notification.extra.FCMService
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.jakewharton.threetenabp.AndroidThreeTen
import dagger.hilt.android.HiltAndroidApp

import timber.log.Timber
import timber.log.Timber.Forest.plant
import java.io.File


@HiltAndroidApp
class KaziApplication : MultiDexApplication() , LifecycleObserver, SharedPreferences.OnSharedPreferenceChangeListener {

	@OnLifecycleEvent(Lifecycle.Event.ON_START)
	fun onEnterForeground() {
		Log.d("AppController", "Foreground")

		//isAppInBackground(false)
		//startRequesting(this)

		// Bind to the service. If the service is in foreground mode, this signals to the service
		// that since this activity is in the foreground, the service can exit foreground mode.

		bindService(Intent(this, LocationUpdatesService::class.java)
			,mServiceConnection, Context.BIND_AUTO_CREATE)
	}

	@OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
	fun onResume() {
		Log.d("AppController", "ON_RESUME")
//		isAppInBackground(false)
//		startRequesting(this)
		LocalBroadcastManager.getInstance(this).registerReceiver(myReceiver!!,
				IntentFilter(LocationUpdatesService.ACTION_BROADCAST))

	}


	@OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
	fun onPause() {
		Log.d("AppController", "ON_PAUSE")
//		isAppInBackground(false)
//		onStop(this)
//		LocalBroadcastManager.getInstance(this).unregisterReceiver(myReceiver!!)
		if (mBound) {
			unbindService(mServiceConnection)
			mBound = false
		}
		PreferenceManager.getDefaultSharedPreferences(this)
				.unregisterOnSharedPreferenceChangeListener(this)
	}

	@SuppressLint("AndroidLogDetector")
	@OnLifecycleEvent(Lifecycle.Event.ON_STOP)
	fun onEnterBackground() {
		Log.d("AppController", "Background")
		isAppInBackground(true)
		//onStop(this)
	}

	// Adding some callbacks for test and log
	interface ValueChangeListener {
		fun onChanged(value: Boolean?)
	}

	private var visibilityChangeListener: ValueChangeListener? = null
	fun setOnVisibilityChangeListener(listener: ValueChangeListener?) {
		visibilityChangeListener = listener
	}

	private fun isAppInBackground(isBackground: Boolean) {
		if (null != visibilityChangeListener) {
			visibilityChangeListener!!.onChanged(isBackground)
		}
	}

    companion object {

		var instancez: KaziApplication? = null
		var mFirebaseAnalytics: FirebaseAnalytics? = null

		var greenPreference: GreenLightPreference? = null

		const val STARTFOREGROUND_ACTION = "STARTFOREGROUND_ACTION"
		const val STOPFOREGROUND_ACTION = "STOPFOREGROUND_ACTION"
		var preference: GreenLightPreference? = null

		//abcd
		var mService: LocationUpdatesService? = null
		private var mBound = false
		private var myReceiver: MyReceiver? = null
		lateinit var mInstance: KaziApplication
		fun getInstance(): KaziApplication? {
			return mInstance
		}

		fun checkPermission(context: Context): Boolean {
			return (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
					PackageManager.PERMISSION_GRANTED
					&& ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
					PackageManager.PERMISSION_GRANTED
					&& ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) ==
					PackageManager.PERMISSION_GRANTED)
		}


		private val mServiceConnection: ServiceConnection = object : ServiceConnection {
			override fun onServiceConnected(name: ComponentName, service: IBinder) {
				val binder: LocationUpdatesService.LocalBinder = service as LocationUpdatesService.LocalBinder
				mService = binder.service
				mBound = true
			}

			override fun onServiceDisconnected(name: ComponentName) {
				mService = null
				mBound = false
			}
		}
	}

	fun getFirebaseInstance(): FirebaseAnalytics {
		if (mFirebaseAnalytics == null) {
			mFirebaseAnalytics = FirebaseAnalytics.getInstance(this)
		}
		return mFirebaseAnalytics as FirebaseAnalytics
	}

    override fun onCreate() {
        super.onCreate()
        instancez = this
		mInstance = this
		Helper.application = applicationContext as Application
		ProcessLifecycleOwner.get().lifecycle.addObserver(this)

		preference = GreenLightPreference.getInstance(this)

		myReceiver = MyReceiver()

		PreferenceManager.getDefaultSharedPreferences(this)
				.registerOnSharedPreferenceChangeListener(this)

		if (BuildConfig.DEBUG) {
			plant(Timber.DebugTree())
		}

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			val name = getString(R.string.channel_name)
			val descriptionText = getString(R.string.channel_description)
//			val importance = NotificationManager.IMPORTANCE_DEFAULT
			val importance = NotificationManager.IMPORTANCE_HIGH
			val channel = NotificationChannel(FCMService.CHANNEL_ID, name, importance).apply {
				description = descriptionText
				enableLights(true)
			}
			// Register the channel with the system
			val notificationManager: NotificationManager =
				getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
			notificationManager.createNotificationChannel(channel)

		}


		getInstance()?.setOnVisibilityChangeListener(object : ValueChangeListener {
			override fun onChanged(value: Boolean?) {
				Log.d("AppController", value.toString())
//				if (value == true) {
////					onStop(this@KaziApplication)
//				} else {
//					//if (Utils.requestingLocationUpdates(this@KaziApplication)) {
//					//startRequesting(this@KaziApplication)
//					//}
//				}
			}
		})


        Stetho.initializeWithDefaults(this)

        AndroidThreeTen.init(this)

		AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
		FirebaseApp.initializeApp(this)

		//FirebaseMessaging.getInstance().setAutoInitEnabled(true);

		val crashlytics = FirebaseCrashlytics.getInstance()
		crashlytics.setCrashlyticsCollectionEnabled(true)

		mFirebaseAnalytics = FirebaseAnalytics.getInstance(this)
		mFirebaseAnalytics?.setAnalyticsCollectionEnabled(true)

        // FirebaseInstanceId.getInstance().getInstanceId()
        greenPreference = GreenLightPreference.getInstance(this)

    }

	private fun stopForeService() {
		val service = Intent(this, NewFourgroundService::class.java)
		service.action = STOPFOREGROUND_ACTION
		stopService(service)
	}

    fun initWorkManager() {

        /*val locationInterval = greenPreference?.getLocationInterval() ?: DEFAULT_INTERVAL

        val work_tag = "hour_work"

        if (checkPersmission()) {
            if (!WorkManagerFactory.isWorkScheduled(work_tag)) {
                WorkManagerFactory.scheduleWork(work_tag, locationInterval)
            }
        }*/

    }

    fun deleteFile(file: File?): Boolean {
        var deletedAll = true
        if (file != null) {
            if (file.isDirectory) {
                val children = file.list()
                for (i in children!!.indices) {
                    deletedAll = deleteFile(File(file, children[i])) && deletedAll
                }
            } else {
                deletedAll = file.delete()
            }
        }

        return deletedAll
    }

    fun clearApplicationData() {
        val cacheDirectory = cacheDir
        val applicationDirectory = File(cacheDirectory.parent!!)
        if (applicationDirectory.exists()) {
            val fileNames = applicationDirectory.list()
            for (fileName in fileNames!!) {
                if (fileName != "lib") {
                    deleteFile(File(applicationDirectory, fileName))
                }
            }
        }

    }

//	fun fcmErrorHandling() {
//		if (greenPreference?.getLoginResponseModel() != null) {
////            Crashlytics.setBool("isLoggedIn", true)
////            Crashlytics.setString("userData", greenPreference?.getLoginResponseModel().toString())
//		} else {
////            Crashlytics.setBool("isLoggedIn", false)
//		}
//	}

//	private fun checkPersmission(): Boolean {
//        return (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
//                PackageManager.PERMISSION_GRANTED)
//    }

	override fun onTerminate() {
		stopForeService()
		super.onTerminate()
	}

	override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {

		// Update the buttons state depending on whether location updates are being requested.
//		if (s == Utils.KEY_REQUESTING_LOCATION_UPDATES) {
//			setButtonsState(sharedPreferences!!.getBoolean(Utils.KEY_REQUESTING_LOCATION_UPDATES,
//				false))
//		}
	}

}

