package com.greenlightplanet.kazi.fseProspective.view.activity

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.view.ViewAnimationUtils
import android.view.animation.AccelerateDecelerateInterpolator

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivityMapsCheckBinding

import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener


class MapsCheckActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private var LAT: Double? = null
    private var LONG: Double? = null
    private var NAME: String? = null
	var mHomeWatcher: HomeWatcher? = null

    private lateinit var binding: ActivityMapsCheckBinding

	override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_maps_check)
        binding = ActivityMapsCheckBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

		Log.d("MapsCheckActivity", "onCreate: ");
        if (intent.hasExtra("LAT")) {
            LAT = intent.getDoubleExtra("LAT", 0.0)
        }

        if (intent.hasExtra("LONG")) {
            LONG = intent.getDoubleExtra("LONG", 0.0)
        }

        if (intent.hasExtra("NAME")) {
            NAME = intent.getStringExtra("NAME")
        }

		mHomeWatcher = HomeWatcher(this)
		mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
			override fun onHomePressed() {
				finish()
			}
		})
		mHomeWatcher!!.startWatch()
    }

    @SuppressLint("RestrictedApi")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Sydney and move the camera
        val sydney = LatLng(LAT!!, LONG!!)
        mMap.addMarker(MarkerOptions().position(sydney).title(NAME))
        val zoomLevel = 16.0f
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, zoomLevel))

        // Initialise the map variable

        // When map is initially loaded, determine which map type option to 'select'
        when {
            mMap.mapType == GoogleMap.MAP_TYPE_SATELLITE -> {
                binding.mapTypeSatelliteBackground.visibility = View.VISIBLE
                binding.mapTypeSatelliteText.setTextColor(Color.BLUE)
            }
            mMap.mapType == GoogleMap.MAP_TYPE_TERRAIN -> {
                binding.mapTypeSatelliteBackground.visibility = View.VISIBLE
                binding.mapTypeTerrainText.setTextColor(Color.BLUE)
            }
            else -> {
                binding.mapTypeDefaultBackground.visibility = View.VISIBLE
                binding.mapTypeDefaultText.setTextColor(Color.BLUE)
            }
        }

        // Set click listener on FAB to open the map type selection view
        binding.mapTypeFAB.setOnClickListener {

            // Start animator to reveal the selection view, starting from the FAB itself
            val anim = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                ViewAnimationUtils.createCircularReveal(
                    binding.mapTypeSelection,
                    binding.mapTypeSelection.width - (binding.mapTypeFAB.width / 2),
                    binding.mapTypeFAB.height / 2,
                    binding.mapTypeFAB.width / 2f,
                    binding.mapTypeSelection.width.toFloat())
            } else {
                TODO("VERSION.SDK_INT < LOLLIPOP")
            }
            anim.duration = 200
            anim.interpolator = AccelerateDecelerateInterpolator()

            anim.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationStart(animation: Animator) {
                    super.onAnimationEnd(animation)
                    binding.mapTypeSelection.visibility = View.VISIBLE
                }
            })

            anim.start()
            binding.mapTypeFAB.visibility = View.INVISIBLE

        }

        // Set click listener on the map to close the map type selection view
        mMap.setOnMapClickListener {

            // Conduct the animation if the FAB is invisible (window open)
            if (binding.mapTypeFAB.visibility == View.INVISIBLE) {

                // Start animator close and finish at the FAB position
                val anim = ViewAnimationUtils.createCircularReveal(
                    binding.mapTypeSelection,
                    binding.mapTypeSelection.width - (binding.mapTypeFAB.width / 2),
                    binding.mapTypeFAB.height / 2,
                    binding.mapTypeSelection.width.toFloat(),
                    binding.mapTypeFAB.width / 2f)
                anim.duration = 200
                anim.interpolator = AccelerateDecelerateInterpolator()

                anim.addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        super.onAnimationEnd(animation)
                        binding.mapTypeSelection.visibility = View.INVISIBLE
                    }
                })

                // Set a delay to reveal the FAB. Looks better than revealing at end of animation
                Handler().postDelayed({
                    kotlin.run {
                        binding.mapTypeFAB.visibility = View.VISIBLE
                    }
                }, 100)
                anim.start()
            }
        }

        // Handle selection of the Default map type
        binding.mapTypeDefault.setOnClickListener {
            binding.mapTypeDefaultBackground.visibility = View.VISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.INVISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.INVISIBLE
            binding.mapTypeDefaultText.setTextColor(Color.BLUE)
            binding.mapTypeSatelliteText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeTerrainText.setTextColor(Color.parseColor("#808080"))
            mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
        }

        // Handle selection of the Satellite map type
        binding.mapTypeSatellite.setOnClickListener {
            binding.mapTypeDefaultBackground.visibility = View.INVISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.VISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.INVISIBLE
            binding.mapTypeDefaultText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeSatelliteText.setTextColor(Color.BLUE)
            binding.mapTypeTerrainText.setTextColor(Color.parseColor("#808080"))
            mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
        }

        // Handle selection of the terrain map type
        binding.mapTypeTerrain.setOnClickListener {
            binding.mapTypeDefaultBackground.visibility = View.INVISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.INVISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.VISIBLE
            binding.mapTypeDefaultText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeSatelliteText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeTerrainText.setTextColor(Color.BLUE)
            mMap.mapType = GoogleMap.MAP_TYPE_TERRAIN
        }

    }


	override fun onDestroy() {
		super.onDestroy()
		mHomeWatcher?.stopWatch();

	}
}
