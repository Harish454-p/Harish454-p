package com.greenlightplanet.kazi.agentReferral.model.referredagentlist

data class ReferralFilterModel(
    var search : String?,
    var firstDate : Long?,
    var secondDate : Long?,
    var status: String?
)