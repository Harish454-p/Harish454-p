package com.greenlightplanet.kazi.incentivenew.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.AdapterSummaryChildBinding
import com.greenlightplanet.kazi.incentivenew.model.deduction.SubFields
import com.greenlightplanet.kazi.utils.Util


/**
 * Created by Rahul on 25/06/20.
 */
class SummaryChildAdapter(private val children: List<SubFields>) :
        RecyclerView.Adapter<SummaryChildAdapter.ViewHolder>() {


    override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
    ): ViewHolder {
        val itemBinding = AdapterSummaryChildBinding.inflate(LayoutInflater.from(parent.context)
               , parent, false)
        return ViewHolder(itemBinding)
    }

    override fun getItemCount(): Int {
        return children.size
    }

    override fun onBindViewHolder(
            holder: ViewHolder,
            position: Int
    ) {

        val child: SubFields = children[position]
        holder.itemOne.text = child.name
        if (child.fieldValueDataType.equals("DOUBLE",true)||
                child.fieldValueDataType.equals("INTEGER",true)) {
            holder.itemTwo.text = child.value?.toDouble()?.let { Util.formatAmount(it) }

        } else {
            holder.itemTwo.text = child.value

        }

    }


    inner class ViewHolder(itemBinding: AdapterSummaryChildBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {

        val itemOne: TextView = itemBinding.tvItemOne
        val itemTwo: TextView = itemBinding.tvItemTwo
    }
}