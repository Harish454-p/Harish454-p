package com.greenlightplanet.kazi.liteFseProspective.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import com.greenlightplanet.kazi.liteFseProspective.extras.ImageUploadUtil
import com.greenlightplanet.kazi.liteFseProspective.model.*
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteInstallationRepo
import com.greenlightplanet.kazi.liteFseProspective.repo.LiteProspectiveRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable

class InstallationViewModel(application: Application) : AndroidViewModel(application) {


    companion object {
        public const val TAG = "InstallationViewModel"
    }

    val repo = LiteInstallationRepo.getInstance(application)
    val pRepo = LiteProspectiveRepo.getInstance(application)


    fun compressImageForAws(context: Context, files: List<ImageUploadUtil.ImageModel>, showProgress: () -> Unit = {}): MutableLiveData<List<LiteAwsImageModel>?> {
        showProgress()
        return repo.compressImageForAws(context, files)
    }

    fun performInstallation(context: Context, fseProspectResponseModel: LiteFseProspectResponseModel?, isOnline: Boolean, prospectId: String, angazaId: String, accountNumber: String, installationAttempted: Int, fileModel: List<LiteAwsImageModel>, /*location: Location,*/ imageName: String, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return repo.performInstallation(context, fseProspectResponseModel, isOnline, prospectId, angazaId, accountNumber, installationAttempted, fileModel/*, location*/)
    }

    fun performInstallation2(context: Context, fseProspectResponseModel: LiteFseProspectResponseModel?, isOnline: Boolean, prospectId: String, fileModel: List<LiteAwsImageModel>, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return repo.performInstallation2(context,fseProspectResponseModel,isOnline, prospectId,fileModel)
    }

    fun insertAwsImageModelToDatabase(inputFiles: List<LiteAwsImageModel>, isUploadedToAws: Boolean): MutableLiveData<List<LiteAwsImageModel>?> {
        return repo.insertAwsImageModelToDatabase(inputFiles, isUploadedToAws)
    }


    fun getCombineRequestModel(prospectId: String): MutableLiveData<CombineRequestModel> {
        return repo.getCombineRequestModel(prospectId)
    }


    fun getAllAwsImageModelByProspectId(prospectId: String): MutableLiveData<List<LiteAwsImageModel>> {
        return repo.getAllAwsImageModelByProspectId(prospectId)
    }

    fun sendInstallationRequestToServerForce(installationRequestModel: LiteInstallationRequestModel, fileModel: List<LiteAwsImageModel>, showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>?> {
        showProgress()
        return repo.sendInstallationRequestToServerForce(installationRequestModel, fileModel)
    }

    fun updateFseProspect(fseProspectResponseModel: LiteFseProspectResponseModel): MutableLiveData<LiteFseProspectResponseModel> {
        return repo.updateFseProspect(fseProspectResponseModel)
    }

    fun getFseProspectiveFromServer(angazaId:String,prospectId:String,showProgress: () -> Unit = {}): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>? {
        showProgress()
        return repo.getFseProspectiveFromServer(angazaId,prospectId)
    }

    fun getAllInstallationFSE(): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {
        return repo.getAllInstallationFSE()
    }

    //
    fun getFseProspectiveFromDatabase(): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {
        return pRepo.getFseProspectiveFromDatabase()
    }
    //

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }

}
