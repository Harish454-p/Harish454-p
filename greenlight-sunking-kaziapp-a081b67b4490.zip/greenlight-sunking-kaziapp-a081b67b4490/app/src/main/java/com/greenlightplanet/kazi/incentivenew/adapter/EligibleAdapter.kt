package com.greenlightplanet.kazi.incentivenew.adapter


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.EligbleListItemBinding
import com.greenlightplanet.kazi.incentivenew.model.incentive.Accounts
import com.greenlightplanet.kazi.utils.Util


/**
 * Created by Rahul on 03/12/20.
 */
class EligibleAdapter(
    private val listData: List<Accounts>,
    var listener: MyDateData,
    var context: Context
) : RecyclerView.Adapter<EligibleAdapter.ViewHolder?>() {
    private var lastPosition = -1

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val itemBinding =
            EligbleListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(itemBinding, listener)
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int
    ) {
        val myListData: Accounts = listData[position]

        holder.bind(myListData)


    }

    override fun getItemCount(): Int {
        return listData.size
    }

    class ViewHolder(val itemBinding: EligbleListItemBinding, listener: MyDateData) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(myListData: Accounts) {
            itemBinding.tvRegistrationDate.text = myListData.registrationDate
            itemBinding.tvAccountNumber.text = myListData.accountNumber.toString()
            itemBinding.tvProductNameValue.text = myListData.product
            itemBinding.tvIncentiveEarn.text = Util.formatAmount(myListData.incentiveEarned!!.toDouble())

        }

    }

    interface MyDateData {

        fun selectedData(date: String, position: Int)
    }


    private fun setAnimation(viewToAnimate: View, position: Int) {
        if (position > lastPosition) {
            val animation = AnimationUtils.loadAnimation(context, android.R.anim.slide_in_left)
            viewToAnimate.startAnimation(animation)
            lastPosition = position
        }
    }
}
