package com.greenlightplanet.kazi.incentivenew.activity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.viewpager.widget.ViewPager
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.viewmodel.AgentReferralViewModel
import com.greenlightplanet.kazi.dashboard.activity.DashBoardActivity
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityNewincentiveBinding
import com.greenlightplanet.kazi.databinding.IncentivewebviewBinding
import com.greenlightplanet.kazi.incentive.adapter.IncentivePagerAdapter
import com.greenlightplanet.kazi.incentivenew.fragment.CheckListIncentiveFragment
import com.greenlightplanet.kazi.incentivenew.fragment.SummaryIncentiveFragment
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryResponseData
import com.greenlightplanet.kazi.incentivenew.viewmodel.SummaryViewModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener


class NewIncentiveActivity : BaseActivity() {

    private lateinit var binding: ActivityNewincentiveBinding

    var loginResponseModel: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    var isFromNotification = false
    var mHomeWatcher: HomeWatcher? = null
    val TAG = "NewIncentiveActivity"

    lateinit var viewModel: SummaryViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewincentiveBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // setContentView(R.layout.activity_newincentive)
        Util.addEvent("312", "IncentiveDashboardScreen", "DashBoard_to_IncentiveDashboardScreen")
        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME

        if (intent.hasExtra("fromNotification")) {
            isFromNotification = intent.getBooleanExtra("fromNotification", false)
        }
        initialize()
//        APICall()
        // summary()

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }

    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();
    }

    override fun onResume() {
        super.onResume()
        summary()
    }

    fun initialize() {
        showProgressDialog(this)
        Util.setToolbar(this,  binding.toolbar2)

        viewModel = ViewModelProvider(this)[SummaryViewModel::class.java]
        preference = GreenLightPreference.getInstance(this)
        loginResponseModel = preference?.getLoginResponseModel()
    }

    private fun setupViewPager(viewPager: ViewPager, summaryResponse: SummaryResponseData?) {
        val adapter = IncentivePagerAdapter(supportFragmentManager)

        val summaryBundle = Bundle()
        summaryBundle.putParcelable("summary", summaryResponse)

        val summary = SummaryIncentiveFragment()
        summary.arguments = summaryBundle

        val checklistBundle = Bundle()
        checklistBundle.putParcelable("checklist", summaryResponse)

        val checklist = CheckListIncentiveFragment()
        checklist.arguments = checklistBundle
        adapter.addFragment(summary, getString(R.string.summary))
        adapter.addFragment(checklist, getString(R.string.checklist))
        //  adapter.addFragment(phoneRecovery, "Others")

        viewPager.adapter = adapter
    }


    //http://rahultyagi.in/summaryFields.json
    fun summary() { //US000726
        viewModel.getSummaryData(this,
            preference?.getLoginResponseModel()?.angazaId).observe(this, Observer
        { response ->
            if (response != null) {

                if (response.success) {

                    cancelProgressDialog()
                    val incentiveResponseModel = response.responseData
                    if (incentiveResponseModel != null) {
                        setIncentives(incentiveResponseModel)
                    }
                    updateSharedPref(true)

                } else {

                    val incentiveResponseModel = response.responseData

                    setIncentives(incentiveResponseModel)
                    cancelProgressDialog()
                    updateSharedPref(false)

                     Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show()
                }
            }

        })
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun onBackPressed() {
        if (isFromNotification) {
            val intent = Intent(this, DashBoardActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        }
        else {
            super.onBackPressed()
        }
    }

    fun setIncentives(summaryResponse: SummaryResponseData?) {
        binding.tvCountry.text = loginResponseModel?.country ?: "NA"
        binding.tvArea.text = summaryResponse?.area ?: "NA"
        binding. tvPhoneNo.text = loginResponseModel?.phoneNumber ?: "NA"
        binding. tvCurrentRole.text = summaryResponse?.currentRole ?: "NA"
        binding.tvCluster.text = summaryResponse?.cluster ?: "NA"
        setupViewPager( binding.viewpager, summaryResponse)
        binding.tabs.setupWithViewPager( binding.viewpager)
    }

    private fun updateSharedPref(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadIncentiveFromPref(this)

        if (data == null) {
            data = LastSaved()
            data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(this, data)
            binding.tvLastSaved.text = data.incentive

        } else {

            if (fromInternet) {
                data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(this, data)
                binding.tvLastSaved.text = data.incentive
            } else {
                binding.tvLastSaved.text = data.incentive

            }
        }

    }

}
