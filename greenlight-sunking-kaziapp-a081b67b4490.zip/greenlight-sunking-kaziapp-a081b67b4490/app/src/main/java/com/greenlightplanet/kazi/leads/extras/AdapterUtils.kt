package com.greenlightplanet.kazi.leads.extras

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.util.Log
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead
import com.greenlightplanet.kazi.utils.Util
import java.text.SimpleDateFormat
import java.util.*

class AdapterUtils {

    companion object {
        public const val TAG = "AdapterUtils"


        fun pendingDaysLeftLogic(leadsCrossSalesLead: LeadsCrossSalesLead?): String? {
            return leadsCrossSalesLead?.expiryDate
        }

        fun getPendingDaysLeft(promiseDate: String?): String {

            var resultPendingDays = ""

            if (!promiseDate.isNullOrEmpty()) {
                try {
                    val promiseDateObject = dateConvertertPending(promiseDate)
                    val diff: Long = promiseDateObject!!.time - Util.parseYYYY_MM_DDtoLong(Util.getDateYYYYMMDD())!!
                    val diffDays = diff / (24 * 60 * 60 * 1000)

                    if (diffDays <= 0) {
                        resultPendingDays = "sync data"
                    } else {
                        resultPendingDays = "$diffDays ${if (diffDays > 1) {
                            "days"
                        } else {
                            "day"
                        }} to go"
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.d(TAG, "abcdPending - getPendingDaysLeft: ${e.localizedMessage} ");
                }

            }
            return resultPendingDays
        }

        fun calledDaysToGoLogic(leadsCrossSalesLead: LeadsCrossSalesLead?): String? {

            return if (!leadsCrossSalesLead?.callDetails.isNullOrEmpty()) {

                var maxCallDetail = leadsCrossSalesLead?.callDetails?.last()

                if (maxCallDetail!!.newVisitDate.isNullOrEmpty()) {
                    maxCallDetail = leadsCrossSalesLead?.callDetails?.last()
                } else {
                    maxCallDetail = leadsCrossSalesLead?.callDetails?.last()
                }
//                val maxCallDetail = leadsCrossSalesLead?.callDetails?.maxBy { it?.attempt!! }
                maxCallDetail?.newVisitDate
            } else {
                ""
            }
        }

        fun getCalledDaysToGo(promiseDate: String?): String {

            var resultCalledDays = ""

            if (!promiseDate.isNullOrEmpty()) {

                try {
                    val promiseDateObject = dateConvertertPending(promiseDate)
                    val diff: Long = promiseDateObject!!.time - Util.parseYYYY_MM_DDtoLong(Util.getDateYYYYMMDD())!!
                    val diffDays = diff / (24 * 60 * 60 * 1000)

                    if (diffDays <= 0) {
                        resultCalledDays = "sync data"
                    } else {
                        resultCalledDays = "$diffDays ${if (diffDays > 1) {
                            "days"
                        } else {
                            "day"
                        }} to go"
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e(TAG, "abcdPending - error: ${e.localizedMessage} ");
                }

            }
            return resultCalledDays
        }

        fun checkCallLogPermission(context: Context): Boolean {
            return ((ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.CALL_PHONE
            ) == PackageManager.PERMISSION_GRANTED)
                    && (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_CALL_LOG
            ) == PackageManager.PERMISSION_GRANTED))
        }

        fun dateConvertertPending(dateString: String): Date? {
            val formatter = SimpleDateFormat("dd-MM-yyyy")
            return formatter.parse(dateString)
        }

		fun dateConvertertCalledUTCtoLocal(dateString: String): String? {
			val oldformatter = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
			oldformatter.timeZone = TimeZone.getTimeZone("UTC")
			val convertedDate = oldformatter.parse(dateString)
			val newformatter = SimpleDateFormat("dd-MM-yyyy")
			newformatter.setTimeZone(TimeZone.getDefault());
			return newformatter.format(convertedDate)
		}

        fun dateConvertertCalled(dateString: String): String? {
            val oldformatter = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
            val convertedDate = oldformatter.parse(dateString)
            val newformatter = SimpleDateFormat("dd-MM-yyyy")
            return newformatter.format(convertedDate)
        }
        fun dates(dateString: String?):Date{
            return  SimpleDateFormat("dd-MM-yyyy").parse(dateString)
        }
        fun newVisitDateTOPromiseDateConverter(dateString: String?): String? {
            if (dateString.isNullOrBlank()) {
                return null
            } else {
                val oldformatter = SimpleDateFormat("yyyy-MM-dd")
                val convertedDate = oldformatter.parse(dateString)
                val newformatter = SimpleDateFormat("dd-MM-yyyy")
                return newformatter.format(convertedDate)
            }
        }

        fun newVisitDateTOPromiseDateConverter2(dateString: String?): String? {
            if (dateString.isNullOrBlank()) {
                return null
            } else {

                val oldformatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                val convertedDate = oldformatter.parse(dateString)
                val newformatter = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
                return newformatter.format(convertedDate)
            }
        }
    }


}
