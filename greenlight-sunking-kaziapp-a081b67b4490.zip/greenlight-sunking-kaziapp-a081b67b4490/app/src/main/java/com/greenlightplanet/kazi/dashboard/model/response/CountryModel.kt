package com.greenlightplanet.kazi.dashboard.model.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class CountryModel(
    val country_code: String?,
    val country_name: String?,
    val currency_symbol: String?,
    val language : String?,
    val max_phone_length: String?,
    val number_formatting: String?
) : Parcelable