package com.greenlightplanet.kazi.collectiongoal.dao

import androidx.room.*
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistory
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistoryModel
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.collectiongoal.model.pastweekincentive.LastWeekIncentiveModel
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistory
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistoryModel
import com.greenlightplanet.kazi.summary.model.CollectionRate
import com.greenlightplanet.kazi.summary.model.SummaryModel
import io.reactivex.Single

@Dao
interface WeeklyTargetCustomerDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertMakeCall(makeCallNewModel: MakeCallNewModel): Long

    @Delete
    fun delete(makeCallNewModel: MakeCallNewModel): Int

    @Query("SELECT * FROM makeCallNewModel")
    fun getWeeklyTargetData(): Single<MakeCallNewModel>

    @Query("SELECT * FROM makeCallNewModel")
    fun getbcWeeklyTargetData(): MakeCallNewModel?

    @Query("DELETE FROM MakeCallNewModel")
    fun deleteAll(): Int


}