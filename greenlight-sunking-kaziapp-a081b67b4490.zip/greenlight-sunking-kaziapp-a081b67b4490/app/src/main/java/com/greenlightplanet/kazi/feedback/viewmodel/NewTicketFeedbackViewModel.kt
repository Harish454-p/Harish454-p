package com.greenlightplanet.kazi.feedback.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.greenlightplanet.kazi.feedback.repo.repository.NewTicketFeedbackRepository
import com.greenlightplanet.kazi.feedback.repo.model.request.CreateNewTicketRequest
import com.greenlightplanet.kazi.feedback.repo.model.response.Field
import com.greenlightplanet.kazi.utils.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NewTicketFeedbackViewModel @Inject constructor(val repo: NewTicketFeedbackRepository): ViewModel() {

    private val _ticketUIResponseLiveData = MutableLiveData<NetworkResult<List<Field>>>()
    val ticketUIResponseLiveData get() = _ticketUIResponseLiveData

    private val _submitTicketLiveData = MutableLiveData<NetworkResult<Boolean>>()
    val submitTicketLiveData get() = _submitTicketLiveData

    val allImageUploadedLiveData = MutableLiveData<Boolean>()


    var imageListFromS3 = mutableListOf<String>()

    var currentRvListWithAnswers = mutableListOf<Field>()

    val currentRvList = mutableListOf<Field>()

    var submitRequestData = CreateNewTicketRequest()

    var isImageMandatory = false

    fun invokeTicketsData(territory: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.getUIWithData(territory).onEach { result ->
                _ticketUIResponseLiveData.postValue(result)
            }.launchIn(viewModelScope)
        }

    }

    fun invokeSubmitNewTickets(requestData: CreateNewTicketRequest, country: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.invokeSubmitNewTicketData(requestData, country).onEach { result ->
                _submitTicketLiveData.postValue(result)
            }.launchIn(viewModelScope)
        }

    }

}