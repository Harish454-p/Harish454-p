package com.greenlightplanet.kazi.liteFseProspective.view.activity.checkInMap

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.annotation.SuppressLint
import android.app.Activity
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.location.Location
import android.os.Build
import android.os.Bundle
import android.os.Handler
import androidx.core.content.ContextCompat
import android.util.Log
import android.view.View
import android.view.ViewAnimationUtils
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Toast
import androidx.lifecycle.ViewModelProviders
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.FakeLocationRequest
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityCheckInMapBinding
import com.greenlightplanet.kazi.fseProspective.viewmodel.ProspectiveViewModel
import com.greenlightplanet.kazi.liteFseProspective.viewmodel.AllViewModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import pl.charmas.android.reactivelocation2.ReactiveLocationProvider


class LiteCheckInMapActivity : BaseActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityCheckInMapBinding
    private lateinit var mMap: GoogleMap
    private var circle: Circle? = null
    private var LAT: Double? = null
    private var LONG: Double? = null
    var mCurrLocationMarker: Marker? = null
    var mBaseLocationMarker: Marker? = null
    var data = MutableLiveData<Location>()
    private val bag: CompositeDisposable = CompositeDisposable()
    var CurrentLoc: LatLng? = null
    val radius: Double = 10000.0
    val markerOptions = MarkerOptions()
    var markerAdded = false
    var currentLocation: Location? = null
    val TAG = "CheckInMapActivity"

    var flag = true
    var preference: GreenLightPreference? = null
    var loginResponseData: LoginResponseModel? = null
    lateinit var viewModel: AllViewModel
    var isLite = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_check_in_map)
        binding = ActivityCheckInMapBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel = ViewModelProviders.of(this).get(AllViewModel::class.java)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        preference = GreenLightPreference.getInstance(this)
        loginResponseData = preference?.getLoginResponseModel()

        isLite = intent.getBooleanExtra("isLite", false)

        LAT = preference!!.getLAT()!!.toDouble()
        LONG = preference!!.getLONG()!!.toDouble()


        binding.btnCheckIn.setOnClickListener {

            intent.extras?.let {
                when(it.getBoolean("fromReplacement", false)) {
                    true -> {
                        Util.addEvent(
                                id = "388",
                                name ="User clicks on 'Check IN' button",
                                event ="user_click_on_check_in_button"
                        )
                    }
                    else->{}
                }
            }

            if (preference?.getFakeLocationSolution() == true) {
                if (currentLocation?.isFromMockProvider == false && !Util.isMockLocationEnabled(this)) {
                    callIntent()
                } else {
                    showFakeDialog()
                    sendFakeLocationToServer()
                }
            } else {

                callIntent()
            }

        }
    }

    private fun sendFakeLocationToServer() {
        viewModel.sendFakeLocationLog(
            this, preference?.getLoginResponseModel()?.angazaId!!,
            FakeLocationRequest(
                angazaId = preference?.getLoginResponseModel()?.angazaId!!,
                appVersionCode = BuildConfig.VERSION_CODE,
                deviceId = Util.getImeiNumber(this) ?: "",
                deviceTime = Util.getUTCCurrentDate(),
                lat = currentLocation?.latitude ?: 0.0,
                lng = currentLocation?.longitude ?: 0.0,
                module = if (isLite) {
                    "FSE_INSTALLATION_LITE_CHECK_IN"
                } else {
                    "FSE_INSTALLATION_CHECK_IN"
                }
            )
        )
    }

    private fun showFakeDialog() {

        Util.customFakeLocationDialog(
            context = this,
            message = resources.getString(R.string.fakeLocation),
            positiveText = resources.getString(R.string.ok_label),
            negetiveText = resources.getString(R.string.cancel),
            poitiveSelected = {
                //add logic
                finish()
                it.dismiss()
            },
            negetiveSelected = {
                finish()
                it.dismiss()
            }
        )
    }

    private fun callIntent() {

        val returnIntent = Intent()
        returnIntent.putExtra("location_result", currentLocation)
        setResult(Activity.RESULT_OK, returnIntent)
        finish()
    }

    override fun onBackPressed() {
        val returnIntent = Intent()
        setResult(Activity.RESULT_CANCELED, returnIntent);
        finish()
    }

    fun setCurreMarker(Lat: Double, Longg: Double) {
        CurrentLoc = LatLng(Lat, Longg)

        markerOptions.position(CurrentLoc!!)
        markerOptions.title("Current Position")

        markerOptions.icon(bitmapDescriptorFromVector(this, R.drawable.ic_current_location_24dp))

        if (!markerAdded) {
            mCurrLocationMarker = mMap.addMarker(markerOptions)
            markerAdded = true
        }
        //move map camera
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CurrentLoc))
        mMap.animateCamera(CameraUpdateFactory.zoomTo(11f))

    }

    fun getCurrentLoc(): MutableLiveData<Location> {

        val data = MutableLiveData<Location>()

        bag.add(
            newGetCurrentLocation(this)!!.subscribe({
                data.postValue(it)
            }, {
                data.postValue(null)
            })
        )
        return data
    }


    @SuppressLint("RestrictedApi")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        getCurrentLoc().observe(this, Observer {
            it?.let {
                binding.tvWaitAccuracy.visibility = View.GONE
                currentLocation = it
                if (it.isFromMockProvider && flag) {
                    showFakeDialog()
                    sendFakeLocationToServer()
                    flag = false
                }

                Log.e("|| == ", "${it.latitude},${it.longitude}")
                binding.tvAccuracy.text = "Accuracy: ${it.accuracy}m"
                setCurreMarker(it.latitude, it.longitude)
            }
        })


        // Add a marker in Sydney and move the camera
        val sydney = LatLng(LAT!!, LONG!!)
        mMap.addMarker(
            MarkerOptions().position(sydney).title("Your Base Location")
                .icon(bitmapDescriptorFromVector(this, R.drawable.ic_base_home_24dp))
        )
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 11.0f))


        val set = preference!!.getProspectAllowedDistance()!!.toDouble()
        drawCircle(LAT!!, LONG!!, set)


        //SATATLITE VIEW


        // Initialise the map variable

        // When map is initially loaded, determine which map type option to 'select'
        when {
            mMap.mapType == GoogleMap.MAP_TYPE_SATELLITE -> {
                binding.mapTypeSatelliteBackground.visibility = View.VISIBLE
                binding.mapTypeSatelliteText.setTextColor(Color.BLUE)
            }
            mMap.mapType == GoogleMap.MAP_TYPE_TERRAIN -> {
                binding.mapTypeTerrainBackground.visibility = View.VISIBLE
                binding.mapTypeTerrainText.setTextColor(Color.BLUE)
            }
            else -> {
                binding.mapTypeDefaultBackground.visibility = View.VISIBLE
                binding.mapTypeDefaultText.setTextColor(Color.BLUE)
            }
        }

        // Set click listener on FAB to open the map type selection view
        binding.mapTypeFAB.setOnClickListener {

            // Start animator to reveal the selection view, starting from the FAB itself
            val anim = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                ViewAnimationUtils.createCircularReveal(
                    binding.mapTypeSelection,
                    binding.mapTypeSelection.width - (binding.mapTypeFAB.width / 2),
                    binding.mapTypeFAB.height / 2,
                    binding.mapTypeFAB.width / 2f,
                    binding.mapTypeSelection.width.toFloat()
                )
            } else {
                TODO("VERSION.SDK_INT < LOLLIPOP")
            }
            anim.duration = 200
            anim.interpolator = AccelerateDecelerateInterpolator()

            anim.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationStart(animation: Animator) {
                    super.onAnimationEnd(animation)
                    binding.mapTypeSelection.visibility = View.VISIBLE
                }
            })

            anim.start()
            binding.mapTypeFAB.visibility = View.INVISIBLE

        }

        // Set click listener on the map to close the map type selection view
        mMap.setOnMapClickListener {

            // Conduct the animation if the FAB is invisible (window open)
            if (binding.mapTypeFAB.visibility == View.INVISIBLE) {

                // Start animator close and finish at the FAB position
                val anim = ViewAnimationUtils.createCircularReveal(
                    binding.mapTypeSelection,
                    binding.mapTypeSelection.width - (binding.mapTypeFAB.width / 2),
                    binding.mapTypeDefault.height / 2,
                    binding.mapTypeSelection.width.toFloat(),
                    binding.mapTypeFAB.width / 2f
                )
                anim.duration = 200
                anim.interpolator = AccelerateDecelerateInterpolator()

                anim.addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        super.onAnimationEnd(animation)
                        binding.mapTypeSelection.visibility = View.INVISIBLE
                    }
                })

                // Set a delay to reveal the FAB. Looks better than revealing at end of animation
                Handler().postDelayed({
                    kotlin.run {
                        binding.mapTypeFAB.visibility = View.VISIBLE
                    }
                }, 100)
                anim.start()
            }
        }

        // Handle selection of the Default map type
        binding.mapTypeDefault.setOnClickListener {
            binding.mapTypeDefaultBackground.visibility = View.VISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.INVISIBLE
            binding.mapTypeTerrainBackground.visibility = View.INVISIBLE
            binding.mapTypeDefaultText.setTextColor(Color.BLUE)
            binding.mapTypeSatelliteText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeTerrainText.setTextColor(Color.parseColor("#808080"))
            mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
        }

        // Handle selection of the Satellite map type
        binding.mapTypeSatellite.setOnClickListener {
            binding.mapTypeDefaultBackground.visibility = View.INVISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.VISIBLE
            binding.mapTypeTerrainBackground.visibility = View.INVISIBLE
            binding.mapTypeDefaultText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeSatelliteText.setTextColor(Color.BLUE)
            binding.mapTypeTerrainText.setTextColor(Color.parseColor("#808080"))
            mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
        }

        // Handle selection of the terrain map type
        binding.mapTypeTerrain.setOnClickListener {
            binding.mapTypeDefaultBackground.visibility = View.INVISIBLE
            binding.mapTypeSatelliteBackground.visibility = View.INVISIBLE
            binding.mapTypeTerrainBackground.visibility = View.VISIBLE
            binding.mapTypeDefaultText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeSatelliteText.setTextColor(Color.parseColor("#808080"))
            binding.mapTypeTerrainText.setTextColor(Color.BLUE)
            mMap.mapType = GoogleMap.MAP_TYPE_TERRAIN
        }


    }

    private fun drawCircle(latitude: Double, longitude: Double, radius: Double) {
        val circleOptions = CircleOptions()
            .center(LatLng(latitude, longitude))
            .radius(radius)
            .strokeWidth(2.0f)
            .strokeColor(ContextCompat.getColor(this, R.color.colorPrimaryDark))
            .fillColor(ContextCompat.getColor(this, R.color.colorMapShadow))
        circle?.remove() // Remove old circle.
        circle = mMap.addCircle(circleOptions) // Draw new circle.
    }

    private fun bitmapDescriptorFromVector(context: Context, vectorResId: Int): BitmapDescriptor {
        val vectorDrawable = ContextCompat.getDrawable(context, vectorResId)
        vectorDrawable!!.setBounds(
            0,
            0,
            vectorDrawable.intrinsicWidth,
            vectorDrawable.intrinsicHeight
        )
        val bitmap =
            Bitmap.createBitmap(
                vectorDrawable.intrinsicWidth,
                vectorDrawable.intrinsicHeight,
                Bitmap.Config.ARGB_8888
            )
        val canvas = Canvas(bitmap)
        vectorDrawable.draw(canvas)
        return BitmapDescriptorFactory.fromBitmap(bitmap)

    }


    @SuppressLint("MissingPermission")
    fun newGetCurrentLocation(context: Context): Observable<Location>? {
        val request = LocationRequest.create() //standard GMS LocationRequest
            .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            .setNumUpdates(50).setInterval(20)

        val locationProvider = ReactiveLocationProvider(context)

        return locationProvider.getUpdatedLocation(request)

    }


    override fun onDestroy() {
        bag.clear()
        super.onDestroy()
    }
}


