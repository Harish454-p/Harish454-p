package com.greenlightplanet.kazi.dashboard.model.call_sms


import com.google.gson.annotations.SerializedName

data class SyncResourcesRequest(
		@SerializedName("angazaId")
		var angazaId: String?, // 1

		@SerializedName("sms")
		var sms: List<SmsRequest>?, // 1

		@SerializedName("callLog")
		var callLog: List<CallLogRequest>?, // 1

		@SerializedName("contacts")
		var contacts: List<ContactRequest>? // 1

)
