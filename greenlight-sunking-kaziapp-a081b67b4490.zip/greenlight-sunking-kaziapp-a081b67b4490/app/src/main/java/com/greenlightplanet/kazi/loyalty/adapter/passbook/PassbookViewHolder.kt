package com.greenlightplanet.kazi.loyalty.adapter.passbook

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.PassbookItemBinding
import com.greenlightplanet.kazi.loyalty.model.passbook.Entries
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.Util.Companion.getDDMMYYYYFormate
import com.greenlightplanet.kazi.utils.Util.Companion.splitUTCConvert

/**
 * Created by Rahul on 08/04/21.
 */
class PassbookViewHolder(val itemBinding:  PassbookItemBinding) : RecyclerView.ViewHolder(itemBinding.root) {

    fun bind(data: Entries) {
        if (data != null) {

            if (data.point ?: 0 > 0) {
                itemBinding.tvPoint.text = "+${data.point?.toDouble()?.let { Util.formatAmount(it) }}"
               // itemView.passbook_arrrowId.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_points_icon, 0,  R.drawable.arrow_upward, 0);
               // itemView.tvPoint.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_points_icon, 0,  R.drawable.ic_watt_point_icon, 0);
                itemBinding.passbookArrrowId.setBackgroundResource( R.drawable.arrow_upward );


            } else {
                itemBinding.tvPoint.text = "${data.point?.toDouble()?.let { Util.formatAmount(it) }}"
              //  itemView.tvPoint.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_points_icon, 0, R.drawable.ic_watt_point_icon, 0)
                itemBinding.passbookArrrowId.setBackgroundResource( R.drawable.arrow_downward );


            }
            val date = data.created_at



            itemBinding.tvDate.text = date?.let { getDDMMYYYYFormate(splitUTCConvert(it)) }

            itemBinding.tvProduct.text = data.event_name.toString()


        }
    }

    companion object {
        fun create(parent: ViewGroup): PassbookViewHolder {
            val itemBinding =PassbookItemBinding.inflate( LayoutInflater.from(parent.context)
                   , parent, false)
            return PassbookViewHolder(itemBinding)
        }
    }
}