package com.greenlightplanet.kazi.dashboard.model.call_sms


import androidx.room.Entity
import com.google.gson.annotations.SerializedName

@Entity(tableName = "CallLogRequest", primaryKeys = ["contactNumber", "date"])
data class CallLogRequest(
		/*@PrimaryKey(autoGenerate = true)
		var id: Long? = null, // test message*/
		@SerializedName("contactNumber")
		var contactNumber: String, // 342
		@SerializedName("to_number")
		var toNumber: String,
		@SerializedName("date")
		var date: String, // 1613051325
		@SerializedName("duration")
		var duration: String?, // 10
		@SerializedName("name")
		var name: String?, // abcd
		@SerializedName("uploadedToServer")
		var uploadedToServer: Boolean = false // UPDATED
)
