package com.greenlightplanet.kazi.fseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.fseProspective.model.InstallationRequestModel
import io.reactivex.Single

@Dao
interface InstallationRequestDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(InstallationRequestModel: List<InstallationRequestModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(InstallationRequestModel: InstallationRequestModel): Long

    @Delete
    fun delete(InstallationRequestModel: InstallationRequestModel): Int

    @Query("DELETE FROM InstallationRequest")
    fun deleteAll(): Int

    @Query("SELECT * FROM InstallationRequest")
    fun getAll(): Single<List<InstallationRequestModel>>

    @Query("SELECT * FROM InstallationRequest LIMIT 1")
    fun get(): Single<InstallationRequestModel>

    @Query("SELECT COUNT(*) from InstallationRequest")
    fun count(): Single<Int>

    @Query("SELECT * FROM InstallationRequest WHERE prospectId=:prospectId LIMIT 1")
    fun getByProspectId(prospectId: String): Single<InstallationRequestModel>?

    @Query("SELECT * FROM InstallationRequest WHERE prospectID IN (:prospectId)")
    fun getAllByProspectId(prospectId: List<String>): Single<List<InstallationRequestModel>?>

}
