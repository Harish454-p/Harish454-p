package com.greenlightplanet.kazi.collectiongoal.model.callhistory

import android.os.Parcelable
import androidx.annotation.Keep
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
@Keep
@Parcelize
@Entity(tableName = "CallHistory")
data class CallHistory(

    @PrimaryKey(autoGenerate = false)
    @ColumnInfo(name = "accountNumber")
    var accountNumber:Int,

    @ColumnInfo(name = "callDate")
    val callDate: String?,

    @ColumnInfo(name = "duration")
    val duration: String?,

    @ColumnInfo(name = "feedbackId")
    val feedbackId: Int?,

    @ColumnInfo(name = "intentId")
    val intentId: Int?,

    @ColumnInfo(name = "promiseDate")
    val promiseDate: String?,

    @ColumnInfo(name = "contactedPhone")
    val contactedPhone: String?

) :Parcelable
