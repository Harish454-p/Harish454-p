package com.greenlightplanet.kazi.feedback.view.activities

import android.app.Dialog
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivityNewTicketFeedbackBinding
import com.greenlightplanet.kazi.databinding.FeedbackTicketSuccessDialogBinding
import com.greenlightplanet.kazi.feedback.feedback_utils.AmazonS3Helper
import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackConstants
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.feedback.feedback_utils.ImageUploadUtil
import com.greenlightplanet.kazi.feedback.repo.model.request.CreateNewTicketRequest
import com.greenlightplanet.kazi.feedback.repo.model.response.Field
import com.greenlightplanet.kazi.feedback.view.adapter.NewTicketAdapterClickListener
import com.greenlightplanet.kazi.feedback.view.adapter.NewTicketFeedbackAdapter
import com.greenlightplanet.kazi.feedback.viewmodel.NewTicketFeedbackViewModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.NetworkResult
import com.greenlightplanet.kazi.utils.Util
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.*
import java.lang.ref.WeakReference
import java.util.*


@AndroidEntryPoint
class NewTicketFeedbackActivity : BaseActivity(), NewTicketAdapterClickListener,
    AmazonS3Helper.AmazonS3HelperCallback {
    private lateinit var binding: ActivityNewTicketFeedbackBinding
    lateinit var progressdialog: Dialog
    lateinit var customDialog: Dialog
    val awsHelper = AmazonS3Helper(this@NewTicketFeedbackActivity)
    private val viewModel: NewTicketFeedbackViewModel by viewModels()
    private val adapter = NewTicketFeedbackAdapter()
    private val IMG_RC: Int = 8
    var angazaId = ""
    var territory = ""
    private var imgPathList = mutableListOf<String>()
    private var imgModelList = mutableListOf<ImageUploadUtil.ImageModel>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewTicketFeedbackBinding.inflate(layoutInflater)
        setContentView(binding.root)
        progressdialog = Dialog(this@NewTicketFeedbackActivity)
        customDialog = Dialog(this@NewTicketFeedbackActivity)
        initToolbar()
        awsHelper.amazonS3HelperCallback = this
        awsHelper.initializer()
        initializeRv()
        setupClickListener()
        observer()
        GreenLightPreference(this@NewTicketFeedbackActivity).getLoginResponseModel()?.let {
            it.angazaId?.let {
                angazaId = it
            }
            it.territory?.let {
                territory = it
                Timber.d("NewTicket: Territory: $territory")
            }

        }
        /** API call for Dynamic UI elements and their data*/
        if (Helper.isNetworkConnected()) {
            viewModel.invokeTicketsData(territory = FeedbackConstants.territory)
        } else {
            lifecycleScope.launch(Dispatchers.Main) {
                showCustomDialog("No internet. Please try again")
                delay(2000)
                hideCustomDialog()
                onBackPressed()
            }
        }

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            IMG_RC -> if (resultCode == RESULT_OK) {
                processImagesWithUri(data)
            }
        }
    }

    /** Uri processing after multiple image picked up for new ticket*/
    private fun processImagesWithUri(data: Intent?) {
        val pathList = mutableListOf<String>()
        if (data?.clipData == null && data?.data != null) {
            val singleUri = data.data
            binding.ivUploadAttachment.setImageDrawable(resources.getDrawable(R.drawable.ic_upload_feedback_green))
            binding.tvAttachmentCount.text = "1"
            val singlePath =
                createCopyAndReturnRealPath(this@NewTicketFeedbackActivity, singleUri)
            singlePath?.let {
                pathList.add(it)
            }
            Timber.d("ImagePickerTicket: Single Picked: $singleUri || Multiple Count: ${data?.clipData?.itemCount}")
            Timber.d("ImagePickerTicket: ClipData Null")
        } else {
            Timber.d("ImagePickerTicket: Multiple Picked Picked")
            binding.ivUploadAttachment.setImageDrawable(resources.getDrawable(R.drawable.ic_upload_feedback_green))
            binding.tvAttachmentCount.text = data?.clipData?.itemCount.toString() ?: ""
            val count = data?.clipData?.itemCount?.let {
                Timber.d("ImagePickerTicket: ClipData Count: $it")
                for (i in 0 until it) {
                    data.clipData!!.getItemAt(i).uri.let { uri ->
                        Timber.d("ImagePickerTicket: Path: ${uri.path}")

                        val path =
                            createCopyAndReturnRealPath(this@NewTicketFeedbackActivity, uri)
                        val file = File(path)

                        Timber.d("ImagePickerTicket: File name  = ${file.path}.jpeg || Extension = ${file}")

                        Timber.d("ImagePickerTicket: Path converted: $path")
                        path?.let {
                            pathList.add(it)
                            Timber.d("ImagePickerTicket: Position: $i || path $it")
                        }
                    }
                }
            }
        }

        if (pathList.isNotEmpty()) {
            imgModelList.clear()
            pathList.forEach {
                imgModelList.add(
                    ImageUploadUtil.ImageModel(
                        File(it),
                        angazaId,
                        UUID.randomUUID().toString()
                    )
                )
            }

        }
        Timber.d("ImagePickerTicket: AngazaId: $angazaId PathList: $pathList }")
    }

    private fun initToolbar() {
        setSupportActionBar(binding.toolbar)
        Util.setToolbar(this@NewTicketFeedbackActivity, binding.toolbar)
    }

    private fun createCopyAndReturnRealPath(context: Context, uri: Uri?): String? {
        val contentResolver: ContentResolver = context.contentResolver ?: return null

        // Create file path inside app's data dir
        val filePath: String = (context.applicationInfo.dataDir.toString() + File.separator
                + System.currentTimeMillis())
        val file = File(filePath)
        try {
            val inputStream = contentResolver.openInputStream(uri!!) ?: return null
            val outputStream: OutputStream = FileOutputStream(file)
            val buf = ByteArray(1024)
            var len: Int
            while (inputStream.read(buf).also { len = it } > 0) outputStream.write(buf, 0, len)
            outputStream.close()
            inputStream.close()
        } catch (ignore: IOException) {
            return null
        }
        return file.absolutePath
    }


    private fun setupClickListener() {
        binding.ivUploadAttachment.setOnClickListener {
            val imgIntent = Intent()
            imgIntent.apply {
                type = "image/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                action = Intent.ACTION_GET_CONTENT
            }
            startActivityForResult(Intent.createChooser(imgIntent, "Select Images"), IMG_RC)
        }

        binding.btnSubmit.setOnClickListener {
            if (Helper.isNetworkConnected()) {
                cookTicketRequestData()
                if (checkValidationBeforeSubmit()) {
                    if (viewModel.isImageMandatory) {
                        uploadImagesToS3()
                    } else {
                        submitDataRequest()
                    }

                }
            } else {
                lifecycleScope.launch(Dispatchers.Main) {
                    showCustomDialog("No internet. Please try again")
                    delay(2000)
                    hideCustomDialog()
                }
            }
        }
    }

    private fun observer() {
        with(viewModel) {
            /** Dynamic UI elements and Data Observer */
            ticketUIResponseLiveData.observe(this@NewTicketFeedbackActivity) { response ->
                when (response) {
                    is NetworkResult.Success -> {
                        hideProgressDialog()
                        response.data?.let { ticketResponse ->
                            Timber.d("Activity: UI API Success -> $ticketResponse ")
                            val mutableList = mutableListOf<Field>()
                            mutableList.add(response.data.first())
                            viewModel.currentRvList.apply {
                                clear()
                                addAll(mutableList)
                            }

                            adapter.setRvData(mutableList)
                        }
                    }
                    is NetworkResult.DbSuccess -> {

                    }
                    is NetworkResult.Error -> {
                        hideProgressDialog()
                        response.message?.let {
//                            Util.showToast(this@NewTicketFeedbackActivity, it)
                            Timber.d("UIApi ERROR: $it")
                        }
                    }
                    is NetworkResult.Loading -> {
                        showProgress()
                    }
                    else->{}
                }
            }

            /** Submit ticket Observer */
            submitTicketLiveData.observe(this@NewTicketFeedbackActivity) { response ->
                when (response) {
                    is NetworkResult.Success -> {
                        hideProgressDialog()
                        response.data?.let { ticketResponse ->
                            Timber.d("Activity: TicketSubmit API Success -> $ticketResponse ")
                            lifecycleScope.launch(Dispatchers.Main) {
                                showCustomDialog()
                                delay(2000)
                                hideCustomDialog()
                                FeedbackConstants.isTicketPostSuccess = true
                                onBackPressed()
                            }
                        }

                    }
                    is NetworkResult.DbSuccess -> {

                    }
                    is NetworkResult.Error -> {
                        hideProgressDialog()
                        response.message?.let {
                            Util.showToast(this@NewTicketFeedbackActivity, it)
                            Timber.d("TicketSubmitApi ERROR: $it")
                        }

                    }
                    is NetworkResult.Loading -> {
                        showProgress()
                    }
                    else->{}
                }
            }
            /** Images Upload Observer */
            allImageUploadedLiveData.observe(this@NewTicketFeedbackActivity) {
                if (it != null && it) {
                    Timber.d("Observer : All Images Uploaded : ${viewModel.imageListFromS3}")
                    viewModel.submitRequestData.apply {
                        attachments.apply {
                            clear()
                            if (viewModel.isImageMandatory) {
                                addAll(viewModel.imageListFromS3)
                            }
                        }
                    }
                    submitDataRequest()
                }
            }
        }

    }

    private fun submitDataRequest() {
        lifecycleScope.launch(Dispatchers.IO) {
            Timber.d("Submit API Request OBJECT ${viewModel.submitRequestData} ")
            viewModel.invokeSubmitNewTickets(
                viewModel.submitRequestData,
                FeedbackConstants.country
            )
        }
    }

    private fun cookTicketRequestData() {
        if (adapter.getRvDataList().isNotEmpty()) {
            viewModel.imageListFromS3.clear()
            viewModel.currentRvListWithAnswers.apply {
                clear()
                addAll(adapter.getRvDataList())
            }
            val requestData = CreateNewTicketRequest()
            viewModel.currentRvListWithAnswers.forEach {
                if (it.heading.isNullOrEmpty()) it.selected = ""
                Timber.d("RV Selection: ${it.selected} || Rv Position: ${it.atRvIndex}")
                Timber.d("VM Image Before Post: ${viewModel.imageListFromS3}")
                requestData.apply {
                    if (it.heading.lowercase().trim() == "account no") {
                        isAccountInUiFound = true
                        if (!it.selected.isNullOrEmpty()) {
                            isAccountFilled = true
                        } else {
                            it.selected = ""
                        }
                    }
                    if (it.heading.lowercase().trim() == "message") {
                        isMessageInUiFound = true
                        if (!it.selected.isNullOrEmpty()) {
                            isMessageFilled = true
                        } else {
                            it.selected = ""
                        }
                    }
                    when (it.heading.lowercase().trim()) {
                        "category" -> category = it.selected
                        "sub-category" -> subcategory = it.selected
                        "account no" -> accountNumber = it.selected
                        "message" -> message = it.selected
                    }

                }

            }
            requestData.apply {
                angazaId = FeedbackConstants.angazaId
                attachments = mutableListOf<String>()
            }
            viewModel.submitRequestData = requestData

        }
    }

    private fun checkValidationBeforeSubmit(): Boolean {
        var isReady = true
        viewModel.submitRequestData.let {
            if (it.isAccountInUiFound) {
                if (it.isAccountFilled) {
                    isReady = true
                } else {
                    showToast("Please enter account number to continue")
                    isReady = false
                    return@let
                }
            }
            if (it.isMessageInUiFound) {
                if (it.isMessageFilled) {
                    isReady = true
                } else {
                    showToast("Please enter message to continue")
                    isReady = false
                    return@let
                }
            }
            if (viewModel.isImageMandatory) {
                if (imgModelList.isNullOrEmpty()) {
                    showToast("Please select images to continue")
                    isReady = false
                    return@let
                }
            }
        }
        return isReady
    }

    private fun showToast(message: String) {
        Toast.makeText(this@NewTicketFeedbackActivity, message, Toast.LENGTH_SHORT).show()
    }

    private fun uploadImagesToS3() {
        Timber.d("NewTicket:Submit Clicked: ImageList : $imgModelList ")
        if (!imgModelList.isNullOrEmpty()) {
            showProgress()
            lifecycleScope.launch(Dispatchers.IO) {
                imgModelList.forEach {
                    awsHelper.uploadImage(it)
                }
            }
        }
    }


    private fun initializeRv() {
        val layoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager
        binding.recyclerView.adapter = adapter
        adapter.attachListener(WeakReference(this))
    }

    override fun onTicketItemClicked(data: Field) {

    }

    fun onImageTagFound(isUpload: Boolean) {
        if (isUpload) {
            with(binding) {
                viewModel.imageListFromS3.clear()
                imgModelList.clear()
                viewModel.isImageMandatory = true
                ivUploadAttachment.visibility = View.VISIBLE
                ivUploadAttachment.setImageDrawable(resources.getDrawable(R.drawable.ic_upload_feedback_24))
                tvAttachmentCount.visibility =  View.VISIBLE
                tvAttachmentCount.text =  ""
            }
        } else {
            with(binding) {
                viewModel.imageListFromS3.clear()
                imgModelList.clear()
                viewModel.isImageMandatory = false
                ivUploadAttachment.visibility = View.GONE
                ivUploadAttachment.setImageDrawable(resources.getDrawable(R.drawable.ic_upload_feedback_24))
                tvAttachmentCount.visibility =  View.GONE
                tvAttachmentCount.text =  ""
            }
        }
    }

    override fun onSpinnerItemSelected(fieldData: Field, selectedLabel: String) {
        val fieldNameList = mutableListOf<String>()
        with(viewModel) {
            ticketUIResponseLiveData.value?.data.let { fieldList ->
                val filteredList = fieldList?.filter {
                    it == fieldData
                }
                Timber.d("Activity: SpinnerItemSelected: FilteredList: $filteredList")
                filteredList?.first().let {
                    val spinnerElementObj = it?.elements?.filter { it.label == selectedLabel }
                    spinnerElementObj?.first()?.requiredFields?.let { requiredFieldList ->
                        var isUpload = false
                        requiredFieldList.forEach { required ->
                            if (required.lowercase().trim() == "attachment") {
                                isUpload = true
                            }
                            fieldNameList.add(required)
                        }
                        onImageTagFound(isUpload)
                        if (fieldNameList.isNotEmpty()) {
                            ticketUIResponseLiveData.value?.data?.let { list ->
                                val toBeAddedFieldList = mutableListOf<Field>()
                                fieldNameList.forEach { fieldName ->
                                    val newFieldList = list.filter {
                                        it.heading == fieldName
                                    }
                                    if (newFieldList.isNotEmpty()) {
                                        toBeAddedFieldList.addAll(newFieldList)
                                    }

                                }
                                Timber.d("Activity: SpinnerItemSelected: TOBeAddedList: $toBeAddedFieldList")
                                adapter.addRvData(toBeAddedFieldList)
                                viewModel.currentRvList.addAll(toBeAddedFieldList)
                            }
                        }


                    }

                }

            }
        }
    }

    override fun onAllUploadCompleted(imageList: List<String>, url: String) {
        viewModel.imageListFromS3.add(url)
        Timber.d("Uploaded Callback: List : $imageList")
        if (imageList.size == imgModelList.size) {
            viewModel.allImageUploadedLiveData.postValue(true)
        }
    }

    private fun showProgress() {
        progressdialog.setContentView(R.layout.progress_dialog)
        progressdialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        progressdialog.setCancelable(true)
        progressdialog.setCanceledOnTouchOutside(false);

        progressdialog.setOnCancelListener {
            onBackPressed()
        }
        try {
            if (!progressdialog.isShowing)
                progressdialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideProgressDialog() {
        progressdialog.dismiss()
    }

    private fun showCustomDialog(message: String = "Ticket Submitted Successfully") {
        val dialogView = FeedbackTicketSuccessDialogBinding.inflate(layoutInflater)
        customDialog.setContentView(dialogView.root)
        customDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialogView.tvMessage.text = message
        customDialog.setCancelable(true)
        customDialog.setCanceledOnTouchOutside(false);
        customDialog.show()
        customDialog.setOnCancelListener {
            onBackPressed()
        }

        try {
            if (!customDialog.isShowing)
                customDialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideCustomDialog() {
        customDialog.dismiss()
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            android.R.id.home -> {

                onBackPressed()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}
