package com.greenlightplanet.kazi.collectiongoal.view.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.SpannableString
import android.text.style.UnderlineSpan
import android.util.Log
import androidx.activity.viewModels
import androidx.annotation.Keep
import androidx.appcompat.app.AppCompatActivity
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.collectiongoal.viewmodel.CollectiontargetViewModel
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityCollectionTargetBinding
import com.greenlightplanet.kazi.newtasks.view.activity.NewTaskActivity
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.summary.model.SummaryModel
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
@Keep
class CollectionTargetActivity : BaseActivity() {

    private lateinit var binding: ActivityCollectionTargetBinding
    var preference: GreenLightPreference? = null
    var loginResponseModel: LoginResponseModel? = null
    var activity: AppCompatActivity? = null
    var isFromNotification = false
    var mHomeWatcher: HomeWatcher? = null
    var summaryModel: SummaryModel? = null
    private val viewModel: CollectiontargetViewModel by viewModels()
    var collectionGoalCommonWeek: SummaryModel.CollectionGoalCommonWeek? = null
    var bundle = Bundle()
    var lastSavedData : String? = ""

    private val TAG = "CollectionTargetActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCollectionTargetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initialize()
        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        if (intent.hasExtra("fromNotification")) {
            isFromNotification = intent.getBooleanExtra("fromNotification", false)
        }
    }

    fun initialize() {
        activity = this
        Util.setToolbar(this, this.binding.toolbar2)
        preference = GreenLightPreference.getInstance(this)
        loginResponseModel = preference?.getLoginResponseModel()

        bundle = intent.extras!!
        summaryModel = intent.extras!!.getParcelable("collectionCommonWeek")

        Log.d("CheckingModelData4",summaryModel?.collectionGoalCurrentWeek?.weekString.toString())

        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this)
        binding.tvLastSaved.text = data?.summary

        setData(summaryModel)
        onClickHandler()



    }

    private fun onClickHandler() {

        binding.buttonThisweekincentive.setOnClickListener {

            val intent = Intent(activity, ThisWeekIncentiveActivity::class.java)
            //val intent = Intent(activity, TestActivity::class.java)
            intent.putExtra("angaza", preference?.getLoginResponseModel()?.angazaId)
            intent.putExtra("flag","CurrentWeekIncentive")
            intent.putExtra("collectionGoalThisWeek", summaryModel)

            Log.d("CheckingModelData3",summaryModel?.collectionGoalCurrentWeek?.weekString.toString())
            Log.d("CheckingSummaryModel34",summaryModel?.collectionGoalAccuredIncentiveMessage.toString())
            startActivity(intent)
        }

        binding.LWIncentiveButton.setOnClickListener {

            val intent = Intent(activity, PastWeekIncentiveActivity::class.java)
            intent.putExtra("angaza", preference?.getLoginResponseModel()?.angazaId)
            startActivity(intent)
        }

        binding.btMakeCall.setOnClickListener {

            Log.d("CheckDoneTargetData", "DoneAccount ${summaryModel?.collectionGoalCurrentWeek?.doneAccount} " +
                    "+\n+ TargetAccount ${summaryModel?.collectionGoalCurrentWeek?.targetAccount}")

            val intent = Intent(activity, MakeCallActivity::class.java)
            intent.putExtra("angaza", preference?.getLoginResponseModel()?.angazaId)
            intent.putExtra("collectionCommonWeek", summaryModel)
            startActivity(intent)

        }

        binding.tvTaskCompleted.setOnClickListener {
            val intent = Intent(activity, NewTaskActivity::class.java)
            intent.putExtra("angaza", preference?.getLoginResponseModel()?.angazaId)
            //intent.putExtra("collectionCommonWeek", summaryModel)
            startActivity(intent)
        }

        binding.ivCommission.setOnClickListener {
            Util.customFseRationaleDialog(this, "",
                hideNegative = true,
                titleSpanned = null,
                hideTitle = true,
                setCanceledOnTouchOutside = false,
                setCancelable = false,
                message = summaryModel?.collectionGoalAccuredIncentiveMessage.toString(),
                positveSelected = {
                    it.dismiss()
                },
                negativeSeleted = {
                    it.dismiss()
                }
            )
        }

    }

    @SuppressLint("LongLogTag", "SetTextI18n")
    private fun setData(responseData: SummaryModel?) {

        val symbol = preference?.getCountryResponseModel()?.countryCurrency ?: "NA"

        binding.tvtargetAccounts.text = Util.checkBlank(responseData?.collectionGoalCurrentWeek?.doneAccount.toString(),applicationContext)+
                "/"+ Util.checkBlank(responseData?.collectionGoalCurrentWeek?.targetAccount.toString(), applicationContext)



//        binding.tvtargetAccounts.text = responseData?.collectionGoalCurrentWeek?.doneAccount.toString()+"/"+
//                responseData?.collectionGoalCurrentWeek?.targetAccount.toString()

//        binding.tvTargetCompleted.text = responseData?.collectionGoalTargetCompletedPercentage.toString()+"%"
        binding.tvTargetCompleted.text = Util.checkBlank(responseData?.
        collectionGoalTargetCompletedPercentage.toString(),applicationContext) + "%"

        var mString = "${Util.checkBlank(summaryModel?.collectionGoalKaziTaskCompletion.toString(), applicationContext)}%"

        val mSpannableString = SpannableString(mString)

        mSpannableString.setSpan(UnderlineSpan(), 0, mSpannableString.length, 0)

        binding.tvTaskCompleted.text = mSpannableString

        binding.tvAccruedCollectionIncentive.text = Util.checkBlank(responseData?.collectionGoalCurrentWeek?.commission?.let {
            Util.formatAmount(it) } + " " + symbol, applicationContext)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        finish()
        return true
    }

//    private val onBackPressedCallback: OnBackPressedCallback =
//        object : OnBackPressedCallback(true) {
//            override fun handleOnBackPressed() {
//                finish()
//            }
//        }

//    override fun onBackPressed() {
//        super.onBackPressed()
//        finish()
//    }

}