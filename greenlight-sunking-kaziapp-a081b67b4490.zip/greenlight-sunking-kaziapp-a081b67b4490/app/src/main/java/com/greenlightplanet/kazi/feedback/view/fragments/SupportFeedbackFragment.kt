package com.greenlightplanet.kazi.feedback.view.fragments

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.ContextThemeWrapper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FeedbackTicketSuccessDialogBinding
import com.greenlightplanet.kazi.databinding.FragmentSupportFeedbackBinding
import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackConstants
import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackSupportFilterDialog
import com.greenlightplanet.kazi.feedback.feedback_utils.FilterDialogListener
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.feedback.repo.paging.SupportDataPagingSource
import com.greenlightplanet.kazi.feedback.repo.model.response.TicketResponseData
import com.greenlightplanet.kazi.feedback.view.activities.ChatFeedbackActivity
import com.greenlightplanet.kazi.feedback.view.adapter.*
import com.greenlightplanet.kazi.feedback.viewmodel.SupportFeedbackViewModel
import com.greenlightplanet.kazi.utils.NetworkResult
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import retrofit2.http.Url
import timber.log.Timber
import java.lang.ref.WeakReference

@AndroidEntryPoint
class SupportFeedbackFragment : Fragment(), SupportFeedbackAdapterClickListener,
    SupportFeedbackFilterAdapterClickListener {
    private val viewModel by activityViewModels<SupportFeedbackViewModel>()
    private lateinit var binding: FragmentSupportFeedbackBinding
    val adapter = SupportFeedbackAdapter()
    val adapterFilter = SupportFeedbackFilterAdapter()
    lateinit var filterDialog: FeedbackSupportFilterDialog
    lateinit var customDialog: Dialog
    lateinit var progressdialog: Dialog
    var isPendingFrag = false
    var isClosedFrag = false
    private var selectedFilterPosition = 0
    private var selectedFilterName = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentSupportFeedbackBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initializeRv()
        initOther()
        observer()
        setListener()
        initFilterDialog()
        initializeFilterRv()


    }

    private fun initOther() {
        customDialog = Dialog(requireContext())
        progressdialog = Dialog(requireContext())
    }

    /** Shows filter dialog to select from options: All /Today /Yesterday /Last 7 Days /Last 14 Days */
    private fun showFilterDialog() {
        val alertDialog: AlertDialog.Builder =
            AlertDialog.Builder(ContextThemeWrapper(requireContext(), R.style.popup_theme))
        val items = resources.getStringArray(R.array.filter_feedback_support)
        alertDialog.setSingleChoiceItems(items, selectedFilterPosition) { dialog, position ->
            selectedFilterPosition = position
            selectedFilterName = items[position]
            dialog.dismiss()
            val color: Int  //The color u want
            onFilterSelected(items, position)
            if (position == 0) {
                color = Color.parseColor("#000000")
            } else {
                color = Color.parseColor("#FFFFFF") //The color u want
            }
            binding.ivFilter.setColorFilter(color)
        }
        alertDialog.show()
    }

    /** Handles Paging Rv and Filtered Rv visibility*/
    private fun setRvVisibility(isFilter: Boolean) {
        if (isFilter) {
            binding.recyclerView.visibility = View.GONE
            binding.recyclerViewFilter.visibility = View.VISIBLE
        } else {
            binding.recyclerView.visibility = View.VISIBLE
            binding.recyclerViewFilter.visibility = View.GONE
        }
    }

    /** Handles and processes Filter selection*/
    private fun onFilterSelected(items: Array<String>, position: Int) {
        when (position) {
            0 -> { //All
                Timber.d("FilterDialog: SelectedItem 0: ${items[position]}")
                if (isClosedFrag) {
                    if (viewModel.currentClosedList.isNotEmpty()) {
                        setRvVisibility(isFilter = false)
                        if (!viewModel.currentClosedList.isNullOrEmpty()) setNoDataVisibility(false)
                        setIsFilterApplied(false)
                    }
                }
                if (isPendingFrag) {
                    if (viewModel.currentPendingList.isNotEmpty()) {
                        setRvVisibility(isFilter = false)
                        if (!viewModel.pendingSearchedList.isNullOrEmpty()) setNoDataVisibility(false)
                        setIsFilterApplied(false)
                    }
                }
            }
            1 -> { //Today
                Timber.d("FilterDialog: SelectedItem 1: ${items[position]}")
                if (isClosedFrag) {
                    if (viewModel.currentClosedList.isNotEmpty()) {
                        setRvVisibility(isFilter = true)
                        setIsFilterApplied(true)

                        val currentT = Helper.getCurrentLocalTimeStamp()
                        val dayFormattedWithTime =
                            Helper.getTimeStampToDate(currentT, FeedbackConstants.utcDateFormat)
                        val dayFormattedDate = Helper.getTimeStampToDate(
                            currentT,
                            FeedbackConstants.requiredDateFormat
                        )
                        Timber.d("Filter Today : Local Date: $dayFormattedDate || Full Format: $dayFormattedWithTime")
                        val filteredList = mutableListOf<TicketResponseData>()
                        viewModel.currentClosedList.forEach {
                            it.closedAt?.let { dateStr ->
                                val datewithTimeLocal = Helper.convertUTCTimeWithFormatToRequired(
                                    dateStr,
                                    requiredFormat = FeedbackConstants.utcDateFormat
                                )
                                val dateLocal = Helper.convertUTCTimeWithFormatToRequired(
                                    dateStr,
                                    requiredFormat = FeedbackConstants.requiredDateFormat
                                )
                                Timber.d("Filter Today Remote: Local Date: $dateLocal || Full Format: $datewithTimeLocal || ORIGINAL remote API: $dateStr")
                                if (dateLocal == dayFormattedDate) {
                                    filteredList.add(it)
                                }
                            }

                        }
                        if (filteredList.isNotEmpty()) {
                            viewModel.filteredClosedList.apply {
                                setNoDataVisibility(false)
                                clear()
                                addAll(filteredList)
                                adapterFilter.setRvData(filteredList, isStatusClosed = true)
                            }
                            Timber.d("FilterDialog: SelectedItem: Today Closed: Closed: ListSize: ${filteredList.size} FilteredList $filteredList")
                        } else {
                            setNoDataVisibility(true)
                            clearFilterData()
                        }
                    }
                }
                if (isPendingFrag) {
                    if (viewModel.currentPendingList.isNotEmpty()) {
                        setRvVisibility(isFilter = true)
                        setIsFilterApplied(true)

                        val currentT = Helper.getCurrentLocalTimeStamp()
                        val dayFormattedWithTime =
                            Helper.getTimeStampToDate(currentT, FeedbackConstants.utcDateFormat)
                        val dayFormattedDate = Helper.getTimeStampToDate(
                            currentT,
                            FeedbackConstants.requiredDateFormat
                        )
                        Timber.d("Filter Today : Local Date: $dayFormattedDate || Full Format: $dayFormattedWithTime")
                        val filteredList = mutableListOf<TicketResponseData>()
                        viewModel.currentPendingList.forEach {

                            it.createdAt?.let { dateStr ->
                                val datewithTimeLocal = Helper.convertUTCTimeWithFormatToRequired(
                                    dateStr,
                                    requiredFormat = FeedbackConstants.utcDateFormat
                                )
                                val dateLocal = Helper.convertUTCTimeWithFormatToRequired(
                                    dateStr,
                                    requiredFormat = FeedbackConstants.requiredDateFormat
                                )
                                Timber.d("Filter Today Remote: Local Date: $dateLocal || Full Format: $datewithTimeLocal || ORIGINAL remote API: $dateStr")
                                if (dateLocal == dayFormattedDate) {
                                    filteredList.add(it)
                                }
                            }
                        }
                        if (filteredList.isNotEmpty()) {
                            viewModel.filteredPendingList.apply {
                                setNoDataVisibility(false)
                                clear()
                                addAll(filteredList)
                                adapterFilter.setRvData(filteredList, isStatusPending = true)
                            }
                            Timber.d("FilterDialog: SelectedItem: Today: Pending: ListSize: ${filteredList.size} FilteredList $filteredList")
                        } else {
                            setNoDataVisibility(true)
                            clearFilterData()
                        }
                    }
                }
            }
            2 -> { //Yesterday
                Timber.d("FilterDialog: SelectedItem 2: ${items[position]}")
                if (isClosedFrag) {
                    if (viewModel.currentClosedList.isNotEmpty()) {
                        setRvVisibility(isFilter = true)
                        setIsFilterApplied(true)

                        val currentT = Helper.getCurrentLocalTimeStamp()
                        val prevDay = Helper.getPrevDate(currentT, -1)
                        val prevDayFormattedWithTime =
                            Helper.getTimeStampToDate(prevDay, FeedbackConstants.utcDateFormat)
                        val prevDayFormattedDate =
                            Helper.getTimeStampToDate(prevDay, FeedbackConstants.requiredDateFormat)
                        Timber.d("Filter Yesterday -1day: Local Date: $prevDayFormattedDate || Full Format: $prevDayFormattedWithTime")

                        val filteredList = mutableListOf<TicketResponseData>()
                        viewModel.currentClosedList.forEach {
                            it.closedAt?.let { dateStr ->
                                val datewithTimeLocal = Helper.convertUTCTimeWithFormatToRequired(
                                    dateStr,
                                    requiredFormat = FeedbackConstants.utcDateFormat
                                )
                                val dateLocal = Helper.convertUTCTimeWithFormatToRequired(
                                    dateStr,
                                    requiredFormat = FeedbackConstants.requiredDateFormat
                                )
                                Timber.d("Filter Yesterday -1day Remote: Local Date: $dateLocal || Full Format: $datewithTimeLocal || ORIGINAL remote API: $dateStr")
                                if (dateLocal == prevDayFormattedDate) {
                                    filteredList.add(it)
                                }
                            }
                        }
                        if (filteredList.isNotEmpty()) {
                            viewModel.filteredClosedList.apply {
                                setNoDataVisibility(false)
                                clear()
                                addAll(filteredList)
                                adapterFilter.setRvData(filteredList, isStatusClosed = true)
                            }
                            Timber.d("FilterDialog: SelectedItem: Yesterday: Closed: ListSize: ${filteredList.size} FilteredList $filteredList")
                        } else {
                            setNoDataVisibility(true)
                            clearFilterData()
                        }
                    }
                }
                if (isPendingFrag) {
                    if (viewModel.currentPendingList.isNotEmpty()) {
                        Timber.d("Filter Inside Yesterday Pending: VM List: ${viewModel.currentPendingList}")
                        setRvVisibility(isFilter = true)
                        setIsFilterApplied(true)
                        val currentT = Helper.getCurrentLocalTimeStamp()
                        val prevDay = Helper.getPrevDate(currentT, -1)
                        val prevDayFormattedWithTime =
                            Helper.getTimeStampToDate(prevDay, FeedbackConstants.utcDateFormat)
                        val prevDayFormattedDate =
                            Helper.getTimeStampToDate(prevDay, FeedbackConstants.requiredDateFormat)
                        Timber.d("Filter Yesterday -1day: Local Date: $prevDayFormattedDate || Full Format: $prevDayFormattedWithTime")
                        val filteredList = mutableListOf<TicketResponseData>()
                        viewModel.currentPendingList.forEach {
                            it.createdAt?.let { dateStr ->
                                val datewithTimeLocal = Helper.convertUTCTimeWithFormatToRequired(
                                    dateStr,
                                    requiredFormat = FeedbackConstants.utcDateFormat
                                )
                                val dateLocal = Helper.convertUTCTimeWithFormatToRequired(
                                    dateStr,
                                    requiredFormat = FeedbackConstants.requiredDateFormat
                                )
                                Timber.d("Filter Yesterday -1day Remote: Local Date: $dateLocal || Full Format: $datewithTimeLocal || ORIGINAL remote API: $dateStr")
                                if (dateLocal == prevDayFormattedDate) {
                                    filteredList.add(it)
                                }
                            }
                        }
                        if (filteredList.isNotEmpty()) {
                            viewModel.filteredPendingList.apply {
                                setNoDataVisibility(false)
                                clear()
                                addAll(filteredList)
                                adapterFilter.setRvData(filteredList, isStatusPending = true)
                            }
                            Timber.d("FilterDialog: SelectedItem Yesterday: Pending: ListSize: ${filteredList.size} FilteredList $filteredList")
                        } else {
                            setNoDataVisibility(true)
                            clearFilterData()
                        }
                    }
                }
            }
            3 -> { //Last 7 Days
                Timber.d("FilterDialog: SelectedItem 3: ${items[position]}")
                if (isClosedFrag) {
                    if (viewModel.currentClosedList.isNotEmpty()) {
                        setRvVisibility(isFilter = true)
                        setIsFilterApplied(true)
                        val currentTime = Helper.getCurrentUTCTimeStamp()
                        val sevenDaysAgo = Helper.getPrevDate(currentTime, -7)
                        val filteredList = mutableListOf<TicketResponseData>()
                        viewModel.currentClosedList.forEach {
                            Timber.d("Filter Inside: ${it.getClosedAtTimeStampUtc()} >= $sevenDaysAgo")
                            Timber.d(
                                "Filter Inside: ${
                                    Helper.getTimeStampToDate(
                                        it.getClosedAtTimeStampUtc(),
                                        FeedbackConstants.requiredDateFormat
                                    )
                                } >= ${
                                    Helper.getTimeStampToDate(
                                        sevenDaysAgo,
                                        FeedbackConstants.requiredDateFormat
                                    )
                                }"
                            )
                            if (it.getClosedAtTimeStampUtc() >= sevenDaysAgo) {
                                filteredList.add(it)
                            }
                        }
                        if (filteredList.isNotEmpty()) {
                            viewModel.filteredClosedList.apply {
                                setNoDataVisibility(false)
                                clear()
                                addAll(filteredList)
                                adapterFilter.setRvData(filteredList, isStatusClosed = true)
                            }
                            Timber.d("FilterDialog: SelectedItem: 7 Days: Closed: ListSize: ${filteredList.size} FilteredList $filteredList")
                        } else {
                            setNoDataVisibility(true)
                            clearFilterData()
                        }
                    }
                }
                if (isPendingFrag) {
                    if (viewModel.currentPendingList.isNotEmpty()) {
                        setRvVisibility(isFilter = true)
                        setIsFilterApplied(true)
                        val currentTime = Helper.getCurrentUTCTimeStamp()
                        val sevenDaysAgo = Helper.getPrevDate(currentTime, -7)
                        val filteredList = mutableListOf<TicketResponseData>()
                        viewModel.currentPendingList.forEach {
                            Timber.d("Filter Inside: ${it.getCreatedAtTimeStampUtc()} >= $sevenDaysAgo")
                            Timber.d(
                                "Filter Inside: ${
                                    Helper.getTimeStampToDate(
                                        it.getCreatedAtTimeStampUtc(),
                                        FeedbackConstants.requiredDateFormat
                                    )
                                } >= ${
                                    Helper.getTimeStampToDate(
                                        sevenDaysAgo,
                                        FeedbackConstants.requiredDateFormat
                                    )
                                }"
                            )
                            if (it.getCreatedAtTimeStampUtc() >= sevenDaysAgo) {
                                filteredList.add(it)
                            }
                        }
                        if (filteredList.isNotEmpty()) {
                            viewModel.filteredPendingList.apply {
                                setNoDataVisibility(false)
                                clear()
                                addAll(filteredList)
                                adapterFilter.setRvData(filteredList, isStatusPending = true)
                            }
                            Timber.d("FilterDialog: SelectedItem: 7 Days: Pending: ListSize: ${filteredList.size} FilteredList $filteredList")
                        } else {
                            setNoDataVisibility(true)
                            clearFilterData()
                        }
                    }
                }
            }
            4 -> { //Last 14 Days
                Timber.d("FilterDialog: SelectedItem 3: ${items[position]}")
                if (isClosedFrag) {
                    if (viewModel.currentClosedList.isNotEmpty()) {
                        Timber.d("FilterDialog: SelectedItem 3: ${items[position]} || vmList: ${viewModel.currentClosedList}")
                        setRvVisibility(isFilter = true)
                        setIsFilterApplied(true)
                        val currentTime = Helper.getCurrentUTCTimeStamp()
                        val fourteenDaysAgo = Helper.getPrevDate(currentTime, -14)
                        val filteredList = mutableListOf<TicketResponseData>()
                        viewModel.currentClosedList.forEach {
                            Timber.d("Filter Inside: ${it.getClosedAtTimeStampUtc()} >= $fourteenDaysAgo")
                            Timber.d(
                                "Filter Inside: ${
                                    Helper.getTimeStampToDate(
                                        it.getClosedAtTimeStampUtc(),
                                        FeedbackConstants.requiredDateFormat
                                    )
                                } >= ${
                                    Helper.getTimeStampToDate(
                                        fourteenDaysAgo,
                                        FeedbackConstants.requiredDateFormat
                                    )
                                }"
                            )
                            if (it.getClosedAtTimeStampUtc() >= fourteenDaysAgo) {
                                filteredList.add(it)
                            }
                        }
                        Timber.d("FilterDialog: SelectedItem 3: ${items[position]} || filteredList: $filteredList")
                        if (filteredList.isNotEmpty()) {
                            viewModel.filteredClosedList.apply {
                                setNoDataVisibility(false)
                                clear()
                                addAll(filteredList)
                                adapterFilter.setRvData(filteredList, isStatusClosed = true)
                            }
                            Timber.d("FilterDialog: SelectedItem: 14 Days: Closed: ListSize: ${filteredList.size} FilteredList $filteredList")
                        } else {
                            setNoDataVisibility(true)
                            clearFilterData()
                        }
                    }
                }
                if (isPendingFrag) {
                    if (viewModel.currentPendingList.isNotEmpty()) {
                        setRvVisibility(isFilter = true)
                        setIsFilterApplied(true)
                        val currentTime = Helper.getCurrentUTCTimeStamp()
                        val fourteenDaysAgo = Helper.getPrevDate(currentTime, -14)
                        val filteredList = mutableListOf<TicketResponseData>()
                        viewModel.currentPendingList.forEach {
                            Timber.d("Filter Inside: ${it.getCreatedAtTimeStampUtc()} >= $fourteenDaysAgo")
                            Timber.d(
                                "Filter Inside: ${
                                    Helper.getTimeStampToDate(
                                        it.getCreatedAtTimeStampUtc(),
                                        FeedbackConstants.requiredDateFormat
                                    )
                                } >= ${
                                    Helper.getTimeStampToDate(
                                        fourteenDaysAgo,
                                        FeedbackConstants.requiredDateFormat
                                    )
                                }"
                            )
                            if (it.getCreatedAtTimeStampUtc() >= fourteenDaysAgo) {
                                filteredList.add(it)
                            }
                        }
                        if (filteredList.isNotEmpty()) {
                            viewModel.filteredPendingList.apply {
                                setNoDataVisibility(false)
                                clear()
                                addAll(filteredList)
                                adapterFilter.setRvData(filteredList, isStatusPending = true)
                            }
                            Timber.d("FilterDialog: SelectedItem: 14 Days: Pending: ListSize: ${filteredList.size} FilteredList $filteredList")
                        } else {
                            setNoDataVisibility(true)
                            clearFilterData()
                        }
                    }
                }
            }
        }
    }

    /** Resets Filtered Closed/Pending Lists stored in viewModel*/
    private fun clearFilterData() {
        adapterFilter.clearRvData()
        if (isClosedFrag) {
            viewModel.filteredClosedList.clear()
        }
        if (isPendingFrag) {
            viewModel.filteredPendingList.clear()
        }
    }

    private fun observer() {
        with(viewModel) {
            if (isClosedFrag) {
                adapter.isClosed = true
                Timber.d("SupportFragment: Inside ClosedFrag")
                lifecycleScope.launch(Dispatchers.Main) {
                    if (Helper.isNetworkConnected()) {
                        lifecycleScope.launch(Dispatchers.Main) { showProgress() }
                        viewModel.fetchClosedTicketsData().collectLatest {
                            Timber.d("SupportFragment: Closed Paging Data Found")
                            setRvVisibility(isFilter = false)
                            adapter.submitData(it)
                        }
                    } else {
                        showCustomDialog("No internet. Please try again")
                        delay(2000)
                        hideCustomDialog()
                        requireActivity().onBackPressed()
                    }

                }

            }
            if (isPendingFrag) {
                adapter.isPending = true
                Timber.d("SupportFragment: Inside PendingFrag")
                lifecycleScope.launch {
                    if (Helper.isNetworkConnected()) {
                        lifecycleScope.launch(Dispatchers.Main) { showProgress() }
                        viewModel.fetchPendingTicketsData().collectLatest {
                            Timber.d("SupportFragment: Pending Paging Data Found")
                            setRvVisibility(isFilter = false)
                            adapter.submitData(it)
                        }
                    } else {
                        lifecycleScope.launch(Dispatchers.Main) {
                            showCustomDialog("No internet. Please try again")
                            delay(2000)
                            hideCustomDialog()
                            requireActivity().onBackPressed()
                        }
                    }
                }
            }
        }
        /** New Paging data observer to store current data to viewModel List for Closed/Pending tickets*/
        SupportDataPagingSource.ticketResponseLiveData.observe(viewLifecycleOwner) {
            it?.let { result ->
                when (result) {
                    is NetworkResult.Success -> {
                        hideProgressDialog()
                        Timber.d("Observer Support: Success: Page No: ${result.data?.pageNumber}")
                        if (!result.data?.responseData.isNullOrEmpty()) {
                            if (isClosedFrag) {
                                if (result.data?.responseData?.first()?.status?.lowercase() == "closed") {
                                    setNoDataVisibility(false)
                                    if (result.data.pageNumber == 0) {
                                        viewModel.currentClosedList.apply {
                                            clear()
                                            addAll(result.data.responseData)
                                            Timber.d("Observer: Closed List Found for 0: PageNo:${result.data.pageNumber} || ${result.data.responseData}")
                                        }
                                    } else {
                                        viewModel.currentClosedList.addAll(result.data.responseData)
                                        Timber.d("Observer: Closed List Found: PageNo:${result.data.pageNumber} || ${result.data.responseData} ")
                                    }
                                }
                            }
                            if (isPendingFrag) {
                                result.data?.let {
//                                    if (result.data?.responseData?.first()?.status?.lowercase() == "pending" || result.data?.responseData?.first()?.status?.lowercase() == "queued" || result.data?.responseData?.first()?.status?.lowercase() == "Solved") {
                                    setNoDataVisibility(false)
                                    if (result.data.pageNumber == 0) {
                                        viewModel.currentPendingList.apply {
                                            clear()
                                            addAll(result.data.responseData)
                                            Timber.d("Observer Support: Success: Pending List Found for 0: PageNo:${result.data.pageNumber} || ${result.data.responseData}")
                                        }
                                    } else {
                                        viewModel.currentPendingList.addAll(result.data.responseData)
                                        Timber.d("Observer Support: Success: Pending List Found: PageNo:${result.data.pageNumber} || ${result.data.responseData}")
                                    }
                                }
                            }
                        }


                    }
                    is NetworkResult.Error -> {
                        hideProgressDialog()
                        when (result.message) {
                            "closed" -> {
                                if (isClosedFrag) {
                                    setNoDataVisibility(true)
                                }

                            }
                            "pending" -> {
                                if (isPendingFrag) {
                                    setNoDataVisibility(true)
                                }
                            }
                            else -> {
                                Timber.d("Observer Support: Error ${result.data}")
                            }
                        }


                    }
                    is NetworkResult.Exception -> {
                        hideProgressDialog()
                        Timber.d("Observer Support: Exception Occured: ${result.data}")
                        setNoDataVisibility(true)
                    }
                    is NetworkResult.Loading -> {

                    }
                    is NetworkResult.DbSuccess -> {

                    }
                }
            }
        }
    }

    private fun setListener() {
        binding.apply {
            ivFilter.setOnClickListener {
                showFilterDialog()
            }
        }
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(text: Editable?) {
                Timber.d("SearchView: $text")
                with(viewModel) {
                    if (isClosedFrag) {
                        if (!currentClosedList.isNullOrEmpty()) {
                            if (viewModel.isFilterAppliedClosed) {
                                val searchFilteredList =
                                    filteredClosedList.filter {
                                        it.ticketId.lowercase().trim()
                                            .contains(
                                                text.toString().lowercase().trim()
                                            ) && !text.isNullOrEmpty()
                                    }
                                if (!searchFilteredList.isNullOrEmpty()) {
                                    isSearchFilteredClosed = true
                                    Timber.d("SearchView Filter Found: $searchFilteredList")
                                    adapterFilter.clearRvData()
                                    setNoDataVisibility(false)
                                    adapterFilter.setRvData(
                                        searchFilteredList,
                                        isStatusClosed = true
                                    )
                                    setRvVisibility(isFilter = true)
                                } else if (text.isNullOrEmpty()) {
                                    if (filteredClosedList.isNotEmpty()) {
                                        isSearchFilteredClosed = false
                                        adapterFilter.clearRvData()
                                        setNoDataVisibility(false)
                                        setRvVisibility(isFilter = true)
                                        adapterFilter.setRvData(
                                            filteredClosedList,
                                            isStatusClosed = true
                                        )
                                    } else {
                                        isSearchFilteredClosed = true
                                        adapterFilter.clearRvData()
                                        setNoDataVisibility(true)
                                        setRvVisibility(isFilter = true)
                                    }
                                } else {
                                    isSearchFilteredClosed = true
                                    adapterFilter.clearRvData()
                                    setNoDataVisibility(true)
                                    setRvVisibility(isFilter = true)
                                }
                            } else {
                                val searchFilteredList =
                                    currentClosedList.filter {
                                        it.ticketId.lowercase().trim()
                                            .contains(
                                                text.toString().lowercase().trim()
                                            ) && !text.isNullOrEmpty()
                                    }
                                Timber.d("SearchView Paging Filter List: $searchFilteredList")
                                if (!searchFilteredList.isNullOrEmpty()) {
                                    isSearchFilteredClosed = true
                                    Timber.d("SearchView Filter Found: $searchFilteredList")
                                    adapterFilter.clearRvData()
                                    setNoDataVisibility(false)
                                    adapterFilter.setRvData(
                                        searchFilteredList,
                                        isStatusClosed = true
                                    )
                                    setRvVisibility(isFilter = true)
                                } else if (text.isNullOrEmpty()) {
                                    if (currentClosedList.isNotEmpty()) {
                                        isSearchFilteredClosed = false
                                        adapterFilter.clearRvData()
                                        setNoDataVisibility(false)
                                        setRvVisibility(isFilter = false)
                                    } else {
                                        isSearchFilteredClosed = true
                                        adapterFilter.clearRvData()
                                        setNoDataVisibility(true)
                                        setRvVisibility(isFilter = true)
                                    }
                                } else {
                                    isSearchFilteredClosed = true
                                    adapterFilter.clearRvData()
                                    setNoDataVisibility(true)
                                    setRvVisibility(isFilter = true)
                                }
                            }


                        }
                    }
                    if (isPendingFrag) {
                        if (!currentPendingList.isNullOrEmpty()) {
                            if (viewModel.isFilterAppliedPending) {
                                val searchFilteredList =
                                    filteredPendingList.filter {
                                        it.ticketId.lowercase().trim()
                                            .contains(
                                                text.toString().lowercase().trim()
                                            ) && !text.isNullOrEmpty()
                                    }
                                if (!searchFilteredList.isNullOrEmpty()) {
                                    isSearchFilteredPending = true
                                    Timber.d("SearchView Filter Found: $searchFilteredList")
                                    adapterFilter.clearRvData()
                                    setNoDataVisibility(false)
                                    adapterFilter.setRvData(
                                        searchFilteredList,
                                        isStatusPending = true
                                    )
                                    setRvVisibility(isFilter = true)
                                } else if (text.isNullOrEmpty()) {
                                    if (filteredPendingList.isNotEmpty()) {
                                        isSearchFilteredPending = false
                                        adapterFilter.clearRvData()
                                        setNoDataVisibility(false)
                                        setRvVisibility(isFilter = true)
                                        adapterFilter.setRvData(
                                            filteredPendingList,
                                            isStatusPending = true
                                        )
                                    } else {
                                        isSearchFilteredPending = true
                                        adapterFilter.clearRvData()
                                        setNoDataVisibility(true)
                                        setRvVisibility(isFilter = true)
                                    }
                                } else {
                                    isSearchFilteredPending = true
                                    adapterFilter.clearRvData()
                                    setNoDataVisibility(true)
                                    setRvVisibility(isFilter = true)
                                }
                            } else {
                                val searchFilteredList =
                                    currentPendingList.filter {
                                        it.ticketId.lowercase().trim()
                                            .contains(
                                                text.toString().lowercase().trim()
                                            ) && !text.isNullOrEmpty()
                                    }
                                if (!searchFilteredList.isNullOrEmpty()) {
                                    isSearchFilteredPending = true
                                    Timber.d("SearchView Filter Found: $searchFilteredList")
                                    adapterFilter.clearRvData()
                                    setNoDataVisibility(false)
                                    adapterFilter.setRvData(
                                        searchFilteredList,
                                        isStatusPending = true
                                    )
                                    setRvVisibility(isFilter = true)
                                } else if (text.isNullOrEmpty()) {
                                    Timber.d("SearchView Filter Pending Empty Text: $searchFilteredList")
                                    if (currentPendingList.isNotEmpty()) {
                                        isSearchFilteredPending = false
                                        adapterFilter.clearRvData()
                                        setNoDataVisibility(false)
                                        setRvVisibility(isFilter = false)
                                    } else {
                                        isSearchFilteredPending = true
                                        adapterFilter.clearRvData()
                                        setNoDataVisibility(true)
                                        setRvVisibility(isFilter = true)
                                    }
                                } else {
                                    isSearchFilteredPending = true
                                    adapterFilter.clearRvData()
                                    setNoDataVisibility(true)
                                    setRvVisibility(isFilter = true)
                                }
                            }


                        }
                    }

                }
            }
        })


    }

    /** Paging Rv Agatper Setup*/
    private fun initializeRv() {
        val layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.layoutManager = layoutManager
        binding.recyclerView.adapter = adapter
        adapter.attachListener(WeakReference(this))

    }

    /** Filtered data Rv Agatper Setup*/
    private fun initializeFilterRv() {
        val layoutFilterManager = LinearLayoutManager(requireContext())
        binding.recyclerViewFilter.layoutManager = layoutFilterManager
        binding.recyclerViewFilter.adapter = adapterFilter
        adapterFilter.attachListener(WeakReference(this))
    }


    /** Handles Paging Rv Item Clicked. (Ticket)*/
    override fun onTicketItemClicked(data: TicketResponseData) {
        if (isClosedFrag) {
            if (Helper.isNetworkConnected()) {
                navigateToChat(ticketId = data.ticketId, isClosed = true, data.status)
            } else {
                lifecycleScope.launch(Dispatchers.Main) {
                    showCustomDialog("No internet. Please try again")
                    delay(2000)
                    hideCustomDialog()
                }
            }

        }
        if (isPendingFrag) {
            if (Helper.isNetworkConnected()) {
                navigateToChat(ticketId = data.ticketId, isClosed = false, data.status)
            } else {
                lifecycleScope.launch(Dispatchers.Main) {
                    showCustomDialog("No internet. Please try again")
                    delay(2000)
                    hideCustomDialog()
                }
            }
        }
    }
    /** Handles Filter Rv Item Clicked. (Ticket)*/
    override fun onTicketItemClickedFilter(data: TicketResponseData) {
        if (isClosedFrag) {
            navigateToChat(ticketId = data.ticketId, isClosed = true, data.status)
        }
        if (isPendingFrag) {
            navigateToChat(ticketId = data.ticketId, isClosed = false, data.status)
        }
    }

    /** Navigates to ChatFeedbackActivity*/
    private fun navigateToChat(ticketId: String, isClosed: Boolean, status: String) {
        Intent(requireContext(), ChatFeedbackActivity::class.java).apply {
            putExtra(FeedbackConstants.TICKETID_CHAT_INTENT, ticketId)
            putExtra(FeedbackConstants.STATUS_CHAT_INTENT, status)
            putExtra(FeedbackConstants.CLOSED_CHAT_INTENT, isClosed)
            startActivity(this)
        }
    }

    fun setNoDataVisibility(isVisible: Boolean) {
        if (isVisible) binding.noData.visibility = View.VISIBLE
        else binding.noData.visibility = View.GONE
    }

    fun setIsFilterApplied(isFilter: Boolean) {
        if (isClosedFrag) {
            viewModel.isFilterAppliedClosed = isFilter
        }
        if (isPendingFrag) {
            viewModel.isFilterAppliedPending = isFilter
        }
    }

    /** Filter dialog Initializer*/
    private fun initFilterDialog() {
        filterDialog = FeedbackSupportFilterDialog(requireContext(),
            object : FilterDialogListener {
                override fun onDialogApply(date: String) {
                    filterDialog.dismiss()
                    Timber.d("Dialog onApply: Date: $date")

                }
            })
    }

    private fun showCustomDialog(message: String = "Ticket Submitted Successfully") {
        val dialogView = FeedbackTicketSuccessDialogBinding.inflate(layoutInflater)
        customDialog.setContentView(dialogView.root)
        customDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialogView.tvMessage.text = message
        customDialog.setCancelable(true)
        customDialog.setCanceledOnTouchOutside(false);
        customDialog.show()
        customDialog.setOnCancelListener {
            requireActivity().onBackPressed()
        }

        try {
            if (!customDialog.isShowing)
                customDialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showProgress() {
        progressdialog.setContentView(R.layout.progress_dialog)
        progressdialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        progressdialog.setCancelable(true)
        progressdialog.setCanceledOnTouchOutside(false);

        progressdialog.setOnCancelListener {
            requireActivity().onBackPressed()
        }

        try {

            if (!progressdialog.isShowing)
                progressdialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideProgressDialog() {
        progressdialog.dismiss()
    }

    private fun hideCustomDialog() {
        customDialog.dismiss()
    }


}