package com.greenlightplanet.kazi.dashboard.model.request

import androidx.room.ColumnInfo
import androidx.room.Entity
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "%s")
data class BaselocationRequestModel(
    @ColumnInfo(name = "fseBaseLocation")
    @SerializedName("fseBaseLocation")
    var fseBaseLocation: FseBaseLocation?,
    @ColumnInfo(name = "hasBaseLocation")
    @SerializedName("hasBaseLocation")
    var hasBaseLocation: Boolean = false // true
) : Parcelable {
    @Parcelize
    @Entity(tableName = "%s")
    data class FseBaseLocation(
        @ColumnInfo(name = "angazaId")
        @SerializedName("angazaId")
        var angazaId: String?, // US043632
        @ColumnInfo(name = "latitude")
        @SerializedName("latitude")
        var latitude: Double?, // 33.01
        @ColumnInfo(name = "longitude")
        @SerializedName("longitude")
        var longitude: Double?, // 23.02
        @ColumnInfo(name = "country")
        @SerializedName("country")
        var country: String?, // 23.02
        @ColumnInfo(name = "accuracy")
        @SerializedName("accuracy")
        var accuracy: Double? // 23.02

    ) : Parcelable
}
