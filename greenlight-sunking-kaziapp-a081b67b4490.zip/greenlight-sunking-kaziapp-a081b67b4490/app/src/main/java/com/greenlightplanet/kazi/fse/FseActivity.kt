package com.greenlightplanet.kazi.fse

import android.os.Bundle
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivityFseBinding
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener


class FseActivity : BaseActivity() {

    private lateinit var binding: ActivityFseBinding

    companion object {
        public const val TAG = "FseActivity"
    }

    var mHomeWatcher: HomeWatcher? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContentView(R.layout.activity_fse)
        binding = ActivityFseBinding.inflate(layoutInflater)
        setContentView(binding.root)

        /*supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)*/

        Util.setToolbar(toolbar = binding.toolbar, context = this)

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }


    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();

    }
}
