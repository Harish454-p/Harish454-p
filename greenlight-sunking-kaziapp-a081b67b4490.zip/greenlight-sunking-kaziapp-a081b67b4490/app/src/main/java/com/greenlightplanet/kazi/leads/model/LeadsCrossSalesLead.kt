package com.greenlightplanet.kazi.leads.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.greenlightplanet.kazi.leads.typeconverter.LeadsCallDetailConverter
import com.greenlightplanet.kazi.leads.typeconverter.StringConverter
import kotlinx.android.parcel.Parcelize

@Parcelize
@TypeConverters(LeadsCallDetailConverter::class, StringConverter::class)
@Entity(tableName = "LeadsCrossSalesLead")
data class LeadsCrossSalesLead(
        @PrimaryKey
        @ColumnInfo(name = "accountNumber")
        @SerializedName("accountNumber")
        var accountNumber: String, // 45592805
        @ColumnInfo(name = "attempt")
        @SerializedName("attempt")
        var attempt: Int?, // 0
        @ColumnInfo(name = "callDetails")
        @SerializedName("callDetails")
        var callDetails: MutableList<LeadsCallDetail?>?,
        @ColumnInfo(name = "country")
        @SerializedName("country")
        var country: String?, // Kenya
        @ColumnInfo(name = "createdDate")
        @SerializedName("createdDate")
        var createdDate: String?, // 29-07-2019
        @ColumnInfo(name = "customerAddress")
        @SerializedName("customerAddress")
        var customerAddress: String?,
        @ColumnInfo(name = "customerName")
        @SerializedName("customerName")
        var customerName: String?, // Mary Adhiambo Ochieng
        @ColumnInfo(name = "id")
        @SerializedName("id")
        var id: Int?, // 3108
        @ColumnInfo(name = "interestedIn")
        @SerializedName("interestedIn")
        var interestedIn: String?, // home_tv_upgrade
        @ColumnInfo(name = "previousProductName")
        @SerializedName("previousProductName")
        var previousProductName: String?, // Home 60 + Radio
        @ColumnInfo(name = "primaryPhoneNumber")
        @SerializedName("primaryPhoneNumber")
        var primaryPhoneNumber: String?, // +254717173781
        @ColumnInfo(name = "productUnlockDate")
        @SerializedName("productUnlockDate")
        var productUnlockDate: String?, // 09-06-2019
        @ColumnInfo(name = "promiseDate")
        @SerializedName("promiseDate")
        var promiseDate: String?, // 30-07-2019

        @ColumnInfo(name = "expiryDate")
        @SerializedName("expiryDate")
        var expiryDate: String?, // 30-07-2019

        @ColumnInfo(name = "responsibleUserAngazaId")
        @SerializedName("responsibleUserAngazaId")
        var responsibleUserAngazaId: String?, // US029268
        @ColumnInfo(name = "secondaryPhoneNumber")
        @SerializedName("secondaryPhoneNumber")
        var secondaryPhoneNumber: String?, // +254717173781
        @ColumnInfo(name = "source")
        @SerializedName("source")
        var source: String?, // ZAPIER
        @ColumnInfo(name = "status")
        @SerializedName("status")
        var status: String?, // REASSIGNED

        @ColumnInfo(name = "preUpgradeAngazaId")
        @SerializedName("preUpgradeAngazaId")
        var preUpgradeAngazaId: String?, //

        @SerializedName("alternateContacts")
        @ColumnInfo(name = "alternateContacts")
        var alternateContacts: List<String?>? = null,

        @ColumnInfo(name = "latitude")
        @SerializedName("latitude")
        var latitude: Double?, //

        @ColumnInfo(name = "longitude")
        @SerializedName("longitude")
        var longitude: Double?, //

        @ColumnInfo(name = "leadFollowupLimit")
        @SerializedName("leadFollowupLimit")
        var leadFollowupLimit: String?, //

        @ColumnInfo(name = "ageAtUnlock")
        @SerializedName("ageAtUnlock")
        var ageAtUnlock: String? //


) : Parcelable
//700504417