package com.greenlightplanet.kazi.agentReferral.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.greenlightplanet.kazi.agentReferral.model.referralStatus.Referral
import io.reactivex.Single

@Dao
interface ReferralStatusDao {
    @Query("SELECT * FROM Referral")
    fun getAgentReferral() : Single<List<Referral>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAgentReferral(referral : Referral)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAllAgentReferral(referral : List<Referral>)

    @Query("DELETE FROM Referral")
    fun deleteAllAgentReferral() : Int

    @Query("SELECT * FROM Referral WHERE child_phone_number = :childPhone")
    fun getAllSelectedChild(childPhone : String) : Single<List<Referral>>
}