package com.greenlightplanet.kazi.incentivenew.dao.converter.incentive

import android.accounts.Account
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.incentivenew.model.incentive.Accounts
import com.greenlightplanet.kazi.incentivenew.model.summary.CheckListFields
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryFields
import com.greenlightplanet.kazi.pricegroup.model.Pricing_group

class AccountConverter {

    @TypeConverter
    fun fromAccountList(list: List<Accounts>?): String? {
        if (list == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<Accounts>>() {

        }.type
        return gson.toJson(list, type)
    }

    @TypeConverter
    fun toAccountList(string: String?): List<Accounts>? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<Accounts>>() {

        }.type
        return gson.fromJson(string, type)
    }

}


