package com.greenlightplanet.kazi.loyalty.adapter.profile

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.appcompat.widget.AppCompatImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.RecycledViewPool
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYou
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYouListener
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentProfileParentItemBinding
import com.greenlightplanet.kazi.loyalty.model.profile.EligibleEvents
import com.greenlightplanet.kazi.loyalty.model.profile.ProfileResponse
import com.greenlightplanet.kazi.loyalty.model.profile.ProfileType
import com.squareup.picasso.Picasso
import com.warkiz.widget.IndicatorSeekBar


/**
 * Created by Rahul on 06/04/21.
 */


class ProfileParentItemAdapter internal constructor(
    var parentdata: ProfileResponse,
    val child: List<EligibleEvents>?,
    val context: Context
) : RecyclerView.Adapter<ProfileParentItemAdapter.ParentViewHolder?>() {
    // An object of RecyclerView.RecycledViewPool
    // is created to share the Views
    // between the child and
    // the parent RecyclerViews
    private val viewPool = RecycledViewPool()
    //  private val itemList: List<ProfileCombineResponseModel>

    public var onClickItem: OnClickItem? = null

    override fun onCreateViewHolder(
        viewGroup: ViewGroup,
        i: Int
    ): ParentViewHolder {

        // Here we inflate the corresponding
        // layout of the parent item
        val itemBinding = FragmentProfileParentItemBinding.inflate(LayoutInflater
            .from(viewGroup.context)
            ,
                viewGroup, false
            )
        return ParentViewHolder(itemBinding)
    }

    override fun onBindViewHolder(
        parentViewHolder: ParentViewHolder,
        position: Int
    ) {

        // Create an instance of the ParentItem
        // class for the given position
        val parentItem = parentdata.types.get(position)

    parentViewHolder.bind(parentItem)
    }

    // This method returns the number
    // of items we have added in the
    // ParentItemList i.e. the number
    // of instances we have created
    // of the ParentItemList
    override fun getItemCount(): Int {
        return parentdata.types.size
    }

    // This class is to initialize
    // the Views present in
    // the parent RecyclerView
    inner class ParentViewHolder(val itemBinding:  FragmentProfileParentItemBinding) : RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(parentItem: ProfileType) {
            // For the created instance,
            // get the title and set it
            // as the text for the TextView
            itemBinding.parentItemTitle.text = parentItem.name

            //Picasso.get().load(parentItem?.icon_url).into(parentViewHolder.eventImage)


            if (parentItem.icon_url?.contains(".svg") == true) {
                GlideToVectorYou
                    .init()
                    .with(context)
                    .withListener(object : GlideToVectorYouListener {
                        override fun onLoadFailed() {

                        }

                        override fun onResourceReady() {
                        }
                    })
                    .load(Uri.parse(parentItem.icon_url), itemBinding.eventImage);
            } else {

                Picasso.get().load(parentItem.icon_url)
                    .into(itemBinding.eventImage)
            }


            parentItem.eligible_events?.toFloat()?.let { itemBinding.incentiveSlider.max = it };

            parentItem.eligible_events?.let { itemBinding.tvmaxProgreesId.text = it.toString() };

            parentItem.achieved_events?.toFloat()
                ?.let { itemBinding.incentiveSlider.setProgress(it) };
            itemBinding.incentiveSlider.setUserSeekAble(false)

            /*  if (parentItem.eligible_events == parentItem.achieved_events?.toInt()){
                  parentViewHolder.tvmaxProgreesId.visibility=View.GONE
              }else{
                  parentViewHolder.tvmaxProgreesId.visibility=View.VISIBLE
              }*/
            try {
                //  parentViewHolder.incentiveSlider.tickCount=1
            } catch (e: Exception) {
            }
            // parentViewHolder.incentiveSlider.hideThumb(true)
//parentViewHolder.incentiveSlider.min= parentItem.achieved_events?.toFloat()!!
            itemBinding.eventImage.setOnClickListener { onClickItem?.onTab(position, parentItem) }
            itemBinding.tvViewallId.setOnClickListener { onClickItem?.onTab(position, parentItem) }
            /* if (parentItem != null) {
                 for (data in parentItem){

                 }
             }*/

            // Create a layout manager
            // to assign a layout
            // to the RecyclerView.

            // Here we have assigned the layout
            // as LinearLayout with vertical orientation


            val eventCommonInChild = child?.map { it.type_id }?.contains(parentItem.id)

            if (eventCommonInChild!!) {
                val layoutManager = LinearLayoutManager(
                    itemBinding.childRecyclerview.context,
                    LinearLayoutManager.HORIZONTAL, false
                )
                // Since this is a nested layout, so
                // to define how many child items
                // should be prefetched when the
                // child RecyclerView is nested
                // inside the parent RecyclerView,
                // we use the following method
                layoutManager.initialPrefetchItemCount = child?.size ?: 0

                // Create an instance of the child
                // item view adapter and set its
                // adapter, layout manager and RecyclerViewPool
                val childItemAdapter =
                    ProfileChildItemAdapter(child?.filter { it.type_id == parentItem.id }
                        ?.distinctBy { it.event_id }, context)
                itemBinding.childRecyclerview.layoutManager = layoutManager
                itemBinding.childRecyclerview.adapter = childItemAdapter
                itemBinding.childRecyclerview.setRecycledViewPool(viewPool)
            }
        }

    }

    init {
        this.parentdata = parentdata
    }


    interface OnClickItem {
        fun onTab(position: Int, profileType: ProfileType)

    }
}
