package com.greenlightplanet.kazi.collectiongoal.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.collectiongoal.model.pastweekincentive.LastWeekIncentiveModel
import com.greenlightplanet.kazi.collectiongoal.repo.SummaryNewRepository
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.utils.Util

class CommonWeekIncentiveViewmodel(application: Application) : AndroidViewModel(application) {


    val repo = SummaryNewRepository.getInstance(application)

    val previousWeekIncentiveData = repo.previousWeekIncentiveData

    var achievedListData = MutableLiveData<MutableList<LastWeekIncentiveModel.AchievedAccount>>()

    var achievedListDataSend: LiveData<MutableList<LastWeekIncentiveModel.AchievedAccount>> = achievedListData

    var notAchievedListData = MutableLiveData<MutableList<LastWeekIncentiveModel.AchievedAccount>>()

    var notAchievedListDataSend: LiveData<MutableList<LastWeekIncentiveModel.AchievedAccount>> = notAchievedListData

    fun updateAchievedFragment(data: MutableList<LastWeekIncentiveModel.AchievedAccount>){
        achievedListData.value = data
    }

    fun updateNotAchievedFragment(data: MutableList<LastWeekIncentiveModel.AchievedAccount>){
        notAchievedListData.value = data
    }


    fun getLWIncentiveFromServer(nextPage: Int):
            MutableLiveData<NewCommonResponseModel<LastWeekIncentiveModel>>{

        if (Util.isOnline(getApplication())){
            return repo.getLWIncentiveFromServer(nextPage)
        }else {
            return repo.getLWIncentiveFromDB(nextPage)
        }

    }

    fun getLWIncentiveFromServer1(previousWeekNextPage: Int):
            MutableLiveData<NewCommonResponseModel<LastWeekIncentiveModel>> {
        return repo.getLWIncentiveFromServer1(previousWeekNextPage)
    }


    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }

    fun getAchievedTabList(
        list: List<LastWeekIncentiveModel.AchievedAccount>,
        search: Boolean = true,
        searchQuery: String = ""
    ): List<LastWeekIncentiveModel.AchievedAccount> {

        return if (search) {
            list.filter {
                it.status && it.customerName?.contains(
                    searchQuery,
                    true
                )!!
            }
        } else {
            list.filter { (it.status == true) }
        }

    }


    fun getNotAchievedTabList(
        list: List<LastWeekIncentiveModel.AchievedAccount>,
        search: Boolean = false,
        searchQuery: String = ""
    ): List<LastWeekIncentiveModel.AchievedAccount> {

        return if (search) {
            list.filter {
                !it.status && it.customerName?.contains(
                    searchQuery,
                    true
                )!!
            }
        } else {
            list.filter { (it.status == false) }
        }
    }

}