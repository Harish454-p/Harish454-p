package com.greenlightplanet.kazi.leads.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.liteFseProspective.extras.ErrorUtils
import com.greenlightplanet.kazi.leads.model.LeadsIntent
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class CustomerLeadsFeedbackRepo(val context: Context) {

    companion object : SingletonHolderUtil<CustomerLeadsFeedbackRepo, Context>(::CustomerLeadsFeedbackRepo) {
        public const val TAG = "CustomerLeadsFeedbackR"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    var gson: Gson? = null


    init {
        try {

            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context)
            gson = Gson()

        } catch (e: Exception) {
            Log.d(TAG, "Init:Error ");
        }
    }


    fun getLeadsIntentFromDb(): MutableLiveData<List<LeadsIntent>> {

        val data = MutableLiveData<List<LeadsIntent>>()

        bag.add(
                localDb?.leadsIntentDao()?.getAll()!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            Log.d(TAG, "getLeadsIntentFromDb - success: ${success}")
                            data.postValue(success)

                        }, { t ->
                            ErrorUtils.errorDatabase(t, TAG, "getLeadsIntentFromDb", "Unable to get data from server", data)
                        })
        )
        return data
    }


    fun destroy() {

        Log.d(TAG, "Repo : destroy");
        bag.clear()
    }

}
