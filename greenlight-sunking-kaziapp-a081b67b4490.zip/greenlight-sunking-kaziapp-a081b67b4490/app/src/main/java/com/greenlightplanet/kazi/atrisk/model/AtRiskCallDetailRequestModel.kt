package com.greenlightplanet.kazi.atrisk.model

import androidx.room.*
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


@Parcelize
@Entity(tableName = "AtRiskCallDetailRequestModel", primaryKeys = arrayOf("accountNumber","calledTime"))
data class AtRiskCallDetailRequestModel(
        @ColumnInfo(name = "accountNumber")
        @SerializedName("accountNumber")
        var accountNumber: Int=0,  // 123459
        @ColumnInfo(name = "attempt")
        @SerializedName("attempt")
        var attempt: Int? = null,  // 0
        @ColumnInfo(name = "callDuration")
        @SerializedName("callDuration")
        var callDuration: Int = 0,  // 56
        @ColumnInfo(name = "calledTime")
        @SerializedName("calledTime")
        var calledTime: String = "",  // 2019-12-01 12:43:39
        @ColumnInfo(name = "contactedNumber")
        @SerializedName("contactedNumber")
        var contactedNumber: String? = null,  // +191e80840385
        @ColumnInfo(name = "imei")
        @SerializedName("imei")
        var imei: String? = null,  // 4273947237498237
        @ColumnInfo(name = "intentId")
        @SerializedName("intentId")
        var intentId: Int? = null,  // 1
        @ColumnInfo(name = "feedbackId")
        @SerializedName("feedbackId")
        var feedbackId: Int? = null,  // 1
        @ColumnInfo(name = "feedbackCode")
        @SerializedName("feedbackCode")
        var feedbackCode: String? = null,
        @ColumnInfo(name = "newVisitDate")
        @SerializedName("newVisitDate")
        var newVisitDate: String? = null,  // 2019-12-01
        @ColumnInfo(name = "otherReason")
        @SerializedName("otherReason")
        var otherReason: String? = null // *Koi bhi reason
) : Parcelable