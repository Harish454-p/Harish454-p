package com.greenlightplanet.kazi.agentReferral.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.greenlightplanet.kazi.agentReferral.model.referralStatus.Referral
import com.greenlightplanet.kazi.agentReferral.model.referralStatusDetail.ReferralDetail
import com.greenlightplanet.kazi.agentReferral.model.referralStatusDetail.ReferralStatusDetailModel
import com.greenlightplanet.kazi.agentReferral.repo.AgentReferralRepo
import com.greenlightplanet.kazi.networking.NewCommonResponseModel

class ReferralStatusDetailViewModel(application: Application) : AndroidViewModel(application) {

    fun prepData(responseData: ReferralStatusDetailModel) {
        responseData.let {
            statusDetails.addAll(ArrayList(responseData.referralDetails!!))
            obsStatusDetails.postValue(statusDetails)
        }
    }

    fun fetchReferralDetail(status : Referral?, isOnline: Boolean) : MutableLiveData<NewCommonResponseModel<ReferralStatusDetailModel>>{
        statusDetails.clear()
        status?.let { stat ->
            obsChildPhone.postValue(stat.childPhoneNumber)
            obsParentPhone.postValue(stat.parentPhoneNumber)
            obsParentRole.postValue(stat.parentRole)
        }
        return when(isOnline) {
            true -> repo.getStatusDetails(
                statusId = status?.id!!,
                childPhone = status.childPhoneNumber!!
            )
            false -> repo.getReferralStatusDetailsSelected(
                statusId = status?.id!!
            )
        }
    }

    private val TAG : String = "ReferralStatusDetailViewModel"
    private val repo : AgentReferralRepo = AgentReferralRepo(context = application.applicationContext)
    private var statusDetails : ArrayList<ReferralDetail> = ArrayList()

    var obsChildPhone : MutableLiveData<String> = MutableLiveData()
    var obsParentPhone : MutableLiveData<String> = MutableLiveData()
    var obsParentRole : MutableLiveData<String> = MutableLiveData()
    var obsStatusDetails : MutableLiveData<ArrayList<ReferralDetail>> = MutableLiveData()


}