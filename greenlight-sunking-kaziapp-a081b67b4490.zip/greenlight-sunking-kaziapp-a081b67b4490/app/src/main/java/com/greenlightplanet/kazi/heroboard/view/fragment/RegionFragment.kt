package com.greenlightplanet.kazi.heroboard.view.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.FragmentRegionBinding
import com.greenlightplanet.kazi.heroboard.extras.LeaderBoardUtil
import com.greenlightplanet.kazi.heroboard.model.LeaderboardModel
import com.greenlightplanet.kazi.heroboard.view.adapter.HeroRecylerAdapter
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util

class RegionFragment : Fragment() {

    private var _binding:FragmentRegionBinding?=null
    private val binding get() = _binding!!

    var heroRecylerAdapter: HeroRecylerAdapter? = null
    var adapterList: MutableList<LeaderboardModel> = mutableListOf()
    private var list: MutableList<LeaderboardModel>? = mutableListOf()
    var Toplist: List<LeaderboardModel> = mutableListOf()
    var rootView: View? = null

    var loginResponseData: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    var eoThere: Boolean = false


    companion object {

        const val TAG = "VerificationFragment"

        fun newInstance(
                list: List<LeaderboardModel>?
        ): RegionFragment {
            val myFragment = RegionFragment()

            val args = Bundle()
            args.putParcelableArrayList("list", ArrayList(list!!))
            myFragment.arguments = args

            return myFragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            if (it.containsKey("list")) {
                list = it.getParcelableArrayList("list")
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        _binding = FragmentRegionBinding.inflate(inflater, container, false)
        val layoutManager = LinearLayoutManager(requireActivity())
        preference = GreenLightPreference.getInstance(requireActivity())
        loginResponseData = preference?.getLoginResponseModel()
        binding!!.regionRecycler.layoutManager = layoutManager

        binding!!.infoDialog.setOnClickListener {

            Util.customFseRationaleDialog(requireActivity(), getString(R.string.top_sales_hero),
                    titleSpanned = null,
                    hideNegative = true,
                    message = getString(R.string.agent_with_top_sales),
                    positveSelected = {
                        it.dismiss()
                    },
                    negativeSeleted = {
                        it.dismiss()
                    }
            )
        }

        setAdapter(list!!)
        Toplist = list!!.toMutableList()
        Toplist = Toplist.toMutableList().sortedBy { it.salesRank }
        Toplist = Toplist.take(3).toMutableList()

        Log.e("|| Reg=Toplist= ", Toplist.toString())
        SetHeroFlags(Toplist)
        return binding.root
    }

    fun setAdapter(mutableList: MutableList<LeaderboardModel>) {
        adapterList.clear()
        adapterList.addAll(mutableList)

        adapterList = adapterList.sortedBy { it.salesRank }.toMutableList()

        val ussEO = adapterList.find { it.eoAngazaId == loginResponseData!!.angazaId }

        if (ussEO != null) {
            eoThere = true
        }

        if (heroRecylerAdapter == null) {
            Log.e("|| Reg=inadapter=${adapterList.size}=${ussEO}=", adapterList.toString())
            heroRecylerAdapter = HeroRecylerAdapter(requireActivity(), adapterList, true, eoThere)
            binding.regionRecycler.adapter = heroRecylerAdapter
        }
        heroRecylerAdapter?.notifyDataSetChanged()
    }

    fun SetHeroFlags(tList: List<LeaderboardModel>) {

        if (tList != null) {
            if (tList.size > 0) {
                binding.tvRegionNoData.visibility = View.GONE
                binding!!.regionRecycler.visibility = View.VISIBLE
                //First
                Glide.with(this)
                        .load(tList.get(0).imageUrl)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .error(R.drawable.no_image)
                        .into(binding!!.image1st)

                binding!!.image1stName.text = tList.get(0).eoName
                binding!!.image1st.setOnClickListener {
                    //            ImagePopWindow(context, rootView, tList.get(0).imageUrl,null)
                    LeaderBoardUtil.CustomLeaderImageDialog(requireActivity()!!, tList.get(0).imageUrl!!)
                }

                //Second
                if (tList.size > 1) {
                    Glide.with(this)
                            .load(tList.get(1).imageUrl)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .error(R.drawable.no_image)
                            .into(binding!!.image2nd)

                    binding!!.image2ndName.text = tList.get(1).eoName
                    binding!!.image2nd.setOnClickListener {
                        //            ImagePopWindow(context, rootView, tList.get(1).imageUrl,null)
                        LeaderBoardUtil.CustomLeaderImageDialog(requireActivity()!!, tList.get(1).imageUrl!!)
                    }
                }
                //Third
                if (tList.size > 2) {
                    Glide.with(this)
                            .load(tList.get(2).imageUrl)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .error(R.drawable.no_image)
                            .into(binding!!.image3rd)

                    binding!!.image3rdName.text = tList.get(2).eoName
                    binding!!.image3rd.setOnClickListener {
                        LeaderBoardUtil.CustomLeaderImageDialog(requireActivity()!!, tList.get(2).imageUrl!!)
                    }
                }
            } else {
                binding!!.tvRegionNoData.visibility = View.VISIBLE
                binding!!.regionRecycler.visibility = View.GONE
//                Toast.makeText(activity,"Size not match" ,Toast.LENGTH_SHORT).show()
            }
        }

    }

}
