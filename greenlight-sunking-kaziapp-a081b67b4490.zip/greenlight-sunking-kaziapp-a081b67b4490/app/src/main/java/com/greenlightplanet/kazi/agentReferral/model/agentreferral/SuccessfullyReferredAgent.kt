package com.greenlightplanet.kazi.agentReferral.model.agentreferral


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class SuccessfullyReferredAgent(
    @SerializedName("agent_name")
    var agentName: String?,
    @SerializedName("angaza_id")
    var angazaId: String?,
    @SerializedName("mtd_sales")
    var mtdSales: Int?,
    @SerializedName("registered_date")
    var registeredDate: String?,
    @SerializedName("registered_date_timestamp")
    var registeredDateTimestamp: String?
) : Parcelable