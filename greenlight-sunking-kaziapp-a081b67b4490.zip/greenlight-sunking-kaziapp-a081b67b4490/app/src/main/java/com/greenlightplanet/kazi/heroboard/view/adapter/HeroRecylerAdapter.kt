package com.greenlightplanet.kazi.heroboard.view.adapter

import android.app.Activity
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.HeroRecyclerItemViewBinding
import com.greenlightplanet.kazi.heroboard.model.LeaderboardModel
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import org.jetbrains.annotations.NotNull
import java.util.*

class HeroRecylerAdapter(val context: Activity, var list: List<LeaderboardModel>, areahai: Boolean = false, EoThere: Boolean = false) : RecyclerView.Adapter<HeroRecylerAdapter.ViewHolder>() {
    var Filterlist: MutableList<LeaderboardModel>? = mutableListOf()
    //var EOFillist: MutableList<LeaderboardModel>? = mutableListOf()
    var area: Boolean = false
    var loginResponseData: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    var eoThere: Boolean

    val TAG = "HeroRecylerAdapter"

    init {
        preference = GreenLightPreference.getInstance(context)
        loginResponseData = preference?.getLoginResponseModel()
        val user = LeaderboardModel(loginResponseData!!.angazaId!!, loginResponseData!!.firstName!!,
                "", "", "", "", "", "", 0.0, 0)
        //EOFillist!!.clear()
        Filterlist!!.clear()
        Filterlist = list.toMutableList()
        //EOFillist = list.toMutableList()
        this.area = areahai
        eoThere = EoThere



        for (i in list.indices) {

            if (eoThere) {
                if (list.get(i).eoAngazaId == loginResponseData!!.angazaId!!) {
                    list.get(i).eoName?.let { Log.e("||!!!! $i= ", it) }
                    list.toMutableList().add(0, list.get(i))
                    /*just comment below line to show eo once in the list*/
                    Filterlist!!.remove(list.get(i))
                    Filterlist!!.add(0, list.get(i))
                }
            } else {

                if (i == 0) {
                    list.toMutableList().add(0, user)
                    Filterlist!!.add(0, user)
                } else {
                    Filterlist!!.set(i, list.get(i - 1))
                }
            }
        }


//Earlier used
        /*for (i in list.indices) {
            if (list.get(i).eoAngazaId == loginResponseData!!.angazaId!!) {
                Log.e("||!!!! $i= ", list.get(i).eoName)
                list.toMutableList().add(0, list.get(i))
                Filterlist!!.remove(list.get(i))
                Filterlist!!.add(0, list.get(i))
            }*/
    }

    override fun onCreateViewHolder(@NotNull parent: ViewGroup, viewType: Int): ViewHolder {

        val itemBinding = HeroRecyclerItemViewBinding.inflate(
            LayoutInflater.from(parent.context) ,parent, false)

        return ViewHolder(itemBinding)

    }

    @OptIn(ExperimentalStdlibApi::class)
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val data = Filterlist!!.get(position)
//        if (position == 0 && data.eoAngazaId == loginResponseData!!.angazaId!!) {
holder.bind(data)
    }


    inner class ViewHolder(val itemBinding: HeroRecyclerItemViewBinding) :
        RecyclerView.ViewHolder(itemBinding.root){
        fun bind(data: LeaderboardModel) {


            if (position == 0) {
                itemBinding.mainBg.background =
                    ContextCompat.getDrawable(context, R.drawable.bg_hero_board)
            } else {
                itemBinding.mainBg.background = ContextCompat.getDrawable(context, R.color.colorWhite)
            }

            if (area) {
                itemBinding.area.visibility = View.VISIBLE
                itemBinding.area.text = data.area!!.toLowerCase(Locale.US).capitalize()
//            holder.area.text = data.area!!.capitalize(Locale.US)
            } else {
                itemBinding.area.visibility = View.GONE
            }
            if (data.sales == 0.0) {
                itemBinding.sales.text = "NA"
            } else {
                itemBinding.sales.text = data.sales.toString()
            }

            if (data.salesRank == 0 || data.salesRank == null) {
                itemBinding.rank.text = ""
                itemBinding.revrank.setBackgroundResource(R.drawable.exclamation_mark)
                itemBinding.revrank.setOnClickListener {
                    Util.customFseRationaleDialog(context, "",
                        hideNegative = true,
                        titleSpanned = null,
                        hideTitle = true,
                        message = context.getString(R.string.either_collection_score_criteria_not_met_or_sales_not_done),
                        positveSelected = {
                            it.dismiss()
                        },
                        negativeSeleted = {
                            it.dismiss()
                        }
                    )
                }
            } else {
                itemBinding.rank.text = data.salesRank.toString()
                itemBinding.revrank.setBackgroundResource(R.drawable.bg_rank)
            }

            itemBinding.name.text = data.eoName
        }
    }

    override fun getItemCount(): Int {
        return Filterlist!!.size
    }

}
