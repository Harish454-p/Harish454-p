package com.greenlightplanet.kazi.agentReferral.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.greenlightplanet.kazi.agentReferral.repo.AgentReferralRepo
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.model.submitAgent.ResponseData
import com.greenlightplanet.kazi.agentReferral.ui.view.ReferNewAgentActivity
import com.greenlightplanet.kazi.utils.Util


class ReferNewAgentViewModel(application: Application) : AndroidViewModel(application) {
    private val TAG : String = "ReferNewAgentViewModel"
    private val repository : AgentReferralRepo = AgentReferralRepo(context = application.applicationContext)
    var obsResponseSms : MutableLiveData<ResponseData> = MutableLiveData()
    var obsErrorResponse : MutableLiveData<String> = MutableLiveData()

    fun submitAgent(
        phoneNumber: String?,
        name : String?,
        referNewAgentActivity: ReferNewAgentActivity,
        countryCode: String
    ){
        Log.e(TAG,"found child info as >$phoneNumber<, >$countryCode<, >$name<")
        when(
            validatePhone(
                name = name,
                phoneNumber = phoneNumber,
                countryCode = countryCode
            )
        ) {
            true -> {
                when(Util.isOnline(context = referNewAgentActivity)) {
                    true -> {
                        repository.submitNewAgentRequest(
                            phoneNumber = phoneNumber,
                            name = name,
                            countryCode = countryCode
                        ).observe(referNewAgentActivity, Observer { response ->
                            when(response) {
                                null -> {
                                    Util.customFseRationaleDialog(
                                        context = referNewAgentActivity,
                                        title = "",
                                        hideNegative = true,
                                        titleSpanned = null,
                                        hideTitle = true,
                                        message = referNewAgentActivity.getString(R.string.no_data),
                                        positveSelected = {
                                            it.dismiss()
                                        },
                                        negativeSeleted = {
                                            it.dismiss()
                                        }
                                    )
                                    referNewAgentActivity.cancelProgressDialog()
                                }
                                else -> {
                                    when (response.success) {
                                        true -> {
                                            response.responseData?.let { newAgentResponseModel ->
                                                when(newAgentResponseModel.success) {
                                                    true -> {
                                                        newAgentResponseModel.responseData?.let { responseData ->
                                                            obsResponseSms.postValue(responseData)
                                                        }
                                                    }
                                                    null,
                                                    false -> {
                                                        newAgentResponseModel.responseData?.let {
                                                            obsErrorResponse.postValue(it.errorMessage)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        false -> {
                                            referNewAgentActivity.cancelProgressDialog()
                                            Util.customFseRationaleDialog(
                                                context = referNewAgentActivity,
                                                title = "",
                                                hideNegative = true,
                                                titleSpanned = null,
                                                hideTitle = true,
                                                message = referNewAgentActivity.getString(R.string.no_data),
                                                positveSelected = {
                                                    it.dismiss()
                                                },
                                                negativeSeleted = {
                                                    it.dismiss()
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        })
                    }
                    false -> {
                        referNewAgentActivity.cancelProgressDialog()
                        Util.customFseRationaleDialog(
                            context = referNewAgentActivity,
                            title = "",
                            hideNegative = true,
                            titleSpanned = null,
                            hideTitle = true,
                            message = referNewAgentActivity.getString(R.string.no_internet_connection),
                            positveSelected = {
                                it.dismiss()
                            },
                            negativeSeleted = {
                                it.dismiss()
                            }
                        )
                    }
                }
            }
            false -> {
                referNewAgentActivity.cancelProgressDialog()
                Util.customFseRationaleDialog(
                    context = referNewAgentActivity,
                    title = "",
                    hideNegative = true,
                    titleSpanned = null,
                    hideTitle = true,
                    message = "please enter valid details",
                    positveSelected = {
                        it.dismiss()
                    },
                    negativeSeleted = {
                        it.dismiss()
                    }
                )
            }
        }
    }

    private fun validatePhone(
        phoneNumber: String?,
        name : String?,
        countryCode: String
    ): Boolean {
//        val mobileLength = getMobileLength(countryCode)
        return when {
            phoneNumber.isNullOrBlank() || phoneNumber.isNullOrEmpty() -> false
            /*phoneNumber.length == 10 -> {
                when {
                    name.isNullOrEmpty() || name.isNullOrBlank() -> false
                    else -> true
                }
            }
            phoneNumber.length < 10 -> false
            phoneNumber.length > 10 -> false*/
            else -> true
        }
    }
}