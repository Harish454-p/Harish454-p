package com.greenlightplanet.kazi.leads.view.activity

import android.app.Activity
import android.app.Dialog
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Parcelable
import com.google.android.material.tabs.TabLayout
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.viewpager.widget.ViewPager
import androidx.appcompat.app.AlertDialog
import android.util.Log
import android.view.*
import android.widget.*
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivityCustomerLeadsBinding
import com.greenlightplanet.kazi.databinding.LeadsFilterDialogBinding
import com.greenlightplanet.kazi.leads.extras.LEAD_STATUS
import com.greenlightplanet.kazi.leads.extras.LEAD_TAB
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead
import com.greenlightplanet.kazi.leads.model.LeadsResponseModel
import com.greenlightplanet.kazi.leads.view.adapter.CustomerLeadsPagerAdapter
import com.greenlightplanet.kazi.leads.view.fragment.CustomerLeadsFragment
import com.greenlightplanet.kazi.leads.view.fragment.LeadsButtomSheetSearch
import com.greenlightplanet.kazi.leads.viewmodel.CustomerLeadsViewModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import java.util.*
import kotlin.math.round


class CustomerLeadsActivity : BaseActivity(), CustomerLeadsFragment.CustomerLeadsFragmentCallback,
    LeadsButtomSheetSearch.LeadsButtomSheetSearchCallback {

    public val TAG = "CustomerLeadsActivity"
    private lateinit var binding: ActivityCustomerLeadsBinding

    var _itemBinding: LeadsFilterDialogBinding? = null
    val itemBinding get() = _itemBinding!!

    lateinit var viewModel: CustomerLeadsViewModel
    var viewpagerAdapterList = mutableListOf<LeadsCrossSalesLead>()
    var viewPagerPagerAdapter: CustomerLeadsPagerAdapter? = null
    var leadsResponseModel: LeadsResponseModel? = null
    private var pendingbadgeTextView: TextView? = null
    private var calledbadgeTextView: TextView? = null
    private var productList: MutableList<String>? = null
    private var selectedFilterPosition = 0
    private var selectedProductName = ""
    var mHomeWatcher: HomeWatcher? = null
    var mSpinnerInitialized = false


    var SELECT_PRODUCT = "Select Product"
    var SELECT_Source = "Select Source"
    var product_spinner: Spinner? = null
    var source_spinner: Spinner? = null


    var adapter: ArrayAdapter<String>? = null
    var adapter_source: ArrayAdapter<String>? = null


    private var sourceList: MutableList<String>? = null
    private var leadCroseMutalbList: MutableList<LeadsCrossSalesLead>? = mutableListOf()
    private var selectedFilterSourcePosition = 0

    private var selectedSourceName = ""

    lateinit var localBroadcastManager: LocalBroadcastManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_customer_leads)
        binding = ActivityCustomerLeadsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        localBroadcastManager = LocalBroadcastManager.getInstance(this)
        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        viewModel = ViewModelProviders.of(this).get(CustomerLeadsViewModel::class.java)

        Util.setToolbar(this, binding.toolbar)

        initTabLayout()

        initSearchView()

        initialize()

        binding.ivFilter.setOnClickListener {
            //showFilterDialog()
            showDialog(this)
        }

//        mHomeWatcher = HomeWatcher(this)
//        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
//            override fun onHomePressed() {
//                finish()
//            }
//        })
//        mHomeWatcher!!.startWatch()
    }

    fun setMetrics(leadsResponseModel: LeadsResponseModel) {

        try {
            val totalConvert = leadsResponseModel.totalConverted ?: 0
            val dayspercent = leadsResponseModel.totalAssigned ?: 0
            binding.tvleadsConverted.text = "${totalConvert}/${dayspercent}"
            //  tvleadsConverted.text = "${leadsResponseModel.totalConverted}/${leadsResponseModel.totalAssigned}"
            if (leadsResponseModel.daysPercentageLeadsConverted != null) {
                val sss = leadsResponseModel.daysPercentageLeadsConverted!! * 100
                binding.tv30daysP.text = "${round(sss)}%"
            } else {
                binding.tv30daysP.text = "${round(0.0)}%"
            }
        } catch (e: Exception) {
            Log.e(TAG, "setMetrics: $e")
        }

    }

    fun showDialog(activity: Activity?) {


        dialog = Dialog(this!!)
        dialog!!.setCancelable(true)
        //dialog!!.setContentView(R.layout.leads_filter_dialog)
        _itemBinding = LeadsFilterDialogBinding.inflate(LayoutInflater.from(this))
        dialog?.setContentView(itemBinding.root)
        val size = Point()
        var width = 0
        var height = 0
        val w = windowManager

        w.defaultDisplay.getSize(size)
        width = size.x - 30
        height = size.y - 40

        dialog!!.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog!!.window!!.setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT)

        product_spinner = dialog!!.findViewById<View>(R.id.product_spinner) as Spinner
        source_spinner = dialog!!.findViewById<View>(R.id.source_spinner) as Spinner

        val btn_ok: Button = dialog!!.findViewById<View>(R.id.btn_ok) as Button
        val close: ImageView = dialog!!.findViewById<View>(R.id.close) as ImageView
        val clearFilter: Button = dialog!!.findViewById<View>(R.id.clearFilter) as Button
        close.setOnClickListener(View.OnClickListener { dialog!!.dismiss() })
        itemBinding!!.btnOk.setOnClickListener(View.OnClickListener {
            if (selectedFilterPosition > 0 || selectedFilterSourcePosition > 0) {
                binding.ivFilter.setColorFilter(Color.parseColor("#FFFF33"))
            }
            dialog!!.dismiss()
        })
        itemBinding.clearFilter.setOnClickListener(View.OnClickListener { it ->
            clearfilter()
            selectedFilterPosition = 0
            selectedFilterSourcePosition = 0
            dialog!!.dismiss()
        })

        val spinnerSelectionList = mutableListOf<String>()
        val spinnerSelectionListSource = mutableListOf<String>()

        productList?.map { spinnerSelectionList.add(it) }
        adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, spinnerSelectionList)
        adapter?.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        sourceList?.map { spinnerSelectionListSource.add(it) }
        adapter_source =
            ArrayAdapter(this, android.R.layout.simple_spinner_item, spinnerSelectionListSource)
        adapter_source?.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        setAdapterProduct()
        setAdapterSource()

        product_spinner!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View, which: Int, id: Long) {
                selectedProductName = productList!![which]
                if (productList.isNullOrEmpty()) {
                    Util.showToast("No Products Available", this@CustomerLeadsActivity)
                } else {
                    selectedFilterPosition = which
                    selectedProductName = productList!![which]
                    if (!mSpinnerInitialized) {
                        mSpinnerInitialized = true;
                        return;
                    }

                    val color: Int  //The color u want

                    if (which == 0) {

                        color = Color.parseColor("#FFFFFF")
                    } else {
                        selectedFilterSourcePosition = 0

                        color = Color.parseColor("#FFFF33") //The color u want
                    }
                    source_spinner!!.setSelection(selectedFilterSourcePosition)
                    setFilterLogic(productList!![which])
                    adapter_source!!.notifyDataSetChanged()
                    binding.ivFilter.setColorFilter(color)
                }


            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        source_spinner!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View, which: Int, id: Long) {

//				selectedSourceName = sourceList!![which]
                if (sourceList.isNullOrEmpty()) {
                    Util.showToast("No Products Available", this@CustomerLeadsActivity)
                } else {

                    selectedFilterSourcePosition = which
                    selectedSourceName = sourceList!![which]

                    val color: Int  //The color u want

                    if (which == 0) {
                        color = Color.parseColor("#FFFFFF")
                    } else {
                        selectedFilterPosition = 0
                        color = Color.parseColor("#FFFF33") //The color u want
                    }
                    product_spinner!!.setSelection(selectedFilterPosition)
                    setFilterLogicSource(sourceList!![which])
                    adapter!!.notifyDataSetChanged()
                    binding.ivFilter.setColorFilter(color)
                }


            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        dialog!!.show()
    }


    private fun setFilterLogicSource(source: String) {

        leadsResponseModel?.let { response ->


            var pendingList: List<LeadsCrossSalesLead>? = null
            var calledList: List<LeadsCrossSalesLead>? = null

            //  if (productName.equals(SELECT_PRODUCT) || productName.equals(SELECT_Source)) {
            if (selectedFilterPosition == 0 && selectedFilterSourcePosition == 0) {
                pendingList = viewModel.getPendingTabList(response.crossSalesLeads!!)
                calledList = viewModel.getCalledTabList(response.crossSalesLeads!!)

                pendingbadgeTextView?.text = "${pendingList?.size}"
                calledbadgeTextView?.text = "${calledList?.size}"
                sendBroadcastToFragment("search", pendingList!!, calledList!!)

            } else if (selectedFilterSourcePosition > 0) {
                pendingList =
                    viewModel.getPendingFilteredListSource(response.crossSalesLeads!!, source)
                calledList =
                    viewModel.getCalledTabFilteredListSource(response.crossSalesLeads!!, source)

                pendingbadgeTextView?.text = "${pendingList?.size}"
                calledbadgeTextView?.text = "${calledList?.size}"
                sendBroadcastToFragment("search", pendingList!!, calledList!!)

            }

        }

    }

    fun setAdapterProduct() {


        product_spinner!!.setAdapter(adapter)
        product_spinner!!.setSelection(selectedFilterPosition)


    }

    fun setAdapterSource() {

        source_spinner!!.adapter = adapter_source
        source_spinner!!.setSelection(selectedFilterSourcePosition)

    }

    fun clearfilter() {

        leadsResponseModel?.let { response ->

            var pendingList: List<LeadsCrossSalesLead>? = null
            var calledList: List<LeadsCrossSalesLead>? = null
            pendingList = viewModel.getPendingTabList(response.crossSalesLeads!!)
            calledList = viewModel.getCalledTabList(response.crossSalesLeads!!)

            pendingbadgeTextView?.text = "${pendingList?.size}"
            calledbadgeTextView?.text = "${calledList?.size}"
            sendBroadcastToFragment("search", pendingList!!, calledList!!)
            val color = Color.parseColor("#FFFFFF")
            binding.ivFilter.setColorFilter(color)

        }
    }

    private fun initTabLayout() {

        binding.tabLayout.addTab(
            binding.tabLayout.newTab().setText(getString(R.string.pending))
                .setCustomView(R.layout.custom_tab_layout), true
        )
        binding.tabLayout.addTab(
            binding.tabLayout.newTab().setText(getString(R.string.tbCalled))
                .setCustomView(R.layout.custom_tab_layout)
        )

        binding.tabLayout.tabGravity = TabLayout.GRAVITY_FILL

        //Get first tab view
        val pendingTab: TabLayout.Tab = binding.tabLayout!!.getTabAt(0)!!
        val pendingTabView: View = pendingTab.customView!!

        //first tab textview
        val pendingTabTextView = pendingTabView.findViewById<TextView>(R.id.text1)
        pendingTabTextView.text = /*LEAD_TAB.PENDING*/getString(R.string.pending)

        //first tab badge
        pendingbadgeTextView = pendingTabView.findViewById<TextView>(R.id.notBadge)
        pendingbadgeTextView?.visibility = View.VISIBLE
        pendingbadgeTextView?.text = "0"

        /******************************************************************************************/

        //Get second tab view
        val calledTab: TabLayout.Tab = binding.tabLayout!!.getTabAt(1)!!
        val calledTabView: View = calledTab.customView!!


        //second tab textview
        val calledTabTextView = calledTabView.findViewById<TextView>(R.id.text1)
        calledTabTextView.text = /*LEAD_TAB.CALLED*/getString(R.string.tbCalled)

        //second tab badge
        calledbadgeTextView = calledTabView.findViewById<TextView>(R.id.notBadge)
        calledbadgeTextView?.visibility = View.VISIBLE
        calledbadgeTextView?.text = "0"


        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                binding.viewpager.currentItem = tab.position
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}

            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        binding.viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {

            override fun onPageScrollStateChanged(p0: Int) {}

            override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {}

            override fun onPageSelected(p0: Int) {
                binding.tabLayout.getTabAt(p0)?.select()
            }
        })

    }

    private fun initSearchView() {
        binding.ivSearch.setOnClickListener {

            val leadsButtomSheetSearch: LeadsButtomSheetSearch =
                LeadsButtomSheetSearch.newInstance(viewpagerAdapterList)
            leadsButtomSheetSearch.leadsButtomSheetSearchCallback = this
            leadsButtomSheetSearch.show(
                supportFragmentManager,
                "leads_Buttom_Sheet_Search"
            )
        }

        val searchCloseButtonId: Int = binding.searchView.context.resources
            .getIdentifier("android:id/search_close_btn", null, null)
        val searchCloseButton: ImageView =
            this.binding.searchView.findViewById(searchCloseButtonId) as ImageView
        searchCloseButton.setOnClickListener {
            hideSearchView()
        }
    }

    private fun showSearchView() {
        binding.llSearchContainer.visibility = View.GONE
        binding.searchView.visibility = View.VISIBLE
        binding.searchView.isIconified = false
        binding.searchView.isFocusable = true
        binding.searchView.requestFocusFromTouch();

        binding.llMatric1.visibility = View.GONE
        binding.llMatric2.visibility = View.GONE

    }

    private fun hideSearchView() {
        binding.llSearchContainer.visibility = View.VISIBLE
        binding.searchView.visibility = View.GONE
        binding.searchView.setQuery("", true)

        binding.llMatric1.visibility = View.VISIBLE
        binding.llMatric2.visibility = View.VISIBLE

    }

    private fun setSearchQueryListener() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextSubmit(query: String): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String): Boolean {

                leadsResponseModel?.let { response ->
                    val pendingList: List<LeadsCrossSalesLead>?
                    val calledList: List<LeadsCrossSalesLead>?

                    if (newText.isBlank()) {

                        if (selectedProductName.isNullOrBlank() || selectedProductName.equals("All")) {
                            pendingList = viewModel.getPendingTabList(response.crossSalesLeads!!)
                            calledList = viewModel.getCalledTabList(response.crossSalesLeads!!)
                        } else {
                            pendingList = viewModel.getPendingTabProductList(
                                response.crossSalesLeads!!,
                                false,
                                "",
                                selectedProductName
                            )
                            calledList = viewModel.getCalledTabProductList(
                                response.crossSalesLeads!!,
                                false,
                                "",
                                selectedProductName
                            )
                        }

                    } else {
                        if (selectedProductName.isNullOrBlank() || selectedProductName.equals("All")) {
                            pendingList = viewModel.getPendingTabList(
                                response.crossSalesLeads!!,
                                true,
                                newText
                            )
                            calledList = viewModel.getCalledTabList(
                                response.crossSalesLeads!!,
                                true,
                                newText
                            )
                        } else {
                            pendingList = viewModel.getPendingTabProductList(
                                response.crossSalesLeads!!,
                                true,
                                newText,
                                selectedProductName
                            )
                            calledList = viewModel.getCalledTabProductList(
                                response.crossSalesLeads!!,
                                true,
                                newText,
                                selectedProductName
                            )
                        }

                    }
                    sendBroadcastToFragment("search", pendingList, calledList)
                }

                return false
            }

        })
    }

    fun sendBroadcastToFragment(
        type: String,
        pendingList: List<LeadsCrossSalesLead>,
        calledList: List<LeadsCrossSalesLead>
    ) {

        val pendingTabIntent = Intent(LEAD_TAB.PENDING)
        pendingTabIntent.putExtra("type", type)
        pendingTabIntent.putParcelableArrayListExtra(
            "list",
            pendingList as ArrayList<out Parcelable>
        )

        val calledTabIntent = Intent(LEAD_TAB.CALLED)
        calledTabIntent.putExtra("type", type)
        calledTabIntent.putParcelableArrayListExtra("list", calledList as ArrayList<out Parcelable>)


        Log.d(TAG, "pendingList : ${pendingList.size ?: "0"} ");
        Log.d(TAG, "calledList : ${calledList.size ?: "0"} ");

        LocalBroadcastManager.getInstance(this@CustomerLeadsActivity)
            .sendBroadcast(pendingTabIntent)
        LocalBroadcastManager.getInstance(this@CustomerLeadsActivity).sendBroadcast(calledTabIntent)

    }

    private fun setAdapter(list: List<LeadsCrossSalesLead>) {

        viewpagerAdapterList.clear()
        viewpagerAdapterList.addAll(list)
        if (viewPagerPagerAdapter == null) {

            val pendingList = viewModel.getPendingTabList(viewpagerAdapterList)
            val calledList = viewModel.getCalledTabList(viewpagerAdapterList)

            pendingbadgeTextView?.text = "${pendingList.size}"
            calledbadgeTextView?.text = "${calledList.size}"

            viewPagerPagerAdapter =
                CustomerLeadsPagerAdapter(supportFragmentManager, pendingList, calledList)
            binding.viewpager.adapter = viewPagerPagerAdapter

        } else {
            binding.viewpager.adapter?.notifyDataSetChanged()
        }

    }

    private fun setFilterLogic(productName: String) {

        leadsResponseModel?.let { response ->


            val pendingList: List<LeadsCrossSalesLead>?
            val calledList: List<LeadsCrossSalesLead>?

            if (productName.equals("All")) {
                pendingList = viewModel.getPendingTabList(response.crossSalesLeads!!)
                calledList = viewModel.getCalledTabList(response.crossSalesLeads!!)
            } else {
                pendingList =
                    viewModel.getPendingFilteredList(response.crossSalesLeads!!, productName)
                calledList =
                    viewModel.getCalledTabFilteredList(response.crossSalesLeads!!, productName)
            }
            pendingbadgeTextView?.text = "${pendingList.size}"
            calledbadgeTextView?.text = "${calledList.size}"

            sendBroadcastToFragment("search", pendingList, calledList)

        }

    }

    fun initialize() {
        if (Util.isOnline(this)) {
            viewModel.solveabc {
                showProgressDialog(this)
            }.observe(this, Observer {
                getData()
            })
        } else {
            getData()
        }
    }


    override fun onBackPressed() {
        if (binding.searchView.visibility == View.VISIBLE) {
            hideSearchView()
        } else {
            super.onBackPressed()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item?.itemId) {
            android.R.id.home -> {

                onBackPressed()

                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    fun getData() {

        val initObserver = Observer<NewCommonResponseModel<LeadsResponseModel>> { result ->

            cancelProgressDialog()
            setLastSaved()
            Log.d(TAG, "result:$result ");

            result?.let {
                if (it.success) {

                    binding.tvNoData.visibility = View.GONE
                    binding.tabLayout.visibility = View.VISIBLE

                    productList = it.responseData?.crossSalesLeads?.distinctBy { it.interestedIn }
                        ?.mapNotNull { it.interestedIn }?.toMutableList()
                    productList?.add(0, "All")

                    leadsResponseModel = it.responseData

                    setMetrics(leadsResponseModel!!)
                    setAdapter(it.responseData!!.crossSalesLeads!!)
                    setSearchQueryListener()

                } else {
                    //handle error here
                    binding.tvNoData.visibility = View.VISIBLE
                    binding.tabLayout.visibility = View.GONE
                    noData(it.error?.messageToUser)
                }
            }

        }

        getCustomerLeads(initObserver)

    }

    override fun refreshFragments() {
        val refreshObserver = Observer<NewCommonResponseModel<LeadsResponseModel>> { result ->
            Log.d(TAG, "result:$result ");

            result?.let {

                cancelProgressDialog()
                setLastSaved()
                if (it.success) {

                    leadsResponseModel = it.responseData
                    setMetrics(leadsResponseModel!!)
                    val pendingList =
                        viewModel.getPendingTabList(leadsResponseModel?.crossSalesLeads!!)
                    val calledList =
                        viewModel.getCalledTabList(leadsResponseModel?.crossSalesLeads!!)
                    pendingbadgeTextView?.text = "${pendingList.size}"
                    calledbadgeTextView?.text = "${calledList.size}"


                    sendBroadcastToFragment("refresh", pendingList, calledList)

                } else {
                    //handle error here
                    noData(it.error?.messageToUser)
                }
            }

        }
        getCustomerLeads(refreshObserver)
    }

    fun getCustomerLeads(observer: Observer<NewCommonResponseModel<LeadsResponseModel>>) {

        viewModel.getCustomerLeadsFromServer(Util.isOnline(this)) {
            if (!isProgressShowing()) {
                showProgressDialog(this)
            }
        }.observe(this, observer)

    }

    private fun noData(message: String?) {
        message?.let {
            //            Util.showToast(message, this)
            Log.e(TAG, message)
        }
        //tvNoData.visibility = View.VISIBLE
        binding.tabLayout.visibility = View.GONE
    }


    override fun onDestroy() {
        super.onDestroy()
//        mHomeWatcher?.stopWatch()
    }


    override fun gotoCustomerLeadsProfile(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead) {
        Log.d(TAG, "gotoCustomerLeadsProfile: ");
        val tabType =
            if (leadsCrossSalesLead.status == LEAD_STATUS.PENDING || leadsCrossSalesLead.status == LEAD_STATUS.REASSIGNED) {
                LEAD_TAB.PENDING
                //}else if (leadsCrossSalesLead.status == LEAD_STATUS.CALLED) {
            } else {
                LEAD_TAB.CALLED
            }
        Log.d(TAG, "gotoCustomerLeadsProfile:tabType => $tabType ");

        val intent = Intent("custom_lead_search")
        intent.putExtra("tabType", tabType)
        intent.putExtra("functionType", "gotoCustomerLeadsProfile")
        intent.putExtra("leadsCrossSalesLead", leadsCrossSalesLead)
        localBroadcastManager.sendBroadcast(intent)
    }

    override fun gotoCustomerLeadsFeedback(
        position: Int,
        leadsCrossSalesLead: LeadsCrossSalesLead
    ) {
        Log.d(TAG, "gotoCustomerLeadsFeedback: ");
        val tabType =
            if (leadsCrossSalesLead.status == LEAD_STATUS.PENDING || leadsCrossSalesLead.status == LEAD_STATUS.REASSIGNED) {
                LEAD_TAB.PENDING
            } else {
                LEAD_TAB.CALLED
            }
        Log.d(TAG, "gotoCustomerLeadsFeedback:tabType => $tabType ");

        val intent = Intent("custom_lead_search")
        intent.putExtra("tabType", tabType)
        intent.putExtra("functionType", "gotoCustomerLeadsFeedback")
        intent.putExtra("leadsCrossSalesLead", leadsCrossSalesLead)
        localBroadcastManager.sendBroadcast(intent)
    }

    override fun makeCall(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead) {
        Log.d(TAG, "makeCall: ");
        val tabType =
            if (leadsCrossSalesLead.status == LEAD_STATUS.PENDING || leadsCrossSalesLead.status == LEAD_STATUS.REASSIGNED) {
                LEAD_TAB.PENDING
            } else {
                LEAD_TAB.CALLED
            }
        Log.d(TAG, "makeCall:tabType => $tabType ");

        val intent = Intent("custom_lead_search")
        intent.putExtra("tabType", tabType)
        intent.putExtra("functionType", "makeCall")
        intent.putExtra("leadsCrossSalesLead", leadsCrossSalesLead)
        localBroadcastManager.sendBroadcast(intent)
    }

    override fun requestCallLogPermission(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead) {
        Log.d(TAG, "requestCallLogPermission: ");
        val tabType =
            if (leadsCrossSalesLead.status == LEAD_STATUS.PENDING || leadsCrossSalesLead.status == LEAD_STATUS.REASSIGNED) {
                LEAD_TAB.PENDING
            } else {
                LEAD_TAB.CALLED
            }
        Log.d(TAG, "requestCallLogPermission:tabType => $tabType ");

        val intent = Intent("custom_lead_search")
        intent.putExtra("tabType", tabType)
        intent.putExtra("functionType", "requestCallLogPermission")
        intent.putExtra("leadsCrossSalesLead", leadsCrossSalesLead)
        localBroadcastManager.sendBroadcast(intent)
    }

    private fun setLastSaved() {
        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this)
        binding.tvLeadsLastSaved.text = data?.leadsCalls
    }

}

