package com.greenlightplanet.kazi.incentivenew.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.CollectionAccounts
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.CollectionBreakdownData
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.Content
import com.greenlightplanet.kazi.incentivenew.repo.CollectionBreakdownRepo
import com.greenlightplanet.kazi.utils.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltViewModel
class AmountCollectedViewModel @Inject constructor(val repo: CollectionBreakdownRepo): ViewModel() {


    private val _collectionBreakdownLiveData = MutableLiveData<NetworkResult<CollectionBreakdownData>>()
    val collectionBreakdownLiveData get() = _collectionBreakdownLiveData

    private val _singleCollectionBreakdownLiveData = MutableLiveData<CollectionBreakdownData?>()
    val singleCollectionBreakdownLiveData get() = _singleCollectionBreakdownLiveData

    private val _amountCollectedLiveData = MutableLiveData<NetworkResult<CollectionAccounts>>()
    val amountCollectedLiveData get() = _amountCollectedLiveData


    private val _singleAmountCollectedLiveData = MutableLiveData<CollectionAccounts?>()
    val singleAmountCollectedLiveData get() = _singleAmountCollectedLiveData

    val currentListForRv = mutableListOf<Content>()
    var filteredClusterList = mutableListOf<Content>()
    var lastObservableList = mutableListOf<Content>()

    var prevDataList = mutableListOf<CollectionAccounts?>()

    var angazaId = ""
    var productName = ""
    var currentPage = 0
    var firstPage = 0
    var totalCount = 0
    var isSearchFiltered = false
    var count = 0
    var incentiveWeek = ""
    var totalCommission = ""
    var commission = ""
    var pageSize = 2


    fun invokeAmountCollectedData(
        angazaId: String,
        page: Int,
        productName: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.getAmountCollectedPagingData(angazaId = angazaId, page = page, pageSize = pageSize, productName = productName).onEach {
                _amountCollectedLiveData.postValue(it)
                Timber.d("AmountCollectedViewModel: AmountCollectedResponse -> ${it.data}")
            }.launchIn(viewModelScope)
        }
    }

    fun getSingleAmountCollectedCachedData(
        angazaId: String,
        productName: String,
        pageNo: Int
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val response = repo.getSingleAmountCachedData(angazaId = angazaId, page = pageNo)
            response.let { result ->
                Timber.d("AmountCollectedViewModel: Page Cache Response -> $result")
                _singleAmountCollectedLiveData.postValue(result)
            }
        }
    }

    suspend fun getCountAmountCollectedData(angazaId: String) = repo.getCountAllPagesAmountCollectedData(angazaId)

    fun invokeCollectionBreakdownData(
        angazaId: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.getCollectionBreakdownData(angazaId = angazaId).onEach {
                _collectionBreakdownLiveData.postValue(it)
                Timber.d("AmountCollectedViewModel: CollectionBreakdownResponse List -> ${it.data}")
            }.launchIn(viewModelScope)
        }
    }

    fun getCollectionBreakdownCachedData(
        angazaId: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val data = repo.getCollectionBreakdownCachedData(angazaId = angazaId)
            _singleCollectionBreakdownLiveData.postValue(data)
        }

    }

}