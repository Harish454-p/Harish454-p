package com.greenlightplanet.kazi.leads.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "LeadsCallDetail")
data class LeadsCallDetail(
        @PrimaryKey
        @ColumnInfo(name = "attempt")
        @SerializedName("attempt")
        var attempt: Int, // 1
        @ColumnInfo(name = "callDuration")
        @SerializedName("callDuration")
        var callDuration: Int?, // 200
        @ColumnInfo(name = "calledDate")
        @SerializedName("calledDate")
        var calledDate: String?, // Tue Jan 07 12:09:42 UTC 2020
        @ColumnInfo(name = "contactedNumber")
        @SerializedName("contactedNumber")
        var contactedNumber: String?, // +254706468574
        @ColumnInfo(name = "intent")
        @SerializedName("intent")
        var intent: Int?, // 2
        @ColumnInfo(name = "newVisitDate")
        @SerializedName("newVisitDate")
        var newVisitDate: String?, // Thu Jan 23 00:00:00 UTC 2020
        @ColumnInfo(name = "otherReason")
        @SerializedName("otherReason")
        var otherReason: String?
) : Parcelable


