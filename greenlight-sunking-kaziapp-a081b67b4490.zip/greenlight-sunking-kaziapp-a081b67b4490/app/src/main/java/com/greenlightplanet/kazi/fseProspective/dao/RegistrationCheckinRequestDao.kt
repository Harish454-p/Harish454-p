package com.greenlightplanet.kazi.fseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.fseProspective.model.RegistrationCheckinRequestModel
import io.reactivex.Single

@Dao
interface RegistrationCheckinRequestDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(RegistrationCheckinRequestModel: List<RegistrationCheckinRequestModel>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(RegistrationCheckinRequestModel: RegistrationCheckinRequestModel): Long

    @Delete
    fun delete(RegistrationCheckinRequestModel: RegistrationCheckinRequestModel): Int

    @Query("DELETE FROM RegistrationCheckinRequest")
    fun deleteAll(): Int

    @Query("SELECT * FROM RegistrationCheckinRequest")
    fun getAll(): Single<List<RegistrationCheckinRequestModel>>

    @Query("SELECT * FROM RegistrationCheckinRequest LIMIT 1")
    fun get(): Single<RegistrationCheckinRequestModel>

    @Query("SELECT COUNT(*) from RegistrationCheckinRequest")
    fun count(): Single<Int>

    @Query("SELECT * FROM RegistrationCheckinRequest WHERE prospectId=:prospectId LIMIT 1")
    fun getByProspectId(prospectId: String): Single<RegistrationCheckinRequestModel>?

    @Query("SELECT * FROM RegistrationCheckinRequest WHERE prospectID IN (:prospectId)")
    fun getAllByProspectId(prospectId: List<String>): Single<List<RegistrationCheckinRequestModel>>

}
