package com.greenlightplanet.kazi.liteFseProspective.view.activity.adapter


import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.annotation.NonNull
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FseMultiRecyclerItemBinding
import com.greenlightplanet.kazi.liteFseProspective.model.LiteFseProspectResponseModel
import kotlinx.android.extensions.LayoutContainer
import org.jetbrains.annotations.NotNull


class MultiImageClickAdapter(val context: Context, var list: List<LiteFseProspectResponseModel.InstallationPictures>, var fseProspectResponseModel: LiteFseProspectResponseModel?)
    : RecyclerView.Adapter<MultiImageClickAdapter.ViewHolder>() {

    var multiImageClickAdapterCallback: MultiImageClickAdapterCallback? = null
    var circularProgressDrawable: CircularProgressDrawable? = null

    init {
        circularProgressDrawable = CircularProgressDrawable(context)
        circularProgressDrawable?.strokeWidth = 5f
        circularProgressDrawable?.centerRadius = 30f
        circularProgressDrawable?.start()
    }

    override fun onCreateViewHolder(@NotNull p0: ViewGroup, viewType: Int): ViewHolder {

        val itemBinding = FseMultiRecyclerItemBinding.inflate(LayoutInflater.from(p0.context), p0, false)
        return ViewHolder(itemBinding)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = list.get(position)
      holder.bind(data)

    }

    inner class ViewHolder( val itemBinding: FseMultiRecyclerItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(data: LiteFseProspectResponseModel.InstallationPictures) {
            itemBinding.name.text = data.name?.replace("_", " ")!!.capitalize()/*?.toLowerCase()*/
            var check = position + 1

            if (data.phoneUrl.isNullOrEmpty()) {
//			holder.clickedImage.visibility = View.GONE
                itemBinding.btnClick.text = "Click Photo"
                itemBinding.clickedImage.setOnClickListener {
                }
            } else {
//			holder.clickedImage.visibility = View.VISIBLE
                setOrientationImageGlide(data.phoneUrl!!, itemBinding.clickedImage, fseProspectResponseModel)
                itemBinding.clickedImage.setOnClickListener {
                    multiImageClickAdapterCallback?.onImageClick(position, data, fseProspectResponseModel!!)
                }
                itemBinding.btnClick.text = "Reclick Photo"


            }

            if (!fseProspectResponseModel!!.isInstallationChanged!!) {

                /*new changes told by ADI on 2 dec */
//            if (position != 0) {
//                if (list.get(position - 1).phoneUrl.isNullOrEmpty()) {
//                    holder.btnClick.setBackgroundResource(R.drawable.disable_curve_bg)
//                    holder.btnClick.isEnabled = false
//                } else {
                itemBinding.btnClick.setBackgroundResource(R.drawable.curve_bg)
                itemBinding.btnClick.isEnabled = true
//                }
//            }

            } else {

                if (data.isRejected!!) {
                    itemBinding.btnClick.setBackgroundResource(R.drawable.curve_bg)
                    itemBinding.btnClick.isEnabled = true
                } else {
                    itemBinding.btnClick.setBackgroundResource(R.drawable.disable_curve_bg)
                    itemBinding.btnClick.isEnabled = false
                }
            }


            itemBinding.btnClick.setOnClickListener {
                multiImageClickAdapterCallback?.onClickPhoto(position, data, fseProspectResponseModel!!)
            }

        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    interface MultiImageClickAdapterCallback {

        fun onClickPhoto(position: Int, installPics: LiteFseProspectResponseModel.InstallationPictures, value: LiteFseProspectResponseModel)
        fun onImageClick(position: Int, installPics: LiteFseProspectResponseModel.InstallationPictures, value: LiteFseProspectResponseModel)

    }

    private fun setOrientationImageGlide(url: String, imageView: ImageView, fseProspectResponseModel: LiteFseProspectResponseModel?) {

        try {
            if (!fseProspectResponseModel!!.isInstallationChanged!!) {
                val bounds: BitmapFactory.Options = BitmapFactory.Options()
                bounds.inJustDecodeBounds = true
                BitmapFactory.decodeFile(url, bounds)

                val opts: BitmapFactory.Options = BitmapFactory.Options()
                val bm: Bitmap = BitmapFactory.decodeFile(url, opts)
                val exif = ExifInterface(url)
                val orientString: String = exif.getAttribute(ExifInterface.TAG_ORIENTATION)!!

                var orientation: Int = 0
                if (orientString != null) {
                    orientation = Integer.parseInt(orientString)
                } else {
                    orientation = ExifInterface.ORIENTATION_NORMAL
                }

                var rotationAngle = 0
                if (orientation == ExifInterface.ORIENTATION_ROTATE_90) rotationAngle = 90
                if (orientation == ExifInterface.ORIENTATION_ROTATE_180) rotationAngle = 180
                if (orientation == ExifInterface.ORIENTATION_ROTATE_270) rotationAngle = 270

                val matrix = Matrix()
                matrix.setRotate(
                        rotationAngle.toFloat(), (bm.getWidth() / 2).toFloat(),
                        (bm.getHeight() / 2).toFloat()
                )
                val rotatedBitmap: Bitmap =
                        Bitmap.createBitmap(bm, 0, 0, bounds.outWidth, bounds.outHeight, matrix, true)


                Glide.with(context)
                        .load(rotatedBitmap)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .apply(RequestOptions()
                                .centerCrop()
                                .placeholder(circularProgressDrawable)
                                .error(R.mipmap.ic_launcher_round))
                        .into(imageView)
            } else {
                Glide.with(context)
                        .load(url)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .apply(RequestOptions()
                                .centerCrop()
                                .placeholder(circularProgressDrawable)
                                .error(R.mipmap.ic_launcher_round))
                        .into(imageView)
            }
        } catch (e: Exception) {
            Log.d("MultiImageClickAdapter", "setOrientationImageGlide: ${e.localizedMessage}")
        }


    }

}
