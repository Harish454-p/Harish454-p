package com.greenlightplanet.kazi.incentivenew.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.CollectionAccounts
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.Content
import kotlinx.coroutines.flow.Flow

@Dao
interface AmountCollectedDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(data: CollectionAccounts): Long

    @Query("SELECT * FROM collectionAmount WHERE angazaId LIKE :angazaId AND number = :page LIMIT 1")
    fun getSingleAmountData(angazaId: String, page: Int) : CollectionAccounts?

    @Query("SELECT COUNT(*) FROM collectionAmount WHERE angazaId LIKE :angazaId")
    suspend fun getCountAllPagesAmountData(angazaId: String) : Int?

    @Query("DELETE FROM collectionAmount")
    suspend fun deleteAll() :Int

    @Query("DELETE FROM collectionAmount WHERE angazaId LIKE :angazaId AND number =:page")
    suspend fun deleteExisting(angazaId: String, page: Int) :Int

    @Transaction
    suspend fun replace(data: CollectionAccounts): Long {
        deleteExisting(data.angazaId?:"", data.number)
        return insert(data)
    }

    @Transaction
    suspend fun replaceAll(data: CollectionAccounts): Long {
        deleteAll()
        return insert(data)
    }

}