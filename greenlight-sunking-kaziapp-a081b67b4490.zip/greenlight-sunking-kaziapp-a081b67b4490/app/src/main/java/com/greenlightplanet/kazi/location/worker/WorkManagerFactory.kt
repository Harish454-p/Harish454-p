package com.greenlightplanet.kazi.location.worker

import android.os.Build
import android.util.Log
import androidx.work.*
import com.greenlightplanet.kazi.location.newworker.NewWorkerRx
import com.greenlightplanet.kazi.location.newworker.WORKER_INTERVAL.WM_INTERVAL
import java.util.concurrent.TimeUnit


class WorkManagerFactory {

	companion object {
		public const val TAG = "WorkManagerFactory"
		fun getWorkInstance(duration:Long): OneTimeWorkRequest {
			return OneTimeWorkRequest.Builder(NewWorkerRx::class.java)
				.setInitialDelay(duration, TimeUnit.MINUTES)
				.build()
		}

		private fun getPeriodicWorkInstance(): PeriodicWorkRequest {
			//return PeriodicWorkRequest.Builder(HourWorkerRx::class.java, WM_INTERVAL,
			return PeriodicWorkRequest.Builder(NewWorkerRx::class.java, 15,
				TimeUnit.MINUTES).build()
		}

		fun makeWork() {
			try{
				Log.d(TAG, ":initWorkManager ");
				val manager = WorkManager.getInstance()
				//val request = getWorkInstance()
				val request = getPeriodicWorkInstance()
				manager.enqueue(request)
			}catch (e:Exception){
				Log.d(TAG, "error:$e ");
			}

		}

		fun makeWorkOneTime(duration:Long = 1) {
			Log.d(TAG, ":makeWork2 ");
			/*val manager = WorkManager.getInstance()

			//val request = getWorkInstance()
			val request = getWorkInstance(duration)
			manager.enqueue(request)*/
		}

		fun scheduleWork(tag: String?, locationInterval: Long) {
			/*val photoCheckBuilder = PeriodicWorkRequest.Builder(NewWorkerRx::class.java, 15,
				TimeUnit.MINUTES)
				//TimeUnit.MINUTES, locationInterval, TimeUnit.MINUTES)
			val photoCheckWork = photoCheckBuilder.build()
			val instance = WorkManager.getInstance()
			instance.enqueueUniquePeriodicWork(tag!!, ExistingPeriodicWorkPolicy.KEEP, photoCheckWork)*/


			/*val periodicSyncDataWork = PeriodicWorkRequest.Builder(NewWorkerRx::class.java, 15, TimeUnit.MINUTES)
				.addTag("TAG_SYNC_DATA")
				//.setConstraints(constraints) // setting a backoff on case the work needs to retry
				.setBackoffCriteria(BackoffPolicy.LINEAR, PeriodicWorkRequest.MIN_BACKOFF_MILLIS, TimeUnit.MILLISECONDS)
				.build()
			val mWorkManager = WorkManager.getInstance()

			mWorkManager.enqueueUniquePeriodicWork(
				"SYNC_DATA_WORK_NAME",
				ExistingPeriodicWorkPolicy.KEEP,  //Existing Periodic Work policy
				periodicSyncDataWork //work request
			)*/

			/*val oneTimeWorkRequest = OneTimeWorkRequest.Builder(NewWorkerRx::class.java)
				//.setConstraints(constraints)
				.setInitialDelay(locationInterval, TimeUnit.MINUTES)
				.addTag("TAG_SYNC_DATA")
				.build()
			val mWorkManager = WorkManager.getInstance()

			*//*mWorkManager.enqueueUniqueWork(
				"SYNC_DATA_WORK_NAME",
				ExistingWorkPolicy.REPLACE,  //Existing Periodic Work policy
				oneTimeWorkRequest //work request
			)*//*

			mWorkManager.enqueue(
				oneTimeWorkRequest //work request
			)*/
			//makeWork()

			makeWork()
		}

		fun isWorkScheduled(tag: String): Boolean {
			/*val instance = WorkManager.getInstance()
			val statuses: ListenableFuture<List<WorkInfo>> = instance.getWorkInfosByTag(tag)
			return try {
				var running = false
				val workInfoList: List<WorkInfo> = statuses.get()
				for (workInfo in workInfoList) {
					val state = workInfo.state
					running = state == WorkInfo.State.RUNNING || state == WorkInfo.State.ENQUEUED
				}
				running
			} catch (e: ExecutionException) {
				e.printStackTrace()
				false
			} catch (e: InterruptedException) {
				e.printStackTrace()
				false
			}*/
			return false
		}
	}

}
