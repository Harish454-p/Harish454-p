package com.greenlightplanet.kazi.collectiongoal.typeconverters

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.summary.model.CollectionRate

class WeeklyTargetAccountsConverter {

    @TypeConverter
    fun fromCollection(crlist: List<MakeCallNewModel.ColGoalAccount>?): String? {
        if (crlist == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<MakeCallNewModel.ColGoalAccount>>() {

        }.type
        return gson.toJson(crlist, type)
    }

    @TypeConverter
    fun toCollectionList(clList: String?): List<MakeCallNewModel.ColGoalAccount>? {
        if (clList == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<MakeCallNewModel.ColGoalAccount>>() {

        }.type
        return gson.fromJson(clList, type)
    }
}