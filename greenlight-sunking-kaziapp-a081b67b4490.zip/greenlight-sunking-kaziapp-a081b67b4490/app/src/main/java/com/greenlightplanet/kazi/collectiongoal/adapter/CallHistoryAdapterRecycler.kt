package com.greenlightplanet.kazi.collectiongoal.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.Keep
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistory
import com.greenlightplanet.kazi.databinding.NewCallHistoryDetailsBinding
import com.greenlightplanet.kazi.newtasks.model.FeedbackIntentModel
import com.greenlightplanet.kazi.utils.Util

@Keep
class CallHistoryAdapterRecycler(
    private val context: Context,
    private var values: List<CallHistory>,
    feedbackIntentModel: FeedbackIntentModel?
) : RecyclerView.Adapter<CallHistoryAdapterRecycler.ViewHolder>() {

    var dialogModel: FeedbackIntentModel? = null

    init {
        dialogModel = feedbackIntentModel
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CallHistoryAdapterRecycler.ViewHolder {

        val itemBinding = NewCallHistoryDetailsBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(itemBinding)

    }

    override fun onBindViewHolder(holder: CallHistoryAdapterRecycler.ViewHolder, position: Int) {
        val task = values[position]
        holder.bind(task, holder.itemView)
    }

    @SuppressLint("LongLogTag")
    override fun getItemCount(): Int {
        Log.d("CallHistoryRecyclerAdapterListSize",values.size.toString())
        return values.size
    }

    inner class ViewHolder(val itemBinding: NewCallHistoryDetailsBinding)
        : RecyclerView.ViewHolder(itemBinding.root) {

        @SuppressLint("SetTextI18n")
        fun bind(task: CallHistory, itemView: View) {

            if (task.callDate.isNullOrBlank()) {
                itemBinding.tvCallDate.text = "NA"
            }
            else {
                itemBinding.tvCallDate.text = Util.convertUTCtoLocatTimeYYYYYMMDD(task.callDate)
            }

            itemBinding.tvCallDuration.text = task.contactedPhone

            itemBinding.LinCutomerDetails.visibility = View.GONE

            setExpendView(itemBinding,task,dialogModel)


            itemBinding.IvOption.setOnClickListener {
               if (itemBinding.LinCutomerDetails.visibility==View.GONE){
                   itemBinding.IvOption.rotation = 180f
                   itemBinding.LinCutomerDetails.visibility=View.VISIBLE

               }else {
                   itemBinding.IvOption.rotation = 0f
                   itemBinding.LinCutomerDetails.visibility=View.GONE
               }
            }
        }
    }

    @SuppressLint("SetTextI18n", "LongLogTag")
    private fun setExpendView(
        itemBinding: NewCallHistoryDetailsBinding,
        task: CallHistory,
        feedbackModel: FeedbackIntentModel?
    ) {

        try {
            Log.e("FeedbackCallHistoryCheck0", "$feedbackModel")

            val intentList: MutableList<FeedbackIntentModel.Intents> = mutableListOf()
            val displayIntentList: MutableList<String> = mutableListOf()
            var intentsorted: FeedbackIntentModel.Intents? = null
            val customerFeedbackList: MutableList<FeedbackIntentModel.Intents.Feedback> = mutableListOf()



            when(task.duration){

                null -> {
                    itemBinding.tvPhoneNo.text = "NA"
                }
                else -> {
                    itemBinding.tvPhoneNo.text = task.duration +" seconds"
                }
            }


            if (task.promiseDate.isNullOrBlank()) {
                itemBinding.tvPromiseDate.text = "NA"
            }
            else {
                itemBinding.tvPromiseDate.text =
                    Util.parseYYYY_MM_DDtoDD_MM_YYYY(task.promiseDate)
            }

            Log.d("CheckIntentID_FeedbackId"," ${task.feedbackId} ${task.intentId}")


            for (dbd in feedbackModel!!.intents) {
                val str = dbd.intent
                displayIntentList.add(str)
            }

            for (dbd in feedbackModel.intents) {
                val str =
                    FeedbackIntentModel.Intents(dbd.id, dbd.feedbacks, dbd.intent, dbd.intentId)
                intentList.add(str)
            }
            intentsorted = intentList.find { it.intentId == task.intentId }
            Log.e("FeedbackCallHistoryListCheck0", "$intentsorted")
            Log.e("FeedbackCallHistoryListCheck1", "$displayIntentList")

            if (intentsorted!=null) {
                itemBinding.tvIntent.visibility = View.VISIBLE
                itemBinding.tvIntent.text = intentsorted.intent
            }
            else {
                itemBinding.tvIntent.visibility = View.GONE
            }

            for (dbd in intentsorted!!.feedbacks) {
                customerFeedbackList.add(
                    FeedbackIntentModel.Intents.Feedback(
                        dbd.feedback,
                        dbd.feedbackId,
                        dbd.intentId
                    )
                )
            }

            Log.e("FeedbackCallHistoryListCheck2", "$customerFeedbackList ${task.feedbackId}")

            task.feedbackId.let { feedbackId ->

                Log.e("FeedbackCallHistoryListCheck4",
                    "$customerFeedbackList ${task.feedbackId}")

                val feed = customerFeedbackList.find { it.feedbackId == task.feedbackId }
                Log.d("CheckFeed"," $feed")



                if (feed!=null) {
                    itemBinding.tvFeedback.visibility = View.VISIBLE
                    itemBinding.tvFeedback.text = feed.feedback
                }
                else {
                    itemBinding.tvFeedback.visibility = View.GONE
                }

            }


        }catch (e: Exception){
            Log.e("FeedbackCallHistoryFrag", "$e")
        }
    }

}