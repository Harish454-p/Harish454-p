package com.greenlightplanet.kazi.collectiongoal.view.activity

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.Keep
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.Observer
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.collectiongoal.adapter.AccountLastWeekPagerAdapter
import com.greenlightplanet.kazi.collectiongoal.model.pastweekincentive.LastWeekIncentiveModel
import com.greenlightplanet.kazi.collectiongoal.viewmodel.CommonWeekIncentiveViewmodel
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityAccountLastWeekBinding
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util

@Keep
class AccountLastWeekAcitivity : BaseActivity() {

    private lateinit var binding: ActivityAccountLastWeekBinding

    val TAG = "AccountLastWeekAcitivity"
    var preference: GreenLightPreference? = null

    var loginResponseData: LoginResponseModel? = null

    var lastWeekIncentiveModel: LastWeekIncentiveModel? = null

    var viewpagerAdapterList = mutableListOf<LastWeekIncentiveModel.AchievedAccount>()

    var achievedList = mutableListOf<LastWeekIncentiveModel.AchievedAccount>()
    var notAchievedList = mutableListOf<LastWeekIncentiveModel.AchievedAccount>()

    var viewPagerPagerAdapter: AccountLastWeekPagerAdapter? = null

    var fragmentType: Boolean? = true

    private val viewModel: CommonWeekIncentiveViewmodel by viewModels()

    var previousWeekNextPageAchieved = 2
    var previousWeekNextPageNotAchieved = 2
    var tempList = mutableListOf<LastWeekIncentiveModel.AchievedAccount>()
    var nextPage: Int = 1
    var completedListSize: Int = 0
    var notCompletedListSize: Int = 0

    /** Observer to get data from server and
     *  update list on view more click (for Pagination effect)
     *  FragmentType == true for Completed tab &
     *  FragmentType == fale for Not Completed tab */

    @SuppressLint("LongLogTag")
    val observer = Observer<NewCommonResponseModel<LastWeekIncentiveModel>> {

        if (this.lifecycle.currentState== Lifecycle.State.RESUMED) {

            cancelProgressDialog()

            if (!it!!.success) {
                binding.tvNoData.visibility = View.VISIBLE
                binding.tvBottom.visibility = View.GONE
            }
            else {
                Log.d(TAG, "Data Success: ${it}")

                binding.tvNoData.visibility = View.GONE
                binding.tvBottom.visibility = View.VISIBLE

                Log.d("previousWeekNextPageNotAchieved",previousWeekNextPageNotAchieved.toString())
                Log.d("previousWeekNextPageAchieved",previousWeekNextPageAchieved.toString())

                lastWeekIncentiveModel = it.responseData

                if (it.responseData?.next.isNullOrEmpty()){
                    Log.d("CheckingNextPageValue", "${it.responseData?.next}")
                    binding.tvBottom.visibility = View.GONE
                    if (fragmentType==true){
                        previousWeekNextPageAchieved = 0
                    }else {
                        previousWeekNextPageNotAchieved = 0
                    }

                    Log.d("CheckingNextPageValue", "previousWeekNextPageAchieved: " +
                            "$previousWeekNextPageAchieved " +
                            "previousWeekNextPageNotAchieved: $previousWeekNextPageNotAchieved")
                } else {
                    if (fragmentType==true){
                        previousWeekNextPageAchieved = it.responseData!!.next!!.toInt()
                    }else {
                        previousWeekNextPageNotAchieved = it.responseData!!.next!!.toInt()
                    }
                }

                Log.d("checkFragmentType",fragmentType.toString())

                Log.d("achievedListSize1",achievedList.size.toString())
                Log.d("achievedListSize1.1",lastWeekIncentiveModel?.achievedAccounts?.size.toString())
                Log.d("notAchievedListSize1",notAchievedList.size.toString())
                Log.d("notachievedListSize1.1",lastWeekIncentiveModel?.notAchievedAccounts?.size.toString())

                if (fragmentType == true){

                    if (lastWeekIncentiveModel?.achievedAccounts.isNullOrEmpty()){
                        previousWeekNextPageAchieved = 0
                    }
                    if (achievedList.isNullOrEmpty()){
                        achievedList.addAll(viewpagerAdapterList.filter { it.status })
                        Log.d("achievedListSize2",achievedList.size.toString())
                        achievedList.addAll(lastWeekIncentiveModel?.achievedAccounts!!)
                        Log.d("achievedListSize3",achievedList.size.toString())
                        viewModel.updateAchievedFragment(achievedList) }
                    else {
                        achievedList.addAll(lastWeekIncentiveModel?.achievedAccounts!!)
                        viewModel.updateAchievedFragment(achievedList)
                    }
                }
                else {

                    if (lastWeekIncentiveModel?.notAchievedAccounts.isNullOrEmpty()){
                        previousWeekNextPageNotAchieved = 0
                    }
                    if (notAchievedList.isNullOrEmpty()){
                        notAchievedList.addAll(viewpagerAdapterList.filter { !it.status })
                        Log.d("notAchievedListSize2",notAchievedList.size.toString())
                        notAchievedList.addAll(lastWeekIncentiveModel?.notAchievedAccounts!!)
                        Log.d("notAchievedListSize3",notAchievedList.size.toString())
                        viewModel.updateNotAchievedFragment(notAchievedList)
                    } else {
                        notAchievedList.addAll(lastWeekIncentiveModel?.notAchievedAccounts!!)
                        viewModel.updateNotAchievedFragment(notAchievedList)
                    }

                }

            }
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAccountLastWeekBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Util.setToolbar(this, binding.toolbar)
        preference = GreenLightPreference.getInstance(this)
        loginResponseData = preference?.getLoginResponseModel()

        initialize()

        if (!viewModel.previousWeekIncentiveData.hasActiveObservers()){
            viewModel.previousWeekIncentiveData.observe(this,observer)
        }
        binding.tvBottom.setOnClickListener {
            Log.d("callingViewMore","OnClicked:" + "true")
            if (Util.isOnline(this)) {
                showProgressDialog(this)
                Util.hideKeyboard(this)
                if (fragmentType==true){
                    viewModel.getLWIncentiveFromServer1(previousWeekNextPageAchieved)
                }else {
                    viewModel.getLWIncentiveFromServer1(previousWeekNextPageNotAchieved)
                }
            } else {
                Util.customFseCompletionDialog(
                    context = this,
                    hideTitle = true,
                    message = "Please check internet connection",
                    okSelected = {
                        it.dismiss()
                    },
                    title = null
                )
            }
        }

    }

    fun initialize() {

        binding.tvAppbottomVersion.text = "V:" + BuildConfig.VERSION_NAME
        binding.tvNoData.visibility = View.GONE
        binding.tabLayout.visibility = View.VISIBLE

        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this)
        binding.tvLastSaved.text = data?.accountLastSaved


        ApiCall(nextPage)

    }

    @SuppressLint("LongLogTag")
    private fun ApiCall(nextPage: Int) {

        Log.d("APICAllNEEDED","OK DONE")
       showProgressDialog(this)
        viewModel.getLWIncentiveFromServer(nextPage)
            .observe(this, Observer { it ->

                cancelProgressDialog()

                if (it.success){
                    Log.d(TAG, "AccountLastWeekActivitySuccess: ${it}")

                    if (it.responseData?.next==null){
                        this.nextPage = 0
                    }else {
                        this.nextPage = it.responseData?.next!!.toInt()
                    }

                    binding.tvNoData.visibility = View.GONE
                    binding.tabLayout.visibility = View.VISIBLE

                    lastWeekIncentiveModel = it.responseData

                    val CommonList = mutableListOf<LastWeekIncentiveModel.AchievedAccount>()
                    CommonList.addAll(lastWeekIncentiveModel?.achievedAccounts!!)
                    CommonList.addAll(lastWeekIncentiveModel?.notAchievedAccounts!!)

                    setupTabLayout()
                    setAdapter(CommonList)

                }
                else {
                    //handle error here
                    Util.showToast(this,it.error?.messageToUser.toString())
                    binding.tvBottom.visibility = View.GONE
                    binding.tvNoData.visibility = View.VISIBLE
                    binding.tabLayout.visibility = View.GONE
                    noData(it.error?.messageToUser)
                }

            })

    }

    @SuppressLint("LongLogTag")
    private fun noData(message: String?) {
        message?.let {
            Log.e(TAG, message)
        }
        binding.tabLayout.visibility = View.GONE
    }

    @SuppressLint("NotifyDataSetChanged", "LongLogTag")
    private fun setAdapter(CommonList: MutableList<LastWeekIncentiveModel.AchievedAccount>) {

        cancelProgressDialog()

        val data: LastSaved? = OfferUtils.loadSummaryFromPref(this)
        binding.tvLastSaved.text = data?.accountLastSaved

        if (CommonList.isNullOrEmpty()) {
            binding.tvNoData.visibility = View.VISIBLE
            binding.tvBottom.visibility = View.GONE
            binding.tabLayout.visibility = View.GONE
        }
        else {
            binding.tvBottom.visibility = View.VISIBLE
            binding.tvNoData.visibility = View.GONE
            binding.tabLayout.visibility = View.VISIBLE

            viewpagerAdapterList.clear()
            if (!CommonList.isNullOrEmpty() && viewpagerAdapterList.isNullOrEmpty()) {
                viewpagerAdapterList.addAll(CommonList)
                Log.d("PastWeekAdapterListSize", "adapter : ${viewpagerAdapterList.size} $viewpagerAdapterList")

                val achievedList = viewModel.getAchievedTabList(viewpagerAdapterList) ?: mutableListOf()
                val notAchievedList = viewModel.getNotAchievedTabList(viewpagerAdapterList) ?: mutableListOf()

                Log.d("AchievedListActivity", "success: ${achievedList.size} ${achievedList}")
                Log.d("NotAchievedListActivity", "success: ${notAchievedList.size} ${notAchievedList}")

                viewPagerPagerAdapter = AccountLastWeekPagerAdapter(supportFragmentManager,achievedList,notAchievedList)
                binding.viewpager.adapter = viewPagerPagerAdapter
            }
        }

    }

    private fun setupTabLayout() {

        binding.tabLayout.apply {
            addTab(this.newTab().setText(getString(R.string.completed)))
            addTab(this.newTab().setText("Not " + getString(R.string.completed)))

            tabGravity = TabLayout.GRAVITY_FILL

            addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab) {
                    binding.viewpager.currentItem = tab.position
                    fragmentType = tab.position==0

                    Log.d("CHeckingScrollingOnly1", " ${tab.position}")

                    if (fragmentType==true){
                        when(previousWeekNextPageAchieved){
                            0 -> binding.tvBottom.visibility = View.GONE
                            else -> binding.tvBottom.visibility = View.VISIBLE
                        }
                    }else {
                        when(previousWeekNextPageNotAchieved){
                            0 -> binding.tvBottom.visibility = View.GONE
                            else -> binding.tvBottom.visibility = View.VISIBLE
                        }
                    }




                }

                override fun onTabUnselected(tab: TabLayout.Tab?) {
                }

                override fun onTabReselected(tab: TabLayout.Tab?) {
                }
            })

            binding.viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {

                override fun onPageScrollStateChanged(position: Int) {


                    Log.d("CHeckingScrollingOnly2", " $position")



                }

                override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {}

                override fun onPageSelected(p0: Int) {
                    binding.tabLayout.getTabAt(p0)?.select()

                }
            })
        }

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

//    private val onBackPressedCallback: OnBackPressedCallback =
//        object : OnBackPressedCallback(true) {
//            override fun handleOnBackPressed() {
//                finish()
//            }
//        }

    override fun onBackPressed() {
        onBackPressedDispatcher.onBackPressed()
        finish()
    }

}