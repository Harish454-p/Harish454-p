package com.greenlightplanet.kazi.incentivenew.fragment


import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.FragmentSummaryIncentiveBinding
import com.greenlightplanet.kazi.incentivenew.activity.DeductionActivity
import com.greenlightplanet.kazi.incentivenew.activity.EarningActivity
import com.greenlightplanet.kazi.incentivenew.adapter.SummaryAdapter
import com.greenlightplanet.kazi.incentivenew.model.summary.SummaryResponseData
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util


class SummaryIncentiveFragment : Fragment(), SummaryAdapter.MyDateData {

    private var _binding:FragmentSummaryIncentiveBinding  ? = null
    private val binding get() = _binding!!

    private  val TAG = "SummaryIncentiveFragmen"
    var preference: GreenLightPreference? = null

    var summaryResponseData: SummaryResponseData? = null
    //var recyclerView: RecyclerView? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        _binding = FragmentSummaryIncentiveBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val bundleSummary = arguments
        summaryResponseData = bundleSummary?.getParcelable("summary") as SummaryResponseData?
        preference = GreenLightPreference.getInstance(requireActivity())

        try {
            if (summaryResponseData?.summaryFields?.size!! > 0) {
                binding.tvNoData.visibility = View.GONE
            } else {
                binding.tvNoData.visibility = View.VISIBLE
            }
        } catch (e: Exception) {
            Log.e(TAG, "onActivityCreated: $e" )
                binding.tvNoData.visibility = View.VISIBLE
        }

        val symbol: String? = preference?.getCountryResponseModel()?.countryCurrency ?: "NA"

        val adapter = summaryResponseData?.summaryFields?.let { symbol?.let { it1 -> SummaryAdapter(it, this, requireContext(), it1) } }
        binding.recyclerView?.setHasFixedSize(true)
        binding.recyclerView?.layoutManager = LinearLayoutManager(requireContext())
       binding.recyclerView?.adapter = adapter
    }

    override fun selectedData(elementName: String, values: String) {
        when (elementName) {
            "earnings" -> startActivity(Intent(requireContext(), EarningActivity::class.java).putExtra("earning",values))
            "deductions" -> startActivity(Intent(requireContext(), DeductionActivity::class.java).putExtra("deduction",values))
            else -> println("$id is invalid")
        }
    }


}
