package com.greenlightplanet.kazi.loyalty.converter.achievement

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.loyalty.model.achievements.Achieved

class AchievementConverter {

    @TypeConverter
    fun fromAchievedList(list: List<Achieved>?): String? {
        if (list == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<Achieved>>() {

        }.type
        return gson.toJson(list, type)
    }

    @TypeConverter
    fun toAchievedList(string: String?): List<Achieved>? {
        if (string == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<Achieved>>() {

        }.type
        return gson.fromJson(string, type)
    }

}


