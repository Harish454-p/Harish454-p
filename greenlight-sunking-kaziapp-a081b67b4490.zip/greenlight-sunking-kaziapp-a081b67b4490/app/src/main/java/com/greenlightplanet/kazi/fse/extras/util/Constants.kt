package com.greenlightplanet.kazi.fse.extras.util

object SortType {

    val ASCENDING = 0
    val DESCENDING = 1

}


object SortAttrFseCommitment {

    val ATTR_CUSTOMER_NAME = 1
    val ATTR_DAYS_DISABLED = 2
    val ATTR_SELECTION = 3

}


