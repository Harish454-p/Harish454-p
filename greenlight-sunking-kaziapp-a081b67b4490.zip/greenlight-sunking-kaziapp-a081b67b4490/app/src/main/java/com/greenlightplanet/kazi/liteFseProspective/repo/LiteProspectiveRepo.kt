package com.greenlightplanet.kazi.liteFseProspective.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.os.Parcelable
import android.util.Log
import com.greenlightplanet.kazi.dashboard.model.FakeLocationRequest
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.liteFseProspective.extras.FseProspectiveConstant
import com.greenlightplanet.kazi.liteFseProspective.model.*
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.Completable
import io.reactivex.Flowable
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

class LiteProspectiveRepo(val context: Context) {

    companion object :
        SingletonHolderUtil<LiteProspectiveRepo, Context>(::LiteProspectiveRepo) {
        public const val TAG = "LiteProspectiveRepo"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null


    //new added for sync process
    val verificationRepo = LiteVerificationRepo.getInstance(context)
    val registrationRepo = LiteRegistrationRepo.getInstance(context)
    val installationRepo = LiteInstallationRepo.getInstance(context)

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context!!)

        } catch (e: Exception) {
            Log.d(TAG, ":Error ");
        }
    }

    private val territory: String? by lazy {
        preference?.getLoginResponseModel()?.territory
    }


    fun getFseProspectiveFromDatabase(): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {

        val data = MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>()


        localDb?.let { appDatabase ->
            bag.add(

                appDatabase.liteFseProspectResponseDao().getAll()
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        Log.d(TAG, "DB-EO-List: ${it}")
                        data.postValue(
                            NewCommonResponseModel<LiteFseProspectResponseData>(
                                responseData = LiteFseProspectResponseData(prospects = it),
                                success = true
                            )
                        )
                    }, { t ->
                        Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        data.postValue(
                            NewCommonResponseModel<LiteFseProspectResponseData>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable to find data in database"
                                ),
                                success = false
                            )
                        )
                    })

            )
        }

        return data
    }

    private fun fseProspectiveFromServerLogic(
        liveData: MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>,
        responseData: NewCommonResponseModel<LiteFseProspectResponseData>
    ) {

        bag.add(
            Completable.fromAction {
                localDb?.liteFseProspectResponseDao()?.deleteAll()
                localDb?.liteFseProspectResponseDao()
                    ?.insertAll(responseData.responseData!!.prospects!!)
            }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "Insertion:Completed ")
                    Log.e(
                        "jfhvjdhfjhd",
                        "${responseData.responseData?.prospects?.map { it.installationPictures?.map { it.isRejected } }}"
                    )
                    preference?.setFseProspectLastSynced(Util.getCurrentLocalFormattedDateForSync())
                    liveData.postValue(responseData)
                    Log.d("TIME_CALC", "prospect-end:${System.currentTimeMillis()} ")
                }, { t ->
                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                })
        )

    }


    fun insertAwsImageModelToDatabase(
        inputFiles: List<LiteAwsImageModel>,
        isUploadedToAws: Boolean
    ): MutableLiveData<List<LiteAwsImageModel>?> {
        return installationRepo.insertAwsImageModelToDatabase(inputFiles, isUploadedToAws)
    }

    fun getFseProspectiveFromServer(angazaId: String): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {

        val data = MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>()

        var value: NewCommonResponseModel<LiteFseProspectResponseData>? = null

        Log.d("TIME_CALC", "prospect-start:${System.currentTimeMillis()} ")
        bag.add(

            localDb!!.liteFseProspectResponseDao().getAll()
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .flatMapCompletable { listFromDatabase ->
                    // here delete all data from database
                    Completable.fromAction {
                        localDb!!.liteFseProspectResponseDao().deleteAll()
                    }.doOnError {
                        Log.d(TAG, "Error-2: ${it.localizedMessage}");
                        data.postValue(
                            NewCommonResponseModel<LiteFseProspectResponseData>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable get data from server"
                                ),
                                success = false
                            )
                        )
                        it.printStackTrace()
                    }.doOnComplete {
                        //ServiceInstance.getInstance(context).service?.getFseProspectives()!!
                        ServiceInstance.getInstance(context).service?.getLiteFseProspectives(
                            territory = territory!!
                            /*, angazaId = angazaId*/
                        )!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .subscribe({
                                value = it

                                val databaseList = listFromDatabase.toMutableList()

                                val serverList = value!!.responseData!!.prospects!!.toMutableList()

                                //val uniqueInDb = mutableListOf<FseProspectResponseData>()

                                try {
                                    databaseList.forEach { databaseItem ->

                                        if (serverList.find { it.prospectId == databaseItem.prospectId } == null) {
                                            databaseList.remove(databaseItem)
                                        }
                                    }
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                    Log.d(
                                        TAG,
                                        "insertAwsImageModelToDatabase-error:${e.localizedMessage}"
                                    )
                                }


                                val combinedList = databaseList + serverList

                                //new Value Added in server response
                                val distinctValueFromServer = combinedList.groupBy { it.prospectId }
                                    .filter { it.value.size == 1 }
                                    .flatMap { it.value }


                                val notNewAddedServerValue =
                                    serverList.toSet().minus(distinctValueFromServer.toSet())
                                        .toMutableList()
                                val notNewAddedDatabaseValue =
                                    databaseList.toSet().minus(distinctValueFromServer.toSet())
                                        .toMutableList()

                                val oldChangedData = mutableListOf<LiteFseProspectResponseModel>()

                                notNewAddedServerValue.forEach { itemServer ->

                                    val sameDataInDatabase =
                                        notNewAddedDatabaseValue.find { it.prospectId == itemServer.prospectId }

                                    fun statusUpdateTimeHandler(
                                        oldStatus: LiteFseProspectResponseModel.StatusUpdateTime,
                                        newStatus: LiteFseProspectResponseModel.StatusUpdateTime,
                                        oldFseProspectResponseModel: LiteFseProspectResponseModel
                                    )
                                            : LiteFseProspectResponseModel.StatusUpdateTime {
                                        var revisedStatus = oldStatus

                                        if (!newStatus.prospect.isNullOrEmpty()) {
                                            revisedStatus.prospect = newStatus.prospect
                                        }

                                        if (!newStatus.otpApproved.isNullOrEmpty()) {
                                            revisedStatus.otpApproved = newStatus.otpApproved
                                        }


                                        if (!newStatus.preApprovedProspect.isNullOrEmpty()) {
                                            revisedStatus.preApprovedProspect =
                                                newStatus.preApprovedProspect
                                        }

                                        if (!newStatus.checkedIn.isNullOrEmpty()) {
                                            revisedStatus.checkedIn = newStatus.checkedIn
                                        }

                                        if (!newStatus.threeWayCallVerification.isNullOrEmpty()) {
                                            revisedStatus.threeWayCallVerification =
                                                newStatus.threeWayCallVerification
                                        }

                                        if (!newStatus.installationPending.isNullOrEmpty()) {
                                            revisedStatus.installationPending =
                                                newStatus.installationPending
                                        }


                                        if (oldFseProspectResponseModel.reattemptedStage == 0) {
                                            //if(oldFseProspectResponseModel.reattemptedStage != 1 || oldFseProspectResponseModel.reattemptedStage != 2){
                                            if (!newStatus.installed.isNullOrEmpty()) {
                                                revisedStatus.installed = newStatus.installed
                                            }

                                            if (!newStatus.installationVerified.isNullOrEmpty()) {
                                                revisedStatus.installationVerified =
                                                    newStatus.installationVerified
                                            }
                                        }

                                        return revisedStatus
                                    }

                                    fun statusUpdateObjectTimeHandler(
                                        oldStatus: List<LiteFseProspectResponseModel.StatusUpdateObjects>,
                                        newStatus: List<LiteFseProspectResponseModel.StatusUpdateObjects>,
                                        oldFseProspectResponseModel: LiteFseProspectResponseModel
                                    )
                                            : List<LiteFseProspectResponseModel.StatusUpdateObjects> {
                                        var revisedStatus = oldStatus
//                                                    Log.e(TAG,"oldStatus ====== $oldStatus")
                                        newStatus.forEach { ns ->

                                            revisedStatus.map { rs ->

                                                if (ns.id.equals(rs.id, true)) {
                                                    if (!ns.visibility!!) {
                                                        rs.visibility = ns.visibility!!
                                                    }
                                                    if (ns.visibility!!) {
                                                        rs.visibility = ns.visibility!!
                                                    }

                                                    if (oldFseProspectResponseModel.reattemptedStage == 0) {
                                                        //if(oldFseProspectResponseModel.reattemptedStage != 1 || oldFseProspectResponseModel.reattemptedStage != 2){
//                                                                if (ns.status == FseProspectiveConstant.ProspectStatus.INSTALLED
//                                                                        || ns.status == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED) {
//                                                        Log.e(
//                                                            TAG,
//                                                            "===Name :: ${oldFseProspectResponseModel.name}==${oldFseProspectResponseModel.reattemptedStage} == ${ns.status}"
//                                                        )
                                                        if (!ns.statusTime.isNullOrBlank()) {
                                                            rs.statusTime = ns.statusTime
                                                        }
//                                                                }

                                                    } else {
                                                        if (!ns.status.equals(
                                                                FseProspectiveConstant.ProspectStatus.INSTALLED,
                                                                true
                                                            )
                                                        ) {
                                                            if (!ns.status!!.equals(
                                                                    FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED,
                                                                    true
                                                                )
                                                            ) {
                                                                Log.e(
                                                                    TAG,
                                                                    "==else=Name :: ${oldFseProspectResponseModel.name}==${oldFseProspectResponseModel.reattemptedStage} == ${ns.status}"
                                                                )
                                                                if (!ns.statusTime.isNullOrBlank()) {
                                                                    rs.statusTime = ns.statusTime
                                                                }
                                                            }

                                                        }
//                                                                if (!ns.statusTime.isNullOrBlank()) {
//                                                                    rs.statusTime = ns.statusTime
//                                                                }
                                                    }

                                                    //
//                                                                if (!ns.statusTime.isNullOrEmpty()) {
//                                                                    rs.statusTime = ns.statusTime!!
//                                                                }
                                                    if (!ns.status.isNullOrEmpty()) {
                                                        rs.status = ns.status!!
                                                    }
                                                    if (!ns.showCaseName.isNullOrEmpty()) {
                                                        rs.showCaseName = ns.showCaseName!!
                                                    }


                                                }


                                            }


                                        }


                                        return revisedStatus
                                    }

                                    fun statusHandler(
                                        oldStatus: String,
                                        newStatus: String
                                    ): String {
                                        var revisedStatus = ""

                                        when (oldStatus) {
//

                                            /*new changes*/

                                            FseProspectiveConstant.ProspectStatus.PROSPECT -> {
//
                                                if (newStatus == FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.PROSPECT
                                                }

                                            }

                                            FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL -> {
                                                if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.THREE_WAY_CALL
                                                }
                                            }
                                            FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING -> {
                                                if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLED) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLED
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                }
                                            }
                                            FseProspectiveConstant.ProspectStatus.INSTALLED -> {
                                                if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                                } else if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLED
                                                }
                                            }
                                            FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED -> {

                                                if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_VERIFIED
                                                }
                                            }

                                            FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT -> {

                                                if (newStatus == FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING) {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_PENDING
                                                } else {
                                                    revisedStatus =
                                                        FseProspectiveConstant.ProspectStatus.INSTALLATION_REATTEMPT
                                                }
                                            }

                                            else -> {
                                                revisedStatus =
                                                    FseProspectiveConstant.ProspectStatus.PROSPECT
                                            }

                                        }

                                        return revisedStatus
                                    }

                                    sameDataInDatabase?.let {

                                        sameDataInDatabase.approved = itemServer.approved
                                        sameDataInDatabase.message = itemServer.message
                                        sameDataInDatabase.customerAddress =
                                            itemServer.customerAddress

                                        sameDataInDatabase.name = itemServer.name
                                        sameDataInDatabase.otp = itemServer.otp
                                        sameDataInDatabase.productName = itemServer.productName
                                        sameDataInDatabase.status = statusHandler(
                                            sameDataInDatabase.status!!,
                                            itemServer.status!!
                                        )
                                        sameDataInDatabase.statusUpdateTime =
                                            statusUpdateTimeHandler(
                                                sameDataInDatabase.statusUpdateTime!!,
                                                itemServer.statusUpdateTime!!,
                                                sameDataInDatabase
                                            )

                                        sameDataInDatabase.ticketType = itemServer.ticketType
                                        sameDataInDatabase.accountNumber = itemServer.accountNumber
                                        sameDataInDatabase.installationPicture =
                                            itemServer.installationPicture
                                        sameDataInDatabase.customerPhoneNumber =
                                            itemServer.customerPhoneNumber
                                        sameDataInDatabase.area = itemServer.area
                                        sameDataInDatabase.latitude = itemServer.latitude
                                        sameDataInDatabase.longitude = itemServer.longitude
                                        sameDataInDatabase.prospectUpdatedAt =
                                            itemServer.prospectUpdatedAt ?: ""

                                        sameDataInDatabase.statusUpdateObjects =
                                            statusUpdateObjectTimeHandler(
                                                sameDataInDatabase.statusUpdateObjects!!,
                                                itemServer.statusUpdateObjects!!,
                                                sameDataInDatabase
                                            )
//                                                    sameDataInDatabase.installationPictures = itemServer.installationPictures
                                        sameDataInDatabase.sampleImages = itemServer.sampleImages

                                        //is uncommented by rahul 20-0ct-2021 because image rejcet was not updating
                                        sameDataInDatabase.installationPictures =
                                            itemServer.installationPictures

                                        oldChangedData.add(sameDataInDatabase)

                                    }
                                    //need to add some new attributes here
                                }

                                //it is comment by rahul just to check the value of isReject not updating 20-0ct-2021
                                val resultData = distinctValueFromServer + oldChangedData
                                /* val resultData =  if(distinctValueFromServer.isNullOrEmpty()){
                                     oldChangedData}else{
                                     distinctValueFromServer
                                 }*/

                                Log.e(
                                    "jfhjkshdfhjshfg",
                                    "${resultData.map { it.installationPictures?.map { it.isRejected } }}"
                                )
                                if (resultData.isNotEmpty()) {

                                    //data.postValue(value)
                                    value!!.responseData!!.prospects = resultData
                                    fseProspectiveFromServerLogic(data, value!!)

                                } else {
                                    data.postValue(
                                        NewCommonResponseModel<LiteFseProspectResponseData>(
                                            error = NewCommonResponseModel.Error(
                                                messageToUser = "Unable get data from server"
                                            ),
                                            success = false
                                        )
                                    )
                                }
                            }, {
                                Log.d(TAG, "Error-1: ${it.localizedMessage}");

                                data.postValue(
                                    NewCommonResponseModel<LiteFseProspectResponseData>(
                                        error = NewCommonResponseModel.Error(
                                            messageToUser = "Unable get data from server"
                                        ),
                                        success = false
                                    )
                                )

                                it.printStackTrace()
                            })
                    }
                }.doOnError {
                    Log.d(TAG, "Error-1: ${it.localizedMessage}");
                    data.postValue(
                        NewCommonResponseModel<LiteFseProspectResponseData>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from server"
                            ),
                            success = false
                        )
                    )
//                    it.printStackTrace()
                }.subscribe({
//                    Log.d(TAG, " on Success ===");
                }, {
                    Log.d(TAG, " Error:${it.printStackTrace()}");
                })

        )

        return data
    }

    //region Sync
    fun getAwsImageModelsFromDatabase(): MutableLiveData<List<LiteAwsImageModel>> {

        val data = MutableLiveData<List<LiteAwsImageModel>>()
        bag.add(
            localDb?.liteAwsImageModelDao()?.getAll()!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(it)
                }, {
                    data.postValue(null)
                })
        )

        return data
    }

    fun getInstallationRequestModelFromDatabaseById(awsImageModels: List<LiteAwsImageModel>): MutableLiveData<List<LiteInstallationRequestModel>> {

        val data = MutableLiveData<List<LiteInstallationRequestModel>>()

        var installationRequestsByIds = mutableListOf<LiteInstallationRequestModel>()

        Log.d(TAG, "DEMO:0 ");

        bag.add(

            localDb?.liteInstallationRequestDao()
                ?.getAllByProspectId(awsImageModels.map { it.prospectId })!!
                .flatMapCompletable {
                    installationRequestsByIds = it.toMutableList()
                    installationRequestsByIds.forEach { request ->

                        val sameAwsImageModelFilter =
                            awsImageModels.filter { it.prospectId == request.prospectId }
                        Log.d(TAG, "sameAwsImageModelFilter:1  ==== $sameAwsImageModelFilter")
                        sameAwsImageModelFilter.let {
                            /*new tried*/
                            it.forEach { list ->
                                request.images!!.map {
                                    if (it.imageName == list.imageName) {
                                        it.installationPictures = list.awsLink
                                    }
                                }
                            }
                        }
                    }

                    Completable.fromAction {
                        localDb!!.liteInstallationRequestDao().insertAll(installationRequestsByIds)
                    }

                }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "DEMO:2 ");
                    data.postValue(installationRequestsByIds)
                }, {

                    Log.d(TAG, "DEMO:3 ${it.localizedMessage}");
                    data.postValue(null)
                })
        )

        return data
    }

    fun getAllInOne2(): MutableLiveData<SyncCombineModel> {
        val data = MutableLiveData<SyncCombineModel>()

        var syncCombineModel = SyncCombineModel()
        bag.add(
            localDb?.liteOtpApprovalRequestDao()?.getAll()?.flatMap {
                syncCombineModel.otpApprovalRequestModels = it
                localDb?.liteRegistrationCheckInRequestDao()?.getAll()!!.flatMap {
                    syncCombineModel.registrationCheckinRequestModels = it
                    localDb?.liteInstallationRequestDao()?.getAll()!!
                }
            }!!.subscribe({
                syncCombineModel.installationRequestModels = it
                data.postValue(syncCombineModel)
            }, {

                it.printStackTrace()
            })
        )

        return data

    }


    fun getAllInOne(): MutableLiveData<SyncCombineModel> {
        val data = MutableLiveData<SyncCombineModel>()

        val syncCombineModel = SyncCombineModel()
        bag.add(localDb?.liteFseProspectResponseDao()?.getAllIsChanged()?.flatMap { isChangedFse ->

            Log.d(TAG, "s1: $isChangedFse");
            Log.d(TAG, "s5: ${isChangedFse.map { it.prospectId }}");

            localDb?.liteOtpApprovalRequestDao()
                ?.getAllByProspectID(isChangedFse.map { it.prospectId })
                ?.flatMap { otpApprovalRequests ->
                    Log.d(TAG, "s2: $otpApprovalRequests");
                    syncCombineModel.otpApprovalRequestModels = otpApprovalRequests
                    localDb?.liteRegistrationCheckInRequestDao()
                        ?.getAllByProspectId(isChangedFse.map { it.prospectId })!!
                        .flatMap { registrationCheckins ->
                            Log.d(TAG, "s3: $registrationCheckins")
                            syncCombineModel.registrationCheckinRequestModels = registrationCheckins
                            localDb?.liteInstallationRequestDao()
                                ?.getAllByProspectId(isChangedFse.map { it.prospectId })!!
                        }
                }

        }!!.subscribe({
            Log.d(TAG, "s4: $it")
            syncCombineModel.installationRequestModels = it
            data.postValue(syncCombineModel)
        }, {
            it.printStackTrace()
        })
        )

        return data
    }


    fun processSyncAll(
        otpList: MutableList<LiteOtpApprovalRequestModel>,
        registrationCheckinList: MutableList<LiteRegistrationCheckinRequestModel>,
        installationRequestList: MutableList<LiteInstallationRequestModel>
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()


        val requests = mutableListOf<Observable<out List<Parcelable>>>()

        if (!otpList.isNullOrEmpty()) {
            requests.add(verificationRepo.processAll(otpList).toObservable())
        }


        if (!registrationCheckinList.isNullOrEmpty()) {
            requests.add(registrationRepo.processAll(registrationCheckinList).toObservable())
        }


        if (!installationRequestList.isNullOrEmpty()) {
            requests.add(installationRepo.processAll(installationRequestList).toObservable())
        }


        Log.d(TAG, "requests-realsize:${requests.size} ");

        bag.add(

            Observable.zip(requests)
            {
                //Log.d(TAG, "requests-newsize:${it.get(1)} ");
                data.postValue(
                    NewCommonResponseModel<NewEmptyParcelable>(
                        success = true
                    )
                )

            }.subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.d(TAG, "DB-EO-List2: ${it}")
                    data.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            success = true
                        )
                    )
                }, { t ->
//                    t.printStackTrace()

                    //data.postValue(null)
                    data.postValue(
                        NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )
                    Log.d(TAG, "API-Error: ${t.localizedMessage}")
                })

        )

        return data

    }
    //endregion Sync

    fun awsRX(
        context: Context,
        requestModel: BaseRequestModel
    ): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
        val data = MutableLiveData<CommonResponseModel<AWSResponseModel>>()

        bag.add(
            ServiceInstance.getInstance(context).service!!.awsRx(requestModel)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "||=======${it}")
                    data.postValue(it)

                }, {
                    Log.e(TAG, "||=======EROORRRR = $it")
                    data.postValue(
                        CommonResponseModel<AWSResponseModel>().apply {
                            this.Error =
                                com.greenlightplanet.kazi.member.Error(MessageToUser = "Unable to send data to server")
                            this.Success = false
                        }
                    )
                })
        )

        return data

    }

    /*new in Collection revamp*/
    //region prospect call details
    fun getProspectCallDetails(prospectId: String): MutableLiveData<NewCommonResponseModel<ProspectCallDetailsModel>> {

        val data = MutableLiveData<NewCommonResponseModel<ProspectCallDetailsModel>>()
        bag.add(
            ServiceInstance.getInstance(context).service?.getProspectCallDetails(prospectId = prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({ success ->
                    Log.d(TAG, "getProspectCallDetails - success: ${success}")
//                            data.postValue(success)
                    insertProspectCallDetailsResponseToDb(prospectId, success, data)
                    data.postValue(
                        NewCommonResponseModel(
                            responseData = success.responseData, success = true
                        )
                    )

                }, { t ->
                    data.postValue(
                        NewCommonResponseModel<ProspectCallDetailsModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "No Data Available"
                            ),
                            success = false
                        )
                    )
                })
        )
        return data
    }

    private fun insertProspectCallDetailsResponseToDb(
        prospectId: String, data: NewCommonResponseModel<ProspectCallDetailsModel>,
        liveData: MutableLiveData<NewCommonResponseModel<ProspectCallDetailsModel>>
    ): Disposable {
        Log.d(TAG, "insertProspectCallDetailsResponseToDb - Outer")
        return Flowable.fromCallable {
            if (!data.responseData!!.prospectCallDetails.isNullOrEmpty()) {
                data.responseData!!.prospectCallDetails.forEach {
                    it.prospectId = prospectId
                }
                localDb?.prospectCallDetailsModelDao()
                    ?.insertAll(data.responseData!!.prospectCallDetails)
            }
        }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe({
                if (data.responseData != null) {
                    Log.d(TAG, "insertProspectCallDetailsResponseToDb - success: ${data}")
                    liveData.postValue(
                        NewCommonResponseModel(
                            responseData = data.responseData, success = true
                        )
                    )
                } else {
                    liveData.postValue(
                        NewCommonResponseModel<ProspectCallDetailsModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "No Data Available"
                            ),
                            success = true
                        )
                    )
                }
            }, { t ->
                Log.d(TAG, "insertProspectCallDetailsResponseToDb - Error: ${t.localizedMessage}")
                liveData.postValue(
                    NewCommonResponseModel<ProspectCallDetailsModel>(
                        error = NewCommonResponseModel.Error(
                            messageToUser = "No Data Available"
                        ),
                        success = false
                    )
                )

            })
    }

    fun getProspectCallDetailsFromDatabase(prospectId: String): MutableLiveData<NewCommonResponseModel<ProspectCallDetailsModel>> {

        val data = MutableLiveData<NewCommonResponseModel<ProspectCallDetailsModel>>()


        bag.add(

            localDb?.prospectCallDetailsModelDao()?.getAllByProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    data.postValue(
                        NewCommonResponseModel(
                            responseData = ProspectCallDetailsModel(it), success = true
                        )
                    )
                }, {
                    data.postValue(
                        NewCommonResponseModel<ProspectCallDetailsModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "No Data Available"
                            ),
                            success = false
                        )
                    )
                })
        )

        return data
    }

    //endregion


    fun getAllFSE(): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>? {

        val data = MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseData>>()


        localDb?.let { appDatabase ->
            bag.add(

                appDatabase.liteFseProspectResponseDao().getAll()
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        Log.d(TAG, "DB-EO-List: ${it}")
                        data.postValue(
                            NewCommonResponseModel<LiteFseProspectResponseData>(
                                responseData = LiteFseProspectResponseData(prospects = it),
                                success = true
                            )
                        )
                    }, { t ->
                        Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        data.postValue(
                            NewCommonResponseModel<LiteFseProspectResponseData>(
                                error = NewCommonResponseModel.Error(
                                    messageToUser = "Unable to find data in database"
                                ),
                                success = false
                            )
                        )
                    })

            )
        }

        return data
    }


    public fun sendFakeLocationRequestToServer(
        context: Context,
        angazaId: String,
        fakeLocationRequest: FakeLocationRequest
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        if (Util.isOnline(context)) {
            bag.add(
                ServiceInstance.getInstance(context).service!!.postFakeLocationLog(
                    angazaId,
                    fakeLocationRequest
                )
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({
                        Log.e(
                            TAG,
                            "||FAKEAPIRESPONSE=======${it}"
                        )
                        data.postValue(it)

                    }, {
                        Log.e(
                            TAG,
                            "||=======EROORRRR = $it"
                        )
                        data.postValue(NewCommonResponseModel<NewEmptyParcelable>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false

                        ))
                    })
            )
        }
        return data
    }

    fun getSingleProspect(prospectId: String): MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>> {

        val data = MutableLiveData<NewCommonResponseModel<LiteFseProspectResponseModel>>()


        bag.add(
            localDb?.liteFseProspectResponseDao()?.getByProspectId(prospectId)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
//                .doFinally { data.postValue(combineModel) }
                .subscribe({
//                    data.postValue(it)
                    data.postValue(NewCommonResponseModel(success = true, responseData = it))
                }, {

                    Log.d(TAG, "ERROR:${it.localizedMessage} ");
                    data.postValue(
                        NewCommonResponseModel<LiteFseProspectResponseModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable get data from server"
                            ),
                            success = false
                        )
                    )
                })
        )
        return data
    }

    fun destroy() {

        Log.d(TAG, "Repo : Destroyed");
        registrationRepo.destroy()
        verificationRepo.destroy()
        bag.clear()

    }

}

