package com.greenlightplanet.kazi.agentReferral.model.referralStatus


import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Entity(tableName = "Referral")
@Parcelize
data class Referral(

    @PrimaryKey(autoGenerate = false)
    @SerializedName("id")
    var id: Int?,
    @ColumnInfo(name = "angaza_account_ticket_id")
    @SerializedName("angaza_account_ticket_id")
    var angazaAccountTicketId: Int?,
    @ColumnInfo(name = "angaza_prospect_attempt")
    @SerializedName("angaza_prospect_attempt")
    var angazaProspectAttempt: Int?,
    @ColumnInfo(name = "angaza_prospect_url")
    @SerializedName("angaza_prospect_url")
    var angazaProspectUrl: String?,
    @ColumnInfo(name = "area")
    @SerializedName("area")
    var area: String?,
    @ColumnInfo(name = "child_angaza_id")
    @SerializedName("child_angaza_id")
    var childAngazaId: String?,
    @ColumnInfo(name = "child_phone_number")
    @SerializedName("child_phone_number")
    var childPhoneNumber: String?,
    @ColumnInfo(name = "country")
    @SerializedName("country")
    var country: String?,
    @ColumnInfo(name = "created_at")
    @SerializedName("created_at")
    var createdAt: String?,
    @ColumnInfo(name = "current_stage")
    @SerializedName("current_stage")
    var currentStage: String?,
    @ColumnInfo(name = "fail_type")
    @SerializedName("fail_type")
    var failType: String?,
    @ColumnInfo(name = "first_screening_ticket_id")
    @SerializedName("first_screening_ticket_id")
    var firstScreeningTicketId: Int?,
    @ColumnInfo(name = "first_screening_ticket_url")
    @SerializedName("first_screening_ticket_url")
    var firstScreeningTicketUrl: String?,
    @ColumnInfo(name = "name")
    @SerializedName("name")
    var name: String?,
    @ColumnInfo(name = "parent_angaza_id")
    @SerializedName("parent_angaza_id")
    var parentAngazaId: String?,
    @ColumnInfo(name = "parent_phone_number")
    @SerializedName("parent_phone_number")
    var parentPhoneNumber: String?,
    @ColumnInfo(name = "parent_role")
    @SerializedName("parent_role")
    var parentRole: String?,
    @ColumnInfo(name = "prospect_qid")
    @SerializedName("prospect_qid")
    var prospectQid: String?,
    @ColumnInfo(name = "reason")
    @SerializedName("reason")
    var reason: String?,
    @ColumnInfo(name = "referred_date_timestamp")
    @SerializedName("referred_date_timestamp")
    var referredDateTimeStamp : String?,
    @ColumnInfo(name = "score")
    @SerializedName("score")
    var score: Int?,
    @ColumnInfo(name = "second_screening_ticket_id")
    @SerializedName("second_screening_ticket_id")
    var secondScreeningTicketId: Int?,
    @ColumnInfo(name = "second_screening_ticket_url")
    @SerializedName("second_screening_ticket_url")
    var secondScreeningTicketUrl: String?,
    @ColumnInfo(name = "status")
    @SerializedName("status")
    var status: String?,
    @ColumnInfo(name = "updated_at")
    @SerializedName("updated_at")
    var updatedAt: String?,
    @ColumnInfo(name = "username")
    @SerializedName("username")
    var username: String?,
    @ColumnInfo(name = "verification_attempt")
    @SerializedName("verification_attempt")
    var verificationAttempt: Int?,
    @ColumnInfo(name = "verified")
    @SerializedName("verified")
    var verified: Boolean?,
    @ColumnInfo(name = "welcome_call_attempt")
    @SerializedName("welcome_call_attempt")
    var welcomeCallAttempt: Int?,
    @ColumnInfo(name = "welcome_ticket_id")
    @SerializedName("welcome_ticket_id")
    var welcomeTicketId: Int?
) : Parcelable