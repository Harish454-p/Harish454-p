package com.greenlightplanet.kazi.fse.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.greenlightplanet.kazi.fse.extras.util.DateConversionUtil.Companion.getCurrentDate
import com.greenlightplanet.kazi.fse.extras.util.DateConversionUtil.Companion.getMilliseconds
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.fse.model.FseHistory
import com.greenlightplanet.kazi.fse.model.FseHistoryResponse
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.AppDatabase
import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class PastFseCommitmentRepo(val context: Context) {


    companion object :
            SingletonHolderUtil<PastFseCommitmentRepo, Context>(::PastFseCommitmentRepo) {
        public const val TAG = "PastFseCommitmentRepo"

    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private val localDb = AppDatabase.getAppDatabase(context)

    //working
    /*fun getFseHistroyFromServer(): MutableLiveData<List<FseHistory>?> {

        val data = MutableLiveData<List<FseHistory>?>()

        bag.add(

                ServiceInstance.getInstance(context).service?.getFseHistory(url = "http://demo8859911.mockable.io/fse-history/US0101")!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success.responseData?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")

                                bag.add(

                                        //localDb.fseDao().deleteAll().toCompletable()
                                        Completable.fromAction { localDb.fseHistoryDao().deleteAll() }
                                                .subscribeOn(Schedulers.io())
                                                .observeOn(Schedulers.io())
                                                .subscribe({

                                                    Log.d(TAG, "Deletion:Completed ")

                                                    bag.add(
                                                            //localDb.fseDao().insertAll(responseData.fseList!!).toSingle()
                                                            Completable.fromAction { localDb.fseHistoryDao().insertAll(responseData.fseHistory!!) }
                                                                    .subscribeOn(Schedulers.io())
                                                                    .observeOn(Schedulers.io())
                                                                    .subscribe({
                                                                        Log.d(TAG, "Insertion:Completed ")
                                                                        data.postValue(responseData.fseHistory as List<FseHistory>?)
                                                                    }, { t ->
                                                                        Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                                                    })
                                                    )

                                                }, { t ->
                                                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                                })
                                )

                            }

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        })
        )

        return data
    }*/

    //working
    /*fun getFseHistroyFromServer(): MutableLiveData<List<FseHistory>?> {

        val data = MutableLiveData<List<FseHistory>?>()

        bag.add(

                ServiceInstance.getInstance(context).service?.getFseHistory(url = "http://demo8859911.mockable.io/fse-history/US0101")!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success.responseData?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")

                                bag.add(

                                        //delete all old fseHistory
                                        Completable.fromAction { localDb.fseHistoryDao().deleteAll() }
                                                .subscribeOn(Schedulers.io())
                                                .observeOn(Schedulers.io())
                                                .subscribe({

                                                    Log.d(TAG, "Deletion:Completed ")

                                                    bag.add(

                                                            //1: add long millisecond date for each fseHistory
                                                            //2: then insert the fesHistory to database
                                                            Completable.fromAction {
                                                                responseData.fseHistory?.forEach {
                                                                    it?.date = it?.getFormattedDate(it.paymentDateFormatted)
                                                                }
                                                                localDb.fseHistoryDao().insertAll(responseData.fseHistory!!)
                                                            }.doOnComplete {

                                                                Log.d(TAG, "CurrentDateMilli: ${getMilliseconds(getCurrentDate())} ")

                                                                //get only today's fesHistory
                                                                queryByDate(fromDate = getMilliseconds(getCurrentDate()), toDate = getMilliseconds(getCurrentDate()))

                                                                        .doOnSuccess {
                                                                            Log.d(TAG, "DB-Success: $it")
                                                                            //send today's data to live-data
                                                                            data.postValue(it)
                                                                        }
                                                                        .doOnError {
                                                                            Log.d(TAG, "DB-Error: ${it.localizedMessage}")
                                                                        }
                                                                        .subscribe()

                                                            }.doOnError {
                                                                Log.d(TAG, "DB-Error: ${it.localizedMessage}")
                                                            }.subscribe()

                                                    )

                                                }, { t ->
                                                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                                })
                                )

                            }

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        })
        )

        return data
    }*/

    //working
    /*fun getFseHistroyFromServer(): MutableLiveData<List<FseHistory>?> {

        val data = MutableLiveData<List<FseHistory>?>()

        bag.add(

                ServiceInstance.getInstance(context).service?.getFseHistory(url = "http://demo8859911.mockable.io/fse-history/US0101?fromDate=${getMilliseconds(getCurrentDate())}&toDate=${getMilliseconds(getCurrentDate())}")!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success.responseData?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")

                                bag.add(

                                        //delete all old fseHistory
                                        Completable.fromAction { localDb.fseHistoryDao().deleteAll() }
                                                .subscribeOn(Schedulers.io())
                                                .observeOn(Schedulers.io())
                                                .subscribe({

                                                    Log.d(TAG, "Deletion:Completed ")

                                                    bag.add(

                                                            //1: add long millisecond date for each fseHistory
                                                            //2: then insert the fesHistory to database
                                                            Completable.fromAction {
                                                                responseData.fseHistory?.forEach {
                                                                    it?.date = it?.getFormattedDate(it.paymentDateFormatted)
                                                                }
                                                                localDb.fseHistoryDao().insertAll(responseData.fseHistory!!)
                                                            }.doOnComplete {

                                                                Log.d(TAG, "CurrentDateMilli: ${getMilliseconds(getCurrentDate())} ")

                                                                data.postValue(responseData.fseHistory as List<FseHistory>?)

                                                                //get only today's fesHistory
                                                                *//*queryByDate(fromDate = getMilliseconds(getCurrentDate()), toDate = getMilliseconds(getCurrentDate()))

                                                                        .doOnSuccess {
                                                                            Log.d(TAG, "DB-Success: $it")
                                                                            //send today's data to live-data
                                                                            data.postValue(it)
                                                                        }
                                                                        .doOnError {
                                                                            Log.d(TAG, "DB-Error: ${it.localizedMessage}")
                                                                        }
                                                                        .subscribe()*//*

                                                            }.doOnError {
                                                                Log.d(TAG, "DB-Error: ${it.localizedMessage}")
                                                            }.subscribe()

                                                    )

                                                }, { t ->
                                                    Log.d(TAG, "DB-Error: ${t.localizedMessage}")
                                                })
                                )

                            }

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        })
        )

        return data
    }*/


    //todo working now
    /*fun getFseByDateFromServer(
            angazaId: String,
            fromDate: String,
            toDate: String
    ): MutableLiveData<List<FseHistory>?> {

        val data = MutableLiveData<List<FseHistory>?>()

        bag.add(

                ServiceInstance.getInstance(context).service?.getFseHistory(angazaId, fromDate, toDate)!!
                        //ServiceInstance.getInstance(context).service?.getFseHistory(fromDate:String,toDate:String)!!
                        //ServiceInstance.getInstance(context).service?.getFseHistory(url = "http://demo8859911.mockable.io/fse-history/US0101?fromDate=$fromDate&toDate=$toDate")!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success.responseData?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")

                                bag.add(

                                        *//*Completable.fromAction{
                                        }.doOnComplete {
                                        }*//*

                                        Completable.fromAction {
                                            localDb.fseHistoryDao().deleteAll()
                                            responseData.fseHistory?.forEach {
                                                it?.date = it?.getFormattedDate(it.paymentDateFormatted)
                                            }
                                            localDb.fseHistoryDao().insertAll(responseData.fseHistory!!)
                                        }.doOnComplete {

                                            Log.d(TAG, "CurrentDateMilli: ${getMilliseconds(getCurrentDate())} ")

                                            data.postValue(responseData.fseHistory as List<FseHistory>?)

                                        }.doOnError {
                                            Log.d(TAG, "DB-Error: ${it.localizedMessage}")
                                        }.subscribe()


                                )

                            }

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        })
        )

        return data
    }*/


    //todo new
    fun getNewFseByDateFromServer(
            angazaId: String,
            fromDate: String,
            toDate: String
    ): MutableLiveData<FseHistoryResponse.ResponseData> {

        val data = MutableLiveData<FseHistoryResponse.ResponseData>()

        bag.add(

                ServiceInstance.getInstance(context).service?.getFseHistory(angazaId, fromDate, toDate)!!
                        //ServiceInstance.getInstance(context).service?.getFseHistory(fromDate:String,toDate:String)!!
                        //ServiceInstance.getInstance(context).service?.getFseHistory(url = "http://demo8859911.mockable.io/fse-history/US0101?fromDate=$fromDate&toDate=$toDate")!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            success.responseData?.let { responseData ->

                                Log.d(TAG, "Response: ${success}")

                                bag.add(

                                        /*Completable.fromAction{
                                        }.doOnComplete {
                                        }*/

                                        Completable.fromAction {
                                            localDb.fseHistoryDao().deleteAll()
                                            localDb.fseHistoryResponseDataDao().deleteAll()
                                            responseData.fseHistory?.forEach {
                                                it?.date = it?.getFormattedDate(it.paymentDateFormatted)
                                            }
                                            localDb.fseHistoryDao().insertAll(responseData.fseHistory!!)
                                            localDb.fseHistoryResponseDataDao().insert(responseData)
                                        }.doOnComplete {

                                            Log.d(TAG, "CurrentDateMilli: ${getMilliseconds(getCurrentDate())} ")

                                            data.postValue(responseData)

                                        }.doOnError {
                                            Log.d(TAG, "DB-Error: ${it.localizedMessage}")
                                        }.subscribe()


                                )

                            }

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")

                            data.postValue(null)

                        })
        )

        return data
    }

    //todo working
    /*fun getFseByDateFromDatabase(
            fromDate: String,
            toDate: String
    ): MutableLiveData<List<FseHistory>?> {

        val data = MutableLiveData<List<FseHistory>?>()

        bag.add(
                queryByDate(fromDate = getMilliseconds(fromDate), toDate = getMilliseconds(toDate))
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->

                            Log.d(TAG, "DB-FSE-List: ${success}")

                            data.postValue(success)

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        })
        )

        return data
    }*/


    //todo new
    fun getNewFseByDateFromDatabase(
            fromDate: String,
            toDate: String
    ): MutableLiveData<FseHistoryResponse.ResponseData> {

        val data = MutableLiveData<FseHistoryResponse.ResponseData>()

        bag.add(

                localDb.fseHistoryResponseDataDao().get().flatMap { responseData ->
                    queryByDate(fromDate = getMilliseconds(fromDate), toDate = getMilliseconds(toDate))
                            .subscribeOn(Schedulers.io())
                            .observeOn(Schedulers.io())
                            .doOnSuccess { list ->

                                Log.d(TAG, "DB-FSE-List: ${list}")
                                responseData.fseHistory = list

                                data.postValue(responseData)

                            }.doOnError { t ->
                                Log.d(TAG, "API-Error: ${t.localizedMessage}")
                                data.postValue(null)

                            }
                    /*.subscribe({ success ->

                        Log.d(TAG, "DB-FSE-List: ${success}")

                        data.postValue(success)

                    }, { t ->
                        Log.d(TAG, "API-Error: ${t.localizedMessage}")
                    })*/
                }.subscribe({}, { t ->
                    data.postValue(null)
                    Log.d(TAG, "API-Error: ${t.localizedMessage}")
                })


        )

        return data
    }

    private fun queryByDate(
            fromDate: Long,
            toDate: Long
    ): Single<List<FseHistory>> {
        return localDb.fseHistoryDao().getByDate(fromDate, toDate)
    }


    //working
    /*fun getFseByDateFromDatabase(
            fromDate: Long,
            toDate: Long
    ): MutableLiveData<List<FseHistory>?> {

        val data = MutableLiveData<List<FseHistory>?>()

        bag.add(
                localDb.fseHistoryDao().getByDate(fromDate, toDate)
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->

                            Log.d(TAG, "DB-FSE-List: ${success}")

                            data.postValue(success)

                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        })
        )

        return data

    }*/


    fun destroy() {

        Log.d(TAG, "Repo : Distroyed");
        bag.clear()

    }
}
