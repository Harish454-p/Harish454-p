package com.greenlightplanet.kazi.incentivenew.adapter


import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ReferelListTemBinding
import com.greenlightplanet.kazi.incentivenew.model.reffrel.ReferredAgents
import com.greenlightplanet.kazi.utils.Util


/**
 * Created by Rahul on 03/12/20.
 */
class ReferalAdapter(private val listData: List<ReferredAgents>, var listener: MyDateData,
                     var context: Context
) : RecyclerView.Adapter<ReferalAdapter.ViewHolder?>() {
    private val viewPool = RecyclerView.RecycledViewPool()
    private var lastPosition = -1

    override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
    ): ViewHolder {
        val itemBinding = ReferelListTemBinding.inflate( LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(itemBinding,listener)
    }

    @SuppressLint("WrongConstant")
    override fun onBindViewHolder(
            holder: ViewHolder,
            position: Int
    ) {
        val myListData: ReferredAgents = listData[position]

       holder.bind(myListData)
      //  setAnimation(holder.itemView,position)
    }

    override fun getItemCount(): Int {
        return listData.size
    }

    class ViewHolder(val itemBinding:  ReferelListTemBinding,val listener: MyDateData) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(myListData: ReferredAgents) {
            itemBinding.tvAgentNameValue?.text = myListData.refferedAgentName
            itemBinding.tvAngazaValue?.text = Util.formatAmount(myListData.unitSold.toDouble())

        }

        var agent: TextView? = null
        var angaza: TextView? = null


        init {
            agent = itemView.findViewById(R.id.tvAgentNameValue)
            angaza = itemView.findViewById(R.id.tvAngazaValue)

        }
    }

    interface MyDateData {

        fun selectedData(date: String, position: Int)


    }
    private fun setAnimation(viewToAnimate: View, position: Int) {
        if (position > lastPosition) {
            val animation = AnimationUtils.loadAnimation(context, android.R.anim.slide_in_left)
            viewToAnimate.startAnimation(animation)
            lastPosition = position
        }
    }
}