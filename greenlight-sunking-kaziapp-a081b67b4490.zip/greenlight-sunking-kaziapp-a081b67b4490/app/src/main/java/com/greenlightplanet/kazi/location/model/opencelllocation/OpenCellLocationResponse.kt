package com.greenlightplanet.kazi.location.model.opencelllocation


import com.google.gson.annotations.SerializedName

data class OpenCellLocationResponse(
    @SerializedName("accuracy")
    var accuracy: Int?, // 730
    @SerializedName("address")
    var address: String?, // 1289-1425 West Mineral Avenue, Littleton, CO 80120, USA
    @SerializedName("balance")
    var balance: Int?, // 100
    @SerializedName("lat")
    var lat: Double?, // 39.573726
    @SerializedName("lon")
    var lon: Double?, // -105.005387
    @SerializedName("status")
    var status: String? // ok
)
