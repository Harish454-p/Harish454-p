package com.greenlightplanet.kazi.fse.ui.adapter

import android.content.Context
import android.graphics.Color
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.widget.TextView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.fse.model.FseHistory
import com.greenlightplanet.kazi.fse.viewmodel.PastFseCommitmentViewModel
import com.greenlightplanet.kazi.utils.Util
import io.github.luizgrp.sectionedrecyclerviewadapter.SectionParameters
import io.github.luizgrp.sectionedrecyclerviewadapter.StatelessSection

//todo start from here

// call constructor with layout resources for this Section header and items
class PastFseCommitmentAdapter(val context: Context, val headerHistory: PastFseCommitmentViewModel.PastHeaderHistory, val list: List<FseHistory>)
    : StatelessSection(SectionParameters.builder()
        .headerResourceId(R.layout.adapter_past_commitments_header)
        .itemResourceId(R.layout.adapter_past_commitments_value)
        .build()) {


    companion object {
        public const val TAG = "PastFseCommitmentAdapter"
    }

    var pastFseCommitmentAdapter: PastFseCommitmentAdapterCallback? = null

    override fun getContentItemsTotal(): Int {
        return list.size // number of items of this section
    }


    //region getViewHolder for Header and Item  = Note: No work here

    override fun getHeaderViewHolder(view: View): RecyclerView.ViewHolder {
        return HeaderViewHolder(view)
    }

    override fun getItemViewHolder(view: View): RecyclerView.ViewHolder {
        // return a custom instance of ViewHolder for the items of this section
        return ItemViewHolder(view)
    }

    //endregion


    //region BindViewHolder for Header and Item

    override fun onBindHeaderViewHolder(holder: RecyclerView.ViewHolder?) {
        val headerHolder = holder as HeaderViewHolder?

        headerHolder?.tvHeaderDate?.text = Util.parseYYYY_MM_DDtoDD_MM_YYYY(headerHistory.date)

        //todo value changed check this for result
        headerHolder?.tvHeaderValue?.text = context.resources.getString(R.string.past_commitment_header_histroy_value).format(headerHistory.value)

        // bind your header view here
        //todo logic for header

    }

    override fun onBindItemViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val itemHolder = holder as ItemViewHolder

        // bind your view here
        //todo logic for value
        val fseHistory = list[position]

        itemHolder.tvValueUserName.text = fseHistory.customerName
        itemHolder.tvValueValue.text = "NGN ${fseHistory.paidAmount}"

        //if(!(fseHistory.paidAmount!!.toInt() > 0 &&  fseHistory.enabled)){

        //todo make it more efficient
        fseHistory.accountStatus?.let {
            if (fseHistory.accountStatus.equals("ENABLED", true)) {
                itemHolder.tvValueUserName.setTextColor( ContextCompat.getColor(context, R.color.colorGreen))
                itemHolder.tvValueValue.setTextColor( ContextCompat.getColor(context, R.color.colorGreen))
            } else {
                itemHolder.tvValueUserName.setTextColor(Color.RED)
                itemHolder.tvValueValue.setTextColor(Color.RED)
            }
        } ?: kotlin.run {

            itemHolder.tvValueUserName.setTextColor( Color.RED)
            itemHolder.tvValueValue.setTextColor(Color.RED)

        }


    }


    //endregion


    //region ViewHolder for Header and Item
    internal inner class HeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvHeaderDate: TextView = itemView.findViewById(R.id.tv_header_history_date)
        val tvHeaderValue: TextView = itemView.findViewById(R.id.tv_header_history_value)


    }

    internal inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvValueUserName: TextView = itemView.findViewById(R.id.tv_value_history_userName)
        val tvValueValue: TextView = itemView.findViewById(R.id.tv_value_history_value)
    }


    //endregion

    interface PastFseCommitmentAdapterCallback {}


}
