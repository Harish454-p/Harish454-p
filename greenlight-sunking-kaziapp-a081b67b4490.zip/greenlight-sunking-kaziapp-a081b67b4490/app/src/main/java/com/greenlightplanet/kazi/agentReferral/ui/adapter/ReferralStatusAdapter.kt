package com.greenlightplanet.kazi.agentReferral.ui.adapter

import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ReferralConstants
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.addUnderline
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.calendar_format_display
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_error
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_failed
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_in_progress
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_prospect_resub
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.status_success
import com.greenlightplanet.kazi.agentReferral.model.referralStatus.Referral
import com.greenlightplanet.kazi.agentReferral.ui.view.ReferralStatusActivity
import com.greenlightplanet.kazi.databinding.AdapterReferralStatusBinding
import com.greenlightplanet.kazi.utils.Util

class ReferralStatusAdapter(val referralStatusActivity: ReferralStatusActivity, var list : ArrayList<Referral>) : RecyclerView.Adapter<ReferralStatusAdapter.ViewHold>() {

    class ViewHold(val binder : AdapterReferralStatusBinding) : RecyclerView.ViewHolder(binder.root) {
        fun bindInfo(model : Referral, referralStatusActivity: ReferralStatusActivity) {
            binder.run {
                txtParentPhone.text = when(model.parentPhoneNumber) {
                    null,"" -> referralStatusActivity.getString(R.string.na)
                    else -> model.parentPhoneNumber
                }
                txtStage.text = when(model.currentStage) {
                    null, "" -> referralStatusActivity.getString(R.string.na)
                    else -> model.currentStage
                }
                txtReferredDate.text = when(model.referredDateTimeStamp) {
                    null -> referralStatusActivity.getString(R.string.na)
                    "" -> ""
                    else -> {
                        val milDate = (model.referredDateTimeStamp!!.toDouble().toLong()) * 1000
                        DateFormat.format(calendar_format_display, milDate).toString()
                    }
                }
                addUnderline(txtStage)
                when(model.status) {
                    status_success -> txtStage.setTextColor(ContextCompat.getColor(referralStatusActivity, R.color.green))
                    status_error, status_failed -> txtStage.setTextColor(ContextCompat.getColor(referralStatusActivity, R.color.red))
                    status_prospect_resub, status_in_progress -> txtStage.setTextColor(ContextCompat.getColor(referralStatusActivity, R.color.black))
                }
                txtStage.setOnClickListener {
                    referralStatusActivity.onStatusSelected(model = model)
                }
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHold {
        val binder : AdapterReferralStatusBinding = AdapterReferralStatusBinding.inflate(
            LayoutInflater.from(referralStatusActivity),
            parent,
            false
        )
        return ViewHold(binder)
    }

    override fun onBindViewHolder(holder: ViewHold, position: Int) {
        holder.bindInfo(list[position], referralStatusActivity)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    interface OnReferredStatus {
        fun onStatusSelected(model : Referral)
    }
}