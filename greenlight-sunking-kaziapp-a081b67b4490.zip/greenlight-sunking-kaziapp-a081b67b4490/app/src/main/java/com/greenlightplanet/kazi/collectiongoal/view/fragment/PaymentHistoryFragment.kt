package com.greenlightplanet.kazi.collectiongoal.view.fragment

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.KaziApplication
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.collectiongoal.adapter.PaymentHistoryAdapterRecycler
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistory
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistoryModel
import com.greenlightplanet.kazi.collectiongoal.view.activity.CustomerHistoryActivity
import com.greenlightplanet.kazi.collectiongoal.viewmodel.CustomerHistoryViewModel
import com.greenlightplanet.kazi.databinding.FragmentPaymentHistoryBinding
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.utils.BaseFragment
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util


class PaymentHistoryFragment : BaseFragment() {

    private var _binding: FragmentPaymentHistoryBinding? = null
    private val binding get() = _binding!!
    val ARG_PARAM1 = "list"
    val ARG_PARAM2 = "AccountNumber"
    val ARG_PARAM3 = "pageNumber"

    private var list: MutableList<PaymentHistory>? = null
    private var activityInstance: CustomerHistoryActivity? = null

    private val viewModel: CustomerHistoryViewModel by viewModels()

    private var adapterList: MutableList<PaymentHistory> = mutableListOf()
    private var adapter: PaymentHistoryAdapterRecycler? = null
    private var accountNumber: Int? = null
    private var pageNumber:Int = 2
    var previousListSize = 0



    companion object {
        const val TAG = "PaymentHistoryFragment"

        @JvmStatic
        fun newInstance(
            list: List<PaymentHistory>?,
            accountNumberString: Int?,
            nextPagePayment: Int
        ) =
            PaymentHistoryFragment().apply {
                arguments = Bundle().apply {
                    putParcelableArrayList(ARG_PARAM1, ArrayList(list!!))
                    putInt(ARG_PARAM2, accountNumberString!!)
                    putInt(ARG_PARAM3, nextPagePayment)
                    arguments?.clear()
                }
            }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapterList.clear()

        arguments?.let {
            list = it.getParcelableArrayList<PaymentHistory>(ARG_PARAM1)
            accountNumber = it.getInt(ARG_PARAM2)
            pageNumber = it.getInt(ARG_PARAM3)
            arguments?.clear()
        }

    }
    @SuppressLint("LongLogTag")
    val observer = Observer<NewCommonResponseModel<PaymentHistoryModel>> {

        Util.cancelProgressDialog()
        if (viewLifecycleOwner.lifecycle.currentState==Lifecycle.State.RESUMED) {
            if (!it!!.success) {
                Util.cancelProgressDialog()
                binding.tvNoData.visibility = View.VISIBLE
                binding.divider.visibility = View.VISIBLE
                binding.tvViewMore.visibility = View.GONE
            }
            else {
                Util.cancelProgressDialog()
                val paymentDetailsList = it.responseData!!.paymentHistory
                Log.d("PageNumberPaymentHistoryFrag",it.responseData?.next.toString())
                if (paymentDetailsList.isNullOrEmpty()) {
                    binding.tvViewMore.visibility = View.GONE
                }

                if (it.responseData?.next==null || it.responseData?.next==0){
                    binding.tvViewMore.visibility = View.GONE
                }else {
                    pageNumber = it.responseData?.next!!.toInt()
                }

                if (adapterList.isNullOrEmpty() && !paymentDetailsList.isNullOrEmpty()) {
                    if (paymentDetailsList.size > 0) {
                        setAdapter(paymentDetailsList.toMutableList())
                    }
                } else {

                    if (!it.responseData?.paymentHistory.isNullOrEmpty()) {
                        val nextPage: Int = 0
                        val data = MutableLiveData<NewCommonResponseModel<PaymentHistoryModel>>()
                        val list = it.responseData?.paymentHistory?.toMutableList()
                        list?.addAll(adapterList)
                        it.responseData?.paymentHistory = emptyList()
                        it.responseData?.paymentHistory = list!!

                        viewModel.insertPaymentHistoryTargetResponseToDb(it, data, accountNumber, nextPage)
                        Log.d("CheckDataListNew", " ${it.responseData!!.paymentHistory?.size} $it")
                    }

                    previousListSize = adapterList.size
                    paymentDetailsList.let {
                            it1 -> setAdapter(it1 as MutableList<PaymentHistory>) }
                    binding.recyclerView.scrollToPosition(previousListSize-1)
                }
                paymentDetailsList?.isEmpty()?.let { it1 -> setViewMoreVisibility(it1) }
            }
        }
    }

    @SuppressLint("LongLogTag")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentPaymentHistoryBinding.inflate(inflater, container, false)
        activityInstance = (activity as CustomerHistoryActivity?)!!

        KaziApplication.preference = GreenLightPreference.getInstance(activityInstance!!)

        Log.d("PaymentHistoryFragmentList", "success: ${list}")

        Initialize()

        binding.tvViewMore.setOnClickListener {
            Log.d("paymentViewMore","OnClicked:" + "true")

            when(Util.isOnline(requireActivity())){

                true -> {

                    if (pageNumber!=null && pageNumber!=0){
                        Util.showProgressDialog(requireContext())
                        viewModel.getPaymentHistoryData1(accountNumber,pageNumber)
                    }
                }

                false -> {
                    Util.customFseCompletionDialog(
                        context = requireActivity(),
                        hideTitle = true,
                        message = "Please check internet connection",
                        okSelected = {
                            it.dismiss()
                        },
                        title = null
                    )
                }
            }

        }
        if (!viewModel.paymentHistoryDetailsData?.hasActiveObservers()!!) {
            viewModel.paymentHistoryDetailsData?.observe(requireActivity(),observer)
        }


        return binding.root;
    }

    private fun Initialize() {

        when(list.isNullOrEmpty()){
            true -> {
                binding.tvViewMore.visibility = View.GONE
                binding.tvNoData.visibility = View.VISIBLE
                binding.divider.visibility = View.VISIBLE
            }
            false -> {
                initRecyclerView(list!!)
                if (pageNumber==null || pageNumber==0){
                    binding.tvViewMore.visibility = View.GONE
                }else {
                    binding.tvViewMore.visibility = View.VISIBLE
                }
            }
        }



    }

    @SuppressLint("LongLogTag", "NotifyDataSetChanged")
    private fun setAdapter(mutableList: MutableList<PaymentHistory>) {

        Log.d("PreviousListPaymentHistory", "success: ${adapterList.size}")
        Log.d("NewListPaymentHistory", "success: ${mutableList?.size}")

        if (mutableList.isNullOrEmpty()) {

            visibilityHandler(false, true, false)
            binding.tvViewMore.visibility = View.GONE
        }
        else {
            binding.tvNoData.visibility = View.GONE
            binding.divider.visibility = View.GONE
            //adapterList.clear()
            if (!mutableList.isNullOrEmpty()) {
                adapterList.addAll(mutableList)
                Log.d("PaymentAdapterListSize", "adapter : $adapterList")
                adapter = PaymentHistoryAdapterRecycler(requireActivity(), adapterList)
                binding.recyclerView.adapter = adapter
                visibilityHandler(true, false, false)
            }
            adapter?.notifyDataSetChanged()
        }


    }

    private fun setViewMoreVisibility(hideViewMore: Boolean = false) {
        if (adapterList.isEmpty() || adapterList.size == 0) {
            binding.tvNoData.visibility = View.VISIBLE
            binding.divider.visibility = View.VISIBLE
            binding.tvViewMore.visibility = View.GONE
        } else {
            Log.d(TAG, "setViewMoreVisibitlity:adapterList.size => ${adapterList.size}")
            binding.tvNoData.visibility = View.GONE
            binding.divider.visibility = View.GONE
        }

        if (hideViewMore) {
            binding.tvViewMore.visibility = View.GONE
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun initRecyclerView(list: MutableList<PaymentHistory>) {

        val layoutManager = LinearLayoutManager(requireActivity())
        binding.recyclerView.layoutManager = layoutManager
        binding.recyclerView.addItemDecoration(
            DividerItemDecoration(
                requireContext(),
                DividerItemDecoration.VERTICAL
            ).apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    this.setDrawable(
                        resources.getDrawable(
                            R.drawable.line_divider,
                            requireContext().theme
                        )
                    )
                } else {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider))
                }
            })

        setAdapter(list)
    }

    private fun visibilityHandler(
        showRecyclerView: Boolean = false,
        showNoData: Boolean = false,
        viewMore: Boolean = false
    ) {

        if (showRecyclerView) {
            binding.recyclerView.visibility = View.VISIBLE
        } else {
            binding.recyclerView.visibility = View.GONE
        }

        if (showNoData) {
            binding.tvNoData.visibility = View.VISIBLE
            binding.divider.visibility = View.VISIBLE
        } else {
            binding.tvNoData.visibility = View.GONE
            binding.divider.visibility = View.GONE
        }
    }

}

