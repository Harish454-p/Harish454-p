package com.greenlightplanet.kazi.fse.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import com.greenlightplanet.kazi.fse.extras.util.SortType.ASCENDING
import com.greenlightplanet.kazi.fse.extras.util.SortType.DESCENDING
import com.greenlightplanet.kazi.fse.model.Fse
import com.greenlightplanet.kazi.fse.model.FseDetailsResponse
import com.greenlightplanet.kazi.fse.repo.FseCommitmentRepo
import com.greenlightplanet.kazi.fse.ui.FseCommitmentFragment.Companion.SORT_TYPE

class FseCommitmentViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "FseCommitmentViewModel"

    }

    val repo = FseCommitmentRepo.getInstance(application)


    //todo old but working
    /*fun getFseCommitment(context: Context, angazaId: String, showProgress: () -> Unit = {}): MutableLiveData<List<Fse>?>? {
        //fun getFseCommitment(progress: CustomProgress?, context: Context, angazaId: String): MutableLiveData<List<Fse>?>? {

        //progress?.showProgressDialog()
        showProgress()

        if (com.greenlightplanet.kazi.utils.Util.isOnline(context)) {
        //if (com.greenlightplanet.kazi.utils.Util.isInternetAvailable() && com.greenlightplanet.kazi.utils.Util.isOnline(context)) {
            return repo.getFseCommitmentFromServer(angazaId)
        } else {
            return repo.getFseCommitmentFromDatabase()
        }

    }


    //fun postFseCommitment(progress: CustomProgress?, angazaId: String, fseList: List<Fse>): MutableLiveData<List<Fse>?> {
    fun postFseCommitment(angazaId: String, fseList: List<Fse>, showProgress: () -> Unit = {}): MutableLiveData<List<Fse>?> {

        //progress?.showProgressDialog()
        showProgress()
        return repo.postFseCommitmentDetails(angazaId, fseList)

    }*/


    //todo new
    fun getNewFseCommitment(context: Context, angazaId: String, forceOffline: Boolean = false, showProgress: () -> Unit = {}): MutableLiveData<FseDetailsResponse.ResponseData>? {
        //fun getFseCommitment(progress: CustomProgress?, context: Context, angazaId: String): MutableLiveData<List<Fse>?>? {

        //progress?.showProgressDialog()
        showProgress()

        if (forceOffline) {
            return repo.getNewFseCommitmentFromDatabase()
        } else if (com.greenlightplanet.kazi.utils.Util.isOnline(context)) {
            //if (com.greenlightplanet.kazi.utils.Util.isInternetAvailable() && com.greenlightplanet.kazi.utils.Util.isOnline(context)) {
            return repo.getNewFseCommitmentFromServer(angazaId)
        } else {
            return repo.getNewFseCommitmentFromDatabase()
        }

    }

    //todo new
    fun newPostFseCommitment(angazaId: String, fseList: List<Fse>, showProgress: () -> Unit = {}): MutableLiveData<FseDetailsResponse.ResponseData> {

        //progress?.showProgressDialog()
        showProgress()
        return repo.postNewFseCommitmentDetails(angazaId, fseList)

    }


    fun customerNameSortLogic(mutableList: MutableList<Fse>): MutableList<Fse> {

        if (SORT_TYPE == ASCENDING) {
            mutableList.sortBy { it.customerName?.toLowerCase() }
            SORT_TYPE = DESCENDING
        } else {
            mutableList.sortByDescending { it.customerName?.toLowerCase() }
            SORT_TYPE = ASCENDING
        }

        return mutableList
    }

    fun daysDisabledSortLogic(mutableList: MutableList<Fse>): MutableList<Fse> {

        if (SORT_TYPE == ASCENDING) {
            mutableList.sortBy { it.daysDisabled }
            SORT_TYPE = DESCENDING
        } else {
            mutableList.sortByDescending { it.daysDisabled }
            SORT_TYPE = ASCENDING
        }

        return mutableList
    }

    fun selectionSortLogic(mutableList: MutableList<Fse>): MutableList<Fse> {

        if (SORT_TYPE == ASCENDING) {
            mutableList.sortBy { it.isSubmitted }
            SORT_TYPE = DESCENDING
        } else {
            mutableList.sortByDescending { it.isSubmitted }
            SORT_TYPE = ASCENDING
        }

        return mutableList
    }


    fun searchLogic(searchKeyword: String, adapterList: MutableList<Fse>): List<Fse> {

        return adapterList?.filter {
            val name = "${it?.customerName}"
            name.contains(
                    searchKeyword,
                    true
            )
        }!!
    }

    override fun onCleared() {
        super.onCleared()
        repo.destroy()
    }

}
