package com.greenlightplanet.kazi.location.model.googlegeolocation


import com.google.gson.annotations.SerializedName
import com.greenlightplanet.kazi.location.model.Location

data class GoogleGeoLocationResponse(
    @SerializedName("accuracy")
    var accuracy: Int?, // 812
    @SerializedName("location")
    var location: Location?
)
