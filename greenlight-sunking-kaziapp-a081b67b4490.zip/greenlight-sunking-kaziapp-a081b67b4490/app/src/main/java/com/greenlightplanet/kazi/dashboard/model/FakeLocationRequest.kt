package com.greenlightplanet.kazi.dashboard.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


@Parcelize
data class FakeLocationRequest (

    @SerializedName("angazaId") val angazaId: String,
    @SerializedName("deviceId") val deviceId: String,
    @SerializedName("deviceTime") val deviceTime: String,
    @SerializedName("module") val module: String,
    @SerializedName("lat") val lat: Double,
    @SerializedName("lng") val lng: Double,
    @SerializedName("appVersionCode") val appVersionCode: Int
):Parcelable
