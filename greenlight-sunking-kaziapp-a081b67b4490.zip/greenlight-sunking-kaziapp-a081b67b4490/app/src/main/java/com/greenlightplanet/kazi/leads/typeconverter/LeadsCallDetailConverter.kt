package com.greenlightplanet.kazi.leads.typeconverter

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.leads.model.LeadsCallDetail


class LeadsCallDetailConverter {

    @TypeConverter
    fun fromLeadsCallDetail(leadsCallDetail: List<LeadsCallDetail?>?): String? {
        if (leadsCallDetail == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<LeadsCallDetail>>() {

        }.type
        return gson.toJson(leadsCallDetail, type)
    }

    @TypeConverter
    fun toLeadsCallDetail(leadsCallDetail: String?): List<LeadsCallDetail>? {
        if (leadsCallDetail == null) {
            return null
        }
        val gson = Gson()
        val type = object : TypeToken<List<LeadsCallDetail>>() {

        }.type
        return gson.fromJson(leadsCallDetail, type)
    }

}
