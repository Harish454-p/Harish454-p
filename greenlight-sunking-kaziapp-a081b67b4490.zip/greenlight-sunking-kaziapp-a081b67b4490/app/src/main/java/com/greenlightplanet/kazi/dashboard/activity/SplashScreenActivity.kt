package com.greenlightplanet.kazi.dashboard.activity

import android.app.Activity
import android.app.Dialog
import androidx.lifecycle.Observer
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.StrictMode
import android.provider.Settings
import com.greenlightplanet.kazi.BuildConfig
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.google.firebase.messaging.FirebaseMessaging
import com.greenlightplanet.kazi.KaziApplication
import com.greenlightplanet.kazi.attendance.model.AttendanceResponseModel
import com.greenlightplanet.kazi.dashboard.model.response.AppVersionResponse
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.dashboard.viewmodel.SplashScreenViewModel
import com.greenlightplanet.kazi.databinding.ActivityGreenLightBinding
import com.greenlightplanet.kazi.databinding.DialogUpdateBinding
import com.greenlightplanet.kazi.liteFseProspective.extras.AmazonS3Helper
import com.greenlightplanet.kazi.liteFseProspective.model.LiteAwsImageModel
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.member.model.BaseResponseModel
import com.greenlightplanet.kazi.networking.*
import com.greenlightplanet.kazi.task.TaskUtils
import com.greenlightplanet.kazi.update.UpdateDialog
import com.greenlightplanet.kazi.utils.*
import com.greenlightplanet.kazi.utils.AppCloning.checkAppCloning
import com.greenlightplanet.kazi.utils.AppCloning.killProcess
import com.greenlightplanet.kazi.utils.PreferenceConstants.Companion.IS_LOGIN
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.util.*


class SplashScreenActivity : BaseActivity(),
    APIInterface<NewCommonResponseModel<AppVersionResponse>>,
    AmazonS3Helper.AmazonS3HelperCallback {
    var db: AppDatabase? = null
    val TAG = "SplashScreenActivity"
    var updateDialog: Dialog? = null

    private lateinit var binding: ActivityGreenLightBinding
    lateinit var itemBinding: DialogUpdateBinding

    var amazonS3Helper: AmazonS3Helper? = AmazonS3Helper(this)
    private var mSPLASH_TIME_OUT: Long = 2000
    var activity: Activity? = null
    var context: Context? = null
    var preference: GreenLightPreference? = null
    var viewModel: SplashScreenViewModel? = null
    var fseCheck: Boolean = false
    var mainApiVersionResponse: AppVersionResponse? = null
    var mHomeWatcher: HomeWatcher? = null
    var isRequesting = false

    var loginResponseData: LoginResponseModel? = null
    var currentTime = Calendar.getInstance().time


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContentView(R.layout.activity_green_light)
        binding = ActivityGreenLightBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(SplashScreenViewModel::class.java)
        db = AppDatabase.getAppDatabase(this)
        FirebaseMessaging.getInstance().isAutoInitEnabled = true
        val builder = StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        //Util.requestAllPermission(this, arrayListOf(Manifest.permission.READ_PHONE_STATE))

        activity = this
        context = activity
        preference = GreenLightPreference.getInstance(this)
        loginResponseData = preference?.getLoginResponseModel()

        binding.tvAppVersion.text = "App version :" + BuildConfig.VERSION_NAME

        if (Util.isOnline(this)) {
//            callTimer()
            setObservers()
            //  callAPI()
            // this method is use for calling Appversion Api which is being coment and place this function on A Dshboard 23-03-2021
        } else {
            callTimer()
        }
        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
        // viewModel!!.getCountrylist(this)

        Log.d("HJASJHS", "111")
    }

    private fun setObservers() {
        Log.d("HJASJHS", "22")
        viewModel!!.getCountrylist(this).observe(this, Observer {
            Log.d("HJASJHS", "3333")
            if (it!!.success) {
                Log.d("HJASJHS", "444")
                lifecycleScope.launch {
                    db?.countryDaos()?.deleteAll()
                    db?.countryDaos()?.insertAll(it!!.responseData?.countryLit!!)
                    callTimer()
                }

            } else {
                callTimer()
            }

        })
    }

    fun callNextScreen() {

        if (!isRequesting && (preference?.getLoginResponseModel() != null) && KaziApplication.checkPermission(
                this
            )
        ) {
            KaziApplication.mService?.requestLocationUpdates()
            isRequesting = true
        }
        val greenlightpreference = GreenLightPreference.getInstance(this)


        if (greenlightpreference?.isBoolean(IS_LOGIN)?.equals(true)!!) {

            val i = Intent(this, DashBoardActivity::class.java)
            i.putExtra("fromSplash", true)
            startActivity(i)
            // close this activity
            finish()
        } else {

            Log.e("hghefegfgef", "${greenlightpreference?.isBoolean(IS_LOGIN)}")

            val i = Intent(this, LoginActivity::class.java)
            startActivity(i)
            // close this activity
            finish()
        }
    }

    fun callUpdate(apiVersionResponse: AppVersionResponse) {
        updateDialog = Util.callUpdate(this, apiVersionResponse)

        itemBinding = DialogUpdateBinding.inflate(updateDialog!!.layoutInflater)
        val taskListResponse = context?.let {
            TaskSolveResponse(
                context = it,
                apiVersionResponse = apiVersionResponse
            )
        }
        itemBinding?.btnUpdate?.setOnClickListener {

            if (preference?.getLoginResponseModel() != null) {
                val ticketRequestModel = activity?.let { TaskUtils.getTicketRequestModel(it) }
                preference?.setForceLogout(apiVersionResponse.forceLogout!!)

                postAllOfflineData(apiVersionResponse)

//                if (ticketRequestModel?.tickets?.isNotEmpty()!!) {
////                    Util.showToast("sync started of app", context)
//                    ServiceInstance.getInstance(this).service?.solveTask(preference?.getLoginResponseModel()?.angazaId!!, ticketRequestModel)?.enqueue(object : APICallback<CommonResponseModel<BaseResponseModel>>(taskListResponse as APIInterface<CommonResponseModel<BaseResponseModel>>, this) {})
//                } else {
//                    updateApp(apiVersionResponse)
//                }
            } else {
                updateApp(apiVersionResponse)
            }
        }
    }

    fun updateApp(apiVersionResponse: AppVersionResponse) {
        itemBinding?.tvMessage?.setText("Please wait, do not go back, application download is in progress")
        itemBinding?.btnUpdate?.visibility = View.GONE
        itemBinding?.btnCancel?.visibility = View.GONE

        UpdateDialog.goToDownload(this, apiVersionResponse.forceUpdateUrl)
    }

    private fun callTimer() {

        //   if (isTimeAutomatic(this) == true) {
        Handler().postDelayed(
            {
                when (checkAppCloning(activity = this)) {
                    true -> {
                        //real app...
                        Log.e(TAG, "launching now....")
                        callNextScreen()
                    }
                    false -> {
                        //fake app...
                        killProcess(this)
                    }
                }
            }, mSPLASH_TIME_OUT
        )
        /*   } else {
               setContentView(R.layout.timedate)
               val textView = findViewById<View>(R.id.time_id) as TextView
               textView.setText(currentTime.toString())
           }*/


    }

    fun isTimeAutomatic(c: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            Settings.Global.getInt(c.contentResolver, Settings.Global.AUTO_TIME, 0) == 1
            //Settings.Global.getInt(contentResolver, Settings.Global.AUTO_TIME, 0) == 1

        } else {
            Settings.System.getInt(c.contentResolver, Settings.System.AUTO_TIME, 0) == 1
            // Settings.System.getInt(contentResolver, Settings.System.AUTO_TIME, 0) ==1

        }
    }

    class TaskSolveResponse(context: Context, apiVersionResponse: AppVersionResponse) :
        APIInterface<CommonResponseModel<BaseResponseModel>> {
        var context = context
        var apiVersionResponse = apiVersionResponse
        var preference = GreenLightPreference.getInstance(context)
        override fun onResponse(response: CommonResponseModel<BaseResponseModel>) {

            if (response.Success!!) {
                val splashScreen = context as SplashScreenActivity
                splashScreen.updateApp(apiVersionResponse)
            } else {
                Toast.makeText(context, "" + response.Error?.MessageToUser, Toast.LENGTH_LONG)
                    .show()
            }
        }

        override fun onError() {}

    }

    override fun onResponse(response: NewCommonResponseModel<AppVersionResponse>) {

        preference!!.setshowProspectTab(response.responseData!!.showProspectTab)
        preference!!.setshowWebViewTab(response.responseData!!.showWebViewTab)
        mainApiVersionResponse = response.responseData

        Log.e(TAG, "response.responseData${response.responseData} ");
        if (response.responseData?.fseAccuracy != null) {
            preference?.setFseAccuracy("${response.responseData?.fseAccuracy}")
        }

        if (response.responseData?.checkInAccuracy != null) {
            preference?.setCheckInAccuracy("${response.responseData?.checkInAccuracy}")
        }

        if (!response.responseData!!.prospectDistanceDetails.isNullOrEmpty()) {

            preference?.setProspectDistanceDetail(response.responseData!!.prospectDistanceDetails as List<AppVersionResponse.ProspectDistanceDetail>)

            //  Log.e(TAG, "version-test1:${preference?.getProspectDistanceDetail()} ");
        }
        //  Log.e(TAG, "version-test1:${preference?.getProspectDistanceDetail()} ");


        if (response.responseData!!.appVersionCode!! > BuildConfig.VERSION_CODE) {
            Log.e(TAG, "========1========")
            val isLogin = preference?.isBoolean(IS_LOGIN)
            if (response.responseData!!.prospectDistanceDetails == null) {
                Log.e(TAG, "========2========" + " " + response.responseData.toString())
                callUpdate(response.responseData!!)
            } else if (isLogin!!) {
                val country = preference?.getLoginResponseModel()?.country

                if (response.responseData!!.prospectDistanceDetails == null) {
                    callUpdate(response.responseData!!)
                    Log.e(TAG, "========3========")
                } else if (response.responseData?.prospectDistanceDetails?.map { it?.country }
                        ?.contains(country!!.toUpperCase())!!) {
                    Log.e(TAG, "========4========")
                    callUpdate(response.responseData!!)
                } else {
                    Log.e(TAG, "========5========")
                    callTimer()
                }
            } else {
                Log.e(TAG, "========6========")
                callTimer()
            }

        } else {
            Log.e(TAG, "========7========")
            callTimer()
        }

        ///


    }

    override fun onError() {
        callTimer()
    }

    fun postAllOfflineData(apiVersionResponse: AppVersionResponse) {

        val ticketRequestModel = activity?.let { TaskUtils.getTicketRequestModel(it) }

        val leadsCallCount = AppDatabase.getAppDatabase(this)?.callDetailRequestModelDao()?.count()

        val offlineList =
            AppDatabase.getAppDatabase(this).attendanceDao().getOfflineAttendance(false)
        val attendanceRequestModel = AttendanceResponseModel(offlineList)
        attendanceRequestModel.checkins =
            offlineList as java.util.ArrayList<AttendanceResponseModel.Checkin>

        //Attendance Post
        if (attendanceRequestModel.checkins!!.size > 0) {
            viewModel!!.attendanceRXPost(
                this,
                preference!!.getLoginResponseModel()!!.angazaId!!,
                attendanceRequestModel
            )
                .observe(this, Observer {

                    viewModel!!.updateOfflineList(false, true)

                    postAllOfflineData(apiVersionResponse)
                })
        }
        //Task Post
        else if (ticketRequestModel?.tickets?.isNotEmpty()!!) {
            viewModel!!.postTask(
                preference!!.getLoginResponseModel()!!.angazaId!!,
                ticketRequestModel
            )
                .observe(this, Observer {
                    AppDatabase.getAppDatabase(activity).userDao().deleteAllCompletedCalls(true)
                    AppDatabase.getAppDatabase(activity).callsDao().deleteAllNotAnswered()
                    postAllOfflineData(apiVersionResponse)
                })
        }
        //Leads post

        else if (leadsCallCount!! > 0) {
            viewModel!!.solveabc().observe(this, Observer {
                postAllOfflineData(apiVersionResponse)
            })
        } else if (!fseCheck) {
            //Fse-Prospect
            fseProspect(apiVersionResponse)
        } else {
            updateApp(apiVersionResponse)
        }
    }

    fun fseProspect(apiVersionResponse: AppVersionResponse) {
        viewModel!!.getAwsImageModelsFromDatabase().observe(this, Observer { awsModels ->

            Log.e(TAG, "abc2: ");
            val validToUpload = awsModels?.filter {
                !it.uploadedToAws &&
                        !it.uploadedToGLPServer &&
                        !it.fileUri.isNullOrEmpty()
            }

            if (validToUpload.isNullOrEmpty()) {
                Log.e(TAG, "abc3: ");
//                cancelProgressDialog()
                //start step 2
                viewModel!!.getAllInOne().observe(this, Observer {
                    Log.e(TAG, "abc4: ");

                    Log.e(TAG, "syncData:$it ");
                    if (it!!.otpApprovalRequestModels.isNullOrEmpty()
                        && it.installationRequestModels.isNullOrEmpty()
                        && it.registrationCheckinRequestModels.isNullOrEmpty()
                    ) {
                        fseCheck = true
                        Log.e(TAG, "fseCheck:$fseCheck ");
                        postAllOfflineData(apiVersionResponse)
                    }

                    if (it != null) {

                        Log.e(TAG, "abc5: ");

                        viewModel!!.alpha(it).observe(this, Observer {

                            Log.e(TAG, "abc6: ");
//                            cancelProgressDialog()

                            if (it!!.success) {
                                Log.e(TAG, "abc7: ");
                                fseCheck = true
                                postAllOfflineData(apiVersionResponse)
//                                Util.showToast("Sync Successful", this)
                            } else {
                                Log.e(TAG, "abc8: ");
                                fseCheck = true
                                postAllOfflineData(apiVersionResponse)
//                                Util.showToast(it.error!!.messageToUser, this)
                            }

                        })

                    } else {
                        fseCheck = true
                        postAllOfflineData(apiVersionResponse)
                        Log.e(TAG, "abc9: ")
//                        cancelProgressDialog()
                    }
                })

            } else {
                Log.e(TAG, "abc10: ");
//                amazonS3Helper?.startUploadProcess(validToUpload, true)
                if (preference?.getAwsAccess().isNullOrEmpty() || preference?.getAwsSecret()
                        .isNullOrEmpty()
                ) {
                    viewModel?.awsRX(this, BaseRequestModel().apply {
                        this.angazaId = loginResponseData?.angazaId
                        this.country = loginResponseData?.country
                    })?.observe(this, Observer {

                        if (it == null || it.Success == false || it.ResponseData?.accessKey.isNullOrEmpty() || it.ResponseData?.secretKey.isNullOrEmpty()) {
                            Util.customFseCompletionDialog(
                                context = this,
                                hideTitle = true,
                                title = null,
                                message = "Unable to upload images please try again later",
                                okSelected = {
                                    it.dismiss()
                                }
                            )
                        } else {
                            preference?.setAwsAccess(it.ResponseData?.accessKey!!)
                            preference?.setAwsSecret(it.ResponseData?.secretKey!!)
                            amazonS3Helper?.startUploadProcess(validToUpload, true)
                        }
                    })
                } else {
                    amazonS3Helper?.startUploadProcess(validToUpload, true)
                }
            }


        })

    }

    override fun onAllUploadCompleted(fileModelsList: List<LiteAwsImageModel>) {

        val isOnline = Util.isOnline(this)

        Log.e(TAG, "Happend:1a ");

        fileModelsList.forEach { it.tried = false }

        Log.e(TAG, "onAllUploadCompleted:fileModelsList = $fileModelsList ");

        if (isOnline) {

            Log.e(TAG, "Happend:1b ");

            viewModel!!.insertAwsImageModelToDatabase(fileModelsList, true)
                .observe(this, Observer { savedAwsImageModels ->

                    Log.e(TAG, "Happend:1 ");

                    savedAwsImageModels?.let {
                        val awsImageModels = savedAwsImageModels.filter {
                            !it.awsLink.isNullOrEmpty()
                        }

                        viewModel!!.getInstallationRequestModelFromDatabaseById(awsImageModels)
                            .observe(this, Observer {

                                Log.e(TAG, "Happend: ")
                                viewModel!!.getAllInOne().observe(this, Observer {
                                    if (it != null) {
                                        viewModel!!.alpha(it).observe(this, Observer {

                                            if (it!!.success) {
//                                        Util.showToast("Sync Successful", this)
                                                fseCheck = true
                                                postAllOfflineData(mainApiVersionResponse!!)
                                            } else {
                                                fseCheck = true
                                                postAllOfflineData(mainApiVersionResponse!!)
//                                        Util.showToast(it.error!!.messageToUser, this)
                                            }
                                        })
                                    } else {
                                        fseCheck = true
                                        postAllOfflineData(mainApiVersionResponse!!)
                                    }

                                })

                            })

                    }

                })

        }

    }

    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();

    }


}
