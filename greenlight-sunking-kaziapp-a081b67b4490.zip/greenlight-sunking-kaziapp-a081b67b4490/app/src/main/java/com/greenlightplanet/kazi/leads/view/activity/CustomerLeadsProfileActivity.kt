package com.greenlightplanet.kazi.leads.view.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.MenuItem
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivityCustomerLeadsProfileBinding
import com.greenlightplanet.kazi.fseProspective.view.activity.MapsCheckActivity
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener

class CustomerLeadsProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCustomerLeadsProfileBinding
    private var leadsCrossSalesLead: LeadsCrossSalesLead? = null
    var mHomeWatcher: HomeWatcher? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContentView(R.layout.activity_customer_leads_profile)
        binding = ActivityCustomerLeadsProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Util.setToolbar(this, binding.toolbar)

        if (intent.hasExtra("LeadsCrossSalesLead")) {

            leadsCrossSalesLead =
                intent.getParcelableExtra<LeadsCrossSalesLead>("LeadsCrossSalesLead")

        }

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }


    override fun onResume() {
        super.onResume()

        leadsCrossSalesLead?.let {
            setData(it)
        }

    }

    private fun setData(leadsCrossSalesLead: LeadsCrossSalesLead) {

        binding.tvName.text = leadsCrossSalesLead.customerName
        binding.tvAddress.text = leadsCrossSalesLead.customerAddress
        binding.tvPhoneNumber1.text = leadsCrossSalesLead.primaryPhoneNumber
        binding.tvPhoneNumber2.text = leadsCrossSalesLead.secondaryPhoneNumber
        binding.tvPreviousProduct.text = leadsCrossSalesLead.previousProductName
        binding.tvProductUnlockDate.text = leadsCrossSalesLead.productUnlockDate
        binding.tvInterestedIn.text = leadsCrossSalesLead.interestedIn
        binding.tvLeadCreatedDate.text = leadsCrossSalesLead.createdDate
        binding.tvPreUpgradeAngazaId.text =
            leadsCrossSalesLead.preUpgradeAngazaId //add new check api if available
        binding.tvAccountNumber.text = leadsCrossSalesLead.accountNumber
        binding.tvAgeAtUnlock.text = leadsCrossSalesLead.ageAtUnlock
        binding.imgLoc.setOnClickListener {
            val intent = Intent(this, MapsCheckActivity::class.java)
            intent.putExtra("LAT", leadsCrossSalesLead.latitude)
            intent.putExtra("LONG", leadsCrossSalesLead.longitude)
            intent.putExtra("NAME", leadsCrossSalesLead.customerName)
            startActivity(intent)
        }

        /*tvShopVisitDate.text = if (leadsCrossSalesLead.status == LEAD_STATUS.PENDING || leadsCrossSalesLead.status == LEAD_STATUS.REASSIGNED) {
            AdapterUtils.pendingDaysLeftLogic(leadsCrossSalesLead)
        } else {
            //For called
            AdapterUtils.calledDaysToGoLogic(leadsCrossSalesLead)
        }*/

        //todo clearify with @aditya
        binding.tvShopVisitDate.text = leadsCrossSalesLead.promiseDate


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item?.itemId) {
            android.R.id.home -> {

                onBackPressed()

                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();

    }
}
