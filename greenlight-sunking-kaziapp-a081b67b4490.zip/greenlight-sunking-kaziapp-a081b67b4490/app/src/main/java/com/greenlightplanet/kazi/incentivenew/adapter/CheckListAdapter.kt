package com.greenlightplanet.kazi.incentivenew.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentIncentiveChecklistsItemBinding
import com.greenlightplanet.kazi.incentivenew.model.summary.CheckListFields


/**
 * Created by Rahul on 03/12/20.
 */
class CheckListAdapter(private val listData: List<CheckListFields>, var listener: MyDateData) : RecyclerView.Adapter<CheckListAdapter.ViewHolder?>() {

    override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
    ): ViewHolder {
        val itemBinding = FragmentIncentiveChecklistsItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(itemBinding,listener)
    }

    override fun onBindViewHolder(
            holder: ViewHolder,
            position: Int
    ) {
        val myListData: CheckListFields = listData[position]

holder.bind(myListData)
    }

    override fun getItemCount(): Int {
        return listData.size
    }

    class ViewHolder(
        private val itemBinding: FragmentIncentiveChecklistsItemBinding,
       private val listener: MyDateData
    ) : RecyclerView.ViewHolder(itemBinding.root) {

        fun bind(myListData: CheckListFields) {

            if (myListData.value.equals(null) || myListData.value.equals(" ")) { // null or empty
                itemBinding.imgCheckListIconValue.setBackgroundResource(R.drawable.exclamation_mark)

            } else if (myListData.value!!.toBoolean()) { // true
                itemBinding.imgCheckListIconValue.setBackgroundResource(R.drawable.double_check)


            } else {
                if (!myListData.value.toBoolean()) { //false
                    itemBinding.imgCheckListIconValue.setBackgroundResource(R.drawable.ic_cancel)
                } }

            itemBinding.tvchecklistValue.text = myListData.name

            itemBinding.imgLineader.setOnClickListener {
                myListData.reason?.let { listener.selectedData(it, position) }
            }

        }
    }

    interface MyDateData {

        fun selectedData(date: String, position: Int)


    }
}