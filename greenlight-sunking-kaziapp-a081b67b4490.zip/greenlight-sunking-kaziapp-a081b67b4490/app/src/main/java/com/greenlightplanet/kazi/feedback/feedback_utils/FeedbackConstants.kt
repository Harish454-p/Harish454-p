package com.greenlightplanet.kazi.feedback.feedback_utils

object FeedbackConstants {

    const val NUM_TABS = 2
    const val DEFAULT_PAGE_SIZE = 20

    var dummyDate = "10-12-2022 08:20:10"
    var utcDateFormat = "dd-MM-yyyy HH:mm:ss"
    var requiredDateFormat = "dd-MM-yyyy"
    var yyyyMMddTHHmmss = "yyyy-MM-dd'T'HH:mm:ss"

    var BASE_URL = ""

    const val FEEDBACK_BASE_URL_PROD = "https://kazi-feedback.glpapps.com/kazi/feedback/"
    const val FEEDBACK_BASE_URL_DEV = "http://dev.glpapps.com:8090/kazi/feedback/"
    const val PENDING_CHAT_URL_DEV = "http://dev.glpapps.com:8090/kazi/feedback/conversations/142816"
    const val CLOSED_CHAT_URL_DEV = "http://dev.glpapps.com:8090/kazi/feedback/conversations/142857"

    const val FORM_UI_ENDPOINT = "form/"
    const val CREATE_TICKETS_ENDPOINT = "create/ticket?country="
    const val TICKET_LIST_ENDPOINT = "tickets/"
    const val CONVERSATION_ENDPOINT = "conversations/"
    const val CHAT_SEND_ENDPOINT = "update/ticket?country="

    const val TICKETID_CHAT_INTENT = "FEEDBACK_CHAT_TICKET"
    const val CLOSED_CHAT_INTENT = "FEEDBACK_CHAT_CLOSED"
    const val STATUS_CHAT_INTENT = "FEEDBACK_CHAT_STATUS"

    var angazaId = ""
    var country = ""
    var territory = ""
    var fullName = ""

    var isTicketPostSuccess = false
//    var accountNumber = ""


}