package com.greenlightplanet.kazi.fse.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.TypeConverters
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.greenlightplanet.kazi.fse.extras.DateConverter
import kotlinx.android.parcel.IgnoredOnParcel
import kotlinx.android.parcel.Parcelize
import java.text.SimpleDateFormat
import java.util.*

@Parcelize
@Entity(tableName = "FseHistory", primaryKeys = ["accountNumber", "paymentDate"])
@TypeConverters(FseHistoryResponse.FseHistoryConverter::class)
data class FseHistory(

        /*@PrimaryKey(autoGenerate = true)
        @ColumnInfo(name = "id")
        @SerializedName("id")
        var id: Int, // 121233*/

        @ColumnInfo(name = "accountStatus")
        @SerializedName("accountStatus")
        var accountStatus: String?, // 121233
        @ColumnInfo(name = "accountNumber")
        @SerializedName("accountNumber")
        var accountNumber: String = "", // 121233
        @ColumnInfo(name = "angazaId")
        @SerializedName("angazaId")
        var angazaId: String?, // US0101
        @ColumnInfo(name = "customerName")
        @SerializedName("customerName")
        var customerName: String?, // Rajiv K
        @ColumnInfo(name = "daysDisabled")
        @SerializedName("daysDisabled")
        var daysDisabled: Int?, // 0
        @ColumnInfo(name = "paidAmount")
        @SerializedName("paidAmount")
        var paidAmount: String?, // 234
        @ColumnInfo(name = "paymentDate")
        @SerializedName("paymentDate")
        var paymentDate: String, // 2019-01-15 00:00:00
        @ColumnInfo(name = "enabled")
        @SerializedName("enabled")
        var enabled: Boolean = false // true
) : Parcelable {


    var isPaid: Boolean = false
        get() = paidAmount?.toDouble()!! > 0.0

    @IgnoredOnParcel
    @ColumnInfo(name = "paymentDateFormatted")
    var paymentDateFormatted: String? = null // 2019-01-15 00:00:00
        get() {
            this.paymentDate?.let {
                return it.subSequence(0, 10).toString()
            }
            return ""
        }


    @ColumnInfo(name = "date")
    @TypeConverters(DateConverter::class)
    var date: Date? = null

    fun getFormattedDate(time: String?): Date {

        if (time == null) {
            return Date()
        } else {

            val sdf = SimpleDateFormat("yyyy-MM-dd")
            val date: Date? = sdf.parse(time)
            return date!!
        }


    }

    /*@IgnoredOnParcel
    @PrimaryKey
    @ColumnInfo(name = "paymentDateOfAccount")
    @SerializedName("paymentDateOfAccount")
    var paymentDateOfAccount: String = "$paymentDate::$accountNumber"// 2019-01-15 00:00:00
    */
}
