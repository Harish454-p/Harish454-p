package com.greenlightplanet.kazi.feedback.feedback_utils

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context.CONNECTIVITY_SERVICE
import android.net.ConnectivityManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.feedback.repo.model.response.NewTicketUIResponse
import com.greenlightplanet.kazi.feedback.repo.model.response.ResponseData
import com.greenlightplanet.kazi.networking.ErrorResponse
import retrofit2.Response
import timber.log.Timber
import java.sql.Timestamp
import java.text.DateFormat
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

object Helper {
    lateinit var application: Application
    fun isNetworkConnected(): Boolean {
        val cm = application.getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager?
        return cm!!.activeNetworkInfo != null
    }

    fun setCountryData(territory: String): String {
        val mList = territory.split("::")
        val country = mList[0]
        println(country)
        return country
    }

    fun getErrorBody(response: Response<NewTicketUIResponse>): ErrorResponse? {
        val gson = Gson()
        val type = object : TypeToken<ErrorResponse>() {}.type
        var errorResponse: ErrorResponse? = gson.fromJson(response.errorBody()!!.charStream(), type)
        return errorResponse
    }

    fun getDummyUIResponseData(): ResponseData {
        val objectArrayString: String =
            application.resources.openRawResource(R.raw.fake_ui_data).bufferedReader()
                .use { it.readText() }
        return Gson().fromJson(objectArrayString, ResponseData::class.java)
    }

    fun getTimeStampToDate(timestamp: Long, dateFormat: String): String {
        var time: String = ""
        try {
            val calendar = Calendar.getInstance()
            calendar.timeInMillis = timestamp
            val sdf = SimpleDateFormat(dateFormat)
            val currentTimeZone = calendar.time as Date
            return sdf.format(currentTimeZone)
        } catch (e: Exception) {

        }

        return time
    }


    @SuppressLint("NewApi")
    fun getDateToTimeStamp(date: String?, dateFormat: String): Long {
        val formatter: DateFormat = SimpleDateFormat(dateFormat)
        val date: Date = formatter.parse(date) as Date
        return date.time
    }

    fun getPrevDate(timeStamp: Long, numberOfDays: Int): Long {
        val calendar = Calendar.getInstance()
        val date = Date(timeStamp)
        calendar.time = date
        Timber.d("TimeStampTest: GetPrevDate : NoOfDays: $numberOfDays")
        calendar.add(Calendar.DAY_OF_YEAR, numberOfDays)
        val newDate = calendar.time
        return newDate.time
    }

    fun getCurrentLocalTimeStamp(): Long {
        val timestamp = Timestamp(System.currentTimeMillis())
        return timestamp.time
    }

    fun getCurrentUTCTimeStamp(): Long {
        val utcFormat = SimpleDateFormat(FeedbackConstants.utcDateFormat)//"Thu Jul 11 16:00:46 GMT+05:30 2019"
        utcFormat.timeZone = TimeZone.getTimeZone("UTC")
        val currentUtcDate =  utcFormat.format(Date())
        return getDateToTimeStamp(currentUtcDate, FeedbackConstants.utcDateFormat)
    }

    fun getUtcToLocalDate() {

    }

    fun convertUTCtoLocatTimeDDMMYYYYY(value: String): String {
        val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
        utcFormat.timeZone = TimeZone.getTimeZone("UTC")
        val date = utcFormat.parse(value)
        val pstFormat = SimpleDateFormat("dd-MM-yyyy")
        System.out.println(pstFormat.format(date))
        return pstFormat.format(date)
    }

    fun convertUTCtoLocatTimeDDMMYYYYYHHmmss(value: String): String {
        val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
        utcFormat.timeZone = TimeZone.getTimeZone("UTC")
        val date = utcFormat.parse(value)
        val pstFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
        System.out.println(pstFormat.format(date))
        return pstFormat.format(date)
    }

    fun convertUTCTimeWithFormatToRequired(value: String, requiredFormat: String): String {
        val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
        utcFormat.timeZone = TimeZone.getTimeZone("UTC")
        val date = utcFormat.parse(value)
        val pstFormat = SimpleDateFormat(requiredFormat)
//        val pstFormat = SimpleDateFormat("yyyy-MM-ddTHH:mm:ss")
        System.out.println(pstFormat.format(date))
        return pstFormat.format(date)
    }

    fun getCurrentDayStartTimeStampUTC(timeStamp: Long = 0): Long {
        var dateToTimeStamp: Long = 0
        if (timeStamp.toString() == "0") {
            val todayTimeStamp = getCurrentUTCTimeStamp()
            val date = getTimeStampToDate(timestamp = todayTimeStamp, FeedbackConstants.requiredDateFormat)
            dateToTimeStamp = getDateToTimeStamp(date, FeedbackConstants.requiredDateFormat)
        } else {
            val date = getTimeStampToDate(timestamp = timeStamp, FeedbackConstants.requiredDateFormat)
            dateToTimeStamp = getDateToTimeStamp(date, FeedbackConstants.requiredDateFormat)
        }

        return dateToTimeStamp
    }

    fun getCurrentUTCDateInRequiredFormat(format: String): String {
        val utcFormat = SimpleDateFormat(format)
        utcFormat.timeZone = TimeZone.getTimeZone("UTC")
        val currentUtcDate =  utcFormat.format(Date())
        return currentUtcDate
    }

    fun formatChanger(dateStr: String, currentFormat: String, requiredFormat: String): String {
        val utc = TimeZone.getDefault()
        val sourceFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
        val destFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        sourceFormat.timeZone = utc
        val convertedDate = sourceFormat.parse(dateStr)
        return destFormat.format(convertedDate)
    }

    @Throws(ParseException::class)
    fun convertToNewFormat(dateStr: String?): String? {
        val utc = TimeZone.getDefault()
        val sourceFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
        val destFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        sourceFormat.timeZone = utc
        val convertedDate = sourceFormat.parse(dateStr)
        return destFormat.format(convertedDate)
    }



}