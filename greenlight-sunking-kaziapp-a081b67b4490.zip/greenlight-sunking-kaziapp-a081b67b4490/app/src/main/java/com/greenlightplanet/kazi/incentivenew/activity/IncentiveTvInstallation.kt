package com.greenlightplanet.kazi.incentivenew.activity

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.viewpager.widget.ViewPager
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.dashboard.model.response.LoginResponseModel
import com.greenlightplanet.kazi.databinding.ActivityAtRiskAccountsBinding
import com.greenlightplanet.kazi.databinding.ActivitySalesBinding
import com.greenlightplanet.kazi.incentive.adapter.IncentivePagerAdapter
import com.greenlightplanet.kazi.incentivenew.fragment.tvinstallation.TvInstallationEligibleFragment
import com.greenlightplanet.kazi.incentivenew.fragment.tvinstallation.TvInstallationInEligibleFragment
import com.greenlightplanet.kazi.incentivenew.model.tvinstallation.Incentive_TvInstallation
import com.greenlightplanet.kazi.incentivenew.viewmodel.IncentiveTvInstallationViewModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener


/**
 * Created by Rahul on 07/12/20.
 */
class IncentiveTvInstallation : BaseActivity() {

    private lateinit var binding: ActivitySalesBinding


    var loginResponseModel: LoginResponseModel? = null
    var preference: GreenLightPreference? = null
    var isFromNotification = false
    var mHomeWatcher: HomeWatcher? = null
    var viewModel: IncentiveTvInstallationViewModel? = null
    val TAG = "IncentiveTvInstalltn"
    var adapter: ArrayAdapter<String>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_sales)
        binding = ActivitySalesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvAppbottomVersions.text = "V:" + BuildConfig.VERSION_NAME

        initialize()

        APICall()

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }

    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();
    }


    fun initialize() {

        Util.setToolbar(this, binding.toolbar2!!)
        Util.addEvent("310", "TvInstallationScreen", "EarningScreen_to_TvInstallationScreen")

        binding. productSpinner.visibility = View.GONE

        showProgressDialog(this)
        viewModel = ViewModelProviders.of(this).get(IncentiveTvInstallationViewModel::class.java)

        preference = GreenLightPreference.getInstance(this)
    }

    private fun setupViewPager(viewPager: ViewPager, incentive_TvInstallation: Incentive_TvInstallation) {
        val adapter = IncentivePagerAdapter(supportFragmentManager)

        val eigibleBundel = Bundle()
        eigibleBundel.putParcelable("eligible", incentive_TvInstallation)

        val eigible = TvInstallationEligibleFragment()
        eigible.arguments = eigibleBundel

        val inEligibleBundel = Bundle()
        inEligibleBundel.putParcelable("inEligible", incentive_TvInstallation)

        val inEligible = TvInstallationInEligibleFragment()
        inEligible.arguments = inEligibleBundel





        adapter.addFragment(eigible, this.getString(R.string.eligible_account))
        adapter.addFragment(inEligible, this.getString(R.string.ineligible_account))


        viewPager.adapter = adapter
    }


    fun APICall() {

        //http://rahultyagi.in/agent-incentive-sales.json //US015055

        viewModel?.getTvInstallation(this, preference?.getLoginResponseModel()?.angazaId)?.observe(this, Observer { response ->
            if (response != null) {

                if (response.success) {
                    cancelProgressDialog()
                    val incentiveResponseModel = response.responseData
                    loginResponseModel = preference?.getLoginResponseModel()
                    if (incentiveResponseModel != null) {
                        setIncentives(incentiveResponseModel)


                    }
                    updateSharedPref(true)

                } else {
                    cancelProgressDialog()
                    // Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show()
                }
            }

        })
    }


    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()

        return true
    }


    fun setIncentives(incentive_TvInstallation: Incentive_TvInstallation) {

        loginResponseModel = preference?.getLoginResponseModel()
       // tvCountry?.text = loginResponseModel?.country
       // tvPhoneNo?.text = loginResponseModel?.phoneNumber
        setupViewPager(this.binding.viewpager!!, incentive_TvInstallation)
        binding.tabs?.setupWithViewPager(binding.viewpager)
    }

    private fun updateSharedPref(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadIncentiveFromPref(this)

        if (data == null) {
            data = LastSaved()
            data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(this, data)
            binding.tvLastSaved.text = data.incentive

        } else {

            if (fromInternet) {
                data.incentive = "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(this, data)
                binding.tvLastSaved.text = data.incentive
            } else {
                binding.tvLastSaved.text = data.incentive

            }
        }

    }

}
