package com.greenlightplanet.kazi.dashboard.dao

import androidx.room.*
import com.greenlightplanet.kazi.dashboard.model.call_sms.CallLogRequest
import io.reactivex.Single

@Dao
interface CallLogRequestDao {

	@Insert(onConflict = OnConflictStrategy.IGNORE)
	fun insertAllIgnore(CallLogRequest: List<CallLogRequest>): List<Long>

	@Insert(onConflict = OnConflictStrategy.REPLACE)
	fun insertAllReplace(CallLogRequest: List<CallLogRequest>): List<Long>

	@Insert(onConflict = OnConflictStrategy.REPLACE)
	fun insert(CallLogRequest: CallLogRequest): Long

	@Delete
	fun delete(CallLogRequest: CallLogRequest): Int

	@Query("DELETE FROM CallLogRequest")
	fun deleteAll(): Int

	@Query("SELECT * FROM CallLogRequest")
	fun getAll(): Single<List<CallLogRequest>>

	@Query("SELECT * FROM CallLogRequest WHERE uploadedToServer = :uploadedToServer")
	fun getAllForUpload(uploadedToServer: Boolean = false): Single<List<CallLogRequest>>

	@Query("SELECT * FROM CallLogRequest LIMIT 1")
	fun get(): Single<CallLogRequest>

	@Query("SELECT COUNT(*) from CallLogRequest")
	fun count(): Single<Int>

}
