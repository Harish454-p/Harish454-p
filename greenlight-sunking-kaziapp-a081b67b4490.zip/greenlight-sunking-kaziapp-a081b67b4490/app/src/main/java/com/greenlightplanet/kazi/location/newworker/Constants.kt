package com.greenlightplanet.kazi.location.newworker

import com.greenlightplanet.kazi.location.newworker.WORKER_DEFAULT_CONST.MILLI_TO_MINUTE
import com.greenlightplanet.kazi.location.newworker.WORKER_INTERVAL.ALARM_INTERVAL

object WORKER_DEFAULT_CONST {
	const val MILLI_TO_MINUTE: Long = 60000L
	const val CHANNEL_NAME: String = "Worker Channel"
	const val CHANNEL_ALARM_ID: String = "worker_alarm_channel"
	const val CHANNEL_SERVICE_ID: String = "worker_service_channel"
	const val WM_TAG = "work_tag"

//	const val EXACT_ALARM_REQUEST_CODE = 584
	var EXACT_ALARM_REQUEST_CODE: Int = 0
		get() = (0..1000).random()
	const val REPEAT_ALARM_REQUEST_CODE = 491
}

object WORKER_TYPE {
	const val WORK_MANAGER = "wm"
	const val ALARM = "alarm"
	const val SERVICE = "service"
	const val LUS = "lus"
}

object PROVIDER_TYPE {
	const val CELL_TOWER = "cell_tower"
	const val GPS = "gps"
	const val GPS_NETWORK = "gps_network"
}

object WORKER_INTERVAL {
//	val WM_INTERVAL: Long = 15 * MILLI_TO_MINUTE
//	val ALARM_INTERVAL: Long = 18 * MILLI_TO_MINUTE

	val WM_INTERVAL: Long = 15
	val ALARM_INTERVAL: Long = (WM_INTERVAL / 1.5).toLong()
}

object WORKER_MINI_DIFF {
	//val DIFF_MILLI = (ALARM_INTERVAL / 1.3).toLong() * MILLI_TO_MINUTE
	val DIFF_MILLI = 5 * MILLI_TO_MINUTE
}
