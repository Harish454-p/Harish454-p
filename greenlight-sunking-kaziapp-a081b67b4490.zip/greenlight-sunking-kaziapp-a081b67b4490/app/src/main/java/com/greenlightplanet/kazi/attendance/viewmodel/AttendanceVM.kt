package com.greenlightplanet.kazi.attendance.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import android.content.Context
import com.greenlightplanet.kazi.attendance.model.AttendanceResponseModel
import com.greenlightplanet.kazi.attendance.model.AttendanceResponseModel.Checkin
import com.greenlightplanet.kazi.attendance.repo.AttendanceRepo
import com.greenlightplanet.kazi.member.model.BaseResponseModel
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import io.reactivex.disposables.Disposable

class AttendanceVM(application: Application) : AndroidViewModel(application) {

    companion object {
        public const val TAG = "AttendanceVM"

    }

    val repo = AttendanceRepo.getInstance(application)

    fun insertAttendance(user: List<AttendanceResponseModel.Checkin>): Disposable {
        return repo.insertAttendance(user)
    }

    fun insertSingleAttendance(user: Checkin): Disposable {
        return repo.insertSingleAttendance(user)
    }
    fun updateOfflineList(isOnlineAdded: Boolean, makeTrue: Boolean): Disposable {
        return repo.updateOfflineList(isOnlineAdded, makeTrue)
    }

    fun getAttendanceSS(): MutableLiveData<List<AttendanceResponseModel.Checkin>> {
        return repo.getAttendanceSS()
    }

    fun getAttendance(fromDate: Long, toDate: Long): MutableLiveData<List<AttendanceResponseModel.Checkin>> {
        return repo.getAttendance(fromDate, toDate)
    }

    fun getOfflineAttendance(isOnlineAdded: Boolean): MutableLiveData<List<AttendanceResponseModel.Checkin>> {
        return repo.getOfflineAttendance(isOnlineAdded)
    }


    fun attendanceRXPost(context: Context, angazaId: String, attendanceRequestModel: AttendanceResponseModel?): MutableLiveData<CommonResponseModel<BaseResponseModel>> {
        return repo.attendanceRXPost(context, angazaId, attendanceRequestModel)
    }

    fun getRXCheckINList(context: Context, angazaId: String, fromDate: String, toDate: String, fromDBDate: Long, toDBDate: Long): MutableLiveData<NewCommonResponseModel<AttendanceResponseModel>> {
        return repo.getRXCheckINList(context, angazaId, fromDate, toDate,fromDBDate, toDBDate)
    }


}
