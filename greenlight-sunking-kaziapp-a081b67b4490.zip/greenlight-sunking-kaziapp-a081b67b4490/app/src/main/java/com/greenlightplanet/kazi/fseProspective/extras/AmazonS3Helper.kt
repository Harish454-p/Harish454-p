package com.greenlightplanet.kazi.fseProspective.extras

import android.app.Activity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import android.content.Context
import android.util.Log
import com.amazonaws.auth.AWSCredentialsProvider
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.mobile.auth.core.IdentityHandler
import com.amazonaws.mobile.auth.core.IdentityManager
import com.amazonaws.mobile.client.AWSMobileClient
import com.amazonaws.mobile.config.AWSConfiguration
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener
import com.amazonaws.mobileconnectors.s3.transferutility.TransferNetworkLossHandler
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility
import com.amazonaws.services.s3.AmazonS3Client
import com.greenlightplanet.kazi.fseProspective.model.AwsImageModel
import com.greenlightplanet.kazi.utils.GreenLightPreference
import java.io.File

@Suppress("DEPRECATION")
class AmazonS3Helper(val activity: Activity) : LifecycleObserver {

    private var awsCredentialsProvider: AWSCredentialsProvider? = null
    private var awsConfiguration: AWSConfiguration? = null
    private var awsMobileClient: AWSMobileClient? = null
    private var identityManager: IdentityManager? = null
    private var basicAWSCredentials: BasicAWSCredentials? = null
    private var amazonS3Client: AmazonS3Client? = null
    private var transferUtility: TransferUtility? = null
    private var transferNetworkLossHandler: TransferNetworkLossHandler? = null
    private var fileModelsList = mutableListOf<AwsImageModel>()
    var amazonS3HelperCallback: AmazonS3HelperCallback? = null
    var isForService = false
    var preference: GreenLightPreference = GreenLightPreference.getInstance(activity)

    //companion object : SingletonHolderUtil<AmazonS3Helper, Activity>(::AmazonS3Helper) {
    companion object {
        const val TAG = "AmazonS3Helper"
        const val TAG_UPLOAD = "AmazonS3Upload"

        const val AMAZON_S3_KEY = "fse_prospective/"
        const val AMAZON_S3_BASE =
            "https://s3.eu-west-2.amazonaws.com/kazi-userfiles-mobilehub-391300116/$AMAZON_S3_KEY"
    }

    private val KEY = preference.getAwsAccess()
    private val SECRET = preference.getAwsSecret()

    @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
    fun initializer() {

        Log.d(TAG, "Initializing AWSMobileClient")


        AWSMobileClient.getInstance().initialize(activity) {
            // Obtain the reference to the AWSCredentialsProvider and AWSConfiguration objects
            awsMobileClient = AWSMobileClient.getInstance()
            awsCredentialsProvider = awsMobileClient?.credentialsProvider
            awsConfiguration = awsMobileClient?.configuration

            buildTransferUtility(activity.applicationContext)

            // Use IdentityManager#getUserID to fetch the identity id.
            IdentityManager.getDefaultIdentityManager().getUserID(object : IdentityHandler {
                override fun onIdentityId(identityId: String) {

                    Log.d(TAG, "Successfully retrieved identity")
                    identityManager = IdentityManager.getDefaultIdentityManager()
                    val cachedIdentityId = identityManager?.cachedUserID

                }

                override fun handleError(exception: Exception) {

                    Log.d(TAG, "Error in retrieving the identity:$exception")

                }
            })
        }.execute()

    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun destroy() {
        awsMobileClient = null
        awsCredentialsProvider = null
        awsConfiguration = null
        basicAWSCredentials = null
        amazonS3Client = null
        transferNetworkLossHandler = null
        transferUtility = null
        identityManager = null
    }

    private fun buildTransferUtility(context: Context) {

        basicAWSCredentials = BasicAWSCredentials(KEY, SECRET);
        amazonS3Client = AmazonS3Client(basicAWSCredentials);
        transferNetworkLossHandler = TransferNetworkLossHandler.getInstance(context);

        transferUtility = TransferUtility.builder()
            .context(context)
            .awsConfiguration(AWSMobileClient.getInstance().getConfiguration())
            .s3Client(amazonS3Client)
            .build()

    }

    //private fun uploadImage(fileName: String, file: File, onStop: () -> Unit = {}) {
    private fun uploadImage(fileModels: AwsImageModel) {
        val rndNumber = (0..10000000).random()
        val photoUrl =
            "${fileModels.installationAttempted}" + "${fileModels.imageName}" + "_" + "${fileModels.prospectId}" + "_" + "$rndNumber"


        val transferObserver =
            transferUtility?.upload(AMAZON_S3_KEY + photoUrl, File(fileModels.fileUri))

        transferObserver?.setTransferListener(object : TransferListener {

            override fun onProgressChanged(id: Int, bytesCurrent: Long, bytesTotal: Long) {

                Log.d(
                    TAG_UPLOAD,
                    "onProgressChanged---> bytesCurrent:$bytesCurrent == bytesTotal$bytesTotal"
                )
            }

            override fun onStateChanged(id: Int, state: TransferState?) {

                Log.d(TAG_UPLOAD, "onStateChanged--->")


                //49122906
                if (TransferState.COMPLETED == state) {

                    Log.d(TAG_UPLOAD, "onStateChanged---> COMPLETED")

                    //hideProgress()
                    // Handle a completed download.
                    //var file = File(mCurrentPhotoPath)
                    //amazon_imagelink = AMAZON_S3_BASE + "" + file.name
                    //Log.d(TAG, "amazon_imagelink:$amazon_imagelink ");
                    //device_image_path = mCurrentPhotoPath

                    val awsLink = AMAZON_S3_BASE + "" + photoUrl
                    internalCallback(awsLink, fileModels)

                    return
                }

                if (TransferState.FAILED == state) {
                    Log.d(TAG_UPLOAD, "onStateChanged---> FAILED")

                    //hideProgress()
                    //getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

                    internalCallback(null, fileModels)
                    return
                }


                if (TransferState.CANCELED == state) {
                    Log.d(TAG_UPLOAD, "onStateChanged---> CANCELED")

                    //hideProgress()
                    //getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

                    internalCallback(null, fileModels)
                    return
                }

            }

            override fun onError(id: Int, ex: Exception?) {
                Log.d(TAG_UPLOAD, "onError---> ex:${ex?.localizedMessage}")
                ex?.printStackTrace()

                //hideProgress()
                //getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

                internalCallback(null, fileModels)
                return

            }

        })

    }

    public fun startUploadProcess(fileModels: List<AwsImageModel>, isForService: Boolean) {
        this.isForService = isForService
        fileModelsList.clear()
        fileModelsList.addAll(fileModels)
        uploadAll(fileModels)
    }

    private fun uploadAll(fileModels: List<AwsImageModel>) {
        //start progress
        uploadImage(fileModels.first())
    }

    private fun internalCallback(awsLink: String?, fileModels: AwsImageModel) {

        if (fileModelsList.isNullOrEmpty()) {
            //no image to upload
            amazonS3HelperCallback?.onAllUploadCompleted(fileModelsList)
        } else {

            if (awsLink.isNullOrEmpty()) {
                //when failed to get aws link
                //when failed to upload image
                fileModelsList.find { it == fileModels }?.apply {
                    this.tried = true
                    this.uploadedToAws = false

                }

            } else {
                //when image upload is success
                fileModelsList.find { it == fileModels }?.apply {
                    this.awsLink = awsLink
                    this.tried = true
                    this.uploadedToAws = true
                    this.savedInDatabase = false
                }
            }

            val notTried = fileModelsList.find { it.tried == false }

            if (notTried != null) {
                uploadImage(notTried)
            } else {
                //completed
                //dismiss progress
                amazonS3HelperCallback?.onAllUploadCompleted(fileModelsList)
            }
        }
    }

    interface AmazonS3HelperCallback {

        fun onAllUploadCompleted(fileModelsList: List<AwsImageModel>)
    }

    public data class FileModel(
        var tried: Boolean = false,
        var fileName: String,
        var file: File,
        var awsLink: String?
    )


}
