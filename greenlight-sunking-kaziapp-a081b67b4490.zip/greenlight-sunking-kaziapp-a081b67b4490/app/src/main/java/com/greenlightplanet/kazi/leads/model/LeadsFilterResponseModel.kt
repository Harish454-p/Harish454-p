package com.greenlightplanet.kazi.leads.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "LeadsFilterResponseModel")
data class LeadsFilterResponseModel(
        @ColumnInfo(name = "intents")
        @SerializedName("intents")
        var intents: List<LeadsIntent>?
) : Parcelable
