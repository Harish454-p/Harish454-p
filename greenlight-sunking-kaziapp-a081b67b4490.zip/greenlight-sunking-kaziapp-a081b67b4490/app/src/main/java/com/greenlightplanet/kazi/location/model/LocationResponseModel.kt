package com.greenlightplanet.kazi.location.model

import com.google.gson.annotations.SerializedName

data class LocationResponseModel(
        @SerializedName("Request")
    var request: Request?,
        @SerializedName("ResponseData")
    var responseData: ResponseData?,
        @SerializedName("ResponseStatus")
    var responseStatus: Int?, // 200
        @SerializedName("Success")
    var success: Boolean? // true
) {

    data class Request(
        @SerializedName("ExecutionTime")
        var executionTime: Double? // 0.005
    )

    class ResponseData()
}