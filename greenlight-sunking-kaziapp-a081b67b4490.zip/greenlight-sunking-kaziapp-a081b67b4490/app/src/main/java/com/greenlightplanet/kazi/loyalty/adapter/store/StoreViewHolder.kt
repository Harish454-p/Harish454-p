package com.greenlightplanet.kazi.loyalty.adapter.store

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYou
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYouListener
import com.greenlightplanet.kazi.databinding.StoreItemBinding
import com.greenlightplanet.kazi.loyalty.model.store.StoreItem
import com.greenlightplanet.kazi.utils.Util
import com.squareup.picasso.Picasso

/**
 * Created by Rahul on 08/04/21.
 */
class StoreViewHolder(val itemBinding:  StoreItemBinding) : RecyclerView.ViewHolder(itemBinding.root) {


    fun bind(data: StoreItem, listener: StoreAdapter.onClickItem?,context:Context) {
        if (data.id != null) {

            itemBinding.tvMessage.text = data?.name.toString()
            itemBinding.btnPoint.text = data.point?.let { Util.formatAmount(it.toDouble())}

            if (data.icon_url.contains(".svg")){
                GlideToVectorYou
                        .init()
                        .with(context)
                        .withListener(object : GlideToVectorYouListener {
                            override fun onLoadFailed() {

                            }

                            override fun onResourceReady() {
                            }
                        })
                        .load(Uri.parse(data?.icon_url), itemBinding.imgRewardIcon)
            }else{
                Picasso.get().load(data.icon_url)
                        .into(itemBinding.imgRewardIcon)
            }


            itemBinding.btnPoint.setOnClickListener {
                listener?.onTab(data)
            }

        }
    }

    companion object {
        fun create(parent: ViewGroup): StoreViewHolder {
            val itemBinding = StoreItemBinding.inflate(LayoutInflater.from(parent.context)
                   , parent, false)
            return StoreViewHolder(itemBinding)
        }
    }


}