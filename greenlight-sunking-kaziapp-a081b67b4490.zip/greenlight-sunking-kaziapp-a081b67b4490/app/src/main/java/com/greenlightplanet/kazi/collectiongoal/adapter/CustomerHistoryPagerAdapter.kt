package com.greenlightplanet.kazi.collectiongoal.adapter

import android.annotation.SuppressLint
import android.util.Log
import androidx.annotation.Keep
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.PagerAdapter
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistory
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistory
import com.greenlightplanet.kazi.collectiongoal.view.fragment.CallingHistoryFragment
import com.greenlightplanet.kazi.collectiongoal.view.fragment.PaymentHistoryFragment

@Keep
class CustomerHistoryPagerAdapter(
    fm: FragmentManager, var callingHistoryList: List<CallHistory>,
    var paymentHistoryList: List<PaymentHistory>,
    var accountNumberString: Int?,
    var nextPage: Int,
    var nextPagePayment: Int
)
    : FragmentPagerAdapter(fm) {

    companion object {
        public const val TAG = "CustomerHistoryPagerAdapter"
    }

    var callingHistoryFragment: CallingHistoryFragment? = null
    var paymentHistoryFragment: PaymentHistoryFragment? = null

    override fun getCount(): Int {
        return 2
    }

    @SuppressLint("LongLogTag")
    override fun getItem(position: Int): Fragment {

        val fragment: Fragment? = null

        when (position) {
            0 -> {

                if(paymentHistoryFragment == null){
                    Log.d("PaymentHistoryListPagerAdp", "success: ${paymentHistoryList}")
                    paymentHistoryFragment = PaymentHistoryFragment.newInstance(paymentHistoryList,accountNumberString,nextPagePayment)
                }

                return paymentHistoryFragment as Fragment
            }
            1 -> {
                if(callingHistoryFragment == null){
                    Log.d("CallingHistoryListPagerAdp", "success: ${callingHistoryList}")
                    callingHistoryFragment = CallingHistoryFragment.newInstance(callingHistoryList,accountNumberString,nextPage)
                }
                return callingHistoryFragment as Fragment
            }
            else ->
                return fragment!!
        }
    }

    override fun getItemPosition(`object`: Any): Int {
        return PagerAdapter.POSITION_NONE
    }

//    override fun getPageTitle(position: Int): CharSequence {
//        var title: String? = null
//        when (position) {
//            0 -> {
//                title = "Payment History"
//                return title
//            }
//            1 -> {
//                title = "Calling History"
//                return title
//            }
//            else ->
//                return title!!
//        }
//    }
}