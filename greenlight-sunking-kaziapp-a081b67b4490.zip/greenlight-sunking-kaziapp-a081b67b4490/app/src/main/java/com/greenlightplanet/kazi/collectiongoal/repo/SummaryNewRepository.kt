package com.greenlightplanet.kazi.collectiongoal.repo

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.annotation.Keep
import androidx.lifecycle.MutableLiveData
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey
import com.google.gson.Gson
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.collectiongoal.model.callhistory.CallHistoryModel
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.collectiongoal.model.pastweekincentive.LastWeekIncentiveModel
import com.greenlightplanet.kazi.collectiongoal.model.paymenthistory.PaymentHistoryModel
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.leads.extras.LEAD_INTENT
import com.greenlightplanet.kazi.leads.extras.LEAD_STATUS
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.new_attendance.extras.ErrorUtils
import com.greenlightplanet.kazi.newcustomerleads.repo.LeadDetailsRepo
import com.greenlightplanet.kazi.newtasks.Status
import com.greenlightplanet.kazi.newtasks.model.CallDetailModel
import com.greenlightplanet.kazi.newtasks.model.CommonTaskModel
import com.greenlightplanet.kazi.newtasks.repo.TaskRepo
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.summary.extras.MAP_STATUS
import com.greenlightplanet.kazi.summary.model.CollectionRateAccount
import com.greenlightplanet.kazi.summary.model.SummaryCallDetailRequestModel
import com.greenlightplanet.kazi.summary.model.post.SummaryCall
import com.greenlightplanet.kazi.summary.model.post.SummaryCallPostRequest
import com.greenlightplanet.kazi.summary.repo.SummaryRepo
import com.greenlightplanet.kazi.task.TaskUtils
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.Flowable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*

@Keep
class SummaryNewRepository(private val context: Context) {

    companion object : SingletonHolderUtil<SummaryNewRepository, Context>(::SummaryNewRepository) {
        const val TAG = "SummaryNewRepository"
    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var gson: Gson? = null
    var preference: GreenLightPreference? = null


    private val angazaId: String? by lazy {
        preference?.getLoginResponseModel()?.angazaId
    }

    init {
        try {

            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context)
            gson = Gson()

        } catch (e: Exception) {
            Log.d(TAG, "Init:Error ");
        }
    }

    fun getLWIncentiveFromServer(nextPage: Int, forceOnline: Boolean = false):
            MutableLiveData<NewCommonResponseModel<LastWeekIncentiveModel>> {

        val data = MutableLiveData<NewCommonResponseModel<LastWeekIncentiveModel>>()
        val forceOnlineString = if (!forceOnline) "false" else "true"
        Log.d("TIME_CALC", "last-week-incentive:${System.currentTimeMillis()} ")

        if (Util.isOnline(context)) {
            bag.add(
                ServiceInstance.getInstance(context).service?.getLWIncentiveData(
                    angazaId!!,
                    forceOnlineString,
                    nextPage
                )!!
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({ success ->
                        success.responseData?.let { response ->

                            Log.d(TAG, "getLWIncentiveFromServer - success: ${success}")

                            success.responseData!!.angazaID = angazaId!!

                            if (!success.responseData!!.achievedAccounts.isNullOrEmpty()) {

                                success.responseData!!.achievedAccounts?.onEach { it.status = true }
                            }
                            if (!success.responseData!!.notAchievedAccounts.isNullOrEmpty()) {

                                success.responseData!!.notAchievedAccounts?.onEach {
                                    it.status = false
                                }
                            }

                            Log.d(TAG, "getLWIncentiveFromServer2 - success: ${success}")
                            updateSharedAccountLastWeekPref(true)
                            data.postValue(success)
                            insertFullLWIncentiveResponseToDb(success, data)
                        }
                    }, { t ->
                        updateSharedAccountLastWeekPref(true)
                        ErrorUtils.errorHandler(
                            gson,
                            t,
                            TAG,
                            "getLastWeekIncentiveFromServer",
                            "Unable to get data from server",
                            data
                        )
                    })
            )
        }

        return data
    }


    fun getLWIncentiveFromDB(nextPage: Int, forceOnline: Boolean = false):
            MutableLiveData<NewCommonResponseModel<LastWeekIncentiveModel>> {

        val data = MutableLiveData<NewCommonResponseModel<LastWeekIncentiveModel>>()
        var result: NewCommonResponseModel<LastWeekIncentiveModel>? = null
        bag.add(
            localDb?.pastWeekIncentiveDao()!!.getAll(angazaId!!)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .map {
                    result = NewCommonResponseModel(success = true, responseData = it)
                }
                .subscribe({ success ->
                    Log.d(TAG, "APICall: Summary3 :$success ")
                    Log.e(TAG, "Offline LastWeek Incentive- success: ${success}")
                    //result?.responseData?.collectionRate?.accounts = success
                    updateSharedAccountLastWeekPref(false)
                    data.postValue(result!!)
                },
                    { t ->
                        ErrorUtils.errorHandler(
                            gson,
                            t,
                            TAG,
                            "Offline LastWeek Incentive",
                            "Unable to get data from server",
                            data
                        )
                    })
        )
        return data
    }

    private fun insertFullLWIncentiveResponseToDb(
        data: NewCommonResponseModel<LastWeekIncentiveModel>?,
        liveData: MutableLiveData<NewCommonResponseModel<LastWeekIncentiveModel>>
    ): Disposable {

        return Flowable.fromCallable {
            localDb?.pastWeekIncentiveDao()?.deleteAll()
        }
            .flatMap {
                Flowable.fromCallable {
                    localDb?.pastWeekIncentiveDao()?.deleteAll()
                }

            }
            .flatMap {
                Flowable.fromCallable {
                    localDb?.pastWeekIncentiveDao()?.insertAll(data?.responseData!!)

                }
            }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe({


                if (data?.responseData != null) {
                    Log.d("TIME_CALC", "lastweek_incentive-end:${System.currentTimeMillis()} ")
                    Log.e(TAG, "insertFullLWIncentiveResponseToDb - success: ${data}")
                    //liveData.postValue(data)

                } else {
                    liveData.postValue(
                        NewCommonResponseModel<LastWeekIncentiveModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = context?.resources?.getString(R.string.no_data_available)
                            ),
                            success = false
                        )
                    )
                }
            }, { t ->
                if (data?.responseData!!.equals(null)) {

                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertLastWeekIncentiveResponseToDb",
                        "No Data Available",
                        liveData
                    )
                } else {
                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertLastWeekIncentiveResponseToDb",
                        "Unable to save data to database",
                        liveData
                    )
                }
            })


    }

    val previousWeekIncentiveData =
        MutableLiveData<NewCommonResponseModel<LastWeekIncentiveModel>>()

    fun getLWIncentiveFromServer1(previousWeekNextPage: Int, forceOnline: Boolean = false)
            : MutableLiveData<NewCommonResponseModel<LastWeekIncentiveModel>> {

        val forceOnlineString = if (!forceOnline) "false" else "true"
        Log.d("TIME_CALC", "last-week-incentive:${System.currentTimeMillis()} ")

        if (Util.isOnline(context)) {
            bag.add(
                ServiceInstance.getInstance(context).service?.getLWIncentiveData(
                    angazaId!!,
                    forceOnlineString,
                    previousWeekNextPage
                )!!
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({ success ->
                        success.responseData?.let { response ->


                            Log.d(TAG, "getLWIncentiveFromServer11 - success: ${success}")

                            success.responseData!!.angazaID = angazaId!!

                            if (!success.responseData!!.achievedAccounts.isNullOrEmpty()) {

                                success.responseData!!.achievedAccounts?.onEach {
                                    it.status = true
                                }
                            }
                            if (!success.responseData!!.notAchievedAccounts.isNullOrEmpty()) {

                                success.responseData!!.notAchievedAccounts?.onEach {
                                    it.status = false
                                }
                            }

                            Log.d(TAG, "getLWIncentiveFromServer22 - success: ${success}")
                            updateSharedPref(true)

                            previousWeekIncentiveData.postValue(
                                NewCommonResponseModel<LastWeekIncentiveModel>(
                                    responseData = success.responseData, success = true
                                )
                            )

                            insertFullLWIncentiveResponseToDb1(
                                success,
                                previousWeekIncentiveData
                            )

                        }
                    },

                        { t ->
                            Util.cancelProgressDialog()
                            updateSharedPref(true)
                            ErrorUtils.errorHandler(
                                gson, t, TAG, "getCallHistoryDetails",
                                "Unable to get data from server", previousWeekIncentiveData
                            )
                        })
            )
        } else {
            var result: NewCommonResponseModel<LastWeekIncentiveModel>? = null
            bag.add(
                localDb?.pastWeekIncentiveDao()!!.getAll(angazaId!!)
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .map {
                        result = NewCommonResponseModel(success = true, responseData = it)
                    }
                    .subscribe({ success ->
                        Log.d(TAG, "APICall: Summary3 :$success ")
                        Log.e(TAG, "Offline LastWeek Incentive- success: ${success}")
                        previousWeekIncentiveData.postValue(result!!)
                    },
                        { t ->
                            ErrorUtils.errorHandler(
                                gson,
                                t,
                                TAG,
                                "Offline LastWeek Incentive",
                                "Unable to get data from server",
                                previousWeekIncentiveData
                            )
                        })
            )
        }

        return previousWeekIncentiveData
    }

    private fun insertFullLWIncentiveResponseToDb1(
        data: NewCommonResponseModel<LastWeekIncentiveModel>?,
        liveData: MutableLiveData<NewCommonResponseModel<LastWeekIncentiveModel>>
    ): Disposable {

        return Flowable.fromCallable {
            localDb?.pastWeekIncentiveDao()?.insertAll(data?.responseData!!)
        }.subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe({


                if (data?.responseData != null) {
                    Log.d("TIME_CALC", "lastweek_incentive-end:${System.currentTimeMillis()} ")
                    Log.e(TAG, "insertFullLWIncentiveResponseToDb - success: ${data}")
                    //liveData.postValue(data)

                } else {
                    liveData.postValue(
                        NewCommonResponseModel<LastWeekIncentiveModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = context?.resources?.getString(R.string.no_data_available)
                            ),
                            success = false
                        )
                    )
                }
            }, { t ->
                if (data?.responseData!!.equals(null)) {
                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertLastWeekIncentiveResponseToDb",
                        "No Data Available",
                        liveData
                    )
                } else {
                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertLastWeekIncentiveResponseToDb",
                        "Unable to save data to database",
                        liveData
                    )
                }
            })
    }

    @SuppressLint("LongLogTag", "LogNotTimber")
    fun getMakeCallDataServer(pageNumber: Int?):
            MutableLiveData<NewCommonResponseModel<MakeCallNewModel>> {

        val data = MutableLiveData<NewCommonResponseModel<MakeCallNewModel>>()
        Log.d("TIME_CALC", "make-call-CollectionGoal:${System.currentTimeMillis()} ")
        if (Util.isOnline(context)) {
            bag.add(
                ServiceInstance.getInstance(context).service?.getMakeCallData(
                    angazaId!!,
                    pageNumber
                )!!
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({ success ->
                        success.responseData?.let { response ->

                            Log.d(
                                "ShivTestModel",
                                "getMakeCall--CollectionGoal - success: ${success.responseData!!.accounts.size}"
                            )

                            if (success.responseData?.next != null) {
                                success.responseData?.next = success.responseData?.next!!.toInt()
                            }

                            @RequiresApi(Build.VERSION_CODES.O)
                            if (!success.responseData!!.accounts.isNullOrEmpty()) {
                                success.responseData!!.id = angazaId!!
                                success.responseData?.accounts?.forEach {
//                                    val l = LocalDate.parse(it.lastCallDate, DateTimeFormatter.ofPattern("dd-MM-yyyy")).toEpochDay()

                                    if (!it.lastCallDate.isNullOrEmpty()) {
                                        val l = LocalDate.parse(
                                            it.lastCallDate,
                                            DateTimeFormatter.ofPattern("yyyy-MM-dd")
                                        ).toEpochDay()
                                        it.date_timestamp = l
                                    }
                                }
                            }

                            Util.cancelProgressDialog()
                            updateSharedMakeCallPref(true)

                            //data.postValue(success)
                            insertFullWeeklyTargetResponseToDb(success, data, pageNumber ?: 1)

                        }
                    },
                        { t ->
                            updateSharedMakeCallPref(true)
                            ErrorUtils.errorHandler(
                                gson,
                                t,
                                TAG,
                                "getNewTaskFromServer",
                                "Unable to get data from server",
                                data
                            )
                        })
            )
        }

        Log.d("CheckingOnVeryFirstDataPostingToUI"," ${data.value?.responseData?.accounts?.size}")
        return data
    }

    fun getMakeCallDataDB(forceOnline: Boolean = false):
            MutableLiveData<NewCommonResponseModel<MakeCallNewModel>> {

        val data = MutableLiveData<NewCommonResponseModel<MakeCallNewModel>>()
        var result: NewCommonResponseModel<MakeCallNewModel>? = null
        bag.add(
            localDb?.weeklyTargetCustomerDao()?.getWeeklyTargetData()!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                /*.map {
                    result = NewCommonResponseModel(success = true, responseData = it)
                }*/
                .subscribe({ success ->
                    Util.cancelProgressDialog()
                    Log.e(TAG, "Offline MakeCall- success: ${success}")
                    result = NewCommonResponseModel(success = true, responseData = success)
                    updateSharedMakeCallPref(false)
                    data.postValue(result!!)
                }, { t ->
                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "getMakeCallDataDB",
                        "Unable to get data from server",
                        data
                    )
                })
        )
        return data
    }

    //Make call accounts saved
/*
    fun insertFullWeeklyTargetResponseToDb(
        data: NewCommonResponseModel<MakeCallNewModel>?,
        liveData: MutableLiveData<NewCommonResponseModel<MakeCallNewModel>>
    ): Disposable {

        return Flowable.fromCallable {
            localDb?.weeklyTargetCustomerDao()?.deleteAll()
        }
            .flatMap {791448
                Flowable.fromCallable {
                    localDb?.weeklyTargetCustomerDao()?.deleteAll()
                }

            }
            .flatMap {
                Flowable.fromCallable {
                    localDb?.weeklyTargetCustomerDao()?.insertMakeCall(data?.responseData!!)

                }
            }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe({

                if (data?.responseData != null) {
                    Log.d("TIME_CALC", "weekly_target-end:${System.currentTimeMillis()} ")
                    Log.e(TAG, "insertFullWeeklyTargetCustomerResponseToDb - success: ${data}")
                    //liveData.postValue(data)

                } else {
                    liveData.postValue(
                        NewCommonResponseModel<MakeCallNewModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = context?.resources?.getString(R.string.no_data_available)
                            ),
                            success = false
                        )
                    )
                }
            }, { t ->
                if (data?.responseData!!.equals(null)) {

                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertFullWeeklyTargetCustomerResponseToDb",
                        "No Data Available",
                        liveData
                    )
                } else {
                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertFullWeeklyTargetCustomerResponseToDb",
                        "Unable to save data to database",
                        liveData
                    )
                }
            })


    }
*/

    fun insertFullWeeklyTargetResponseToDb(
        data: NewCommonResponseModel<MakeCallNewModel>?,
        liveData: MutableLiveData<NewCommonResponseModel<MakeCallNewModel>>,
        pageNumber: Int
    ): Disposable {
        var make: MakeCallNewModel? = null
        val listAll: MutableList<MakeCallNewModel.ColGoalAccount> = mutableListOf()
        listAll.clear()
        return Single.fromCallable {
            localDb?.weeklyTargetCustomerDao()?.getWeeklyTargetData()
        }
            .flatMap {

                Single.fromCallable {
                    if (pageNumber == 1) {
                        localDb?.weeklyTargetCustomerDao()?.deleteAll()
                    }
                    val rr = localDb?.weeklyTargetCustomerDao()?.getbcWeeklyTargetData()
                    if (rr != null) {
                        listAll.addAll(rr.accounts)
                    }
                }

            }
            .flatMap {
                Single.fromCallable {
                    listAll.addAll(data?.responseData?.accounts!!.toMutableList())
                }
            }
            .flatMap {
                Single.fromCallable {
                    localDb?.weeklyTargetCustomerDao()?.deleteAll()
                }
            }
            .flatMap {
                Single.fromCallable {
                    make = data?.responseData!!
                    make?.accounts = listAll.distinctBy { it.accounAngazaId }
                    localDb?.weeklyTargetCustomerDao()?.insertMakeCall(data.responseData!!)
                }
            }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe({

                if (data?.responseData != null) {
                    Log.d("TIME_CALC", "weekly_target-end:${System.currentTimeMillis()} ")
                    Log.e(TAG, "insertFullWeeklyTargetCustomerResponseToDb - success: ${data} " +
                            "\n ListSize : ${data?.responseData?.accounts?.size}")
                   liveData.postValue(data)

                } else {
                    liveData.postValue(
                        NewCommonResponseModel<MakeCallNewModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = context?.resources?.getString(R.string.no_data_available)
                            ),
                            success = false
                        )
                    )
                }
            }, { t ->
                if (data?.responseData!!.equals(null)) {

                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertFullWeeklyTargetCustomerResponseToDb",
                        "No Data Available",
                        liveData
                    )
                } else {
                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertFullWeeklyTargetCustomerResponseToDb",
                        "Unable to save data to database",
                        liveData
                    )
                }
            })

    }


    val callDetailsData = MutableLiveData<NewCommonResponseModel<CallHistoryModel>>()

    @SuppressLint("LongLogTag")
    fun getCallHistory1(accountNumber: Int?, nextPageCalling: Int)
            : MutableLiveData<NewCommonResponseModel<CallHistoryModel>> {

        Log.d("CheckingDataOnCallingApi", " $accountNumber $nextPageCalling")
        bag.add(
            ServiceInstance.getInstance(context).service?.getCallHistory(
                accountNumber,
                nextPageCalling
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({ success ->
                    success.responseData?.let { response ->

                        Util.cancelProgressDialog()
                        updateSharedPrefCallHistory(true)

                        if (success.responseData?.next != null) {
                            success.responseData?.next = success.responseData?.next!!.toInt()
                        }

                        if (!response.callHistory.isNullOrEmpty()) {

                            response.callHistory.onEach {
                                it.accountNumber = success.responseData!!.accountNumber
                            }
                        } else {
                            Util.cancelProgressDialog()
                        }

                        callDetailsData.postValue(
                            NewCommonResponseModel<CallHistoryModel>(
                                responseData = response, success = true
                            )
                        )
                        Log.e(
                            LeadDetailsRepo.TAG,
                            "getLeadsCallDetails - success:${response.callHistory.size} ${success}"
                        )
                    }
                },
                    { t ->
                        Util.cancelProgressDialog()
                        updateSharedPrefCallHistory(true)
                        ErrorUtils.errorHandler(
                            gson, t, TAG, "getCallHistoryDetails",
                            "Unable to get data from server", callDetailsData
                        )
                    })
        )
        return callDetailsData
    }

    fun getCallHistoryServer(accountNumber: Int?, nextPage: Int):
            MutableLiveData<NewCommonResponseModel<CallHistoryModel>> {

        val data = MutableLiveData<NewCommonResponseModel<CallHistoryModel>>()

        Log.d("TIME_CALC", "Call-History:${System.currentTimeMillis()} ")

        Log.d("getCallHistoryAPI_CALL0", " $accountNumber $nextPage")

        if (Util.isOnline(context)) {
            bag.add(
                ServiceInstance.getInstance(context).service?.getCallHistory(
                    accountNumber,
                    nextPage
                )!!
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe({ success ->
                        success.responseData?.let { response ->

                            if (success.responseData?.next != null) {
                                success.responseData?.next = success.responseData?.next!!.toInt()
                            }

                            if (!success.responseData!!.callHistory.isNullOrEmpty()) {

                                success.responseData!!.callHistory.onEach {
                                    it.accountNumber = success.responseData!!.accountNumber
                                }
                            } else {
                                Util.cancelProgressDialog()
                            }

                            Log.d(TAG, "getMakeCall--CustomerCallingHistory - success: ${success}")
                            updateSharedPrefCallHistory(true)
                            data.postValue(success)
                            Log.d(
                                "CheckCallingHistoryDB0",
                                "${data.value?.responseData?.callHistory}"
                            )
                            insertCallHistoryTargetResponseToDb(success, data, accountNumber)


                        }
                    }, { t ->
                        updateSharedPrefCallHistory(true)
                        ErrorUtils.errorHandler(
                            gson,
                            t,
                            TAG,
                            "getCallHistoryCustonmer",
                            "Unable to get data from server",
                            data
                        )
                    })
            )
        }

        return data
    }

    fun getCallingHistoryDB(accountNumber: Int?, nextPage: Int)
            : MutableLiveData<NewCommonResponseModel<CallHistoryModel>> {
        val data = MutableLiveData<NewCommonResponseModel<CallHistoryModel>>()
        var result: NewCommonResponseModel<CallHistoryModel>? = null

        bag.add(
            localDb?.customerHistoryDao()?.getAllCallingHistory1(accountNumber)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .map {
                    result = NewCommonResponseModel(success = true, responseData = it)
                }
                .subscribe({ success ->
                    Log.d(TAG, "APICall: CallingHistory :$success ")
                    Log.e(TAG, "Offline CallingHistory- success: ${success}")
                    //result?.responseData?.collectionRate?.accounts = success
                    updateSharedPrefCallHistory(false)
                    data.postValue(result!!)
                },
                    { t ->
                        ErrorUtils.errorHandler(
                            gson,
                            t,
                            TAG,
                            "Offline CallingHistory",
                            "Unable to get data from server",
                            data
                        )
                    })
        )

        return data

    }

    fun insertCallHistoryTargetResponseToDb(
        data: NewCommonResponseModel<CallHistoryModel>?,
        liveData: MutableLiveData<NewCommonResponseModel<CallHistoryModel>>,
        accountNumber: Int?,
    ): Disposable {

        return Flowable.fromCallable {
            localDb?.customerHistoryDao()?.deleteCustomerHistoryAll(accountNumber)
        }
            .flatMap {
                Flowable.fromCallable {
                    localDb?.customerHistoryDao()?.deleteCustomerHistoryAll(accountNumber)
                }

            }
            .flatMap {
                Flowable.fromCallable {
                    localDb?.customerHistoryDao()?.insertCallHistory(data?.responseData!!)

                }
            }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe({


                if (data?.responseData != null) {
                    Log.d("TIME_CALC", "weekly_target-end:${System.currentTimeMillis()} ")
                    Log.e(
                        TAG,
                        "insertFullWeeklyTargetCustomerResponseToDb - success: ${data}"
                    )
                    //liveData.postValue(data)

                } else {
                    liveData.postValue(
                        NewCommonResponseModel<CallHistoryModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = context?.resources?.getString(R.string.no_data_available)
                            ),
                            success = false
                        )
                    )
                }
            }, { t ->
                if (data?.responseData!!.equals(null)) {

                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertFullWeeklyTargetCustomerResponseToDb",
                        "No Data Available",
                        liveData
                    )
                } else {
                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertFullWeeklyTargetCustomerResponseToDb",
                        "Unable to save data to database",
                        liveData
                    )
                }
            })


    }

    val paymentHistoryDetailsData = MutableLiveData<NewCommonResponseModel<PaymentHistoryModel>>()

    @SuppressLint("LongLogTag")
    fun getPaymentHistory1(accountNumber: Int?, pageNumber: Int)
            : MutableLiveData<NewCommonResponseModel<PaymentHistoryModel>> {

        Log.d("CheckingDataOnPaymentApi", " $accountNumber $pageNumber")
        bag.add(
            ServiceInstance.getInstance(context).service?.getPaymentHistory(
                accountNumber,
                pageNumber
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({ success ->
                    success.responseData?.let { response ->

                        Util.cancelProgressDialog()
                        updateSharedPrefPaymentHistory(true)
                        if (success.responseData?.next != null) {
                            success.responseData?.next = success.responseData?.next!!.toInt()
                        }

                        paymentHistoryDetailsData.postValue(
                            NewCommonResponseModel<PaymentHistoryModel>(
                                responseData = response, success = true
                            )
                        )
                        Log.e(
                            TAG,
                            "getPaymentHistoryDetails - success:${response.paymentHistory?.size} ${success}"
                        )
                    }
                }, { t ->
                    updateSharedPrefPaymentHistory(true)
                    ErrorUtils.errorHandler(
                        gson, t, LeadDetailsRepo.TAG, "getPaymentHistory",
                        "Unable to get data from server", callDetailsData
                    )
                })
        )
        return paymentHistoryDetailsData
    }

    fun getPaymentHistoryServer(accountNumber: Int?, nextPagePayment: Int):
            MutableLiveData<NewCommonResponseModel<PaymentHistoryModel>> {

        val data = MutableLiveData<NewCommonResponseModel<PaymentHistoryModel>>()

        Log.d("TIME_CALC", "payment-History:${System.currentTimeMillis()} ")

        bag.add(
            ServiceInstance.getInstance(context).service?.getPaymentHistory(
                accountNumber,
                nextPagePayment
            )!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({ success ->
                    success.responseData?.let { response ->

                        if (success.responseData?.next != null) {
                            success.responseData?.next = success.responseData?.next!!.toInt()
                        }
                        if (!success.responseData!!.paymentHistory.isNullOrEmpty()) {

                            success.responseData!!.paymentHistory?.onEach {
                                it.accountNumber = success.responseData!!.accountNumber
                            }
                        } else {
                            Util.cancelProgressDialog()
                        }

                        Log.d(TAG, "getMakeCall--PaymentHistory - success: ${success}")
                        updateSharedPrefPaymentHistory(true)
                        data.postValue(success)
                        Log.d(
                            "CheckPaymentHistoryDB0",
                            "${data.value?.responseData?.paymentHistory}"
                        )
                        insertPaymentHistoryTargetResponseToDb(
                            success,
                            data,
                            accountNumber,
                            nextPagePayment
                        )


                    }
                },
                    { t ->
                        updateSharedPrefPaymentHistory(true)
                        ErrorUtils.errorHandler(
                            gson,
                            t,
                            TAG,
                            "getPaymentHistoryCustonmer",
                            "Unable to get data from server",
                            data
                        )
                    })
        )


        return data
    }

    fun getPaymentHistoryDB(accountNumber: Int?, nextPagePayment: Int)
            : MutableLiveData<NewCommonResponseModel<PaymentHistoryModel>> {
        val data = MutableLiveData<NewCommonResponseModel<PaymentHistoryModel>>()
        var result: NewCommonResponseModel<PaymentHistoryModel>? = null

        bag.add(
            localDb?.customerHistoryDao()?.getAllPaymentHistory1(accountNumber)!!
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .map {
                    result = NewCommonResponseModel(success = true, responseData = it)
                }
                .subscribe({ success ->
                    Log.d(TAG, "APICall: PaymentHistory :$success ")
                    Log.e(TAG, "Offline PaymentHistory- success: ${success}")
                    //result?.responseData?.collectionRate?.accounts = success
                    updateSharedPrefPaymentHistory(false)
                    data.postValue(result!!)
                },
                    { t ->
                        ErrorUtils.errorHandler(
                            gson,
                            t,
                            TAG,
                            "Offline PaymentHistory",
                            "Unable to get data from server",
                            data
                        )
                    })
        )

        return data

    }

    fun insertPaymentHistoryTargetResponseToDb(
        data: NewCommonResponseModel<PaymentHistoryModel>?,
        liveData: MutableLiveData<NewCommonResponseModel<PaymentHistoryModel>>,
        accountNumber: Int?,
        CallingnextPage: Int
    ): Disposable {

        return Flowable.fromCallable {
            localDb?.customerHistoryDao()?.deletePaymentHistoryAll(accountNumber)
        }
            .flatMap {
                Flowable.fromCallable {
                    localDb?.customerHistoryDao()?.deletePaymentHistoryAll(accountNumber)
                }

            }
            .flatMap {
                Flowable.fromCallable {
                    localDb?.customerHistoryDao()?.insertPaymentHistory(data?.responseData!!)

                }
            }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe({


                if (data?.responseData != null) {
                    Log.d("TIME_CALC", "Payment_History-end:${System.currentTimeMillis()} ")
                    Log.e(
                        TAG,
                        "insertPaymentHistoryTargetResponseToDb - success: ${data}"
                    )
                    //liveData.postValue(data)

                } else {
                    liveData.postValue(
                        NewCommonResponseModel<PaymentHistoryModel>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = context?.resources?.getString(R.string.no_data_available)
                            ),
                            success = false
                        )
                    )
                }
            }, { t ->
                if (data?.responseData!!.equals(null)) {

                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertPaymentHistoryTargetResponseToDb",
                        "No Data Available",
                        liveData
                    )
                } else {
                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertPaymentHistoryTargetResponseToDb",
                        "Unable to save data to database",
                        liveData
                    )
                }
            })

    }


    /*new added*/
    //region

    //region Post Called details
    fun solveTaskCallDetailRequest(
        summaryCallDetailRequestModel: SummaryCallDetailRequestModel,
        isPresent: Boolean
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        bag.add(

            insertSummaryCalledDetails(summaryCallDetailRequestModel, isPresent)
                .flatMap { solveRateCalledDetails(angazaId!!) }
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "solveTaskCallDetailRequest - success: ${it}")
                    data.postValue(it)
                }, { t ->
                    ErrorUtils.errorDatabase(
                        t,
                        TAG,
                        "solveCallDetailRequest",
                        "Unable to save data to database",
                        data
                    )
                })
        )

        return data
    }

    //For saving Call details
    private fun insertSummaryCalledDetails(
        summaryCallDetailRequestModel: SummaryCallDetailRequestModel,
        isPresent: Boolean
    ): Single<Any?> {
//        var collectionRateAccount: CollectionRateAccount? = null
        var cgAccount: MakeCallNewModel.ColGoalAccount? = null
        var commonTaskDetails: CommonTaskModel? = null
        if (isPresent) {
            return Single.fromCallable {
                localDb?.summaryCallDetailRequestModelDao()?.insert(summaryCallDetailRequestModel)
            }.flatMap {
                Log.e(
                    TAG,
                    "commonTaskDetails - accountNumber:${summaryCallDetailRequestModel.accountNumber.toString()} "
                )
//                localDb?.collectionRateAccountsDao()
//                    ?.getByAccountNumber(summaryCallDetailRequestModel.accountNumber.toString())
                val rr = localDb?.weeklyTargetCustomerDao()?.getbcWeeklyTargetData()!!
                if (rr != null) {
                    val mm =
                        rr.accounts.find { it.accountNumber == summaryCallDetailRequestModel.accountNumber.toString() }
                    if (mm != null) {
                        cgAccount = mm
                    }
                }
                localDb?.weeklyTargetCustomerDao()?.getWeeklyTargetData()!!

            }
                .flatMap {
//                collectionRateAccount = it
                    var date: Date? = null
                    date = Util.getCurrentDate()

                    if (date == null) {
                        date = Calendar.getInstance().time
                    }

                    Log.e(TAG, "cgAccount -1 => :$cgAccount ");

                    val newSummaryCall = SummaryCall(
                        accountAngazaId = cgAccount?.accounAngazaId!!,
                        accountNumber = cgAccount?.accountNumber?.toInt(),
                        attempt = summaryCallDetailRequestModel.attempt,
                        callDuration = summaryCallDetailRequestModel.callDuration,
                        callType = if (!cgAccount!!.isTask!!) {
                            "COLLECTION_CALL"
                        } else {
                            if (cgAccount!!.ticketType.equals("CALLED", true)) {
                                "FOLLOWUP"
                            } else {
                                cgAccount!!.ticketType!!
                            }

                        },
                        calledAt = Util.formateDatetoDDMMYYYYHHMMSS(date!!),
                        contactedNumber = summaryCallDetailRequestModel.contactedNumber,
                        country = preference!!.getLoginResponseModel()!!.country,
                        customerIntent = summaryCallDetailRequestModel.intentId,
                        feedbackCode = summaryCallDetailRequestModel.feedbackId,
                        followUpDate = summaryCallDetailRequestModel.newVisitDate,
                        imei = summaryCallDetailRequestModel.imei,
                        isTask = cgAccount!!.isTask ?: false,
                        otherReason = summaryCallDetailRequestModel.otherReason ?: "",
                        taskId = cgAccount?.taskId!!.toLong(),
                        ticketType = cgAccount!!.ticketType ?: "1st Call",
                        module = summaryCallDetailRequestModel.module
                    )

                    /* if (cgAccount!!.taskStatus.equals("VISIT", true)) {
                         cgAccount!!.eligibleForReimbursement = false
                     } else {
                         if (summaryCallDetailRequestModel.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
                             cgAccount?.ticketType = LEAD_STATUS.CALLED
                             cgAccount!!.eligibleForReimbursement = false
                         }
                         if (newSummaryCall.ticketType != "CALLED") {
                             val oldCallMade = preference?.getNewTaskCallMade() ?: 0
                             preference?.setNewTaskCallMade(oldCallMade + 1)
                         }
                     }*/


                    Single.fromCallable {
                        localDb?.summaryCallPostRequestDao()?.insert(newSummaryCall)
                    }

                }
                .flatMap {
                    Log.e(TAG, "cgAccount -2 => :$cgAccount ")
//                Single.fromCallable {
//                    localDb?.collectionRateAccountsDao()
//                        ?.insertCollectionRate(cgAccount!!)
//                }
                    val rr = localDb?.weeklyTargetCustomerDao()?.getbcWeeklyTargetData()!!
                    val am: MutableList<MakeCallNewModel.ColGoalAccount> = mutableListOf()
                    if (rr != null) {
                        am.clear()
                        am.addAll(rr.accounts)
                        am.forEach {
                            if (it.accountNumber == summaryCallDetailRequestModel.accountNumber.toString()) {
                                if (summaryCallDetailRequestModel.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
                                    it.status = MAP_STATUS.ENABLED
                                    it.isTask = false
                                }
                            }
                        }
                        localDb?.weeklyTargetCustomerDao()?.deleteAll()
                    }
                    Single.fromCallable {
                        localDb?.weeklyTargetCustomerDao()
                            ?.insertMakeCall(
                                MakeCallNewModel(
                                    id = rr.id,
                                    accounts = am,
                                    next = rr.next,
                                    pageNo = rr.pageNo,
                                    isCollectionGoal = rr.isCollectionGoal
                                )
                            )
                    }
                }
                ///new Added to migrate Customer to Task
                .flatMap {

                    Log.e(
                        TAG,
                        "commonTaskDetails - accountNumber 22:${summaryCallDetailRequestModel.accountNumber} "
                    )
                    localDb?.commonTaskModelDao()
                        ?.getByAccountNumber(summaryCallDetailRequestModel.accountNumber.toString())

                }.flatMap {
                    if (isPresent) {
                        var date: Date? = null
                        date = Util.getCurrentDate()

                        if (date == null) {
                            date = Calendar.getInstance().time
                        }

                        if (it == null) {
                            val list: MutableList<String> = mutableListOf()
                            list.clear()
                            cgAccount?.alternateContact1?.let {
                                list.add(0, it)
                            }
                            cgAccount?.alternateContact2?.let {
                                list.add(0, it)
                            }
                            cgAccount?.alternateContact3?.let {
                                list.add(0, it)
                            }
                            cgAccount?.alternateContact4?.let {
                                list.add(0, it)
                            }
                            cgAccount?.alternateContact5?.let {
                                list.add(0, it)
                            }
                            commonTaskDetails = CommonTaskModel(
                                status = /*collectionRateAccount!!.taskStatus!!*/Status.CALLED,
                                accountNumber = cgAccount!!.accountNumber?.toInt()!!,
                                latitude = 0.0,
                                longitude = 0.0,
                                migrationCount = 0,
                                accountAngazaId = cgAccount!!.accounAngazaId,
                                addedDaysAgo = 0,
                                address = cgAccount!!.address,
                                alternateContacts = list,
                                attempt = cgAccount!!.attempt!!,
                                balanceAmount = cgAccount!!.balanceAmount?.toInt(),
                                callDetail = emptyList<CallDetailModel>().toMutableList(),
                                daysDisabled = /*cgAccount!!.daysDisabled*/0,
                                expectedPaid = "0",
                                extraParamTask = "",
                                groupName = cgAccount!!.productName,
                                latestPayment = "",
                                ownerName = cgAccount!!.customerName,
                                ownerPhoneNumber = cgAccount!!.ownerPhoneNumber,
                                registrationDate = cgAccount!!.registrationDate,
                                secondaryPhoneNumber = cgAccount!!.secondaryPhoneNumber,
                                taskId = cgAccount!!.taskId?.toLong(),
                                ticketType = Status.CALLED,
                                totalPaid = cgAccount!!.totalPaid!!.toInt(),
                                weekPaid = 0/*cgAccount!!.weekPaid*/,
                                // for visits
                                barcode = false,
                                imageCapture = false,
                                visitDoneControl = 0,
                                visitMigrationCount = 0,
                                //region dynamic question for visits...
                                dynamicQuestions = emptyList(),
                                paymentAmount = 0,
                                resolvedType = "",
                                //endregion
                            )

                        } else {
                            commonTaskDetails = it

                            if (commonTaskDetails?.callDetail != null) {
                                commonTaskDetails?.callDetail?.add(
                                    CallDetailModel(
                                        attempt = summaryCallDetailRequestModel.attempt!!,
                                        callDetailId = 0,
                                        calledNumber = summaryCallDetailRequestModel.contactedNumber,
                                        date = TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!),
                                        duration = summaryCallDetailRequestModel.callDuration.toString(),
                                        extraParamCallDetail = "",
                                        feedbackId = summaryCallDetailRequestModel.feedbackId,
                                        followupDate = summaryCallDetailRequestModel.newVisitDate,
                                        intentId = summaryCallDetailRequestModel.intentId,
                                        otherReason = summaryCallDetailRequestModel.otherReason,
                                        isVisit = false,
                                        visitDetail = null
                                    )
                                )
                            } else {
                                commonTaskDetails?.callDetail = mutableListOf()
                                commonTaskDetails?.callDetail?.add(
                                    CallDetailModel(
                                        attempt = summaryCallDetailRequestModel.attempt!!,
                                        callDetailId = 0,
                                        calledNumber = summaryCallDetailRequestModel.contactedNumber,
                                        date = TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!),
                                        duration = summaryCallDetailRequestModel.callDuration.toString(),
                                        extraParamCallDetail = "",
                                        feedbackId = summaryCallDetailRequestModel.feedbackId,
                                        followupDate = summaryCallDetailRequestModel.newVisitDate,
                                        intentId = summaryCallDetailRequestModel.intentId,
                                        otherReason = summaryCallDetailRequestModel.otherReason,
                                        isVisit = false,
                                        visitDetail = null
                                    )
                                )
                            }
                            Log.e(TAG, "commonTaskDetails -1 => :$commonTaskDetails ")
                            if (commonTaskDetails!!.ticketType.equals("Visit", true)) {
                                Log.e(TAG, "commonTaskDetails -Visits => :$commonTaskDetails ")
                            } else {
                                if (summaryCallDetailRequestModel.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
                                    commonTaskDetails!!.status = Status.CALLED
                                    commonTaskDetails!!.ticketType = Status.CALLED
                                }
//                                commonTaskDetails!!.status = Status.CALLED
//                                commonTaskDetails!!.ticketType = Status.CALLED
                            }
                        }
                        Single.fromCallable {
                            localDb?.commonTaskModelDao()?.insert(commonTaskDetails!!)
                        }
                    } else {
                        null
                    }

                }

        }
        else {
//not present in Task
            return Single.fromCallable {
                localDb?.summaryCallDetailRequestModelDao()?.insert(summaryCallDetailRequestModel)
            }.flatMap {
                Log.e(
                    TAG,
                    "commonTaskDetails NOT PRESENT - else - accountNumber:${summaryCallDetailRequestModel.accountNumber.toString()} "
                )
                val rr = localDb?.weeklyTargetCustomerDao()?.getbcWeeklyTargetData()!!
                if (rr != null) {
                    val mm =
                        rr.accounts.find { it.accountNumber == summaryCallDetailRequestModel.accountNumber.toString() }
                    if (mm != null) {
                        cgAccount = mm
                    }
                }
                localDb?.weeklyTargetCustomerDao()?.getWeeklyTargetData()!!

            }.flatMap {
//                collectionRateAccount = it

                var date: Date? = null
                date = Util.getCurrentDate()

                if (date == null) {
                    date = Calendar.getInstance().time
                }

                Log.e(TAG, "cgAccount -1 - else - => :$cgAccount ");

                val newSummaryCall = SummaryCall(
                    accountAngazaId = cgAccount?.accounAngazaId!!,
                    accountNumber = cgAccount?.accountNumber?.toInt(),
                    attempt = summaryCallDetailRequestModel.attempt,
                    callDuration = summaryCallDetailRequestModel.callDuration,
                    callType = "COLLECTION_GOAL"
                    /*if (!cgAccount!!.isTask!!) {
                        "COLLECTION_GOAL"
                    } else {
                        if (cgAccount!!.ticketType.equals("CALLED", true)) {
                            "FOLLOWUP"
                        } else {
                            cgAccount!!.ticketType!!
                        }
                    }*/,
                    calledAt = Util.formateDatetoDDMMYYYYHHMMSS(date!!),
                    contactedNumber = summaryCallDetailRequestModel.contactedNumber,
                    country = preference!!.getLoginResponseModel()!!.country,
                    customerIntent = summaryCallDetailRequestModel.intentId,
                    feedbackCode = summaryCallDetailRequestModel.feedbackId,
                    followUpDate = summaryCallDetailRequestModel.newVisitDate,
                    imei = summaryCallDetailRequestModel.imei,
                    isTask = cgAccount!!.isTask ?: false,
                    otherReason = summaryCallDetailRequestModel.otherReason ?: "",
                    taskId = cgAccount?.taskId?.toLong(),
                    ticketType = cgAccount!!.status ?: "1st Call",
                    module = summaryCallDetailRequestModel.module
                )


//                if (collectionRateAccount!!.taskStatus.equals("VISIT", true)) {
//                    collectionRateAccount!!.eligibleForReimbursement = false
//                } else {
//                    if (summaryCallDetailRequestModel.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
//                        collectionRateAccount?.taskStatus = LEAD_STATUS.CALLED
//                        collectionRateAccount!!.eligibleForReimbursement = false
//                    }
//                    if (newSummaryCall.ticketType != "CALLED") {
//                        val oldCallMade = preference?.getNewTaskCallMade() ?: 0
//                        preference?.setNewTaskCallMade(oldCallMade + 1)
//                    }
//                }

                Single.fromCallable {
                    localDb?.summaryCallPostRequestDao()?.insert(newSummaryCall)
                }

            }
            /*.flatMap {
            Log.e(TAG, "collectionRateAccount -2 => :$collectionRateAccount ")
            Single.fromCallable {
                localDb?.collectionRateAccountsDao()
                    ?.insertCollectionRate(collectionRateAccount!!)
            }
        }*/
        }

    }

    //offline Save
    fun insertCallDetailRequestToDb(
        summaryCallDetailRequestModel: SummaryCallDetailRequestModel,
        isPresent: Boolean
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {

        val data = MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>>()

        bag.add(
            insertSummaryCalledDetails(summaryCallDetailRequestModel, isPresent)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "insertCallDetailRequestToDb - success: ${it}")
                    data.postValue(
                        NewCommonResponseModel(
                            success = true,
                            responseData = NewEmptyParcelable()
                        )
                    )

                }, { t ->
                    ErrorUtils.errorHandler(
                        gson,
                        t,
                        TAG,
                        "insertCallDetailRequestToDb",
                        "Unable to save data to database",
                        data
                    )
                })
        )

        return data
    }

    private fun solveRateCalledDetails(angazaId: String): Single<NewCommonResponseModel<NewEmptyParcelable>?> {

//        return localDb?.taskSolveRequestDao()?.getAll()!!
        return localDb?.summaryCallPostRequestDao()?.getAll()!!
            .flatMap {
                if (it.isNullOrEmpty()) {
                    Single.just(
                        NewCommonResponseModel(
                            success = false,
                            error = NewCommonResponseModel.Error(messageToUser = "No Calls to solve")
                        )
                    )
                } else {
                    sendCallDetailRequestToServer(angazaId, SummaryCallPostRequest(it))
                }
            }
    }

    //Post and delete
    private fun sendCallDetailRequestToServer(
        angazaId: String,
        summaryCallPostRequest: SummaryCallPostRequest
    ): Single<NewCommonResponseModel<NewEmptyParcelable>?> {

        var response: NewCommonResponseModel<NewEmptyParcelable>? = null

        return ServiceInstance.getInstance(context!!).service?.solveSummaryCall(
            angazaId,
            summaryCallPostRequest
        )!!
            .flatMap {
                response = it
                Single.fromCallable {
                    localDb?.summaryCallPostRequestDao()?.deleteAll()
                }
            }
            .flatMap { Single.just(response) }
    }


    //endregion

    //region last saved
    private fun updateSharedMakeCallPref(fromInternet: Boolean) {
        var data: LastSaved? = OfferUtils.loadSummaryFromPref(context)
        if (data == null) {
            data = LastSaved()
            data.makeCallSaved =
                "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(context, data)

        } else {
            if (fromInternet) {
                data.makeCallSaved =
                    "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(context, data)
            }
        }
    }

    private fun updateSharedAccountLastWeekPref(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadIncentiveFromPref(context)

        if (data == null) {
            data = LastSaved()
            data.accountLastSaved =
                "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(context, data)

        } else {
            if (fromInternet) {
                data.accountLastSaved =
                    "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(context, data)
            }
        }

    }

    private fun updateSharedPrefCallHistory(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadIncentiveFromPref(context)

        if (data == null) {
            data = LastSaved()
            data.customerCallHistorySaved =
                "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(context, data)

        } else {
            if (fromInternet) {
                data.customerCallHistorySaved =
                    "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(context, data)
            }
        }

    }

    private fun updateSharedPrefPaymentHistory(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadIncentiveFromPref(context)

        if (data == null) {
            data = LastSaved()
            data.customerPaymentHistorySaved =
                "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(context, data)

        } else {
            if (fromInternet) {
                data.customerPaymentHistorySaved =
                    "${context.getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(context, data)
            }
        }

    }

    private fun updateSharedPref(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadSummaryFromPref(context)
        if (data == null) {
            data = LastSaved()
            data.accountLastSaved = context.getString(R.string.last_saved_key) +
                    " ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveSummaryToPref(context, data)
        } else {
            if (fromInternet) {
                data.accountLastSaved = context.getString(R.string.last_saved_key) +
                        " ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveSummaryToPref(context, data)
            }
        }
    }
    //endregion

    fun destroy() {
        Log.d(TAG, "Repo : destroy");
        bag.clear()
    }
}