package com.greenlightplanet.kazi.incentivenew.repo

import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.CollectionAccounts
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.CollectionBreakdownData
import com.greenlightplanet.kazi.networking.NetworkService
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.NetworkResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.HttpException
import timber.log.Timber
import java.io.IOException
import javax.inject.Inject

class CollectionBreakdownRepo @Inject constructor(
    val db: AppDatabase, val networkService: NetworkService, val preference: GreenLightPreference
) {

    suspend fun getAmountCollectedPagingData(
        angazaId: String, page: Int, pageSize: Int, productName: String
    ): Flow<NetworkResult<CollectionAccounts>> = flow {
        if (Helper.isNetworkConnected()) {
            try {
                emit(NetworkResult.Loading())
                Timber.d("AnountCollectedReq: angazaId: $angazaId || || ProductName :$productName || Page :$page || PageSize: $pageSize")
                val response =
                    networkService.getAmountCollectedData(angazaId = angazaId, product = productName , pageNo = page)
                if (response.isSuccessful) {
                    response.body()?.ResponseData?.collectionAccounts?.let { data ->
                        data.angazaId = angazaId
                        emit(NetworkResult.Success(data))
                        //Offline
                        try {
                            if (data.totalElements != 0) {
                                if (page == 0) {
                                    Timber.d("LOCAL SYNC FIRST PAGE CACHE -> Page :$page ")
                                    val cachedLong = db.amountCollectedDao().replace(data)
                                    Timber.d("LOCAL SYNC AmountCollectedData -> $cachedLong ")
                                    emit(NetworkResult.DbSuccess(isSuccess = true, data = data))
                                } else {
                                    Timber.d("LOCAL SYNC NOT FIRST PAGE CACHE -> Page :$page ")
                                    val cachedLong = db.amountCollectedDao().insert(data)
                                    Timber.d("LOCAL SYNC AmountCollectedData: Page :$page -> $cachedLong ")
                                    emit(NetworkResult.DbSuccess(isSuccess = true, data = data))
                                }

                            } else {
                                Timber.d("LOCAL SYNC AmountCollectedData -> Failed: Count is ${data.totalElements} ")
                                emit(NetworkResult.DbSuccess(isSuccess = false))
                            }

                        } catch (e: Exception) {
                            Timber.d("LOCAL SYNC EXCEPTION -> ${e.localizedMessage}")
                            emit(NetworkResult.DbSuccess(isSuccess = false))
                        }
                    }
                } else {
                    Timber.d("USER API SYNC ERROR")
                    emit(NetworkResult.Error("API error occurred"))
                }
            } catch (e: HttpException) {
                Timber.d("USER API SYNC EXCEPTION -> ${e.localizedMessage}")
                emit(NetworkResult.Error(e.localizedMessage ?: "An unexpected error occurred"))
            } catch (e: IOException) {
                Timber.d("USER API SYNC EXCEPTION -> ${e.localizedMessage}")
                emit(NetworkResult.Error("Couldn't reach server. Check your internet connection."))
            } catch (e: Exception) {
                Timber.d("USER API SYNC EXCEPTION -> ${e.localizedMessage}")
                emit(NetworkResult.Exception("An unexpected error occurred"))
            }
        }

    }

    suspend fun getSingleAmountCachedData(angazaId: String, page: Int): CollectionAccounts?{
        return db.amountCollectedDao().getSingleAmountData(angazaId = angazaId, page = page)
    }


    suspend fun getCountAllPagesAmountCollectedData(angazaId: String) =
        db.amountCollectedDao().getCountAllPagesAmountData(angazaId = angazaId)


    suspend fun getCollectionBreakdownData(angazaId: String): Flow<NetworkResult<CollectionBreakdownData>> =
        flow {
            if (Helper.isNetworkConnected()) {
                try {
                    emit(NetworkResult.Loading())
                    // Replace the url
//                    val url = "https://dev.glpapps.com/kazi-core/v1.0/agent-incentive/agent-incentive-collection/US00001"
                    val response = networkService.getCollectionBreakdownData(angazaId)
//                    val response = networkService.getCollectionBreakdownData(url)
                    if (response.isSuccessful) {
                        response.body()?.let { resp ->
                            resp.ResponseData?.let { data ->
                                data.angazaId = angazaId
                                emit(NetworkResult.Success(data))
                                //Offline
                                try {
                                    val synced = db.collectionBreakdownDao().replaceAll(data)
                                    Timber.d("LOCAL SYNC CollectionBreakdownData -> $synced ")
                                    if (synced != null) {
                                        emit(NetworkResult.DbSuccess(isSuccess = true, data = data))
                                    } else emit(NetworkResult.DbSuccess(isSuccess = false))

                                } catch (e: Exception) {
                                    Timber.d("LOCAL SYNC EXCEPTION -> ${e.localizedMessage}")
                                    emit(NetworkResult.DbSuccess(isSuccess = false))
                                }
                            }
                        }
                    }else {
                        Timber.d("CRITERIA API SYNC ERROR")
                        emit(NetworkResult.Error("API error occurred"))
                    }
                } catch (e: HttpException) {
                    emit(NetworkResult.Exception(e.localizedMessage ?: "An unexpected error occurred"))
                } catch (e: IOException) {
                    emit(NetworkResult.Exception("Couldn't reach server. Check your internet connection."))
                } catch (e: Exception) {
                    emit(NetworkResult.Exception("Couldn't reach server. Check your internet connection."))
                }
            }
        }

    suspend fun getCollectionBreakdownCachedData(angazaId: String) =
        db.collectionBreakdownDao().getSingleCollectionData(angazaId)


}