package com.greenlightplanet.kazi.atrisk.model

import android.os.Parcelable
import androidx.room.*
import kotlinx.android.parcel.Parcelize
import com.google.gson.annotations.SerializedName

@Parcelize
data class AtRiskCallPostRequest(
        @ColumnInfo(name = "calls")
        @SerializedName("calls")
        var calls: List<AtRiskCall>
) : Parcelable

@Parcelize
@Entity(tableName = "AtRiskCall", primaryKeys = ["accountAngazaId", "calledAt"])
data class AtRiskCall(
        @ColumnInfo(name = "accountAngazaId")
        @SerializedName("accountAngazaId")
        var accountAngazaId: String,
        @ColumnInfo(name = "accountNumber")
        @SerializedName("accountNumber")
        var accountNumber: Int?,
        @ColumnInfo(name = "attempt")
        @SerializedName("attempt")
        var attempt: Int?,
        @ColumnInfo(name = "callDuration")
        @SerializedName("callDuration")
        var callDuration: Int?,
        @ColumnInfo(name = "callType")
        @SerializedName("callType")
        var callType: String?,
        @ColumnInfo(name = "calledAt")
        @SerializedName("calledAt")
        var calledAt: String,
        @ColumnInfo(name = "contactedNumber")
        @SerializedName("contactedNumber")
        var contactedNumber: String?,
        @ColumnInfo(name = "country")
        @SerializedName("country")
        var country: String?,
        @ColumnInfo(name = "customerIntent")
        @SerializedName("customerIntent")
        var customerIntent: Int?,
        @ColumnInfo(name = "feedbackCode")
        @SerializedName("feedbackCode")
        var feedbackCode: Int?,
        @ColumnInfo(name = "followUpDate")
        @SerializedName("followUpDate")
        var followUpDate: String?,
        @ColumnInfo(name = "imei")
        @SerializedName("imei")
        var imei: String?,
        @ColumnInfo(name = "isTask")
        @SerializedName("isTask")
        var isTask: Boolean,
        @ColumnInfo(name = "otherReason")
        @SerializedName("otherReason")
        var otherReason: String?,
        @ColumnInfo(name = "taskId")
        @SerializedName("taskId")
//        var taskId: Int?,
        var taskId: Long?,
        @ColumnInfo(name = "ticketType")
        @SerializedName("ticketType")
        var ticketType: String?
) : Parcelable