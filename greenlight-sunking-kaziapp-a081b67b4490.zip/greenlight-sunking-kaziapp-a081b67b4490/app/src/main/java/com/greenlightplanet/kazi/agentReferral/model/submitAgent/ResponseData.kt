package com.greenlightplanet.kazi.agentReferral.model.submitAgent


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ResponseData(
    @SerializedName("sms")
    var sms: Sms?,
    @SerializedName("error_message")
    var errorMessage : String?,
    @SerializedName("response_message")
    var responseMessage : String?
) : Parcelable