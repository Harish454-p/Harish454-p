package com.greenlightplanet.kazi.agentReferral.model.referredagentlist


import android.os.Parcelable
import androidx.room.Entity
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ReferredAgentModel(
    @SerializedName("length")
    var length: Int?,
    @SerializedName("pagination")
    var pagination: Pagination?,
    @SerializedName("referred_agents")
    var referredAgents: List<ReferredAgent>?
) : Parcelable