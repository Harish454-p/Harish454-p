package com.greenlightplanet.kazi.leads.view.activity

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import android.util.Log
import android.view.MenuItem
import android.view.View
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivityCustomerLeadsFeedbackBinding
import com.greenlightplanet.kazi.leads.extras.AdapterUtils
import com.greenlightplanet.kazi.leads.extras.AdapterUtils.Companion.dates
import com.greenlightplanet.kazi.leads.model.LeadsCallDetail
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead
import com.greenlightplanet.kazi.leads.model.LeadsIntent
import com.greenlightplanet.kazi.leads.view.adapter.CustomerLeadsFeedbackAdapter
import com.greenlightplanet.kazi.leads.viewmodel.CustomerLeadsFeedbackViewModel
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener

class CustomerLeadsFeedbackActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCustomerLeadsFeedbackBinding
    lateinit var viewModel: CustomerLeadsFeedbackViewModel
    private var leadsCrossSalesLead: LeadsCrossSalesLead? = null
    var adapterList: MutableList<LeadsCallDetail> = mutableListOf()
    private var leadsIntentList: List<LeadsIntent>? = null
    var adapter: CustomerLeadsFeedbackAdapter? = null
    var mHomeWatcher: HomeWatcher? = null

    companion object {
        const val TAG = "CustomerLeadsFragment"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_customer_leads_feedback)
        binding = ActivityCustomerLeadsFeedbackBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProviders.of(this).get(CustomerLeadsFeedbackViewModel::class.java)

        Util.setToolbar(this, binding.toolbar)

        if (intent.hasExtra("LeadsCrossSalesLead")) {
            leadsCrossSalesLead =
                intent.getParcelableExtra<LeadsCrossSalesLead>("LeadsCrossSalesLead")
        }
        binding.recyclerView.isNestedScrollingEnabled = false
        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }

    override fun onResume() {
        super.onResume()

        leadsCrossSalesLead?.let { leadsCrossSalesLead ->

            viewModel.getLeadsIntentFromDb().observe(this, Observer {
                leadsIntentList = it
                setData(leadsCrossSalesLead)
            })
        }
    }

    private fun setData(leadsCrossSalesLead: LeadsCrossSalesLead) {
        binding.tvCustomerName.text = leadsCrossSalesLead.customerName
        binding.tvAccountNumber.text = leadsCrossSalesLead.accountNumber
        binding.tvRegistrationDate.text = leadsCrossSalesLead.createdDate //double check this
        binding.tvInterestedIn.text = leadsCrossSalesLead.interestedIn

        //recyclerView

        val layoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager
        binding.recyclerView.addItemDecoration(
            DividerItemDecoration(
                this,
                DividerItemDecoration.VERTICAL
            ).apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider, theme))
                } else {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider))
                }
            })

        if (!leadsCrossSalesLead.callDetails.isNullOrEmpty()) {
            binding.tvNoData.visibility = View.GONE
            binding.recyclerView.visibility = View.VISIBLE


            setAdapter(leadsCrossSalesLead.callDetails?.filterNotNull()?.toMutableList())
        } else {
            binding.tvNoData.visibility = View.VISIBLE
            binding.recyclerView.visibility = View.GONE
        }

    }

    fun setAdapter(mutableList: MutableList<LeadsCallDetail>?) {
        adapterList.clear()
        mutableList?.let { adapterList.addAll(mutableList) }
        if (adapter == null) {
            Log.d(TAG, "adapter : $adapterList")



            adapter = CustomerLeadsFeedbackAdapter(
                this,
                ArrayList(adapterList)
                    .sortedWith(compareByDescending<LeadsCallDetail> {
                        dates(AdapterUtils.dateConvertertCalled(it.calledDate!!)).time
                    }),
                leadsIntentList
            )
            //adapter?.customerLeadsAdapterCallback = this
            binding.recyclerView.adapter = adapter
        }
        adapter?.notifyDataSetChanged()

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item?.itemId) {
            android.R.id.home -> {

                onBackPressed()

                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();

    }

}
