package com.greenlightplanet.kazi.incentivenew.adapter


import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.greenlightplanet.kazi.databinding.EarningListTemBinding
import com.greenlightplanet.kazi.incentivenew.activity.CollectionBreakdownActivity
import com.greenlightplanet.kazi.incentivenew.model.earning.EarningsFields
import com.greenlightplanet.kazi.utils.Constants
import com.greenlightplanet.kazi.utils.Constants.Companion.DRILL_DOWN_WITH_LINK
import com.greenlightplanet.kazi.utils.Constants.Companion.LOOKUP_RIGHT_ARROW_WEB_RENDER
import com.greenlightplanet.kazi.utils.Util
import com.jakewharton.rxbinding3.view.visibility
import timber.log.Timber

/**
 * Created by Rahul on 03/12/20.
 */
class EarningAdapter(
    private val listdata: List<EarningsFields>,
    private var listener: MyDateData, var context: Context,
    private var webListner: WebCallBack
) : RecyclerView.Adapter<EarningAdapter.ViewHolder?>() {
    companion object

    val TAG = "EarningAdapter"

    private var lastPosition = -1

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val itemBinding =
            EarningListTemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(itemBinding, listener, webListner, context)
    }

    @SuppressLint("WrongConstant")
    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int
    ) {
        val myListData: EarningsFields = listdata[position]
        holder.bind(myListData)
    }

    override fun getItemCount(): Int {
        return listdata.size
    }

    class ViewHolder(
        private val itemBinding: EarningListTemBinding,
        private val listener: MyDateData,
        private val webListner: WebCallBack,
        private val context: Context,

        ) : RecyclerView.ViewHolder(itemBinding.root) {

        private val viewPool = RecyclerView.RecycledViewPool()
        var hashmap: HashMap<String?, String?> = HashMap<String?, String?>()


        @SuppressLint("WrongConstant")
        fun bind(myListData: EarningsFields) {


            itemBinding.tvComponentValue?.text = myListData.name
            try {

                if (myListData.fieldValueDataType.equals("DOUBLE", true) ||
                    myListData.fieldValueDataType.equals("INTEGER", true)
                ) {
                    itemBinding.tvAmountValue?.text =
                        myListData.value?.toDouble()?.let { Util.formatAmount(it) }
                } else {
                    itemBinding.tvAmountValue?.text = myListData.value.toString()
                }
            } catch (e: Exception) {
                Log.e("EaringAdapter", "onBindViewHolder: $e")
            }


            if (myListData.fieldType.equals(Constants.RIGHT_ARROW, false)) {
                itemBinding.imgDownIcon.visibility = View.GONE
                itemBinding.imgRightIcon.visibility = View.VISIBLE

            } else if (myListData.fieldType.equals(DRILL_DOWN_WITH_LINK)) {
                /**/
                itemBinding.imgDownIcon.visibility = View.VISIBLE

                Util.addUnderline2(itemBinding.tvAmountValue)

                itemBinding.tvAmountValue.setOnClickListener {
                    val intent = Intent(context, CollectionBreakdownActivity::class.java)
                    context.startActivity(intent)
                }


                val childLayoutManager = LinearLayoutManager(
                    itemBinding.rvChild?.context, LinearLayout.VERTICAL, false
                )

                childLayoutManager.initialPrefetchItemCount = 4
                itemBinding.rvChild.apply {
                    layoutManager = childLayoutManager
                    adapter = myListData.subFields?.let {
                        myListData.subFields.let { it1 -> EarningChildAdapter(it1) }!!
                    }
                    setRecycledViewPool(viewPool)
                }

                /**/
            } else if (myListData.fieldType.equals(LOOKUP_RIGHT_ARROW_WEB_RENDER)) {
                itemBinding.imgWebIcon.visibility = View.VISIBLE

            } else {
                itemBinding.imgDownIcon.visibility = View.GONE
                itemBinding.imgWebIcon.visibility = View.GONE

                if (myListData.fieldType.equals(Constants.DOWN_ARROW)) {
                    itemBinding.imgDownIcon.visibility = View.VISIBLE
                    itemBinding.imgRightIcon.visibility = View.GONE
                } else {
                    itemBinding.imgRightIcon.visibility = View.GONE

                }
            }


            itemBinding.imgWebIcon.setOnClickListener {
                myListData.renderLink?.let { it1 -> webListner.getWebLink(it1) }
            }

            itemBinding.imgDownIcon.setOnClickListener(null)
            if (hashmap.containsValue(myListData.id)) {
                itemBinding.rvChild.visibility = View.VISIBLE
            } else {
                itemBinding.rvChild.visibility = View.GONE
            }

            itemBinding.imgRightIcon.setOnClickListener {
                myListData.id.let { it1 -> listener.selectedData(it1, position) }
            }

            itemBinding.imgDownIcon.setOnClickListener {
                Timber.d(": imgDownIcon clickkkk }")
                if (itemBinding.rvChild.visibility == View.VISIBLE) {
                    itemBinding.rvChild.visibility = View.GONE
                    itemBinding.imgDownIcon.rotation = Constants.ROTATION_360
                } else {
                    itemBinding.rvChild.visibility = View.VISIBLE
                    itemBinding.imgDownIcon.rotation = Constants.ROTATION_180
                }
            }

            val childLayoutManager = LinearLayoutManager(
                itemBinding.rvChild?.context, LinearLayout.VERTICAL, false
            )

            childLayoutManager.initialPrefetchItemCount = 4
            itemBinding.rvChild.apply {
                layoutManager = childLayoutManager
                adapter = myListData.subFields?.let {
                    myListData.subFields?.let { it1 -> EarningChildAdapter(it1) }!!
                }
                setRecycledViewPool(viewPool)
            }


        }


        /*old with new mix*/
/*
        @SuppressLint("WrongConstant")
        fun bind(myListData: EarningsFields) {


            itemBinding.tvComponentValue?.text = myListData.name
            try {

                if (myListData.fieldValueDataType.equals("DOUBLE", true) ||
                    myListData.fieldValueDataType.equals("INTEGER", true)
                ) {
                    itemBinding.tvAmountValue?.text =
                        myListData.value?.toDouble()?.let { Util.formatAmount(it) }
                } else {
                    itemBinding.tvAmountValue?.text = myListData.value.toString()
                }
            } catch (e: Exception) {
                Log.e("EaringAdapter", "onBindViewHolder: $e")
            }


            if (myListData.fieldType.equals(Constants.RIGHT_ARROW, false)) {
                itemBinding.imgDownIcon.visibility = View.GONE
                itemBinding.imgRightIcon.visibility = View.VISIBLE

            } else if (myListData.fieldType.equals(DRILL_DOWN_WITH_LINK)) {
                */
/**//*

                itemBinding.imgDownIcon.visibility = View.VISIBLE

                val childLayoutManager = LinearLayoutManager(
                    itemBinding.rvChild?.context, LinearLayout.VERTICAL, false
                )

                childLayoutManager.initialPrefetchItemCount = 4
                itemBinding.rvChild.apply {
                    layoutManager = childLayoutManager
                    adapter = myListData.subFields?.let {
                        myListData.subFields.let { it1 -> EarningChildAdapter(it1) }!!
                    }
                    setRecycledViewPool(viewPool)
                }

                */
/**//*

            } else {
                itemBinding.imgDownIcon.visibility = View.GONE
                if (myListData.fieldType.equals(Constants.DOWN_ARROW)) {
                    itemBinding.imgDownIcon.visibility = View.VISIBLE
                    itemBinding.imgRightIcon.visibility = View.GONE
                } else {
                    itemBinding.imgRightIcon.visibility = View.GONE

                }
            }

            if (myListData.fieldType.equals(LOOKUP_RIGHT_ARROW_WEB_RENDER)) {
                itemBinding.imgWebIcon.visibility = View.VISIBLE
            } else {
                itemBinding.imgWebIcon.visibility = View.GONE
            }


            itemBinding.imgWebIcon.setOnClickListener {
                myListData.renderLink?.let { it1 -> webListner.getWebLink(it1) }
            }

            itemBinding.imgDownIcon.setOnClickListener(null)
            if (hashmap.containsValue(myListData.id)) {
                itemBinding.rvChild.visibility = View.VISIBLE
            } else {
                itemBinding.rvChild.visibility = View.GONE
            }

            itemBinding.imgRightIcon.setOnClickListener {
                myListData.id.let { it1 -> listener.selectedData(it1, position) }
            }

            itemBinding.imgDownIcon.setOnClickListener {
                Timber.d(": imgDownIcon clickkkk }")

                if (myListData.fieldType.equals(DRILL_DOWN_WITH_LINK)) {
                    if (itemBinding.rvChild.visibility == View.VISIBLE) {
                        itemBinding.rvChild.visibility = View.GONE
                        itemBinding.imgDownIcon.rotation = Constants.ROTATION_360
                    } else {
                        itemBinding.rvChild.visibility = View.VISIBLE
                        itemBinding.imgDownIcon.rotation = Constants.ROTATION_180
                    }
                } else {
                    Timber.d(": imgDownIcon else clickkkk }")
                    if (hashmap.containsValue(myListData.id)) {
                        hashmap.remove(myListData.id)
                        itemBinding.rvChild.visibility = View.GONE
                        itemBinding.imgDownIcon.rotation = Constants.ROTATION_360
                    } else {
                        itemBinding.imgDownIcon.rotation = Constants.ROTATION_180
                        hashmap[myListData.id] = myListData.id
                    }
                }

            }

            val childLayoutManager = LinearLayoutManager(
                itemBinding.rvChild?.context, LinearLayout.VERTICAL, false
            )

            childLayoutManager.initialPrefetchItemCount = 4
            itemBinding.rvChild.apply {
                layoutManager = childLayoutManager
                adapter = myListData.subFields?.let {
                    myListData.subFields?.let { it1 -> EarningChildAdapter(it1) }!!
                }
                setRecycledViewPool(viewPool)
            }

            if (myListData.fieldType.equals(DRILL_DOWN_WITH_LINK)) {
                Util.addUnderline2(itemBinding.tvAmountValue)

                itemBinding.imgWebIcon.visibility = View.VISIBLE
                itemBinding.imgWebIcon.rotation = 90f

                itemBinding.tvAmountValue.setOnClickListener {
                    val intent = Intent(context, CollectionBreakdownActivity::class.java)
                    context.startActivity(intent)
                }
//                itemBinding.rvChild.visibility = View.VISIBLE


            } else {
//                itemBinding.imgWebIcon.visibility = View.GONE
            }


        }
*/

    }

    interface MyDateData {

        fun selectedData(date: String, position: Int)

    }

    interface WebCallBack {
        fun getWebLink(link: String)
    }

}