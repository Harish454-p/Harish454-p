package com.greenlightplanet.kazi.collectiongoal.view.fragment

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Resources
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.collectiongoal.adapter.MakeCallRecyclerAdapter
import com.greenlightplanet.kazi.collectiongoal.extra.CollectionGoalCallDialog
import com.greenlightplanet.kazi.collectiongoal.model.makecall.MakeCallNewModel
import com.greenlightplanet.kazi.collectiongoal.view.activity.CustomerProfileActivity
import com.greenlightplanet.kazi.collectiongoal.view.activity.MakeCallActivity
import com.greenlightplanet.kazi.collectiongoal.viewmodel.MakeCallViewModel
import com.greenlightplanet.kazi.leads.extras.LEAD_INTENT
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.newtasks.extras.AdapterUtils
import com.greenlightplanet.kazi.newtasks.extras.PermissionHelper
import com.greenlightplanet.kazi.newtasks.extras.SendingCallStatus
import com.greenlightplanet.kazi.newtasks.model.CommonTaskModel
import com.greenlightplanet.kazi.newtasks.model.FeedbackIntentModel
import com.greenlightplanet.kazi.newtasks.model.TaskResponseModel
import com.greenlightplanet.kazi.newtasks.view.fragment.NewTaskButtomSheetSearch
import com.greenlightplanet.kazi.summary.model.SummaryCallDetailRequestModel
import com.greenlightplanet.kazi.utils.Constants
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import timber.log.Timber

private const val ARG_PARAM1 = "list"

@SuppressLint("LongLogTag")
class MakeCallBottomSheetSearch : BottomSheetDialogFragment(),
MakeCallRecyclerAdapter.MakeCallAdapterCallback, CollectionGoalCallDialog.CallIntentDialogCallback,
    SendingCallStatus {


    companion object {
        public const val TAG = "MakeCallBottomSheetSearch"

        @JvmStatic
        fun newInstance(list: List<MakeCallNewModel.ColGoalAccount>?) =
            MakeCallBottomSheetSearch().apply {
                arguments = Bundle().apply {
                    putParcelableArrayList(ARG_PARAM1, ArrayList(list!!))
                }
                Log.d(TAG, "list-newInstance:$list ");
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            list.clear()
            it.getParcelableArrayList<MakeCallNewModel.ColGoalAccount>(ARG_PARAM1)
                ?.let { it1 -> list.addAll(it1) }
        }

        Log.d(TAG, "list-onCreate:$list ")
    }

    var makeCallBottomSheetSearchCallback: MakeCallBottomSheetSearchCallback? = null

    private var list: MutableList<MakeCallNewModel.ColGoalAccount> = mutableListOf()
    private var adapterList: MutableList<MakeCallNewModel.ColGoalAccount> = mutableListOf()
    private var adapter: MakeCallRecyclerAdapter? = null

    private var mBehavior: BottomSheetBehavior<*>? = null
    var editSearch: EditText? = null
    var recycle: RecyclerView? = null

    var permissionHelper: PermissionHelper? = null
    private var collectionGoalCallDialog: CollectionGoalCallDialog? = null
    private var taskFeedback: List<FeedbackIntentModel.Intents>? = null
    private var activityInstance: MakeCallActivity? = null
    var preference: GreenLightPreference? = null
    private val viewModel: MakeCallViewModel by activityViewModels()
    var taskResponseModel: TaskResponseModel? = null
    private var callReceiver: BroadcastReceiver? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val dialog = super.onCreateDialog(savedInstanceState) as BottomSheetDialog
        val view = View.inflate(context, R.layout.bottomsheet_search, null)

        editSearch = view.findViewById(R.id.editTextSearch)
        recycle = view.findViewById(R.id.recyclerView)
        val linearLayout: LinearLayout = view.findViewById(R.id.root)
        val params = linearLayout.layoutParams as LinearLayout.LayoutParams
        params.height = getScreenHeight()
        linearLayout.layoutParams = params
        dialog.setContentView(view)
        init(view)
        mBehavior = BottomSheetBehavior.from(view.parent as View)
        return dialog
    }

    fun init(view: View) {

        activityInstance = (activity as MakeCallActivity?)
        permissionHelper = PermissionHelper(activityInstance!!)
        preference = GreenLightPreference.getInstance(activityInstance!!)
        collectionGoalCallDialog = CollectionGoalCallDialog(activityInstance!!,this)

        collectionGoalCallDialog!!.callIntentDialogCallback = this

        viewModel!!.getTaskIntentFromDb().observe(activityInstance!!, Observer {
            taskFeedback = it?.responseData?.intents
            viewModel.getNewTaskFromDb().observe(this, Observer {
                Log.e("${TAG} == ", "getNewTaskFromDb ${it!!.success}")
                taskResponseModel = it.responseData
            })
        })

        initRecyclerView(view, list)

        setUpReceiver()

        editSearch?.requestFocus()

        editSearch?.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                s?.let {
                    if (s.isEmpty() || s.isBlank()) {
                        setAdapter(list)
                    } else {
                        val text = s.toString()
                        val result = list?.filter { it.customerName!!.contains(text, true) }
                        this@MakeCallBottomSheetSearch.setAdapter(result!!.toMutableList())
                    }

                }

            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                s?.let {
                    val text = s.toString()
                    Log.d(NewTaskButtomSheetSearch.TAG, "text1:$text ");
                }
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                s?.let {
                    val text = s.toString()
                    Log.d(NewTaskButtomSheetSearch.TAG, "text1:$text ");
                }
            }
        })

        view.findViewById<ImageView>(R.id.btnCancel).setOnClickListener {
            Util.hideKeyboard(requireActivity())
            dismiss()
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun initRecyclerView(view: View, list: MutableList<MakeCallNewModel.ColGoalAccount>) {

        val layoutManager = LinearLayoutManager(activity)
        recycle?.layoutManager = layoutManager
        recycle?.addItemDecoration(
            DividerItemDecoration(
                requireContext(),
                DividerItemDecoration.VERTICAL
            ).apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    this.setDrawable(
                        resources.getDrawable(
                            R.drawable.line_divider,
                            requireContext().theme
                        )
                    )
                } else {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider))
                }
            })

        setAdapter(list)
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun setAdapter(mutableList: MutableList<MakeCallNewModel.ColGoalAccount>) {

        Log.e(TAG, "mutableList : ${mutableList!!.size}")
        adapterList.clear()
        if (!mutableList.isNullOrEmpty()) {

            adapterList.addAll(mutableList)
            if (adapter == null) {
                Log.d(NewTaskButtomSheetSearch.TAG, "adapter : ${adapterList.size}")
                adapter = MakeCallRecyclerAdapter(requireContext(), adapterList)
                adapter?.makeCallAdapterCallback = this
                recycle?.adapter = adapter
            }
        }
        adapter?.notifyDataSetChanged()

    }

    override fun onDetach() {
        adapter = null
        Util.hideKeyboard(requireActivity())
        super.onDetach()
    }

    override fun onStart() {
        super.onStart()
        Util.hideKeyboard(requireActivity())
        mBehavior!!.state = BottomSheetBehavior.STATE_EXPANDED

    }

    private fun getScreenHeight(): Int {
        return Resources.getSystem().getDisplayMetrics().heightPixels
    }


    interface MakeCallBottomSheetSearchCallback {

        fun gotoNewTaskProfile(position: Int, commonTaskModel: MakeCallNewModel.ColGoalAccount)
        fun gotoNewTaskFeedback(position: Int, commonTaskModel: MakeCallNewModel.ColGoalAccount)
        fun makeCall(position: Int, commonTaskModel: MakeCallNewModel.ColGoalAccount)
        fun requestCallLogPermission(position: Int, commonTaskModel: MakeCallNewModel.ColGoalAccount)

    }

    override fun gotoNewTaskProfile(position: Int, account: MakeCallNewModel.ColGoalAccount) {
        dismiss()
        val intent = Intent(requireContext(), CustomerProfileActivity::class.java)
        intent.putExtra("makeCallCustomerData", account)
        requireContext().startActivity(intent)

    }

    override fun makeCall(account: MakeCallNewModel.ColGoalAccount) {

        val list: MutableList<String> = mutableListOf()
        list.clear()
        account.alternateContact1?.let {
            list.add(0, it)
        }
        account.alternateContact2?.let {
            list.add(0, it)
        }
        account.alternateContact3?.let {
            list.add(0, it)
        }
        account.alternateContact4?.let {
            list.add(0, it)
        }
        account.alternateContact5?.let {
            list.add(0, it)
        }
        account.secondaryPhoneNumber?.let {
            list.add(0, it)
        }
        account.ownerPhoneNumber?.let {
            list.add(0, it)
        }


        collectionGoalCallDialog?.newShowPhoneNumberDialog(
            account,
            list.filterNot { it.isNullOrBlank() || it.equals("NA") || it.equals("NULL") },
            taskFeedback,
            !account.isTask!!
        )
    }

    override fun requestCallLogPermission(account: MakeCallNewModel.ColGoalAccount) {

        permissionHelper?.onPermissionGranted = { makeCall(account) }
        permissionHelper?.onPermissionRejected = {
            Util.customFseCompletionDialog(
                context = activityInstance!!,
                hideTitle = true,
                message = getString(R.string.please_allow_call),
                okSelected = {
                    it.dismiss()
                },
                title = null
            )
        }
        permissionHelper?.performPermissionCheck(activityInstance!!)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        permissionHelper?.onRequestPermissionsResult(requestCode, permissions, grantResults)
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun dialogCompleted(summaryCallDetailRequestModel: SummaryCallDetailRequestModel) {
        if (summaryCallDetailRequestModel.callDuration < preference!!.getMinimumCallDuration()!!
            && summaryCallDetailRequestModel.intentId != LEAD_INTENT.DID_NOT_ANSWER
        ) {

            AdapterUtils.taskDurationDialog(
                context = activityInstance!!,
                message = "${getString(R.string.duration)} " + summaryCallDetailRequestModel.callDuration.toString() + "${
                    getString(
                        R.string.sec_time
                    )
                } " + AdapterUtils.durationFormat(
                    summaryCallDetailRequestModel.calledTime
                )!!,//"2021-06-03 07:00:00"
                dialogButton = {
                    it.dismiss()
                },
                title = getString(R.string.calls_duration_low)
            )


        } else {
            Log.e("MAzhar ==>", "Completed ==> ${summaryCallDetailRequestModel}")
            performTask(summaryCallDetailRequestModel)
        }

    }

    private fun performTask(summaryCallDetailRequestModel: SummaryCallDetailRequestModel) {
        summaryCallDetailRequestModel.module = Constants.COLLECTION_GOAL_FLAG
        val observer = Observer<NewCommonResponseModel<NewEmptyParcelable>> {
            Log.e("TAG = performTask = ::", "dialogCompleted: $it ")
            Util.cancelProgressDialog()
            if (summaryCallDetailRequestModel.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
                Util.customFseCompletionDialog(
                    context = activityInstance!!,
                    hideTitle = true,
                    message = getString(R.string.congrats_call_made),
                    okSelected = {
                        it.dismiss()
//                        callSummary()
                    },
                    title = null
                )
            }

        }

        val list: MutableList<CommonTaskModel> = mutableListOf()
        list.clear()
        list.addAll(taskResponseModel!!.called!!)
        list.addAll(taskResponseModel!!.firstCall!!)

        val aa = list.find { it.accountNumber == summaryCallDetailRequestModel.accountNumber }
        val isPresent = aa != null
        Log.e("Maz =$isPresent= ", "${aa}")


        if (Util.isOnline(activityInstance!!)) {
            viewModel.solveTaskCallDetailRequest(summaryCallDetailRequestModel, isPresent) {
                Util.showProgressDialog(activityInstance!!)
            }.observe(this, observer)
        } else {
            viewModel.insertCallDetailRequestToDb(summaryCallDetailRequestModel, isPresent) {
                Util.showProgressDialog(activityInstance!!)
            }.observe(this, observer)
        }
    }

    //region for call status
    private fun setUpReceiver() {
        val intentFilter = IntentFilter()

        callReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {

                try {
                    val state = intent?.getStringExtra(TelephonyManager.EXTRA_STATE);
                    if (state.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                        Timber.d("BROADCAST==: CALL STATE: RINGING")
                    }
                    if (state.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                        Timber.d("BROADCAST==: CALL STATE: Connected")
                    }
                    if (state.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                        // CALL ENDED
                        Timber.d("BROADCAST==: CALL STATE: Disconnected")
                        if (preference?.getIsOnCall()!!) {
                            preference?.setIsOnCall(false)
//                            viewModel.currentTask?.let {
//                                navigateToDynamicFeedbackActivity(task = it)
//                            }
                            isOnCall()

                        }
                    }
                } catch (e1: Exception) {
                    Timber.d("BROADCAST==: CALL STATE: EXCEPTION : $e1")
                    e1.printStackTrace();
                }
            }
        }

        intentFilter.addAction("android.intent.action.PHONE_STATE")
        requireActivity().registerReceiver(callReceiver, intentFilter)

    }

    override fun setOnCall(isOnCall: Boolean) {
        preference?.setIsOnCall(isOnCall)!!
    }

    override fun isOnCall(): Boolean {
        return preference?.getIsOnCall()!!
    }

}