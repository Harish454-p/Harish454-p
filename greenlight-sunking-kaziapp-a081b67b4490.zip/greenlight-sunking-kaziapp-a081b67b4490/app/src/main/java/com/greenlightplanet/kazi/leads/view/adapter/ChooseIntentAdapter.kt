package com.greenlightplanet.kazi.leads.view.adapter
/*

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.leads.model.LeadsIntent

class ChooseIntentAdapter(val context: Context, val phoneNumbers: List<LeadsIntent>) : BaseAdapter() {


    companion object {
        public const val TAG = "ChooseIntentAdapter"
    }

    var chooseIntentAdapterCallback: ChooseIntentAdapterCallback? = null
    var view: View? = null
    var selectedPosition: Int? = null

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val inflater = context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE) as LayoutInflater

        view = inflater.inflate(R.layout.adapter_choose_intent, null)

        bind(view!!, position)

        return view!!
    }

    override fun getItem(position: Int): Any? {
        return null
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return phoneNumbers.size
    }


    private fun bind(view: View, position: Int) {
        val leadsIntent = phoneNumbers.get(position)
        view.tvIntent.text = leadsIntent.intent


//        if (selectedPosition != null) {
//            if (selectedPosition == position) {
//                select(view.tvIntent)
//            } else {
//                deSelect(view.tvIntent)
//            }
//        }

        view.tvIntent.setOnClickListener {
            //selectedPosition = position
            chooseIntentAdapterCallback?.numberSelected(position, leadsIntent)
        }

    }


    interface ChooseIntentAdapterCallback {

        fun numberSelected(position: Int, leadsIntent: LeadsIntent)

    }

    private fun select(tv: TextView) {
        tv.setBackgroundResource(R.color.clr_glp_dark);
    }

    private fun deSelect(tv: TextView) {
        tv.setBackgroundResource(R.color.clr_glp);
    }
}
*/
