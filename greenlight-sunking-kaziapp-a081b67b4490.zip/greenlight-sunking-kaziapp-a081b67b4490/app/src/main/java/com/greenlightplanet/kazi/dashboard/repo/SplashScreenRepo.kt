package com.greenlightplanet.kazi.dashboard.repo

import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.dashboard.model.response.AppVersionResponse
import com.greenlightplanet.kazi.fse.extras.util.SingletonHolderUtil
import com.greenlightplanet.kazi.dashboard.model.CountryResponseData
import com.greenlightplanet.kazi.member.model.BaseRequestModel
import com.greenlightplanet.kazi.member.model.BaseResponseModel
import com.greenlightplanet.kazi.networking.CommonResponseModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.promotion.repo.PromotionRepo
import com.greenlightplanet.kazi.task.model.request.TicketRequestModel
import com.greenlightplanet.kazi.tvinstallation.model.response.AWSResponseModel
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class SplashScreenRepo(val context: Context) {

    companion object : SingletonHolderUtil<SplashScreenRepo, Context>(::SplashScreenRepo) {
        public const val TAG = "SplashScreenRepo"
    }

    private val bag: CompositeDisposable = CompositeDisposable()
    private var localDb: AppDatabase? = null
    var preference: GreenLightPreference? = null
    //private val angazaId = "US029268"
    private val angazaId by lazy {
        preference?.getLoginResponseModel()?.angazaId
    }
    var gson: Gson? = null

    init {
        try {
            localDb = AppDatabase.getAppDatabase(context)
            preference = GreenLightPreference.getInstance(context)
            gson = Gson()
        } catch (e: Exception) {
            Log.d(TAG, "Init:Error ");
        }
    }

    fun deleteAll (){

    }

    fun postTask(angazaId: String, requestModel: TicketRequestModel?): MutableLiveData<CommonResponseModel<BaseResponseModel>> {

        val data = MutableLiveData<CommonResponseModel<BaseResponseModel>>()

        bag.add(
                ServiceInstance.getInstance(context).serviceTask?.solveRXTask(
                        angazaId = angazaId, requestModel = requestModel)!!
                        .subscribeOn(Schedulers.io())
                        .observeOn(Schedulers.io())
                        .subscribe({ success ->
                            data.postValue(success)
                        }, { t ->
                            Log.d(TAG, "API-Error: ${t.localizedMessage}")
                        })
        )

        return data

    }


	fun awsRX(context: Context, requestModel: BaseRequestModel): MutableLiveData<CommonResponseModel<AWSResponseModel>> {
		val data = MutableLiveData<CommonResponseModel<AWSResponseModel>>()

		bag.add(
				ServiceInstance.getInstance(context).service!!.awsRx(requestModel)
						.subscribeOn(Schedulers.io())
						.observeOn(Schedulers.io())
						.subscribe({
							Log.e(TAG, "||=======${it}")
							data.postValue(it)

						}, {
							Log.e(TAG, "||=======EROORRRR = $it")
							data.postValue(
									CommonResponseModel<AWSResponseModel>().apply {
										this.Error = com.greenlightplanet.kazi.member.Error(MessageToUser = "Unable to send data to server")
										this.Success = false
									}
							)
						})
		)

		return data

	}

    fun getRXVersion(
    ): MutableLiveData<NewCommonResponseModel<AppVersionResponse>> {
        val data = MutableLiveData<NewCommonResponseModel<AppVersionResponse>>()

        bag.add(
            ServiceInstance.getInstance(context).service!!
                .getRXVersion(
                    versionCode = BuildConfig.VERSION_CODE,
                    territory = null
                )
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe({
                    Log.e(TAG, "||===RESPONSE ${it}")
                    data.postValue(it)
                }, {
                    Log.e(TAG, "||===ERROR = $it")
                    data.postValue(
                        NewCommonResponseModel<AppVersionResponse>(
                            error = NewCommonResponseModel.Error(
                                messageToUser = "Unable to send data to server"
                            ),
                            success = false
                        )
                    )

                })
        )

        return data
    }

    fun getCountries(context: Context): MutableLiveData<NewCommonResponseModel<CountryResponseData>> {
        val mutableLiveData: MutableLiveData<NewCommonResponseModel<CountryResponseData>> = MutableLiveData()

        bag.add(
            ServiceInstance.getInstance(context).service?.getCountries()
                ?.subscribeOn(Schedulers.io())
                ?.observeOn(Schedulers.io())
                ?.subscribe({
                    mutableLiveData.postValue(it!!)

                    Log.e(PromotionRepo.TAG, "==getPromotionResponse== Done")
                }, {
                    it.printStackTrace()
                    Log.e(PromotionRepo.TAG, "==getPromotionResponse== EROOORRRR"+it.message.toString()+"==="+it.localizedMessage)
                    mutableLiveData.postValue(NewCommonResponseModel<CountryResponseData>(
                        error = NewCommonResponseModel.Error(
                            messageToUser = "Unable get data from server"
                        ),
                        success = false
                    ))
                })!!
        )
        return mutableLiveData
    }

}
