package com.greenlightplanet.kazi.leads.view.fragment

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import androidx.fragment.app.Fragment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.FragmentCustomerLeadsBinding
import com.greenlightplanet.kazi.leads.extras.LeadsFeedbackDialog
import com.greenlightplanet.kazi.leads.extras.LEAD_INTENT
import com.greenlightplanet.kazi.leads.extras.LEAD_TAB
import com.greenlightplanet.kazi.leads.extras.PermissionHelper
import com.greenlightplanet.kazi.leads.model.CallDetailRequestModel
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead
import com.greenlightplanet.kazi.leads.model.LeadsIntent
import com.greenlightplanet.kazi.leads.view.activity.CustomerLeadsActivity
import com.greenlightplanet.kazi.leads.view.activity.CustomerLeadsFeedbackActivity
import com.greenlightplanet.kazi.leads.view.activity.CustomerLeadsProfileActivity
import com.greenlightplanet.kazi.leads.view.adapter.CustomerLeadsAdapter
import com.greenlightplanet.kazi.leads.viewmodel.CustomerLeadsViewModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.newtasks.extras.AdapterUtils
import com.greenlightplanet.kazi.newtasks.extras.SendingCallStatus
import com.greenlightplanet.kazi.task.activity.EligibilityActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import timber.log.Timber


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "list"
private const val ARG_PARAM2 = "type"


class CustomerLeadsFragment : Fragment(), CustomerLeadsAdapter.CustomerLeadsAdapterCallback,
    LeadsFeedbackDialog.DummyFeedbackIntentDialogCallback, SendingCallStatus {

    private var _binding: FragmentCustomerLeadsBinding? = null
    private val binding get() = _binding!!

    companion object {
        const val TAG = "CustomerLeadsFragment"

        @JvmStatic
        fun newInstance(list: List<LeadsCrossSalesLead>?, type: String) =
            CustomerLeadsFragment().apply {
                arguments = Bundle().apply {
                    putParcelableArrayList(ARG_PARAM1, ArrayList(list!!))
                    putString(ARG_PARAM2, type)
                }
            }
    }

    var permissionHelper: PermissionHelper? = null

    var customerLeadsFragmentCallback: CustomerLeadsFragmentCallback? = null
    lateinit var viewModel: CustomerLeadsViewModel
    private var activityInstance: CustomerLeadsActivity? = null
    private var list: MutableList<LeadsCrossSalesLead>? = null
    private val type: String? by lazy {
        arguments?.getString(ARG_PARAM2)
    }
    private var leadsIntents: List<LeadsIntent>? = null

    private var adapterList: MutableList<LeadsCrossSalesLead> = mutableListOf()
    private var adapter: CustomerLeadsAdapter? = null
    var preference: GreenLightPreference? = null
    private var leadsFeedbackDialog: LeadsFeedbackDialog? = null
    private var callReceiver: BroadcastReceiver? = null

    private var receiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null) {

                if (intent.action == "custom_lead_search") {
                    val functionType = intent.getStringExtra("functionType")
                    val tabType = intent.getStringExtra("tabType")
                    Log.d(TAG, "type:$type ");
                    Log.d(TAG, "tabType:$tabType ");
                    if (type == tabType) {


                        if (functionType == "gotoCustomerLeadsProfile") {
                            val leadsCrossSalesLead =
                                intent.getParcelableExtra<LeadsCrossSalesLead>("leadsCrossSalesLead")
                            leadsCrossSalesLead?.let { gotoCustomerLeadsProfile(0, it) }
                        } else if (functionType == "gotoCustomerLeadsFeedback") {
                            val leadsCrossSalesLead =
                                intent.getParcelableExtra<LeadsCrossSalesLead>("leadsCrossSalesLead")
                            leadsCrossSalesLead?.let { gotoCustomerLeadsFeedback(0, it) }
                        } else if (functionType == "makeCall") {
                            val leadsCrossSalesLead =
                                intent.getParcelableExtra<LeadsCrossSalesLead>("leadsCrossSalesLead")
                            val newPosition =
                                adapterList.indexOf(adapterList.find { it.accountNumber == leadsCrossSalesLead?.accountNumber })
                            leadsCrossSalesLead?.let { makeCall(newPosition, it) }
                        } else if (functionType == "requestCallLogPermission") {
                            val leadsCrossSalesLead =
                                intent.getParcelableExtra<LeadsCrossSalesLead>("leadsCrossSalesLead")
//							requestCallLogPermission(0, leadsCrossSalesLead)
                            val newPosition =
                                adapterList.indexOf(adapterList.find { it.accountNumber == leadsCrossSalesLead?.accountNumber })
                            leadsCrossSalesLead?.let { requestCallLogPermission(newPosition, it) }
                        }
                    }
                } else {
                    val type = intent.getStringExtra("type")
                    val intentResult: MutableList<LeadsCrossSalesLead>? =
                        intent.getParcelableArrayListExtra<LeadsCrossSalesLead>("list")
                    if (type == "search") {
                        if (intentResult.isNullOrEmpty()) {
                            visibilityHandler(false, false, true)
                        } else {
                            visibilityHandler(true, false, false)
                        }
                    }

                    setAdapter(intentResult)
                }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            list = it.getParcelableArrayList<LeadsCrossSalesLead>(ARG_PARAM1)
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentCustomerLeadsBinding.inflate(inflater, container, false)

        activityInstance = (activity as CustomerLeadsActivity?)!!
        customerLeadsFragmentCallback = activityInstance

        viewModel =
            ViewModelProviders.of(activityInstance!!).get(CustomerLeadsViewModel::class.java)
        preference = GreenLightPreference.getInstance(activityInstance!!)
        permissionHelper = PermissionHelper(activityInstance!!)

        initBroadcast()

        initRecyclerView(list)
        leadsFeedbackDialog = LeadsFeedbackDialog(activityInstance!!, this)
        leadsFeedbackDialog?.dummyFeedbackIntentDialogCallback = this
        setUpReceiver()

        viewModel.getLeadsIntentFromDb().observe(activityInstance!!, Observer {
            leadsIntents = it
        })

        binding.btSearchedData.setOnClickListener {
            startActivity(Intent(context, EligibilityActivity::class.java))
        }

        return binding.root

    }

    private fun initRecyclerView(list: List<LeadsCrossSalesLead>?) {
        val layoutManager = LinearLayoutManager(activityInstance)
        binding.recyclerView.layoutManager = layoutManager
        binding.recyclerView.addItemDecoration(
            DividerItemDecoration(
                requireContext(),
                DividerItemDecoration.VERTICAL
            ).apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    this.setDrawable(
                        resources.getDrawable(
                            R.drawable.line_divider,
                            requireContext().theme
                        )
                    )
                } else {
                    this.setDrawable(resources.getDrawable(R.drawable.line_divider))
                }
            })

        visibilityHandler(false, true, false)
        setAdapter(list?.toMutableList())

    }

    private fun initBroadcast() {
        val lbm = LocalBroadcastManager.getInstance(requireContext())
        if (type == LEAD_TAB.PENDING) {
            lbm.registerReceiver(receiver, IntentFilter(LEAD_TAB.PENDING))
        } else if (type == LEAD_TAB.CALLED) {
            lbm.registerReceiver(receiver, IntentFilter(LEAD_TAB.CALLED))
        }

        lbm.registerReceiver(receiver, IntentFilter("custom_lead_search"))
    }

    fun setAdapter(mutableList: MutableList<LeadsCrossSalesLead>?) {
        Log.e(TAG, "mutableList : $mutableList")
        adapterList.clear()
        if (!mutableList.isNullOrEmpty()) {

            visibilityHandler(true, false, false)

            adapterList.addAll(mutableList)
            if (adapter == null) {
                Log.d(TAG, "adapter : $adapterList")
                adapter = CustomerLeadsAdapter(activityInstance!!, adapterList)
                adapter?.customerLeadsAdapterCallback = this
                binding!!.recyclerView.adapter = adapter
            }
        }
        adapter?.notifyDataSetChanged()
    }


    override fun gotoCustomerLeadsProfile(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead) {
        val intent = Intent(context, CustomerLeadsProfileActivity::class.java)
        intent.putExtra("LeadsCrossSalesLead", leadsCrossSalesLead)
        startActivity(intent)
    }

    override fun gotoCustomerLeadsFeedback(
        position: Int,
        leadsCrossSalesLead: LeadsCrossSalesLead
    ) {
        val intent = Intent(context, CustomerLeadsFeedbackActivity::class.java)
        intent.putExtra("LeadsCrossSalesLead", leadsCrossSalesLead)
        startActivity(intent)
    }

    override fun makeCall(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead) {

        val list = leadsCrossSalesLead.alternateContacts?.toMutableList()

        leadsCrossSalesLead.primaryPhoneNumber?.let {
            list?.add(0, it)
        }

        leadsCrossSalesLead.secondaryPhoneNumber?.let {
            list?.add(1, it)
        }

        if (!list.isNullOrEmpty() && !leadsIntents.isNullOrEmpty()) {
            leadsFeedbackDialog?.newShowPhoneNumberDialog(
                leadsCrossSalesLead,
                position,
                list.filterNot { it.isNullOrBlank() || it.equals("NA") },
                leadsIntents
            )
        } else {
            Util.showToast(getString(R.string.unable_to_make_call), activityInstance)
        }


    }

    override fun requestCallLogPermission(position: Int, leadsCrossSalesLead: LeadsCrossSalesLead) {

        permissionHelper?.onPermissionGranted = { makeCall(position, leadsCrossSalesLead) }
        permissionHelper?.onPermissionRejected = {
            Util.customFseCompletionDialog(
                context = activityInstance!!,
                hideTitle = true,
                message = getString(R.string.please_allow_call),
                okSelected = {
                    it.dismiss()
                },
                title = null
            )
        }
        permissionHelper?.performPermissionCheck(activityInstance!!)
    }


    override fun dialogCompleted(
        callDetailRequestModel: CallDetailRequestModel,
        adapterPosition: Int
    ) {

        if (callDetailRequestModel.callDuration < 20 && callDetailRequestModel.intentId != LEAD_INTENT.DID_NOT_ANSWER) {

            /*Util.customFseCompletionDialog(
                context = activityInstance!!,
                hideTitle = true,
                message = "Call Duration low, Duration=" + callDetailRequestModel.callDuration + ",Time =" + callDetailRequestModel.calledTime,
                okSelected = {
                    it.dismiss()
                },
                title = null
            )*/

            AdapterUtils.taskDurationDialog(
                context = requireActivity(),
                message = "${getString(R.string.duration)} " + callDetailRequestModel.callDuration.toString() + "${
                    getString(
                        R.string.sec_time
                    )
                } " + AdapterUtils.durationFormat(
                    callDetailRequestModel.calledTime
                )!!,//"2021-06-03 07:00:00"
                dialogButton = {
                    it.dismiss()
                },
                title = getString(R.string.calls_duration_low)
            )

        } else {

            if (callDetailRequestModel.intentId == LEAD_INTENT.CANCLE) {

                Util.customFseRationaleDialog(activityInstance!!, "",
                    hideNegative = false,
                    titleSpanned = null,
                    hideTitle = true,
                    message = getString(R.string.lead_will_stop_in_kazi_are_u_sure),
                    positveSelected = {
                        it.dismiss()
                        perfromLeads(callDetailRequestModel)
                    },
                    negativeSeleted = {
                        it.dismiss()
                        leadsFeedbackDialog!!.newSpinnerIntentDialog(
                            activityInstance!!,
                            leadsIntents
                        )
                    }
                )

            } else {
                perfromLeads(callDetailRequestModel)
            }

        }

    }

    private fun visibilityHandler(
        showRecyclerView: Boolean = false,
        showNoData: Boolean = false,
        showSearchNoData: Boolean = false
    ) {

        if (showRecyclerView) {
            binding.recyclerView.visibility = View.VISIBLE
        } else {
            binding.recyclerView.visibility = View.GONE
        }

        if (showNoData) {
            binding.tvNoData.visibility = View.VISIBLE
        } else {
            binding.tvNoData.visibility = View.GONE
        }

        if (showSearchNoData) {
            binding.tvSearchedData.visibility = View.VISIBLE
            binding.btSearchedData.visibility = View.VISIBLE
        } else {
            binding.tvSearchedData.visibility = View.GONE
            binding.btSearchedData.visibility = View.GONE
        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        permissionHelper?.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    interface CustomerLeadsFragmentCallback {
        fun refreshFragments()
    }


    private fun perfromLeads(callDetailRequestModel: CallDetailRequestModel) {

        val observer = Observer<NewCommonResponseModel<NewEmptyParcelable>> {
            Log.d(TAG, "dialogCompleted: $it ");

            if (callDetailRequestModel.intentId != LEAD_INTENT.DID_NOT_ANSWER) {
                Util.customFseCompletionDialog(
                    context = activityInstance!!,
                    hideTitle = true,
                    message = if (callDetailRequestModel.intentId == LEAD_INTENT.CANCLE) {
                        getString(R.string.lead_has_cancelled)
                    } else {
                        getString(R.string.congrats_call_made)
                    },
                    okSelected = {
                        it.dismiss()
                    },
                    title = null
                )
            }

            customerLeadsFragmentCallback?.refreshFragments()
        }



        if (Util.isOnline(activityInstance)) {
            viewModel.solveCallDetailRequest(callDetailRequestModel) {
                activityInstance?.showProgressDialog(activityInstance)
            }.observe(activityInstance!!, observer)
        } else {
            viewModel.insertCallDetailRequestToDb(callDetailRequestModel) {
                activityInstance?.showProgressDialog(activityInstance)
            }.observe(activityInstance!!, observer)
        }


    }

    //region for call status
    private fun setUpReceiver() {
        val intentFilter = IntentFilter()

        callReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {

                try {
                    val state = intent?.getStringExtra(TelephonyManager.EXTRA_STATE);
                    if (state.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                        Timber.d("BROADCAST==: CALL STATE: RINGING")
                    }
                    if (state.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                        Timber.d("BROADCAST==: CALL STATE: Connected")
                    }
                    if (state.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                        // CALL ENDED
                        Timber.d("BROADCAST==: CALL STATE: Disconnected")
                        if (preference?.getIsOnCall()!!) {
                            preference?.setIsOnCall(false)
//                            viewModel.currentTask?.let {
//                                navigateToDynamicFeedbackActivity(task = it)
//                            }
                            isOnCall()

                        }
                    }
                } catch (e1: Exception) {
                    Timber.d("BROADCAST==: CALL STATE: EXCEPTION : $e1")
                    e1.printStackTrace();
                }
            }
        }

        intentFilter.addAction("android.intent.action.PHONE_STATE")
        requireActivity().registerReceiver(callReceiver, intentFilter)

    }

    override fun setOnCall(isOnCall: Boolean) {
        preference?.setIsOnCall(isOnCall)!!
    }

    override fun isOnCall(): Boolean {
        return preference?.getIsOnCall()!!
    }

    //endregion

}
