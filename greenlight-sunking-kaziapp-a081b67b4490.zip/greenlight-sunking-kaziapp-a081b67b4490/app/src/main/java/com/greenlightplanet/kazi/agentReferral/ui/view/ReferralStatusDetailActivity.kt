package com.greenlightplanet.kazi.agentReferral.ui.view

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.agentReferral.ReferralConstants.referral_status_detail
import com.greenlightplanet.kazi.agentReferral.model.referralStatus.Referral
import com.greenlightplanet.kazi.agentReferral.model.referralStatusDetail.ReferralDetail
import com.greenlightplanet.kazi.agentReferral.ui.adapter.ReferralStatusDetailAdapter
import com.greenlightplanet.kazi.agentReferral.viewmodel.ReferralStatusDetailViewModel
import com.greenlightplanet.kazi.databinding.ActivityReferralStatusDetailBinding
import com.greenlightplanet.kazi.leads.view.activity.CustomerLeadsFeedbackActivity
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener

class ReferralStatusDetailActivity : BaseActivity(), ReferralStatusDetailAdapter.OnReferralDetail {

    private val TAG : String = "RefStatDetActivity"
    private lateinit var binder : ActivityReferralStatusDetailBinding
    private lateinit var viewModel : ReferralStatusDetailViewModel
    private var mHomeWatcher: HomeWatcher? = null
    private var referral : Referral? = null
    private var adapter : ReferralStatusDetailAdapter? = null
    private var preference : GreenLightPreference? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binder = ActivityReferralStatusDetailBinding.inflate(layoutInflater)
        setContentView(binder.root)

        preference = GreenLightPreference.getInstance(this)
        Util.setToolbar(this, binder.toolbar)
        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                Log.i(CustomerLeadsFeedbackActivity.TAG, "onHomePressed")
                finish()
            }
        })
        mHomeWatcher!!.startWatch()

        viewModel = ViewModelProvider(this)[ReferralStatusDetailViewModel::class.java]

        viewModelHandler()
    }

    private fun viewModelHandler() {
        showLastSync()

        intent.extras?.let {
            referral = it.getParcelable(referral_status_detail)
        }
        viewModel.run {
            binder.run {
                showProgressDialog(context = this@ReferralStatusDetailActivity)
                fetchReferralDetail(
                    isOnline = Util.isOnline(this@ReferralStatusDetailActivity),
                    status = referral
                ).observe(this@ReferralStatusDetailActivity, Observer { response ->
                    when(response) {
                        null -> {
                            txtNoReferralDetail.visibility = View.VISIBLE
                            rcReferralDetails.visibility = View.GONE
                            cancelProgressDialog()
                        }
                        else -> {
                            when(response.success) {
                                true -> {
                                    showLastSync()
                                    when(response.responseData) {
                                        null -> {
                                            txtNoReferralDetail.visibility = View.VISIBLE
                                            rcReferralDetails.visibility = View.GONE
                                            cancelProgressDialog()
                                        }
                                        else -> prepData(response.responseData!!)
                                    }
                                }
                                false -> {
                                    txtNoReferralDetail.visibility = View.VISIBLE
                                    rcReferralDetails.visibility = View.GONE
                                    cancelProgressDialog()
                                    Util.customFseRationaleDialog(
                                        context = this@ReferralStatusDetailActivity,
                                        title = "",
                                        hideNegative = true,
                                        titleSpanned = null,
                                        hideTitle = true,
                                        message = this@ReferralStatusDetailActivity.getString(R.string.no_data),
                                        positveSelected = {
                                            it.dismiss()
                                        },
                                        negativeSeleted = {
                                            it.dismiss()
                                        }
                                    )
                                }
                            }
                        }
                    }
                })
                obsChildPhone.observe(this@ReferralStatusDetailActivity, Observer { child ->
                    txtChildPhone.text = when(child) {
                        null, "" -> getString(R.string.na)
                        else -> child
                    }
                })
                obsParentPhone.observe(this@ReferralStatusDetailActivity, Observer { parentPhone ->
                    txtParentPhone.text = when(parentPhone) {
                        null, "" -> getString(R.string.na)
                        else -> parentPhone
                    }
                })
                obsParentRole.observe(this@ReferralStatusDetailActivity, Observer { role ->
                    txtParentRole.text = when(role) {
                        null, "" -> getString(R.string.na)
                        else -> role
                    }
                })
                obsStatusDetails.observe(this@ReferralStatusDetailActivity, Observer { list ->
                    when{
                        list.isEmpty() -> {
                            txtNoReferralDetail.visibility = View.VISIBLE
                            rcReferralDetails.visibility = View.GONE
                            cancelProgressDialog()
                        }
                        else -> {
                            when(adapter) {
                                null -> {
                                    adapter = ReferralStatusDetailAdapter(
                                        referralStatusDetailActivity = this@ReferralStatusDetailActivity,
                                        list = list
                                    )
                                    rcReferralDetails.layoutManager = LinearLayoutManager(this@ReferralStatusDetailActivity)
                                    rcReferralDetails.adapter = adapter
                                }
                                else -> {
                                    adapter?.let {
                                        it.list = list
                                        it.notifyDataSetChanged()
                                    }
                                }
                            }
                            txtNoReferralDetail.visibility = View.GONE
                            rcReferralDetails.visibility = View.VISIBLE
                            cancelProgressDialog()
                        }
                    }
                    showLastSync()
                })
            }
        }
    }

    override fun onDetailSelected(model: ReferralDetail) {
        Log.e(TAG,"selected model as ${model.stage}, ${model.status}, ${model.assessmentSmsBody}, ${model.childPhone}")
        validateSms(
            phone = model.childPhone,
            message = model.assessmentSmsBody
        )

    }

    private fun validateSms(phone: String?, message: String?) {
        when(phone) {
            null, "" -> {
                Util.customFseRationaleDialog(
                    context = this,
                    title = "",
                    hideNegative = true,
                    titleSpanned = null,
                    hideTitle = true,
                    message = "Child phone number not found",
                    positveSelected = {
                        it.dismiss()
                    },
                    negativeSeleted = {
                        it.dismiss()
                    }
                )
            }
            else -> {
                when(message) {
                    null, "" -> {
                        Util.customFseRationaleDialog(
                            context = this,
                            title = "",
                            hideNegative = true,
                            titleSpanned = null,
                            hideTitle = true,
                            message = "Message not found",
                            positveSelected = {
                                it.dismiss()
                            },
                            negativeSeleted = {
                                it.dismiss()
                            }
                        )
                    }
                    else -> {
                        Util.customFseRationaleDialog(
                            context = this,
                            title = "",
                            hideNegative = true,
                            titleSpanned = null,
                            hideTitle = true,
                            message = "Do you want to send assessement link to the referred agent?",
                            positveSelected = {
                                it.dismiss()
                                sendSMS(
                                    phone = phone,
                                    message = message
                                )
                            },
                            negativeSeleted = {
                                it.dismiss()
                                sendSMS(
                                    phone = phone,
                                    message = message
                                )
                            }
                        )
                    }
                }
            }
        }
    }

    private fun sendSMS(
        phone: String,
        message: String
    ) {
        Log.i(TAG,"initiate Send SMS")
        val uri = Uri.parse("smsto:$phone")
        val smsIntent = Intent(Intent.ACTION_SENDTO, uri)
        smsIntent.putExtra("sms_body", message)
        try {
            Log.i(TAG, "launching SMS app...")
            startActivity(smsIntent)
        } catch (ex: ActivityNotFoundException) {
            Log.e(TAG,"sms failed with error : ${ex.localizedMessage}")
        }
    }

    private fun showLastSync() {
        binder.run {
            txtAppVersion.text = this@ReferralStatusDetailActivity.getString(R.string.app_version, BuildConfig.VERSION_NAME)
            txtLastSync.text = this@ReferralStatusDetailActivity.getString(R.string.last_sync, preference?.getReferralStatusDetailLastSync())
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        mHomeWatcher?.stopWatch()
        super.onDestroy()
        finish()
    }
}