package com.greenlightplanet.kazi.atrisk.viewmodel

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.room.ColumnInfo
import com.google.gson.annotations.SerializedName
import com.greenlightplanet.kazi.atrisk.repo.AtRiskAccountRepo
import com.greenlightplanet.kazi.atrisk.model.AtRiskAccountModel
import com.greenlightplanet.kazi.atrisk.model.AtRiskCallDetailRequestModel
import com.greenlightplanet.kazi.networking.NewCommonResponseModel
import com.greenlightplanet.kazi.networking.NewEmptyParcelable
import com.greenlightplanet.kazi.networking.RetrofitInstance
import com.greenlightplanet.kazi.newtasks.model.FeedbackIntentModel
import com.greenlightplanet.kazi.newtasks.model.TaskResponseModel
import com.greenlightplanet.kazi.newtasks.repo.TaskRepo
import com.greenlightplanet.kazi.utils.Constants.Companion.STAFF_DEV_URL
import com.greenlightplanet.kazi.utils.Constants.Companion.STAFF_PRODUCTION_URL


class AtRiskAccountViewModel(application: Application) : AndroidViewModel(application) {
    private var BASE_URL = ""

    val repo = AtRiskAccountRepo.getInstance(application)
    val taskRepo = TaskRepo.getInstance(application)

    init {
        if (RetrofitInstance.isOnProduction) {
            BASE_URL = STAFF_PRODUCTION_URL
        } else {
            BASE_URL = STAFF_DEV_URL
        }
    }

    fun getAtRiskAccount(
        context: Context,
        angaza: String
    ): MutableLiveData<NewCommonResponseModel<AtRiskAccountModel>> {
        Log.e("urls", BASE_URL + angaza)
        return repo.getAtRiskAccount(context, BASE_URL + angaza, angaza)
    }

    fun getProductInit(): AtRiskAccountModel.CollectionAccount {

        return AtRiskAccountModel.CollectionAccount(
            accountAngazaId = "NA",
            accountNumber = 0,
            address = "NA",
            amountCollected = 0.0,
            angazaId = "NA",
            balanceAmount = 0.0,
            collectionExpectedPaid = 0.0,
            collectionPaid = 0.0,
            collectionRate = 0.0,
            collectionWtd = 0.0,
            customerName = "NA",
            daysDisabled = 0,
            expectedPaid = 0.0,
            id = 0,
            lastPaidDate = "NA",
            latitude = 0.0,
            longitude = 0.0,
            productGroup = "All",
            ownerPhoneNumber = "NA",
            partOfCollectionRate = "NA",
            pendingPayment = "NA",
            pendingToExitRiskPermanent = 0,
            product_name = "All",
            rate = 0.0,
            registrationDate = "NA",
            secondaryPhoneNumber = "NA",
            status = "NA",
            totalPaid = 0.0,
            successfulCallMessage = "",
            accountLatitude = "",
            accountLongitude = "",
            taskAttempt = 0,
            taskId = 0,
            taskStatus = "",
            isTask = false,
            alternateContacts = emptyList(),
            accountExpectedPaid = "",
            eligibleForReimbursement = false
        )
        /*return AtRiskAccountModel.CollectionAccount(0, "All", "null", "NA", 0, "NA",
                "NA","NA","NA","NA","NA")*/
    }


    //region added when calling
    fun getTaskIntentFromDb(): MutableLiveData<NewCommonResponseModel<FeedbackIntentModel>> {
        return taskRepo!!.getTaskIntentFromDb()
    }

    fun getNewTaskFromDb(): MutableLiveData<NewCommonResponseModel<TaskResponseModel>> {
        return taskRepo!!.getNewTaskFromDb()
    }

    fun insertCallDetailRequestToDb(
        callDetailsRequest: AtRiskCallDetailRequestModel,
        isPresent: Boolean,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        showProgress()
        return repo!!.insertCallDetailRequestToDb(callDetailsRequest, isPresent)
    }

    fun solveTaskCallDetailRequest(
        callDetailsRequest: AtRiskCallDetailRequestModel,
        isPresent: Boolean,
        showProgress: () -> Unit = {}
    ): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        showProgress()
        return repo!!.solveTaskCallDetailRequest(callDetailsRequest, isPresent)
    }

    fun solveAllAtRisk(): MutableLiveData<NewCommonResponseModel<NewEmptyParcelable>> {
        return repo.solveAllAtRisk()
    }
    //endreion

}
