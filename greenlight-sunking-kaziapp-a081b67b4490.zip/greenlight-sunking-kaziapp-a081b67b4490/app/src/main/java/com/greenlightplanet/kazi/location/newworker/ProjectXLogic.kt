package com.greenlightplanet.kazi.location.newworker

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import android.telephony.CellInfo
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.greenlightplanet.kazi.location.dao.LocationRequestDao
import com.google.android.gms.location.LocationRequest
import com.greenlightplanet.kazi.location.extras.FunctionalUtils
import com.greenlightplanet.kazi.location.model.LocationRequestModel
import com.greenlightplanet.kazi.location.newworker.PROVIDER_TYPE.CELL_TOWER
import com.greenlightplanet.kazi.location.newworker.PROVIDER_TYPE.GPS
import com.greenlightplanet.kazi.location.newworker.PROVIDER_TYPE.GPS_NETWORK
import com.greenlightplanet.kazi.networking.ServiceInstance
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import pl.charmas.android.reactivelocation2.ReactiveLocationProvider
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit


class ProjectXLogic(val context: Context, val preference: GreenLightPreference, val dao: LocationRequestDao, val bag: CompositeDisposable? = null) {

	companion object {
		public const val TAG = "ProjectXLogic"
	}

	val projectXLogicCallback: ProjectXLogicCallback? = null
	var lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

	fun perform(context: Context, angazaId: String) {
		Log.d(TAG, "perform-t:${Thread.currentThread().id} ");
		bag?.add(
			makeLocationRequest(context, angazaId, WORKER_TYPE.ALARM)
				.subscribeOn(Schedulers.newThread())
				.observeOn(Schedulers.io())
				.flatMap {
					//insertLocationRequestModel(it).blockingGet()
					insertLocationRequestModel(it)
//					successfullyModelStored()
//					it
				}.map {
					successfullyModelStored(true)
					it
				}.flatMap {
					if (Util.isOnline(context)) {
						whenOnline(context)
					} else {
						Single.just(it)
					}
				}
				.subscribe({
					Log.d(TAG, "perform-success:$it ");
					successfullyModelStored()
					projectXLogicCallback?.success()
					projectXLogicCallback?.complete()
				}, {
					Log.d(TAG, "perform-error:${it.localizedMessage} ");
					successfullyModelStored()
					it.printStackTrace()
					projectXLogicCallback?.failed(it)
					projectXLogicCallback?.complete()
				})
		)

	}

	fun performRxWM(context: Context, angazaId: String): Single<Any> {
		Log.d(TAG, "performRx-t:${Thread.currentThread().id} ");
		return makeLocationRequest(context, angazaId, WORKER_TYPE.WORK_MANAGER)
			.subscribeOn(Schedulers.newThread())
			.observeOn(Schedulers.io())
			.map {
				insertLocationRequestModel(it).blockingGet()
				successfullyModelStored(true)
				it
			}.flatMap {
				if (Util.isOnline(context)) {//is online
					successfullyModelStored()
					whenOnline(context)
				} else {
					successfullyModelStored()
					Single.just(it)
				}
			}
	}

	fun performRxService(context: Context, angazaId: String): Single<Any> {
		Log.d(TAG, "performService-t:${Thread.currentThread().id} ");
		return makeLocationRequest(context, angazaId, WORKER_TYPE.SERVICE)
			.subscribeOn(Schedulers.newThread())
			.observeOn(Schedulers.io())
			.map {
				insertLocationRequestModel(it).blockingGet()
				successfullyModelStored(true)
				it
			}.flatMap {
				if (Util.isOnline(context)) {//is online
					successfullyModelStored()
					whenOnline(context)
				} else {
					successfullyModelStored()
					Single.just(it)
				}
			}
	}

	fun performRxAlarm(context: Context, angazaId: String): Single<Any> {
		Log.d(TAG, "performService-t:${Thread.currentThread().id} ");
		return makeLocationRequest(context, angazaId, WORKER_TYPE.ALARM)
			.subscribeOn(Schedulers.newThread())
			.observeOn(Schedulers.io())
			.map {
				insertLocationRequestModel(it).blockingGet()
				successfullyModelStored(true)
				it
			}.flatMap {
				if (Util.isOnline(context)) {//is online
					successfullyModelStored()
					whenOnline(context)
				} else {
					successfullyModelStored()
					Single.just(it)
				}
			}
	}

	fun performRxLUS(context: Context, location: Location?, angazaId: String): Single<Any> {
		Log.d(TAG, "performRxLUS-t:${Thread.currentThread().id} ");
		return makeLocationRequestLUS(context, location, angazaId, WORKER_TYPE.LUS)
//			.subscribeOn(Schedulers.newThread())
//			.observeOn(Schedulers.io())
			.map {
				Log.d(TAG, "LocationRequestLUS:$it ");
				insertLocationRequestModel(it).blockingGet()
				successfullyModelStored(true)
				it
			}.flatMap {
				if (Util.isOnline(context)) {//is online
					successfullyModelStored()
					whenOnline(context)
				} else {
					successfullyModelStored()
					Single.just(it)
				}
			}
	}

	private fun whenOnline(context: Context): Single<Int> {
		var locationRequestModels: List<LocationRequestModel>? = null
		return dao.getAll()
			.flatMap {
				Log.d(TAG, "whenOnline-t:${Thread.currentThread().id} ");
				locationRequestModels = it
				ServiceInstance.getInstance(context).service?.sendLocation(locationRequestModels!!)
			}.flatMap {
				Log.d(TAG, "whenOnline-response:$it");
				Single.fromCallable {
					dao.deleteAllAnother(locationRequestModels!!)
				}
			}
			.subscribeOn(Schedulers.io())
			.observeOn(Schedulers.trampoline())
	}

	private fun insertLocationRequestModel(locationRequestModel: LocationRequestModel): Single<Long> {
		return Single.fromCallable {
			dao.insert(locationRequestModel)
		}
	}

	private fun makeLocationRequest(context: Context, angazaId: String, taskPerformer: String): Single<LocationRequestModel> {
		//todo add is location enable check
		if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
			return bestAccuracyLocation(context)!!
				.map {
					Log.d(TAG, "makeLocationRequest-t:${Thread.currentThread().id} ");
					val dateTime = FunctionalUtils.getCurrentUtcDateTime()
					val dateTimeFormatted = FunctionalUtils.getCurrentUtcDateTimeFormatted(dateTime)
					val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
					utcFormat.timeZone = TimeZone.getTimeZone("UTC")
					val milliseconds = utcFormat.parse(dateTimeFormatted).time
					var callInfo: String? = null

					if (preference.getUseGPSAndService()) {
						callInfo = getCellInfo(context).toString()
					}

					LocationRequestModel(
						angazaId = angazaId,
						battery = batteryPercentage(context).toString(),
						imei = imei(context),
						latitude = it.latitude.toString(),
						longitude = it.longitude.toString(),
						deviceTimeMilli = milliseconds,
						deviceTime = dateTimeFormatted,
						locationType = if (it.accuracy < 25) {
							GPS_NETWORK
						} else {
							GPS
						},
						accuracy = it.accuracy.toString(),
						taskPerformer = taskPerformer,
						androidApiNumber = Build.VERSION.SDK_INT,
						networkData = callInfo
					)
				}
		} else {
			return Single.create {
				val callInfo = getCellInfo(context)
				val dateTime = FunctionalUtils.getCurrentUtcDateTime()
				val dateTimeFormatted = FunctionalUtils.getCurrentUtcDateTimeFormatted(dateTime)
				val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
				utcFormat.timeZone = TimeZone.getTimeZone("UTC")
				val milliseconds = utcFormat.parse(dateTimeFormatted).time

				LocationRequestModel(
					angazaId = angazaId,
					battery = batteryPercentage(context).toString(),
					imei = imei(context),
					latitude = null,
					longitude = null,
					deviceTimeMilli = milliseconds,
					deviceTime = dateTimeFormatted,
					locationType = CELL_TOWER,
					accuracy = null,
					taskPerformer = taskPerformer,
					androidApiNumber = Build.VERSION.SDK_INT,
					networkData = callInfo.toString()
				)
			}
		}


	}

	private fun makeLocationRequestLUS(context: Context, location: Location?, angazaId: String, taskPerformer: String): Single<LocationRequestModel> {

		return Single.fromCallable {
			if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {// && location == null) {
				Log.d(TAG, "makeLocationRequestLUS-t:${Thread.currentThread().id} ");
				val dateTime = FunctionalUtils.getCurrentUtcDateTime()
				val dateTimeFormatted = FunctionalUtils.getCurrentUtcDateTimeFormatted(dateTime)
				val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
				utcFormat.timeZone = TimeZone.getTimeZone("UTC")
				val milliseconds = utcFormat.parse(dateTimeFormatted).time
				var callInfo: String? = null

				if (preference.getUseGPSAndService()) {
					callInfo = getCellInfo(context).toString()
				}

				LocationRequestModel(
					angazaId = angazaId,
					battery = batteryPercentage(context).toString(),
					imei = imei(context),
					latitude = location?.latitude.toString(),
					longitude = location?.longitude.toString(),
					deviceTimeMilli = milliseconds,
					deviceTime = dateTimeFormatted,
					locationType = if (location?.accuracy ?: 100F < 25) { //fix this
						GPS_NETWORK
					} else {
						GPS
					},
					accuracy = location?.accuracy.toString(),
					taskPerformer = taskPerformer,
					androidApiNumber = Build.VERSION.SDK_INT,
					networkData = callInfo
				)
			} else {
				val callInfo = getCellInfo(context)
				val dateTime = FunctionalUtils.getCurrentUtcDateTime()
				val dateTimeFormatted = FunctionalUtils.getCurrentUtcDateTimeFormatted(dateTime)
				val utcFormat = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
				utcFormat.timeZone = TimeZone.getTimeZone("UTC")
				val milliseconds = utcFormat.parse(dateTimeFormatted).time

				LocationRequestModel(
					angazaId = angazaId,
					battery = batteryPercentage(context).toString(),
					imei = imei(context),
					latitude = null,
					longitude = null,
					deviceTimeMilli = milliseconds,
					deviceTime = dateTimeFormatted,
					locationType = CELL_TOWER,
					accuracy = null,
					taskPerformer = taskPerformer,
					androidApiNumber = Build.VERSION.SDK_INT,
					networkData = callInfo.toString()
				)
			}
		}
	}

	private fun bestAccuracyLocation(context: Context): Single<Location?>? {

		var location: Location? = null

		return locations(context)!!
			.map {

				if (location == null) {
					location = it
				} else {
					if (location!!.accuracy > it.accuracy) {
						location = it
					}
				}
				location
			}
			.timeout(10, TimeUnit.SECONDS)
			.lastOrError()
	}


	@SuppressLint("MissingPermission")
	private fun locations(context: Context): Observable<Location>? {

		val request = LocationRequest.create() //standard GMS LocationRequest
			.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
			.setNumUpdates(5).setInterval(20)

		return ReactiveLocationProvider(context)
			.getUpdatedLocation(request)

	}

	private fun batteryPercentage(context: Context): Int {

		val iFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
		val batteryStatus = context.registerReceiver(null, iFilter)

		val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
		val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
		val batteryPct = level / scale.toFloat()

		return (batteryPct * 100).toInt()
	}

	@SuppressLint("MissingPermission")
	fun imei(context: Context): String {
		val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager?
		val android_id: String = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID)
		Log.e("===getImei===", "-----$android_id----|||||||")
		if (Build.VERSION.SDK_INT < 29) {
			return telephonyManager!!.deviceId
		} else {
			return android_id
		}
//		return "android_id_test_motoe56"
	}

	private fun successfullyModelStored(completed: Boolean = false) {
		if (completed) {
			preference?.setLastCalledNewWorker(System.currentTimeMillis())
		}
	}

	fun onDestroy() {
		bag?.clear()
	}

	interface ProjectXLogicCallback {
		fun success()
		fun failed(t: Throwable)
		fun complete()
	}

	//New Logics

	@SuppressLint("MissingPermission", "NewApi")
	fun getCellInfo(ctx: Context): MutableList<CellInfo>? {
		val tel = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
		val phoneTypeInt = tel.phoneType
		var phoneType: String? = null
		phoneType = if (phoneTypeInt == TelephonyManager.PHONE_TYPE_GSM) "gsm" else phoneType
		phoneType = if (phoneTypeInt == TelephonyManager.PHONE_TYPE_CDMA) "cdma" else phoneType
		return tel.allCellInfo
	}

	private fun checkPermission(context: Context): Boolean {
		return ((ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) ||
			((ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED))
	}
}
