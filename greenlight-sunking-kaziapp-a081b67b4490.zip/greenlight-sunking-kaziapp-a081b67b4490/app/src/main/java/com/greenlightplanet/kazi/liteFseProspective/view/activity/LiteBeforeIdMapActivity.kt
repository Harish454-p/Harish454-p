package com.greenlightplanet.kazi.liteFseProspective.view.activity

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import com.greenlightplanet.kazi.databinding.ActivityBeforeIdMapBinding
import com.greenlightplanet.kazi.liteFseProspective.view.activity.mapActivity.LiteSetBaseLocationMapsActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.homeKeys.HomeWatcher
import com.greenlightplanet.kazi.utils.homeKeys.OnHomePressedListener


class LiteBeforeIdMapActivity : AppCompatActivity() {


    var locationManager: LocationManager? = null
    var network_enabled = false
    var mHomeWatcher: HomeWatcher? = null


    private var allowedDistance: Int = 0
    var preference: GreenLightPreference? = null

    private lateinit var binding: ActivityBeforeIdMapBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        preference = GreenLightPreference.getInstance(this)
        val country = preference?.getLoginResponseModel()?.country
//        val prospectDistanceDetail = Util.getProspectDistance(this, country!!)

        allowedDistance = preference!!.getAllowFseRaduis()!!

        // setContentView(R.layout.activity_before_id_map)
        binding = ActivityBeforeIdMapBinding.inflate(layoutInflater)
        setContentView(binding.root)

        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        network_enabled =
            locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER) && locationManager!!.isProviderEnabled(
                LocationManager.GPS_PROVIDER
            )
        binding.btnCheckIn.setOnClickListener {
            network_enabled =
                locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER) && locationManager!!.isProviderEnabled(
                    LocationManager.GPS_PROVIDER
                )
            Log.e("||=network_bled=1=", "${network_enabled}")

            if (!network_enabled) {
                showSettingsAlert()
            } else {
                Log.e("||=network_bled=2=", "${network_enabled}")
                if (checkPersmission() && network_enabled) {
                    val eoIDIntent = Intent(this, LiteSetBaseLocationMapsActivity::class.java)
                    eoIDIntent.putExtra("radius", allowedDistance)
                    startActivity(eoIDIntent)
                } else {
                    requestPermission()
                }
            }
        }

        mHomeWatcher = HomeWatcher(this)
        mHomeWatcher!!.setOnHomePressedListener(object : OnHomePressedListener {
            override fun onHomePressed() {
                finish()
            }
        })
        mHomeWatcher!!.startWatch()
    }

    private val PERMISSION_REQUEST_CODE: Int = 101
    private fun checkPersmission(): Boolean {
        return (ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        ) ==
                PackageManager.PERMISSION_GRANTED)
    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(
            this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    val eoIDIntent = Intent(this, LiteSetBaseLocationMapsActivity::class.java)
                    eoIDIntent.putExtra("radius", allowedDistance)
                    startActivity(eoIDIntent)
                }
            }
        }
    }

    fun showSettingsAlert() {
        val alertDialog = AlertDialog.Builder(this)
        // Setting Dialog Title
        alertDialog.setTitle("GPS is settings")
        // Setting Dialog Message
        alertDialog.setMessage("GPS is not enabled. Do you want to go to settings menu?")
        // On pressing Settings button
        alertDialog.setPositiveButton("Settings") { dialog, which ->
            val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            startActivity(intent)
        }
        // on pressing cancel button
        alertDialog.setNegativeButton("Cancel") { dialog, which -> dialog.cancel() }
        alertDialog.show()
    }


    override fun onDestroy() {
        super.onDestroy()
        mHomeWatcher?.stopWatch();

    }
}
