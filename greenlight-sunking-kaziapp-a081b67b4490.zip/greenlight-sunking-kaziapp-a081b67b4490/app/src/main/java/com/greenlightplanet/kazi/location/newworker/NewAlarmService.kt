package com.greenlightplanet.kazi.location.newworker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.location.LocationManager
import android.os.Build
import android.os.Build.VERSION_CODES.O
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.greenlightplanet.kazi.location.dao.LocationRequestDao
import com.greenlightplanet.kazi.KaziApplication
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.location.newworker.WORKER_DEFAULT_CONST.CHANNEL_ALARM_ID
import com.greenlightplanet.kazi.location.newworker.WORKER_DEFAULT_CONST.CHANNEL_NAME
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import java.util.concurrent.TimeUnit


class NewAlarmService : Service(), ProjectXLogic.ProjectXLogicCallback {

	companion object {
		const val TAG = "AlarmService"
		private var is_service_running = false
		private var mWakeLock: PowerManager.WakeLock? = null
	}

	private var mContext: Context? = null

	var preference: GreenLightPreference? = null
	private var localDb: AppDatabase? = null
	private lateinit var dao: LocationRequestDao

	var projectXLogic: ProjectXLogic? = null
	private val bag = CompositeDisposable()
	var delay: Long? = null

	var lm: LocationManager? = null

	override fun onBind(p0: Intent?): IBinder? {
		return null
	}

	override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

		try {
			acquireWakeLock();
			initialize(this)

			delay = preference?.getLocationIntervalAlarm()

			notification()

			/*if (preference?.getLoginResponseModel() != null) {
				if (lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true || Build.VERSION.SDK_INT < O) {
					projectXLogic.perform(mContext!!, preference?.getLoginResponseModel()?.angazaId!!)
				} else {
					nextTrigger(this)
					stopSelf()
				}
			} else {
				nextTrigger(this)
				stopSelf()
			}*/

			/*bag.add(
				Observable.timer(2, TimeUnit.MINUTES)
					.repeat() //to perform your task every 5 seconds
					.flatMap {
						if (lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true || Build.VERSION.SDK_INT < O) {
							projectXLogic.performRx(mContext!!, preference?.getLoginResponseModel()?.angazaId!!).toObservable()
						} else {
							Observable.just(1)
						}
					}
					.subscribe({
						Log.d(TAG, "onStartCommand-onNext:$it ");
					}, {
						Log.d(TAG, "onStartCommand-error:$it ");
					})
			)*/

			/*if (preference?.getLastCalledWorkManager() != null && (preference?.getLastCalledWorkManager()!!.toLong() - System.currentTimeMillis()) < DIFF_MILLI) {
				stopSelf()
			} else {
				if (preference?.getLoginResponseModel() != null) {
					projectXLogic.perform(mContext!!, preference?.getLoginResponseModel()?.angazaId!!)
				} else {
					stopSelf()
				}
			}*/


			bag.add(Observable.interval(0L, delay
				?: WORKER_INTERVAL.ALARM_INTERVAL, TimeUnit.MINUTES)
				.flatMap {
					preference = GreenLightPreference(this)
					projectXLogic = ProjectXLogic(mContext!!, preference!!, dao, bag)

					val data = preference?.settings?.getString("LoginResponseModel", "")
					Log.d(TAG, "data:${data} ");
					Log.d(TAG, "logic:${((lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true || Build.VERSION.SDK_INT < O) && preference?.getLoginResponseModel() != null)} ");
					Log.d(TAG, "(lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true || Build.VERSION.SDK_INT < O):${(lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true || Build.VERSION.SDK_INT < O)} ");
					Log.d(TAG, "preference != null):${preference != null} ");
					Log.d(TAG, "preference?.getLoginResponseModel() != null):${preference?.getLoginResponseModel() != null} ");

					if (preference?.getLoginResponseModel() != null) {
//						if (true) {
					if (preference?.getLastCalledNewWorker()!! <= 0 || (System.currentTimeMillis() - preference?.getLastCalledNewWorker()!!.toLong()) >= WORKER_MINI_DIFF.DIFF_MILLI) {
							if ((lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true || Build.VERSION.SDK_INT < O) && preference?.getLoginResponseModel() != null) {
//							projectXLogic.performRxAlarm(mContext!!, "US008712").toObservable()
								projectXLogic?.performRxAlarm(mContext!!, preference?.getLoginResponseModel()?.angazaId!!)?.toObservable()
							} else {
								Observable.just(1)
							}
						} else {
							Observable.just(1)
						}
					} else {
						Observable.just(1)
					}

				}
				.onErrorResumeNext(Observable.empty())
				.subscribe({
					Log.d(TAG, "onStartCommand-onNext:$it ");
					nextTrigger(this)
					stopSelf()
				}, {
					it.printStackTrace()
					nextTrigger(this, true)
					Log.d(TAG, "onStartCommand-error:$it ");
					stopSelf()
				}))
		} catch (e: Exception) {
			nextTrigger(this, true)
			e.printStackTrace()
			Log.d(TAG, "error:$e ");
			stopSelf()
		}



		return START_STICKY
	}

	fun initialize(context: Context) {

		mContext = context
		lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
		preference = GreenLightPreference.getInstance(mContext!!)
		localDb = AppDatabase.getAppDatabase(mContext!!)
		dao = localDb!!.locationRequestDao()
		preference?.setLastCalledWorker(System.currentTimeMillis())

		projectXLogic = ProjectXLogic(context, preference!!, dao, bag)

	}

	fun notification() {

		if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O) {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
				val descriptionText = getString(R.string.channel_description)
				val importance = NotificationManager.IMPORTANCE_DEFAULT
				val channel = NotificationChannel(CHANNEL_ALARM_ID, CHANNEL_NAME, importance).apply {
					description = descriptionText
					enableLights(true)

				}
				val notificationManager: NotificationManager =
					getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
				notificationManager.createNotificationChannel(channel)
			}

			val notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ALARM_ID)

			val notification = notificationBuilder.setContentTitle("Kazi")
				.setContentText("Application is processing")
				.setLargeIcon(BitmapFactory.decodeResource(this.getResources(),
					R.mipmap.ic_launcher_round))
				.setAutoCancel(true)
				.setSmallIcon(R.mipmap.ic_launcher_round)
				.setChannelId(CHANNEL_ALARM_ID)
				.build()

			startForeground(2, notification)
		}


//		startForeground()
	}

	override fun onDestroy() {
		projectXLogic?.onDestroy()
		bag.clear()
		releaseWakeLock()
		super.onDestroy()
	}

	override fun success() {
	}

	override fun failed(t: Throwable) {
	}

	override fun complete() {
		stopSelf()
	}

	fun nextTrigger(context: Context, now: Boolean = false) {
		NewAlarmUtils.setNewAlarm(context, if (now) {
			0
		} else {
			WORKER_INTERVAL.ALARM_INTERVAL
		})




		if (!NewAlarmUtils.repeatAlreadyExists(context)) {
			NewAlarmUtils.setRepeatAlarm(context)
		}



		/*if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O){

			WorkManagerFactory.makeWorkOneTime(if (now) {
				0
			} else {
//			WORKER_INTERVAL.ALARM_INTERVAL
				15
			})

			if (!WorkManagerFactory.isWorkScheduled(WORKER_DEFAULT_CONST.WM_TAG)) {
				WorkManagerFactory.scheduleWork(WORKER_DEFAULT_CONST.WM_TAG, WORKER_INTERVAL.WM_INTERVAL)
			}
		}*/

		val service = Intent(context, NewFourgroundService::class.java)
		service.action = KaziApplication.STARTFOREGROUND_ACTION
		context.startService(service)
	}


	fun acquireWakeLock() {
		/*val powerManager = mContext!!.getSystemService(Context.POWER_SERVICE) as PowerManager
		releaseWakeLock()
		//Acquire new wake lock
		mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, TAG + ":NewAlarmService")
		mWakeLock?.acquire()*/
	}

	fun releaseWakeLock() {
		/*if (mWakeLock != null && mWakeLock!!.isHeld) {
			mWakeLock!!.release()
			mWakeLock = null
		}*/
	}
}
