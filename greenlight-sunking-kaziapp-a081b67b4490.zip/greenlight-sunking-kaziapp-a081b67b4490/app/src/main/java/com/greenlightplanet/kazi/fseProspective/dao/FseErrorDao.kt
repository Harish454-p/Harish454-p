package com.greenlightplanet.kazi.fseProspective.dao

import androidx.room.*
import com.greenlightplanet.kazi.fseProspective.model.FseError
import io.reactivex.Single

@Dao
interface FseErrorDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(FseError: List<FseError>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(FseError: FseError): Long

    @Delete
    fun delete(FseError: FseError): Int

    @Query("DELETE FROM FseError")
    fun deleteAll(): Int

    @Query("SELECT * FROM FseError")
    fun getAll(): Single<List<FseError>>

    @Query("SELECT * FROM FseError LIMIT 1")
    fun get(): Single<FseError>

    @Query("SELECT COUNT(*) from FseError")
    fun count(): Single<Int>

    @Query("SELECT * FROM FseError WHERE prospectId=:prospectId LIMIT 1")
    fun getByProspectId(prospectId: String): Single<FseError>?

    @Query("SELECT * FROM FseError WHERE prospectID IN (:prospectId)")
    fun getAllByProspectId(prospectId: List<String>): Single<List<FseError>?>


    @Query("DELETE FROM FseError where prospectID LIKE :prospectId")
    fun deleteProspectById(prospectId: String)
}
