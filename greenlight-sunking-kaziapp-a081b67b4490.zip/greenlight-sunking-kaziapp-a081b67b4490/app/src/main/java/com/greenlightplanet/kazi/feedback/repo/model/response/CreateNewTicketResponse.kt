package com.greenlightplanet.kazi.feedback.repo.model.response

import androidx.annotation.Keep

@Keep
data class CreateNewTicketResponse(
    val message: String,
    val request: RequestObject,
    val status: String,
    val statusCode: Int,
    val ticketId: String
)

@Keep
data class RequestObject(
    val accountNumber: String,
    val angazaId: String,
    val attachments: List<String>,
    val category: String,
    val message: String,
    val subcategory: String
)