package com.greenlightplanet.kazi.incentivenew.model.summary

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Created by Rahul on 09/12/20.
 */

@Parcelize
@Entity
data class CheckListFields (

        @ColumnInfo
        @SerializedName("name") val name : String?,

        @ColumnInfo
        @SerializedName("reason") val reason : String?,

        @ColumnInfo
        @SerializedName("value") val value : String?,

        @ColumnInfo
        @SerializedName("fieldType") val fieldType : String?,

        @PrimaryKey
        @ColumnInfo
        @SerializedName("id") val id : String,

        @ColumnInfo
        @SerializedName("fieldValueDataType") val fieldValueDataType : String?,

        @ColumnInfo
        @SerializedName("subFields") val subFields : List<String>?
):Parcelable