package com.greenlightplanet.kazi.feedback.repo.model.response

import androidx.annotation.Keep

@Keep
data class NewTicketUIResponse(
    val request: Request,
    val responseData: ResponseData,
    val responseStatus: Int,
    val serverIp: String,
    val serverPort: String,
    val success: Boolean
)
@Keep
data class Request(
    val executionTime: Double
)
@Keep
data class ResponseData(
    val fields: List<Field>
)
@Keep
data class Field(
    val elements: List<Element>,
    val heading: String,
    val type: String
) {
    var selected = ""
    var atRvIndex = 0
    var selectedSpItemIndex = 0
    var isAccountNoMandatory = false
}


@Keep
data class Element(
    val label: String,
    val parentLabel: String?,
    val requiredFields: List<String>
)