package com.greenlightplanet.kazi.feedback.repo.repository

import com.greenlightplanet.kazi.feedback.feedback_utils.FeedbackConstants
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.feedback.repo.model.request.CreateNewTicketRequest
import com.greenlightplanet.kazi.feedback.repo.model.request.SendRequest
import com.greenlightplanet.kazi.feedback.repo.model.response.ChatData
import com.greenlightplanet.kazi.feedback.repo.model.response.Field
import com.greenlightplanet.kazi.feedback.repo.model.response.SendResponse
import com.greenlightplanet.kazi.networking.NetworkService
import com.greenlightplanet.kazi.utils.AppDatabase
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.NetworkResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.HttpException
import timber.log.Timber
import java.io.IOException
import javax.inject.Inject


class ChatFeedbackRepository @Inject constructor(
    val db: AppDatabase, val networkService: NetworkService, val preference: GreenLightPreference
) {

    fun getConversationData(ticketId: String) : Flow<NetworkResult<List<ChatData>>> =  flow {
        if (Helper.isNetworkConnected()) {
            try {
                emit(NetworkResult.Loading())
                val url = "${FeedbackConstants.BASE_URL}${FeedbackConstants.CONVERSATION_ENDPOINT}$ticketId"
                Timber.d("ConversationRepo: Conversation Endpoint: $url")
                val response = networkService.getConversationData(url)
                if (response.isSuccessful) {
                    response.body()?.let { response ->
                        emit(NetworkResult.Success(response.responseData))
                        Timber.d("ConversationRepo: API Response: ${response.responseData}")
                    }
                }
                else {
                    emit(NetworkResult.Error( "An unexpected error occurred"))
                }
            } catch (e: HttpException) {
                emit(NetworkResult.Error(e.localizedMessage ?: "An unexpected error occurred"))
            } catch (e: IOException) {
                emit(NetworkResult.Error("Couldn't reach server. Check your internet connection."))
            }
        } else {
            emit(NetworkResult.Error("Couldn't reach server. Check your internet connection."))
        }
    }

    fun sendChatMessageData(country: String, sendRequest: SendRequest) : Flow<NetworkResult<Boolean>> =  flow {
        if (Helper.isNetworkConnected()) {
            try {
                emit(NetworkResult.Loading())
                val url = "${FeedbackConstants.BASE_URL}${FeedbackConstants.CHAT_SEND_ENDPOINT}$country"
                Timber.d("ConversationRepo: Send Chat Endpoint: $url")
                val response = networkService.sendMessageData(url, sendRequest)
                if (response.isSuccessful) {
                    if (response.body()?.status?.lowercase() == "success") {
                        response.body()?.let { response ->
                            emit(NetworkResult.Success(true))
                            Timber.d("ConversationRepo: Send Chat API Response: ${response.message}")
                        }
                    } else {
                        emit(NetworkResult.Error( "${response.body()?.message}", data = false))
                    }
                }
                else {
                    emit(NetworkResult.Error( "An unexpected error occurred"))
                }
            } catch (e: HttpException) {
                emit(NetworkResult.Exception(e.localizedMessage ?: "An unexpected error occurred"))
            } catch (e: IOException) {
                emit(NetworkResult.Exception("Couldn't reach server. Check your internet connection."))
            }
        } else {
            emit(NetworkResult.Exception("Couldn't reach server. Check your internet connection."))
        }
    }



}