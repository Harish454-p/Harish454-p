package com.greenlightplanet.kazi.location.newworker

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.AlarmManager.RTC_WAKEUP
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.greenlightplanet.kazi.location.newworker.WORKER_DEFAULT_CONST.EXACT_ALARM_REQUEST_CODE
import com.greenlightplanet.kazi.location.newworker.WORKER_DEFAULT_CONST.MILLI_TO_MINUTE
import com.greenlightplanet.kazi.location.newworker.WORKER_DEFAULT_CONST.REPEAT_ALARM_REQUEST_CODE
import com.greenlightplanet.kazi.location.newworker.WORKER_INTERVAL.ALARM_INTERVAL
import com.greenlightplanet.kazi.location.worker.WorkManagerFactory
import com.greenlightplanet.kazi.utils.GreenLightPreference


object NewAlarmUtils {


	@SuppressLint("UnspecifiedImmutableFlag")
	fun alreadyExists(context: Context): Boolean {
		val serviceIntent = Intent(context, NewAlarmService::class.java)
		val pendingIntent = PendingIntent.getService(
			context,
			EXACT_ALARM_REQUEST_CODE,
			serviceIntent,
			PendingIntent.FLAG_NO_CREATE)

		return pendingIntent != null
	}

	fun cancelNewAlarm(context: Context) {
		val serviceIntent = Intent(context, NewAlarmService::class.java)
		val pendingIntent = PendingIntent.getService(
			context,
			EXACT_ALARM_REQUEST_CODE,
			serviceIntent,
			PendingIntent.FLAG_NO_CREATE)
		pendingIntent?.cancel()
	}

	fun setNewAlarm(context: Context, minutes: Long? = null) {

		val timeOfAlarm: Long
		val locationInterval = GreenLightPreference.getInstance(context).getLocationIntervalAlarm()!!

		if (minutes != null) {
			timeOfAlarm = MILLI_TO_MINUTE * minutes
		} else {
			timeOfAlarm = locationInterval
		}


		//WorkManagerFactory.makeWorkOneTime(minutes?:1)

		Log.d("NewAlarmUtils", "timeOfAlarm:$timeOfAlarm ");
		Log.d("NewAlarmUtils", "minutes:$minutes ");
		val serviceIntent = Intent(context, NewAlarmService::class.java)


		val pIntent = if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O) {
			PendingIntent.getForegroundService(
				context,
				EXACT_ALARM_REQUEST_CODE,
				serviceIntent,
				0
			)
		} else {
			PendingIntent.getService(
				context,
				EXACT_ALARM_REQUEST_CODE,
				serviceIntent,
				0
			)
		}

		/*val pIntent = PendingIntent.getService(
			context,
			EXACT_ALARM_REQUEST_CODE,
			serviceIntent,
			0
		)*/

		val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

		when {
			Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> {
				alarmMgr.setExactAndAllowWhileIdle(RTC_WAKEUP, System.currentTimeMillis() + timeOfAlarm, pIntent)
				alarmMgr.setAlarmClock(
					AlarmManager.AlarmClockInfo(
						System.currentTimeMillis() + timeOfAlarm,
						pIntent
					), pIntent
				)
			}
			Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP -> {
				alarmMgr.setAlarmClock(
					AlarmManager.AlarmClockInfo(
						System.currentTimeMillis() + timeOfAlarm,
						pIntent
					), pIntent
				)
			}
			Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT -> {
				alarmMgr.setExact(
					AlarmManager.RTC_WAKEUP,
					System.currentTimeMillis() + timeOfAlarm,
					pIntent
				)
			}
			else -> {
				alarmMgr.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + timeOfAlarm, pIntent)
			}
		}
	}


	fun repeatAlreadyExists(context: Context): Boolean {
		val serviceIntent = Intent(context, NewAlarmService::class.java)
		val pendingIntent = PendingIntent.getService(
			context,
			REPEAT_ALARM_REQUEST_CODE,
			serviceIntent,
			PendingIntent.FLAG_NO_CREATE)

		return pendingIntent != null
	}

	fun cancelRepeatAlarm(context: Context) {
		val serviceIntent = Intent(context, NewAlarmService::class.java)
		val pendingIntent = PendingIntent.getService(
			context,
			REPEAT_ALARM_REQUEST_CODE,
			serviceIntent,
			PendingIntent.FLAG_NO_CREATE)
		pendingIntent?.cancel()
	}

	fun setRepeatAlarm(context: Context) {

		val timeOfAlarm = MILLI_TO_MINUTE * ALARM_INTERVAL

		val serviceIntent = Intent(context, NewAlarmService::class.java)

		val pIntent = PendingIntent.getService(
			context,
			REPEAT_ALARM_REQUEST_CODE,
			serviceIntent,
			0
		)

		val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
		alarmMgr.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), timeOfAlarm, pIntent);

	}

	//FirebaseJobDispatcher
	/*fun abcd(context: Context) {
		val dispatcher = FirebaseJobDispatcher(GooglePlayDriver(context))
		val periodicJob: Job = dispatcher.newJobBuilder() // the JobService that will be called
			.setService(ReminderService::class.java) // uniquely identifies the job
			.setTag("abcd") // Recurring job
			.setRecurring(true) // persist past a device reboot
			.setLifetime(Lifetime.FOREVER) // start between 0 and 120 seconds from now
			.setTrigger(Trigger.executionWindow(0, 900)) // don't overwrite an existing job with the same tag
			.setReplaceCurrent(true) // retry with exponential backoff
			.setRetryStrategy(RetryStrategy.DEFAULT_EXPONENTIAL) // constraints that need to be satisfied for the job to run
			.setConstraints( // only run on an unmetered network
				Constraint.DEVICE_IDLE
			)
			.build()
		dispatcher.mustSchedule(periodicJob)
	}*/
}

