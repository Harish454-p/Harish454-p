package com.greenlightplanet.kazi.incentivenew.activity

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.BuildConfig
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.ActivityAmountCollectedBinding
import com.greenlightplanet.kazi.databinding.ActivityCollectionBreakdownBinding
import com.greenlightplanet.kazi.databinding.FeedbackTicketSuccessDialogBinding
import com.greenlightplanet.kazi.feedback.feedback_utils.Helper
import com.greenlightplanet.kazi.incentivenew.adapter.AdapterClickListener
import com.greenlightplanet.kazi.incentivenew.adapter.CollectionBreakdownAdapter
import com.greenlightplanet.kazi.incentivenew.common_utils.Constants
import com.greenlightplanet.kazi.incentivenew.model.collection_breakdown.Content
import com.greenlightplanet.kazi.incentivenew.viewmodel.AmountCollectedViewModel
import com.greenlightplanet.kazi.offers.extras.LastSaved
import com.greenlightplanet.kazi.offers.extras.OfferUtils
import com.greenlightplanet.kazi.utils.BaseActivity
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.NetworkResult
import com.greenlightplanet.kazi.utils.Util
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber
import java.lang.ref.WeakReference

@AndroidEntryPoint
class CollectionBreakdownActivity : BaseActivity(), AdapterClickListener {

    private lateinit var binding: ActivityCollectionBreakdownBinding
    private val viewModel by viewModels<AmountCollectedViewModel>()
    val adapter = CollectionBreakdownAdapter()
    var preference: GreenLightPreference? = null
    lateinit var progressdialog: Dialog
    lateinit var customDialog: Dialog
    var symbol = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCollectionBreakdownBinding.inflate(layoutInflater)
        setContentView(binding.root)
        progressdialog = Dialog(this@CollectionBreakdownActivity)
        customDialog = Dialog(this@CollectionBreakdownActivity)
        initToolbar()
        initOther()
        initializeRv()
        observer()
        updateSharedPref(false)
        invokeApi()
        binding.tvCommission.text = "Commission ($symbol)"
    }

    private fun initOther() {
        val loginResponse = preference?.getLoginResponseModel()
        loginResponse?.angazaId?.let {
            viewModel.angazaId = it
        }

    }

    private fun invokeApi() {
        if (Helper.isNetworkConnected()) {
            viewModel.invokeCollectionBreakdownData(viewModel.angazaId)
        } else {
            viewModel.getCollectionBreakdownCachedData(angazaId = viewModel.angazaId)
            updateSharedPref(false)
        }

    }

    private fun initToolbar() {
        preference = GreenLightPreference.getInstance(this)
        symbol = Util.getCurrencyCode(
            preference?.getLoginResponseModel()?.country!!.lowercase().capitalize()
        ) ?: "NA"
        Util.setToolbar(this, binding.toolbar, "")
        binding.tvAppbottomVersion.text = getString(R.string.app_version, BuildConfig.VERSION_NAME)
    }

    private fun initializeRv() {
        val layoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager
        adapter.attachListener(WeakReference(this))
        binding.recyclerView.adapter = adapter
        binding.recyclerView.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                this.setDrawable(resources.getDrawable(R.drawable.line_divider, theme))
            } else {
                this.setDrawable(resources.getDrawable(R.drawable.line_divider))
            }
        })
    }

    fun setNoDataVisibility(isVisible: Boolean) {
        if (isVisible) binding.tvNoData.visibility = View.VISIBLE
        else binding.tvNoData.visibility = View.GONE
    }

    private fun navigateToAmountCollectedScreen(
        angazaId: String,
        productName: String,
        commission: String
    ) {
        val intent = Intent(this, AmountCollectedActivity::class.java)
        intent.putExtra(
            Constants.ANGAZA_ID_INTENT,
            angazaId
        )
        intent.putExtra(
            Constants.PRODUCT_NAME_INTENT,
            productName
        )

        intent.putExtra(
            Constants.INCENTIVE_WEEK_INTENT,
            viewModel.incentiveWeek
        )

        intent.putExtra(
            Constants.COMMISSION_INTENT,
            commission
        )
        startActivity(intent)
    }


    private fun updateSharedPref(fromInternet: Boolean) {

        var data: LastSaved? = OfferUtils.loadIncentiveFromPref(this)

        if (data == null) {
            data = LastSaved()
            data.collectionBreakdown =
                "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
            OfferUtils.saveIncentiveToPref(this, data)
            binding.tvLastSaved.text = data.collectionBreakdown

        } else {

            if (fromInternet) {
                data.collectionBreakdown =
                    "${getString(R.string.last_saved_key)} ${OfferUtils.getCurrentLocalFormattedDate()}"
                OfferUtils.saveIncentiveToPref(this, data)
                binding.tvLastSaved.text = data.collectionBreakdown
            } else {
                binding.tvLastSaved.text = data.collectionBreakdown

            }
        }

    }

    override fun onItemClicked(data: Content) {
        if (data.angazaId != null && data.productGroup != null) {
            navigateToAmountCollectedScreen(
                angazaId = data.angazaId,
                productName = data.productGroup,
                commission = "${data.commission?:0}"
            )
        }

    }

    private fun observer() {
        with(viewModel) {
            //User Network Observer
            collectionBreakdownLiveData.observe(this@CollectionBreakdownActivity) { response ->
                when (response) {
                    is NetworkResult.Success -> {
                        response.data?.let { resp ->
                            Timber.d("Activity: CollectionBreakdown API Success -> $resp ")
                        }
                        hideProgressDialog()
                    }
                    is NetworkResult.DbSuccess -> {
                        response.isSuccess?.let {
                            hideProgressDialog()
                            if (it) {
                                if (response.data != null) {
                                    setNoDataVisibility(false)
                                    updateSharedPref(true)
                                    Timber.d("CollectionCommissionApiData: Room Cache Success : ${response.data}")
                                    lifecycleScope.launch(Dispatchers.IO) {
                                        getCollectionBreakdownCachedData(angazaId)
                                    }
                                }
                            } else {
                                setNoDataVisibility(true)
                                Timber.d("CollectionBreakdownApiData: Room Cache Failed")
                            }
                        }
                        hideProgressDialog()
                    }
                    is NetworkResult.Error -> {
                        response.message?.let {
                            Util.showToast(this@CollectionBreakdownActivity, it)
                            Timber.d("Api ERROR: $it")
                        }
                        setNoDataVisibility(true)
                        hideProgressDialog()
                    }
                    is NetworkResult.Exception -> {
                        hideProgressDialog()
                        response.message?.let {
                            Util.showToast(this@CollectionBreakdownActivity, it)
                            Timber.d("Api Exception: $it")
                        }
                        setNoDataVisibility(true)
                    }
                    is NetworkResult.Loading -> {
                        showProgress()
                    }
                }
            }

            singleCollectionBreakdownLiveData.observe(this@CollectionBreakdownActivity) {
                it?.let { data ->
                    if (viewModel.currentListForRv != data.collectionSummary) {
                        data.incentiveWeek?.let {

                            viewModel.incentiveWeek = it
                            binding.tvIncentiveWeek.text = "Incentive Week " + it
                        }
                        data.totalCommision?.let {
                            val commaSeparated = Util.getOneDecimal(it.toDouble())
                            viewModel.totalCommission = it.toString()
                            binding.tvTotalCommission.text =
                                "Total Commission ($symbol $commaSeparated)"
                        }
                        if (!data.collectionSummary.isNullOrEmpty()) {
                            adapter.setRvData(data.collectionSummary)
                            viewModel.currentListForRv.addAll(data.collectionSummary)
                            setNoDataVisibility(false)
                        } else setNoDataVisibility(true)

                    }
                }
            }

        }
    }


    private fun hideProgressDialog() {
        progressdialog.dismiss()
    }

    private fun showProgress() {
        progressdialog.setContentView(R.layout.progress_dialog)
        progressdialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        progressdialog.setCancelable(true)
        progressdialog.setCanceledOnTouchOutside(false);

        progressdialog.setOnCancelListener {
            onBackPressed()
        }
        try {
            if (!progressdialog.isShowing)
                progressdialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showCustomDialog(message: String) {
        val dialogView = FeedbackTicketSuccessDialogBinding.inflate(layoutInflater)
        customDialog.setContentView(dialogView.root)
        customDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialogView.tvMessage.text = message
        customDialog.setCancelable(true)
        customDialog.setCanceledOnTouchOutside(false);
        customDialog.show()
        customDialog.setOnCancelListener {
            onBackPressed()
        }

        try {
            if (!customDialog.isShowing)
                customDialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}