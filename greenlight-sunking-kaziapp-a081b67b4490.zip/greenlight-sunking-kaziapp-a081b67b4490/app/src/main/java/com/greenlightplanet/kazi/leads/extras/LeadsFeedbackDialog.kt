@file:Suppress("DEPRECATION")

package com.greenlightplanet.kazi.leads.extras


import android.annotation.SuppressLint
import android.app.Activity
import android.app.DatePickerDialog
import android.app.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.ArrayAdapter
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenlightplanet.kazi.R
import com.greenlightplanet.kazi.databinding.DialogIntentLeadsBinding
import com.greenlightplanet.kazi.databinding.DialogNewChoosePhonenoBinding
import com.greenlightplanet.kazi.leads.model.CallDetailRequestModel
import com.greenlightplanet.kazi.leads.model.LeadsCrossSalesLead
import com.greenlightplanet.kazi.leads.model.LeadsIntent
import com.greenlightplanet.kazi.leads.view.adapter.ChoosePhoneNoAdapter
import com.greenlightplanet.kazi.newtasks.extras.SendingCallStatus
import com.greenlightplanet.kazi.task.TaskUtils
import com.greenlightplanet.kazi.utils.GreenLightPreference
import com.greenlightplanet.kazi.utils.Util
import java.text.SimpleDateFormat
import java.util.*


class LeadsFeedbackDialog(val activity: Activity, val sendingCallStatus: SendingCallStatus) :
    LifecycleObserver {

    var dummyFeedbackIntentDialogCallback: DummyFeedbackIntentDialogCallback? = null
    var preference: GreenLightPreference? = GreenLightPreference.getInstance(activity)
    var phoneNumberDialog: Dialog? = null
    var datePicker: DatePickerDialog? = null
    var intentDialog: Dialog? = null
    var callDetailRequestModel: CallDetailRequestModel? = null
    var adapterPosition: Int? = null


    fun newShowPhoneNumberDialog(
        leadsCrossSalesLead: LeadsCrossSalesLead,
        position: Int,
        list: List<String?>,
        leadsIntents: List<LeadsIntent>?
    ) {

        var itemBinding: DialogNewChoosePhonenoBinding? = null
        adapterPosition = position
        callDetailRequestModel =
            CallDetailRequestModel(accountNumber = leadsCrossSalesLead.accountNumber.toInt())
        callDetailRequestModel.apply {
            this?.imei = Util.getImeiNumber(activity)
            this?.attempt = leadsCrossSalesLead.attempt?.plus(1) ?: 1
            this?.leadId = leadsCrossSalesLead.id
        }
        itemBinding = DialogNewChoosePhonenoBinding.inflate(LayoutInflater.from(activity))
        phoneNumberDialog = Dialog(activity, R.style.Theme_Dialog)
        phoneNumberDialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        phoneNumberDialog?.setCanceledOnTouchOutside(true)

        // phoneNumberDialog?.setContentView(R.layout.dialog_new_choose_phoneno)
        phoneNumberDialog?.setContentView(itemBinding.root)
        phoneNumberDialog?.setCancelable(false)
        //
        itemBinding?.ivInfo?.visibility = View.GONE
        itemBinding?.tvInfo?.visibility = View.GONE
        //
        itemBinding?.imCancel!!.setOnClickListener {
            phoneNumberDialog!!.dismiss()
        }

        val listAdapter = ChoosePhoneNoAdapter(activity, list.filterNotNull())
        listAdapter.choosePhoneNoAdapterCallback =
            object : ChoosePhoneNoAdapter.ChoosePhoneNoAdapterCallback {
                @SuppressLint("MissingPermission")
                override fun numberSelected(position: Int, number: String) {
                    phoneNumberDialog?.dismiss()

                    callDetailRequestModel.apply {
                        this?.contactedNumber = number
                    }

                    val callCustomer = Intent(Intent.ACTION_CALL)
                    callCustomer.data = Uri.parse("tel:$number")
                    activity.startActivity(callCustomer)
                    sendingCallStatus.setOnCall(true)
                    leadsIntents?.let {

                        newSpinnerIntentDialog(activity, it)
                        //showDatePicker(activity, 14, it)
                    }
                }
            }

        itemBinding.listview.layoutManager = LinearLayoutManager(activity)
        itemBinding?.listview?.adapter = listAdapter
        listAdapter.notifyDataSetChanged()

        phoneNumberDialog?.show()

    }

    private fun showDatePicker(context: Context, followUpDayLimit: Int?) {
        if (isAbleToCall()) {

            var maxDateDays: Int? = 0

            val listener = DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
                val calendar = Calendar.getInstance()
                calendar.set(year, month, dayOfMonth)
                val newVisitDateFormat = SimpleDateFormat("yyyy-MM-dd")
                val newVisitDate = newVisitDateFormat.format(calendar.time)

                callDetailRequestModel.apply {
                    this?.newVisitDate = newVisitDate
                }

                //todo add new logic here
                //newSpinnerIntentDialog(context, list)

                dummyFeedbackIntentDialogCallback?.dialogCompleted(
                    callDetailRequestModel!!,
                    adapterPosition!!
                )

            }

            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_MONTH, 1)

            datePicker = DatePickerDialog(
                context,
                R.style.DialogTheme2,
                listener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            )
            datePicker?.setCanceledOnTouchOutside(false)
            datePicker?.getButton(DatePickerDialog.BUTTON_NEGATIVE)?.visibility = View.INVISIBLE
            datePicker?.getButton(DatePickerDialog.BUTTON_NEUTRAL)?.visibility = View.INVISIBLE
            datePicker?.setButton(DatePickerDialog.BUTTON_NEGATIVE, "", datePicker)
            datePicker?.datePicker?.minDate = cal.timeInMillis


            val defaultLimit = 14

            if (followUpDayLimit != null) {
                maxDateDays = followUpDayLimit
                maxDateDays -= 1
            } else {
                maxDateDays = defaultLimit - 1
            }

            cal.add(Calendar.DATE, maxDateDays)
            datePicker?.datePicker?.maxDate = cal.timeInMillis
            datePicker?.show()

        }

    }

    fun newSpinnerIntentDialog(context: Context, list: List<LeadsIntent>?) {

        val feedbackList: MutableList<String> = mutableListOf()

        var itemBinding: DialogIntentLeadsBinding? = null
        intentDialog = Dialog(context, R.style.Theme_Dialog)
        intentDialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        intentDialog?.setCanceledOnTouchOutside(false)

        itemBinding = DialogIntentLeadsBinding.inflate(LayoutInflater.from(context))
        intentDialog?.setContentView(itemBinding.root)
        //intentDialog?.setContentView(R.layout.dialog_intent_leads)
        intentDialog?.setCancelable(false)

        if (list != null) {
            list.let {
                it.map { feedbackList.add(it.intent!!) }
            }
            feedbackList.add(0, context.getString(R.string.select_customer_feedback))
        } else {
            val leadsIntents = activity.resources?.getStringArray(R.array.leads_intents)
            feedbackList.addAll(leadsIntents!!.toMutableList())
        }


        val spinnerArrayAdapter = ArrayAdapter(
            context, R.layout.spinner_item,
            feedbackList
        )
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        itemBinding?.spinner?.adapter = spinnerArrayAdapter

        itemBinding?.spinner?.onItemSelectedListener = object : OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {
                val selectedItem = parent.getItemAtPosition(position).toString()
                if (selectedItem != context.getString(R.string.select_customer_feedback)) { // do your stuff
                    if (list != null) {
                        callDetailRequestModel.apply {
                            this?.intentId = list.find { it.intent.equals(selectedItem) }?.intentId
                        }
                    } else {
                        if (position == 0) {
                            callDetailRequestModel?.intentId = null
                        } else {
                            callDetailRequestModel.apply {
                                this?.intentId = position
                            }
                        }
                    }

                } else {
                    callDetailRequestModel?.intentId = null
                }
            } // to close the onItemSelected

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        itemBinding.btnSubmit.setOnClickListener {

            if (!sendingCallStatus.isOnCall()) {
                if (callDetailRequestModel!!.intentId != null) {

                    val otherReason = itemBinding?.etFeedback?.text.toString()

                    if (callDetailRequestModel!!.intentId != LEAD_INTENT.OTHER || !otherReason.isBlank()) {

                        callDetailRequestModel.apply {
                            this?.otherReason = otherReason
                        }

                        intentDialog?.dismiss()

                        if (callDetailRequestModel!!.intentId == LEAD_INTENT.DID_NOT_ANSWER) {

                            var date: Date? = null
                            date = Util.getCurrentDate()

                            if (date == null) {
                                date = Calendar.getInstance().time
                            }

                            callDetailRequestModel!!.callDuration = 0
                            callDetailRequestModel!!.calledTime =
                                TaskUtils.formateDatetoYYYYMMDDHHMMSS(date!!)
                            dummyFeedbackIntentDialogCallback?.dialogCompleted(
                                callDetailRequestModel!!,
                                adapterPosition!!
                            )
                        } else if (callDetailRequestModel!!.intentId == LEAD_INTENT.CANCLE) {
                            if (isAbleToCall()) {
                                dummyFeedbackIntentDialogCallback?.dialogCompleted(
                                    callDetailRequestModel!!,
                                    adapterPosition!!
                                )
                            }

                        } else {
                            val mm = preference!!.getLeadsFollowupLimit()
                            showDatePicker(activity, mm!!.toInt())
                        }

                        //todo add new logic here
                        //dummyFeedbackIntentDialogCallback?.dialogCompleted(callDetailRequestModel!!, adapterPosition!!)

                    } else {
                        Util.showToast("Please add your reason", context)
                    }
                } else {
                    Util.showToast("Please select a feedback", context)
                }
            } else {
                Util.showToast(context.getString(R.string.proceed_once_call_ended), context)
            }

        }

        intentDialog?.show()


    }


    //new added
    private fun isAbleToCall(): Boolean {

        val callLogModel = Util.checkCallLog(
//        val callLogModel = Util.checkCalledLog(
            phoneNumber = callDetailRequestModel?.contactedNumber!!,
            activity = activity
        )

        if (callLogModel.time.isNullOrBlank()) {
            Util.showToast("Unable to make a call", activity)
            return false
        } else {

            callLogModel.apply {

                this.time = convertCallLogTimestamp(this.time!!)

            }

            callDetailRequestModel.apply {
                this?.callDuration = callLogModel.lastCallTime ?: 0
                this?.calledTime = callLogModel.time!!
            }

            return true
        }
    }

    interface DummyFeedbackIntentDialogCallback {

        fun dialogCompleted(callDetailRequestModel: CallDetailRequestModel, adapterPosition: Int)

    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun onDestroy() {

        phoneNumberDialog?.let {
            dismissDialog(it)
        }

        datePicker?.let {
            dismissDialog(it)
        }


        intentDialog?.let {
            dismissDialog(it)
        }
    }

    private fun dismissDialog(dialog: Dialog) {
        if (dialog.isShowing) {
            dialog.dismiss()
        }
    }


    private fun convertCallLogTimestamp(value: String): String {

        val oldFormat = SimpleDateFormat("yyyy:MM:dd h:mm:ss a")
        val date = oldFormat.parse(value)
        val newFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        newFormat.timeZone = TimeZone.getTimeZone("UTC")

        return newFormat.format(date)
    }

}
